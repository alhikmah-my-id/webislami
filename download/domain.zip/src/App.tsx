import { Header } from "@/components/Header";
import { Hero } from "@/components/Hero";
import { DomainSearch } from "@/components/DomainSearch";
import { Services } from "@/components/Services";
import { Pricing } from "@/components/Pricing";
import { Footer } from "@/components/Footer";

export default function App() {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 antialiased">
      <Header />
      <main>
        <Hero />
        <DomainSearch />
        <Services />
        <Pricing />
      </main>
      <Footer />
    </div>
  );
}