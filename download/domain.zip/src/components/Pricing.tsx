import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const AFFILIATE_URL = "https://billing.exabytes.co.id/aff.php?aff=8303039";

const plans = [
  {
    name: "Starter",
    price: "Rp 15.000",
    period: "/bulan",
    desc: "Untuk blog & portofolio pribadi.",
    features: ["1 website", "10 GB SSD", "SSL gratis", "1 email domain"],
    highlight: false,
  },
  {
    name: "Bisnis",
    price: "Rp 49.000",
    period: "/bulan",
    desc: "Untuk UMKM & toko online.",
    features: ["25 website", "100 GB SSD", "SSL gratis", "25 email domain", "Backup harian"],
    highlight: true,
  },
  {
    name: "Cloud Pro",
    price: "Rp 149.000",
    period: "/bulan",
    desc: "Untuk agensi & aplikasi berat.",
    features: ["Unlimited website", "250 GB NVMe", "SSL gratis", "Unlimited email", "Dukungan prioritas"],
    highlight: false,
  },
];

export function Pricing() {
  return (
    <section id="harga" className="bg-slate-900 py-16 sm:py-20">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <div className="max-w-2xl">
          <span className="text-sm font-semibold uppercase tracking-wide text-teal-400">
            Harga Transparan
          </span>
          <h2 className="mt-2 font-serif text-3xl font-bold tracking-tight text-white sm:text-4xl">
            Pilih paket sesuai skala bisnismu
          </h2>
          <p className="mt-3 text-base text-slate-400">
            Tanpa biaya tersembunyi. Upgrade atau downgrade kapan saja.
          </p>
        </div>

        <div className="mt-10 grid gap-6 lg:grid-cols-3">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={
                plan.highlight
                  ? "relative rounded-2xl border border-teal-500/40 bg-gradient-to-b from-teal-900/40 to-slate-800 p-6 shadow-xl ring-1 ring-teal-500/30"
                  : "rounded-2xl border border-slate-700 bg-slate-800/60 p-6 shadow-sm"
              }
            >
              {plan.highlight && (
                <Badge className="absolute -top-3 left-6 bg-teal-500 text-white hover:bg-teal-500">
                  Paling Populer
                </Badge>
              )}
              <h3 className="text-lg font-bold text-white">{plan.name}</h3>
              <p className="mt-1 text-sm text-slate-400">{plan.desc}</p>
              <div className="mt-5 flex items-baseline gap-1">
                <span className="text-3xl font-bold text-white">{plan.price}</span>
                <span className="text-sm text-slate-400">{plan.period}</span>
              </div>
              <ul className="mt-6 space-y-3">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-sm text-slate-300">
                    <Check className="h-4 w-4 shrink-0 text-teal-400" />
                    {f}
                  </li>
                ))}
              </ul>
              <Button
                asChild
                className={
                  plan.highlight
                    ? "mt-6 w-full bg-teal-500 text-white hover:bg-teal-400"
                    : "mt-6 w-full bg-slate-700 text-white hover:bg-slate-600"
                }
              >
                <a href={AFFILIATE_URL}>Mulai Sekarang</a>
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}