import { Globe2 } from "lucide-react";

const AFFILIATE_URL = "https://billing.exabytes.co.id/aff.php?aff=8303039";

const columns = [
  {
    title: "Domain",
    links: ["Cari domain murah", "Beli domain", "Gratis domain", "WHOIS", "Transfer domain"],
  },
  {
    title: "Hosting",
    links: ["Web hosting", "Shared hosting", "VPS hosting", "Cloud hosting", "Email hosting"],
  },
  {
    title: "Solusi",
    links: ["Hosting WordPress", "Hosting WooCommerce", "Hosting agensi", "Minecraft hosting", "Self-hosted n8n"],
  },
  {
    title: "Perusahaan",
    links: ["Tentang kami", "Kontak", "Kebijakan privasi", "Syarat layanan", "Status"],
  },
];

export function Footer() {
  return (
    <footer id="bantuan" className="border-t border-slate-200 bg-white">
      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16">
        <div className="grid gap-10 lg:grid-cols-6">
          <div className="lg:col-span-2">
            <a href={AFFILIATE_URL} className="flex items-center gap-2">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-teal-500 to-emerald-600 text-white shadow-sm">
                <Globe2 className="h-5 w-5" />
              </span>
              <span className="text-lg font-bold tracking-tight text-slate-900">
                Mikro<span className="text-teal-600">dinet</span>
              </span>
            </a>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-slate-500">
              Mitra domain dan hosting terpercaya untuk bisnis Indonesia. Cepat,
              aman, dan didukung tim lokal.
            </p>
          </div>

          {columns.map((col) => (
            <div key={col.title}>
              <h4 className="text-sm font-semibold text-slate-900">{col.title}</h4>
              <ul className="mt-4 space-y-2.5">
                {col.links.map((link) => (
                  <li key={link}>
                    <a
                      href={AFFILIATE_URL}
                      className="text-sm text-slate-500 transition-colors hover:text-teal-600"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-slate-100 pt-6 sm:flex-row">
          <p className="text-xs text-slate-400">
            © {new Date().getFullYear()} Mikrodinet. Seluruh hak cipta dilindungi.
          </p>
          <div className="flex gap-4 text-xs text-slate-400">
            <a href={AFFILIATE_URL} className="transition-colors hover:text-teal-600">Privasi</a>
            <a href={AFFILIATE_URL} className="transition-colors hover:text-teal-600">Syarat</a>
            <a href={AFFILIATE_URL} className="transition-colors hover:text-teal-600">Status</a>
          </div>
        </div>
      </div>
    </footer>
  );
}