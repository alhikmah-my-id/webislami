import { ShieldCheck, Zap, Headphones } from "lucide-react";

const stats = [
  { value: "1,2 Jt+", label: "Domain aktif" },
  { value: "99,9%", label: "Uptime SLA" },
  { value: "24/7", label: "Dukungan live" },
];

export function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-teal-50 via-emerald-50/60 to-slate-50">
      <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-teal-200/40 blur-3xl" />
      <div className="pointer-events-none absolute -left-20 top-40 h-64 w-64 rounded-full bg-emerald-200/40 blur-3xl" />

      <div className="relative mx-auto max-w-6xl px-4 pb-10 pt-16 sm:px-6 sm:pt-20">
        <div className="grid items-center gap-10 lg:grid-cols-5">
          <div className="lg:col-span-3">
            <span className="inline-flex items-center gap-2 rounded-full border border-teal-200 bg-white/70 px-3 py-1 text-xs font-semibold text-teal-700 shadow-sm">
              <Zap className="h-3.5 w-3.5" />
              Domain & hosting untuk Indonesia
            </span>

            <h1 className="mt-5 font-serif text-4xl font-bold leading-tight tracking-tight text-slate-900 sm:text-5xl">
              Nama besar dimulai dari{" "}
              <span className="bg-gradient-to-r from-teal-600 to-emerald-600 bg-clip-text text-transparent">
                domain kecil
              </span>{" "}
              yang tepat.
            </h1>

            <p className="mt-5 max-w-xl text-base leading-relaxed text-slate-600 sm:text-lg">
              Cari, beli, dan kelola domain plus hosting dalam satu dasbor.
              Gratis WHOIS privacy, SSL, dan email forwarding di setiap pembelian.
            </p>

            <div className="mt-8 flex flex-wrap gap-6">
              {stats.map((s) => (
                <div key={s.label} className="flex flex-col">
                  <span className="text-2xl font-bold text-slate-900">{s.value}</span>
                  <span className="text-xs font-medium uppercase tracking-wide text-slate-500">
                    {s.label}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-2">
            <div className="rounded-2xl border border-teal-100 bg-white p-6 shadow-md">
              <h3 className="text-sm font-semibold uppercase tracking-wide text-teal-700">
                Kenapa Mikrodinet
              </h3>
              <ul className="mt-4 space-y-4">
                <li className="flex items-start gap-3">
                  <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-teal-50 text-teal-600">
                    <ShieldCheck className="h-4 w-4" />
                  </span>
                  <div>
                    <p className="text-sm font-semibold text-slate-900">SSL & WHOIS gratis</p>
                    <p className="text-xs text-slate-500">Perlindungan data tanpa biaya tambahan.</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600">
                    <Zap className="h-4 w-4" />
                  </span>
                  <div>
                    <p className="text-sm font-semibold text-slate-900">Aktivasi instan</p>
                    <p className="text-xs text-slate-500">Domain langsung aktif dalam hitungan menit.</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-amber-50 text-amber-600">
                    <Headphones className="h-4 w-4" />
                  </span>
                  <div>
                    <p className="text-sm font-semibold text-slate-900">Dukungan 24/7</p>
                    <p className="text-xs text-slate-500">Tim lokal siap bantu via chat & email.</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}