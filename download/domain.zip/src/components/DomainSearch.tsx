import { useMemo, useState } from "react";
import { Search, Check, X, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

const AFFILIATE_URL = "https://billing.exabytes.co.id/aff.php?aff=8303039";

type Result = {
  tld: string;
  price: string;
  available: boolean;
  popular?: boolean;
};

const tlds: Result[] = [
  { tld: ".com", price: "Rp 149.000", available: true, popular: true },
  { tld: ".id", price: "Rp 199.000", available: true },
  { tld: ".co.id", price: "Rp 249.000", available: true },
  { tld: ".net", price: "Rp 179.000", available: true },
  { tld: ".online", price: "Rp 99.000", available: false },
  { tld: ".store", price: "Rp 129.000", available: true },
];

export function DomainSearch() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Result[] | null>(null);
  const [loading, setLoading] = useState(false);

  const cleanName = useMemo(
    () => query.trim().toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, ""),
    [query]
  );

  function handleSearch() {
    if (!cleanName) return;
    setLoading(true);
    setResults(null);
    window.setTimeout(() => {
      setResults(tlds);
      setLoading(false);
    }, 700);
  }

  return (
    <section id="domain" className="relative z-10 mx-auto -mt-6 max-w-6xl px-4 sm:px-6">
      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-lg sm:p-6">
        <div className="flex flex-col gap-3 sm:flex-row">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
              placeholder="Cari nama domain impianmu..."
              className="h-12 pl-9 text-base"
            />
          </div>
          <Button
            onClick={handleSearch}
            disabled={!cleanName || loading}
            className="h-12 bg-teal-600 px-8 text-base font-semibold text-white shadow-sm hover:bg-teal-700"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Cari Domain"}
          </Button>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-slate-500">
          <span className="font-medium">Populer:</span>
          {[".com", ".id", ".co.id", ".net"].map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => setQuery(cleanName || "merekaku")}
              className="rounded-full border border-slate-200 px-2.5 py-1 font-medium text-slate-600 transition-colors hover:border-teal-300 hover:bg-teal-50 hover:text-teal-700"
            >
              {t}
            </button>
          ))}
        </div>

        {loading && (
          <div className="mt-6 space-y-2">
            {[0, 1, 2].map((i) => (
              <div key={i} className="h-14 animate-pulse rounded-xl bg-slate-100" />
            ))}
          </div>
        )}

        {results && (
          <div className="mt-6">
            <p className="mb-3 text-sm text-slate-500">
              Hasil untuk{" "}
              <span className="font-semibold text-slate-900">{cleanName}</span>
            </p>
            <div className="grid gap-2 sm:grid-cols-2">
              {results.map((r) => (
                <div
                  key={r.tld}
                  className="flex items-center justify-between rounded-xl border border-slate-200 bg-slate-50/60 px-4 py-3 transition-colors hover:border-teal-200 hover:bg-teal-50/50"
                >
                  <div className="flex items-center gap-3">
                    <span
                      className={
                        r.available
                          ? "flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-100 text-emerald-600"
                          : "flex h-8 w-8 items-center justify-center rounded-lg bg-rose-100 text-rose-500"
                      }
                    >
                      {r.available ? <Check className="h-4 w-4" /> : <X className="h-4 w-4" />}
                    </span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold text-slate-900">
                          {cleanName}
                          {r.tld}
                        </span>
                        {r.popular && (
                          <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">
                            Populer
                          </Badge>
                        )}
                      </div>
                      <span className="text-xs text-slate-500">
                        {r.available ? r.price + " / tahun" : "Sudah terdaftar"}
                      </span>
                    </div>
                  </div>
                  {r.available ? (
                    <Button
                      asChild
                      size="sm"
                      className="bg-teal-600 text-white hover:bg-teal-700"
                    >
                      <a href={AFFILIATE_URL}>Beli</a>
                    </Button>
                  ) : (
                    <Button asChild size="sm" variant="outline">
                      <a href={AFFILIATE_URL}>WHOIS</a>
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}