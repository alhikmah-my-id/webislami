import { useState } from "react";
import { Menu, X, Globe2 } from "lucide-react";
import { Button } from "@/components/ui/button";

const AFFILIATE_URL = "https://billing.exabytes.co.id/aff.php?aff=8303039";

const navLinks = [
  { label: "Domain", href: "#domain" },
  { label: "Hosting", href: "#hosting" },
  { label: "Harga", href: "#harga" },
  { label: "Bantuan", href: "#bantuan" },
];

export function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-teal-900/10 bg-white/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
        <a href={AFFILIATE_URL} className="flex items-center gap-2">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-teal-500 to-emerald-600 text-white shadow-sm">
            <Globe2 className="h-5 w-5" />
          </span>
          <span className="text-lg font-bold tracking-tight text-slate-900">
            Mikro<span className="text-teal-600">dinet</span>
          </span>
        </a>

        <nav className="hidden items-center gap-1 md:flex">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="rounded-lg px-3 py-2 text-sm font-medium text-slate-600 transition-colors hover:bg-teal-50 hover:text-teal-700"
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="hidden items-center gap-2 md:flex">
          <Button
            asChild
            variant="ghost"
            className="text-slate-700 hover:bg-teal-50 hover:text-teal-700"
          >
            <a href={AFFILIATE_URL}>Masuk</a>
          </Button>
          <Button asChild className="bg-teal-600 text-white shadow-sm hover:bg-teal-700">
            <a href={AFFILIATE_URL}>Daftar Gratis</a>
          </Button>
        </div>

        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="flex h-10 w-10 items-center justify-center rounded-lg text-slate-700 transition-colors hover:bg-teal-50 md:hidden"
          aria-label="Toggle menu"
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {open && (
        <div className="border-t border-slate-100 bg-white px-4 pb-4 pt-2 md:hidden">
          <nav className="flex flex-col gap-1">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-2 text-sm font-medium text-slate-700 transition-colors hover:bg-teal-50 hover:text-teal-700"
              >
                {link.label}
              </a>
            ))}
          </nav>
          <div className="mt-3 flex flex-col gap-2">
            <Button asChild variant="outline" className="w-full">
              <a href={AFFILIATE_URL}>Masuk</a>
            </Button>
            <Button asChild className="w-full bg-teal-600 text-white hover:bg-teal-700">
              <a href={AFFILIATE_URL}>Daftar Gratis</a>
            </Button>
          </div>
        </div>
      )}
    </header>
  );
}