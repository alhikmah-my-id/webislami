import {
  Server,
  Cloud,
  Mail,
  ShoppingCart,
  Gamepad2,
  Briefcase,
  Boxes,
  Bot,
  Globe,
  ShieldCheck,
  ArrowRightLeft,
  Lock,
} from "lucide-react";

const domainServices = [
  { icon: Globe, title: "Cari Domain Murah", desc: "Bandingkan harga ratusan ekstensi." },
  { icon: ArrowRightLeft, title: "Transfer Domain", desc: "Pindahkan domain tanpa downtime." },
  { icon: ShieldCheck, title: "WHOIS Privacy", desc: "Sembunyikan data pribadi Anda." },
  { icon: Lock, title: "SSL Gratis", desc: "Sertifikat HTTPS otomatis." },
];

const hostingServices = [
  { icon: Server, title: "Shared Hosting", desc: "Cocok untuk website pertama." },
  { icon: Cloud, title: "Cloud Hosting", desc: "Skalabel dengan resource terjamin." },
  { icon: Boxes, title: "VPS Hosting", desc: "Kontrol penuh server virtual." },
  { icon: Mail, title: "Email Hosting", desc: "Email profesional nama domain." },
  { icon: ShoppingCart, title: "Hosting WooCommerce", desc: "Toko online siap jualan." },
  { icon: Briefcase, title: "Hosting untuk Agensi", desc: "Kelola banyak klien sekaligus." },
  { icon: Gamepad2, title: "Minecraft Hosting", desc: "Server game low-latency." },
  { icon: Bot, title: "Self-hosted n8n", desc: "Otomasi workflow tanpa batas." },
];

export function Services() {
  return (
    <section id="hosting" className="mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-20">
      <div className="max-w-2xl">
        <span className="text-sm font-semibold uppercase tracking-wide text-teal-600">
          Layanan Kami
        </span>
        <h2 className="mt-2 font-serif text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">
          Semua yang kamu butuhkan untuk online
        </h2>
        <p className="mt-3 text-base text-slate-600">
          Dari membeli domain hingga menjalankan server, Mikrodinet menyediakan
          ekosistem lengkap dalam satu tempat.
        </p>
      </div>

      <div className="mt-10 grid gap-6 lg:grid-cols-3">
        <div className="rounded-2xl border border-teal-100 bg-gradient-to-b from-teal-50 to-white p-6 shadow-sm lg:col-span-1">
          <h3 className="text-lg font-bold text-slate-900">Domain</h3>
          <p className="mt-1 text-sm text-slate-500">Kelola identitas digitalmu.</p>
          <ul className="mt-5 space-y-4">
            {domainServices.map((s) => (
              <li key={s.title} className="flex items-start gap-3">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-white text-teal-600 shadow-sm">
                  <s.icon className="h-4 w-4" />
                </span>
                <div>
                  <p className="text-sm font-semibold text-slate-900">{s.title}</p>
                  <p className="text-xs text-slate-500">{s.desc}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>

        <div className="lg:col-span-2">
          <div className="grid gap-4 sm:grid-cols-2">
            {hostingServices.map((s) => (
              <div
                key={s.title}
                className="group rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition-all hover:-translate-y-0.5 hover:border-emerald-200 hover:shadow-md"
              >
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600 transition-colors group-hover:bg-emerald-600 group-hover:text-white">
                  <s.icon className="h-5 w-5" />
                </span>
                <p className="mt-4 text-sm font-semibold text-slate-900">{s.title}</p>
                <p className="mt-1 text-xs text-slate-500">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}