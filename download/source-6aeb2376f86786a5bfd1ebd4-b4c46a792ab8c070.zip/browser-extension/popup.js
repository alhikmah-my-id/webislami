const SITE = "https://alhikmah.my.id";
const MENU = [
  ["Beranda", SITE + "/"],
  ["Al-Qur'an", SITE + "/kategori/alquran-digital"],
  ["Jadwal Adzan", SITE + "/kategori/adhan"],
  ["Artikel", SITE + "/artikel"],
  ["Aplikasi", "https://app.alhikmah.my.id"],
  ["Android APK", "https://github.com/rumus-music/rumus-music.github.io/raw/refs/heads/main/alhikmah.apk"],
];
const PROJECTS = ["aplikasi","calligraphy","code","collor","eq","finder","img","kodepost","maps","qr","quran","seo","source","tools","vidio"];

function render(id, items) {
  const ul = document.getElementById(id);
  for (const [label, href] of items) {
    const li = document.createElement("li");
    const a = document.createElement("a");
    a.href = href; a.textContent = label; a.target = "_blank"; a.rel = "noopener";
    li.appendChild(a); ul.appendChild(li);
  }
}

render("menu", MENU);
render("projects", PROJECTS.map((p) => [p.charAt(0).toUpperCase() + p.slice(1), `https://awdevmyid.github.io/${p}/`]));

document.getElementById("search").addEventListener("submit", (e) => {
  e.preventDefault();
  const q = document.getElementById("q").value.trim();
  const url = q ? `https://www.google.com/search?q=${encodeURIComponent("site:alhikmah.my.id " + q)}` : SITE + "/";
  window.open(url, "_blank", "noopener");
});
