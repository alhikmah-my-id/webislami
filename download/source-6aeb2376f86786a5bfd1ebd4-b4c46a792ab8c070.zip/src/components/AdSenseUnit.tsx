import { useEffect, useRef } from "react";

declare global {
  interface Window {
    adsbygoogle?: unknown[];
  }
}

/** Unit iklan Google AdSense responsif (default: "Iklan Bawah Artikel"). */
export function AdSenseUnit({
  client = "ca-pub-6718454554209533",
  slot = "7205994686",
}: {
  client?: string;
  slot?: string;
}) {
  const ref = useRef<HTMLModElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el || el.getAttribute("data-adsbygoogle-status")) return;
    try {
      (window.adsbygoogle = window.adsbygoogle || []).push({});
    } catch {
      /* iklan diblokir atau belum siap */
    }
  }, []);

  return (
    <div id="iklan-bawah" className="iklan-bawah my-6">
      <p className="text-[10px] uppercase tracking-wider text-slate-400 text-center mb-1">Iklan</p>
      <ins
        ref={ref}
        className="adsbygoogle"
        style={{ display: "block" }}
        data-ad-client={client}
        data-ad-slot={slot}
        data-ad-format="auto"
        data-full-width-responsive="true"
      />
    </div>
  );
}
