import { MapPin, LocateFixed } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CITY_PRESETS, type GeoLocation } from "@/lib/islamic";

export function LocationPicker({ loc, setLoc, detect, status }: { loc: GeoLocation; setLoc: (l: GeoLocation) => void; detect: () => void; status: string }) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      <span className="flex items-center gap-1 text-xs text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-full px-3 py-1.5">
        <MapPin className="h-3.5 w-3.5" /> {loc.label}
      </span>
      <select
        value={CITY_PRESETS.find((c) => c.label === loc.label)?.label ?? ""}
        onChange={(e) => { const c = CITY_PRESETS.find((x) => x.label === e.target.value); if (c) setLoc(c); }}
        className="h-8 rounded-md border border-emerald-200 bg-white text-xs px-2"
      >
        <option value="" disabled>Pilih kota...</option>
        {CITY_PRESETS.map((c) => <option key={c.label} value={c.label}>{c.label}</option>)}
      </select>
      <Button size="sm" variant="outline" onClick={detect} className="h-8 border-emerald-300 text-emerald-700 text-xs">
        <LocateFixed className="h-3.5 w-3.5 mr-1" /> {status === "loading" ? "Mendeteksi..." : "Lokasi Saya"}
      </Button>
      {status === "error" && <span className="text-xs text-rose-600">Izin lokasi ditolak / tidak tersedia</span>}
    </div>
  );
}
