import { useCallback, useEffect, useState } from "react";

/* ------------------------------------------------------------------ */
/* Lokasi                                                              */
/* ------------------------------------------------------------------ */
export type GeoLocation = { lat: number; lng: number; label: string };
export const DEFAULT_LOCATION: GeoLocation = { lat: -6.9932, lng: 110.4203, label: "Semarang (default)" };

export const CITY_PRESETS: GeoLocation[] = [
  DEFAULT_LOCATION,
  { lat: -6.2088, lng: 106.8456, label: "Jakarta" },
  { lat: -7.2575, lng: 112.7521, label: "Surabaya" },
  { lat: -6.9175, lng: 107.6191, label: "Bandung" },
  { lat: -7.7956, lng: 110.3695, label: "Yogyakarta" },
  { lat: 3.5952, lng: 98.6722, label: "Medan" },
  { lat: -5.1477, lng: 119.4327, label: "Makassar" },
  { lat: 5.5483, lng: 95.3238, label: "Banda Aceh" },
  { lat: 21.4225, lng: 39.8262, label: "Makkah" },
];

const LOC_KEY = "alhikmah:location";

export function useGeoLocation() {
  const [loc, setLoc] = useState<GeoLocation>(() => {
    try {
      const saved = localStorage.getItem(LOC_KEY);
      if (saved) return JSON.parse(saved) as GeoLocation;
    } catch { /* abaikan */ }
    return DEFAULT_LOCATION;
  });
  const [status, setStatus] = useState<"idle" | "loading" | "error">("idle");

  const save = useCallback((l: GeoLocation) => {
    setLoc(l);
    try { localStorage.setItem(LOC_KEY, JSON.stringify(l)); } catch { /* abaikan */ }
  }, []);

  const detect = useCallback(() => {
    if (!navigator.geolocation) { setStatus("error"); return; }
    setStatus("loading");
    navigator.geolocation.getCurrentPosition(
      (p) => {
        save({ lat: p.coords.latitude, lng: p.coords.longitude, label: `GPS ${p.coords.latitude.toFixed(3)}, ${p.coords.longitude.toFixed(3)}` });
        setStatus("idle");
      },
      () => setStatus("error"),
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }, [save]);

  return { loc, setLoc: save, detect, status };
}

/* ------------------------------------------------------------------ */
/* Jadwal sholat (algoritma astronomis, parameter Kemenag RI)          */
/* ------------------------------------------------------------------ */
const rad = (d: number) => (d * Math.PI) / 180;
const deg = (r: number) => (r * 180) / Math.PI;
const fix = (a: number, b: number) => { const x = a - b * Math.floor(a / b); return x < 0 ? x + b : x; };

function sunPosition(jd: number) {
  const D = jd - 2451545.0;
  const g = fix(357.529 + 0.98560028 * D, 360);
  const q = fix(280.459 + 0.98564736 * D, 360);
  const L = fix(q + 1.915 * Math.sin(rad(g)) + 0.02 * Math.sin(rad(2 * g)), 360);
  const e = 23.439 - 0.00000036 * D;
  const RA = fix(deg(Math.atan2(Math.cos(rad(e)) * Math.sin(rad(L)), Math.cos(rad(L)))) / 15, 24);
  const eqt = q / 15 - RA;
  const decl = deg(Math.asin(Math.sin(rad(e)) * Math.sin(rad(L))));
  return { decl, eqt };
}

function julian(y: number, m: number, d: number) {
  if (m <= 2) { y -= 1; m += 12; }
  const A = Math.floor(y / 100);
  const B = 2 - A + Math.floor(A / 4);
  return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + B - 1524.5;
}

export type PrayerName = "Imsak" | "Subuh" | "Terbit" | "Dhuha" | "Dzuhur" | "Ashar" | "Maghrib" | "Isya";
export type PrayerTime = { name: PrayerName; date: Date; label: string };
export const WAJIB: PrayerName[] = ["Subuh", "Dzuhur", "Ashar", "Maghrib", "Isya"];

export function computePrayerTimes(date: Date, lat: number, lng: number): PrayerTime[] {
  const y = date.getFullYear(), m = date.getMonth() + 1, d = date.getDate();
  const tz = -new Date(y, m - 1, d, 12).getTimezoneOffset() / 60;
  const jd = julian(y, m, d) - lng / (15 * 24);
  const { decl, eqt } = sunPosition(jd + 0.5);
  const noon = 12 + tz - lng / 15 - eqt;

  const hourAngle = (alt: number) => {
    const v = (Math.sin(rad(alt)) - Math.sin(rad(lat)) * Math.sin(rad(decl))) / (Math.cos(rad(lat)) * Math.cos(rad(decl)));
    return deg(Math.acos(Math.max(-1, Math.min(1, v)))) / 15;
  };
  const asrAlt = deg(Math.atan(1 / (1 + Math.tan(rad(Math.abs(lat - decl))))));
  const ihtiyat = 2 / 60;

  const raw: [PrayerName, number][] = [
    ["Subuh", noon - hourAngle(-20) + ihtiyat],
    ["Terbit", noon - hourAngle(-0.833) - ihtiyat],
    ["Dhuha", noon - hourAngle(4.5) + ihtiyat],
    ["Dzuhur", noon + ihtiyat + 1 / 60],
    ["Ashar", noon + hourAngle(asrAlt) + ihtiyat],
    ["Maghrib", noon + hourAngle(-0.833) + ihtiyat],
    ["Isya", noon + hourAngle(-18) + ihtiyat],
  ];
  raw.unshift(["Imsak", raw[0][1] - 10 / 60]);

  return raw.map(([name, h]) => {
    const mins = Math.round(h * 60);
    const dt = new Date(y, m - 1, d, 0, mins, 0);
    return { name, date: dt, label: dt.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit", hour12: false }) };
  });
}

export function nextPrayer(now: Date, lat: number, lng: number) {
  const today = computePrayerTimes(now, lat, lng).filter((p) => WAJIB.includes(p.name));
  const upcoming = today.find((p) => p.date > now);
  if (upcoming) return upcoming;
  const tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
  return computePrayerTimes(tomorrow, lat, lng).find((p) => p.name === "Subuh")!;
}

export const formatCountdown = (ms: number) => {
  const s = Math.max(0, Math.floor(ms / 1000));
  return [Math.floor(s / 3600), Math.floor((s % 3600) / 60), s % 60].map((n) => String(n).padStart(2, "0")).join(" : ");
};

export const ADHAN_AUDIO_LIST = [
  { id: "azan1", name: "Adzan Makkah", url: "https://www.islamcan.com/audio/adhan/azan1.mp3" },
  { id: "azan2", name: "Adzan Madinah", url: "https://www.islamcan.com/audio/adhan/azan2.mp3" },
  { id: "azan3", name: "Adzan Al-Aqsa", url: "https://www.islamcan.com/audio/adhan/azan3.mp3" },
];

/* ------------------------------------------------------------------ */
/* Arah kiblat                                                         */
/* ------------------------------------------------------------------ */
export const KAABA = { lat: 21.4225, lng: 39.8262 };

export function qiblaBearing(lat: number, lng: number) {
  const φ = rad(lat), φk = rad(KAABA.lat), Δλ = rad(KAABA.lng - lng);
  const b = deg(Math.atan2(Math.sin(Δλ), Math.cos(φ) * Math.tan(φk) - Math.sin(φ) * Math.cos(Δλ)));
  return fix(b, 360);
}

export function distanceToKaaba(lat: number, lng: number) {
  const R = 6371;
  const dφ = rad(KAABA.lat - lat), dλ = rad(KAABA.lng - lng);
  const a = Math.sin(dφ / 2) ** 2 + Math.cos(rad(lat)) * Math.cos(rad(KAABA.lat)) * Math.sin(dλ / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

/* ------------------------------------------------------------------ */
/* Kalender Hijriyah                                                    */
/* ------------------------------------------------------------------ */
export const HIJRI_MONTHS = [
  "Muharram", "Safar", "Rabiul Awal", "Rabiul Akhir", "Jumadil Awal", "Jumadil Akhir",
  "Rajab", "Sya'ban", "Ramadhan", "Syawal", "Dzulqa'dah", "Dzulhijjah",
];
export const MASEHI_MONTHS = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
export const DAY_NAMES = ["Ahad", "Senin", "Selasa", "Rabu", "Kamis", "Jum'at", "Sabtu"];

let hijriFmt: Intl.DateTimeFormat | null = null;
export function toHijri(date: Date, offsetDays = 0) {
  const d = new Date(date.getFullYear(), date.getMonth(), date.getDate() + offsetDays, 12);
  try {
    hijriFmt ??= new Intl.DateTimeFormat("en-u-ca-islamic-umalqura", { day: "numeric", month: "numeric", year: "numeric" });
    const parts = hijriFmt.formatToParts(d);
    const get = (t: string) => Number(parts.find((p) => p.type === t)?.value.replace(/\D/g, ""));
    const day = get("day"), month = get("month"), year = get("year");
    if (day && month && year) return { day, month, year, monthName: HIJRI_MONTHS[month - 1] };
  } catch { /* fallback di bawah */ }
  // Fallback: algoritma Kuwaiti
  const jd = Math.floor(julian(d.getFullYear(), d.getMonth() + 1, d.getDate()) + 0.5);
  const l = jd - 1948440 + 10632;
  const n = Math.floor((l - 1) / 10631);
  const l2 = l - 10631 * n + 354;
  const j = Math.floor((10985 - l2) / 5316) * Math.floor((50 * l2) / 17719) + Math.floor(l2 / 5670) * Math.floor((43 * l2) / 15238);
  const l3 = l2 - Math.floor((30 - j) / 15) * Math.floor((17719 * j) / 50) - Math.floor(j / 16) * Math.floor((15238 * j) / 43) + 29;
  const month = Math.floor((24 * l3) / 709);
  const day = l3 - Math.floor((709 * month) / 24);
  const year = 30 * n + j - 30;
  return { day, month, year, monthName: HIJRI_MONTHS[month - 1] };
}

export const ISLAMIC_EVENTS: Record<string, string> = {
  "1-1": "Tahun Baru Hijriyah",
  "1-10": "Hari Asyura",
  "3-12": "Maulid Nabi Muhammad ﷺ",
  "7-27": "Isra' Mi'raj",
  "8-15": "Nisfu Sya'ban",
  "9-1": "Awal Ramadhan",
  "9-17": "Nuzulul Qur'an",
  "10-1": "Idul Fitri",
  "12-9": "Hari Arafah",
  "12-10": "Idul Adha",
};

/* ------------------------------------------------------------------ */
/* Arabic Pegon (Latin → Pegon Jawa/Sunda/Melayu)                      */
/* ------------------------------------------------------------------ */
const PEGON_DIGRAPH: [string, string][] = [
  ["ng", "ڠ"], ["ny", "ۑ"], ["kh", "خ"], ["sy", "ش"], ["dz", "ذ"], ["ts", "ث"],
  ["gh", "غ"], ["dh", "ڎ"], ["th", "ڟ"], ["ch", "چ"],
];
const PEGON_CONS: Record<string, string> = {
  b: "ب", c: "چ", d: "د", f: "ف", g: "ڮ", h: "ه", j: "ج", k: "ك", l: "ل", m: "م", n: "ن",
  p: "ڤ", q: "ق", r: "ر", s: "س", t: "ت", v: "ۏ", w: "و", x: "كس", y: "ي", z: "ز",
};
const PEGON_VOWEL_MID: Record<string, string> = { a: "ا", i: "ي", u: "و", e: "ي", é: "ي", o: "و" };
const PEGON_VOWEL_INIT: Record<string, string> = { a: "ا", i: "اي", u: "او", e: "اي", é: "اي", o: "او" };

export function latinToPegon(text: string) {
  return text.split(/(\s+)/).map((word) => {
    if (/^\s+$/.test(word)) return word;
    const w = word.toLowerCase();
    let out = "";
    let i = 0;
    while (i < w.length) {
      const two = w.slice(i, i + 2);
      const dg = PEGON_DIGRAPH.find(([k]) => k === two);
      if (dg) { out += dg[1]; i += 2; continue; }
      const ch = w[i];
      if (PEGON_VOWEL_MID[ch]) {
        // akhir kata huruf 'a' setelah konsonan di Pegon biasanya ditulis alif
        out += i === 0 ? PEGON_VOWEL_INIT[ch] : PEGON_VOWEL_MID[ch];
      } else if (PEGON_CONS[ch]) {
        out += PEGON_CONS[ch];
      } else {
        out += ch === "," ? "،" : ch === "?" ? "؟" : ch === ";" ? "؛" : ch;
      }
      i += 1;
    }
    return out;
  }).join("");
}

/* ------------------------------------------------------------------ */
/* Transliterasi Latin → Arab (Arabic keyboard phonetic)              */
/* ------------------------------------------------------------------ */
const ARABIC_PHONETIC: [string, string][] = [
  ["allah", "الله"], ["sy", "ش"], ["kh", "خ"], ["dz", "ذ"], ["ts", "ث"], ["gh", "غ"], ["th", "ط"],
  ["dh", "ض"], ["zh", "ظ"], ["sh", "ص"], ["aa", "آ"], ["ii", "ي"], ["uu", "و"], ["'", "ع"],
  ["a", "ا"], ["b", "ب"], ["t", "ت"], ["j", "ج"], ["h", "ح"], ["d", "د"], ["r", "ر"], ["z", "ز"],
  ["s", "س"], ["f", "ف"], ["q", "ق"], ["k", "ك"], ["l", "ل"], ["m", "م"], ["n", "ن"], ["w", "و"],
  ["y", "ي"], ["i", "ي"], ["u", "و"], ["e", "ي"], ["o", "و"], ["p", "ب"], ["v", "ف"], ["g", "ج"], ["c", "تش"], ["x", "كس"],
  ["0", "٠"], ["1", "١"], ["2", "٢"], ["3", "٣"], ["4", "٤"], ["5", "٥"], ["6", "٦"], ["7", "٧"], ["8", "٨"], ["9", "٩"],
  [",", "،"], ["?", "؟"], [";", "؛"],
];

export function latinToArabic(text: string) {
  const lower = text.toLowerCase();
  let out = "";
  let i = 0;
  outer: while (i < lower.length) {
    for (const [k, v] of ARABIC_PHONETIC) {
      if (lower.startsWith(k, i)) { out += v; i += k.length; continue outer; }
    }
    out += lower[i];
    i += 1;
  }
  return out;
}

/* ------------------------------------------------------------------ */
/* Al-Qur'an API (equran.id v2 & alquran.cloud)                         */
/* ------------------------------------------------------------------ */
export type SurahMeta = { nomor: number; nama: string; namaLatin: string; jumlahAyat: number; tempatTurun: string; arti: string; audioFull: Record<string, string> };
export type Ayat = { nomorAyat: number; teksArab: string; teksLatin: string; teksIndonesia: string; audio: Record<string, string> };
export type SurahDetail = SurahMeta & { deskripsi: string; ayat: Ayat[] };
export type TafsirDetail = SurahMeta & { tafsir: { ayat: number; teks: string }[] };

export const QARI_EQURAN: { id: string; name: string }[] = [
  { id: "05", name: "Misyari Rasyid Al-Afasi" },
  { id: "01", name: "Abdullah Al-Juhany" },
  { id: "02", name: "Abdul Muhsin Al-Qasim" },
  { id: "03", name: "Abdurrahman As-Sudais" },
  { id: "04", name: "Ibrahim Al-Dossari" },
  { id: "06", name: "Yasser Al-Dosari" },
];

const cache = new Map<string, Promise<unknown>>();
function getJSON<T>(url: string): Promise<T> {
  if (!cache.has(url)) {
    const p = fetch(url).then((r) => { if (!r.ok) throw new Error(`HTTP ${r.status}`); return r.json(); });
    p.catch(() => cache.delete(url));
    cache.set(url, p);
  }
  return cache.get(url) as Promise<T>;
}

export const fetchSurahList = () => getJSON<{ data: SurahMeta[] }>("https://equran.id/api/v2/surat").then((r) => r.data);
export const fetchSurah = (n: number) => getJSON<{ data: SurahDetail }>(`https://equran.id/api/v2/surat/${n}`).then((r) => r.data);
export const fetchTafsir = (n: number) => getJSON<{ data: TafsirDetail }>(`https://equran.id/api/v2/tafsir/${n}`).then((r) => r.data);

export type JuzAyah = { number: number; text: string; audio: string; numberInSurah: number; surah: { number: number; name: string; englishName: string } };
export const fetchJuz = (juz: number, edition = "ar.alafasy") =>
  getJSON<{ data: { ayahs: JuzAyah[] } }>(`https://api.alquran.cloud/v1/juz/${juz}/${edition}`).then((r) => r.data.ayahs);

export const QARI_JUZ = [
  { id: "ar.alafasy", name: "Mishary Rashid Alafasy" },
  { id: "ar.abdurrahmaansudais", name: "Abdurrahman As-Sudais" },
  { id: "ar.husary", name: "Mahmoud Khalil Al-Husary" },
  { id: "ar.minshawi", name: "Muhammad Siddiq Al-Minshawi" },
  { id: "ar.abdulbasitmurattal", name: "Abdul Basit (Murattal)" },
];

/** Hook generik untuk memuat data async dengan status loading/error. */
export function useAsync<T>(fn: () => Promise<T>, deps: unknown[]) {
  const [state, setState] = useState<{ data: T | null; loading: boolean; error: string | null }>({ data: null, loading: true, error: null });
  useEffect(() => {
    let alive = true;
    setState((s) => ({ ...s, loading: true, error: null }));
    fn().then(
      (data) => alive && setState({ data, loading: false, error: null }),
      (e: unknown) => alive && setState({ data: null, loading: false, error: e instanceof Error ? e.message : "Gagal memuat data" })
    );
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  return state;
}

/** Unduh file dari string / Blob. */
export function downloadFile(name: string, content: string | Blob, type = "text/plain;charset=utf-8") {
  const blob = typeof content === "string" ? new Blob([content], { type }) : content;
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/** Bunyi beep pendek via WebAudio (untuk timer/tasbih). */
export function beep(duration = 0.6, freq = 880) {
  try {
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new Ctx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.frequency.value = freq;
    osc.connect(gain);
    gain.connect(ctx.destination);
    gain.gain.setValueAtTime(0.3, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
    osc.start();
    osc.stop(ctx.currentTime + duration);
    osc.onended = () => ctx.close();
  } catch { /* abaikan */ }
}

/** Ucapkan teks Arab via Web Speech API (untuk Iqro'). */
export function speakArabic(text: string) {
  if (!("speechSynthesis" in window)) return false;
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = "ar-SA";
  u.rate = 0.7;
  const voice = window.speechSynthesis.getVoices().find((v) => v.lang.startsWith("ar"));
  if (voice) u.voice = voice;
  window.speechSynthesis.speak(u);
  return true;
}
