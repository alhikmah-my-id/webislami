import { useEffect, useState, type AnchorHTMLAttributes, type MouseEvent } from "react";

/** Peta kategori → slug URL. Setiap kategori memiliki halaman sendiri di /kategori/<slug>. */
export const CATEGORY_SLUGS: Record<string, string> = {
  Home: "",
  Aplikasi: "aplikasi",
  "Kisah Hikmah": "kisah-hikmah",
  "Kitab/Buku": "kitab-buku",
  Pendidikan: "pendidikan",
  Sholawat: "sholawat",
  Khutbah: "khutbah",
  "Kisah dan Tokoh": "kisah-dan-tokoh",
  Informasi: "informasi",
  Vidio: "vidio",
  Adhan: "adhan",
  "Iqro'": "iqro",
  "Tafsir Web": "tafsir-web",
  Perpustakaan: "perpustakaan",
  "Arabic Pegon": "arabic-pegon",
  "Arabic Calligraphy": "arabic-calligraphy",
  Kalender: "kalender",
  Timer: "timer",
  "Murotal 30 Juz": "murotal-30-juz",
  "Alqur'an Digital": "alquran-digital",
  WebOffice: "weboffice",
  "CorelDRAW Arabic": "coreldraw-arabic",
};

export const SLUG_TO_CATEGORY: Record<string, string> = Object.fromEntries(
  Object.entries(CATEGORY_SLUGS).map(([k, v]) => [v, k])
);

/** Menu navigasi cepat atas → halaman tujuan. */
export const NAV_TARGETS: Record<string, string> = {
  ADZKAR: "/kategori/sholawat#adzkar",
  "AL-QUR'AN": "/kategori/alquran-digital",
  TAKLIM: "/kategori/pendidikan",
  HADIST: "/kategori/kitab-buku#hadist",
  SHOLAWAT: "/kategori/sholawat",
  ARABIC: "/kategori/arabic-pegon",
};

export const LEGAL_PAGES: Record<string, string> = {
  "About Us": "about-us",
  "Kontak Kami": "kontak-kami",
  "Privacy Policy": "privacy-policy",
  Disclaimers: "disclaimers",
  Sitemap: "sitemap",
  "Terms & Conditions": "terms-and-conditions",
};

export const categoryPath = (cat: string) => (cat === "Home" ? "/" : `/kategori/${CATEGORY_SLUGS[cat] ?? ""}`);
export const articlePath = (slug: string) => `/artikel/${slug}`;

export type Route =
  | { name: "home" }
  | { name: "category"; category: string }
  | { name: "article"; slug: string }
  | { name: "legal"; page: string }
  | { name: "notfound" };

export function parseRoute(pathname: string): Route {
  const parts = pathname.replace(/\/+$/, "").split("/").filter(Boolean).map(decodeURIComponent);
  if (parts.length === 0) return { name: "home" };
  if (parts[0] === "kategori" && parts[1] && SLUG_TO_CATEGORY[parts[1]] !== undefined)
    return { name: "category", category: SLUG_TO_CATEGORY[parts[1]] };
  if (parts[0] === "artikel" && parts[1]) return { name: "article", slug: parts[1] };
  if (parts[0] === "halaman" && parts[1] && Object.values(LEGAL_PAGES).includes(parts[1]))
    return { name: "legal", page: parts[1] };
  return { name: "notfound" };
}

const EVENT = "alhikmah:navigate";

export function navigate(to: string) {
  const [path, hash] = to.split("#");
  if (path + (hash ? `#${hash}` : "") !== window.location.pathname + window.location.hash) {
    window.history.pushState({}, "", to);
  }
  window.dispatchEvent(new Event(EVENT));
  if (hash) {
    setTimeout(() => document.getElementById(hash)?.scrollIntoView({ behavior: "smooth", block: "start" }), 120);
  } else {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
}

export function useRoute(): Route {
  const [route, setRoute] = useState<Route>(() => parseRoute(window.location.pathname));
  useEffect(() => {
    const update = () => setRoute(parseRoute(window.location.pathname));
    window.addEventListener("popstate", update);
    window.addEventListener(EVENT, update);
    return () => {
      window.removeEventListener("popstate", update);
      window.removeEventListener(EVENT, update);
    };
  }, []);
  return route;
}

export function Link({ to, onClick, ...rest }: AnchorHTMLAttributes<HTMLAnchorElement> & { to: string }) {
  const handle = (e: MouseEvent<HTMLAnchorElement>) => {
    onClick?.(e);
    if (e.defaultPrevented || e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
    e.preventDefault();
    navigate(to);
  };
  return <a href={to} onClick={handle} {...rest} />;
}
