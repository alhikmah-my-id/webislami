import { useState } from "react";
import { Check, Copy, Download, Languages, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { downloadFile, latinToArabic, latinToPegon } from "@/lib/islamic";
import { ArabicKeyboard } from "@/components/Widgets";
import { PageHeader, inputClass, CategoryArticles } from "./_shared";

const SAMPLES = ["bismillah", "sugeng enjing", "ngaji kitab kuning", "pondok pesantren", "kanjeng nabi"];

export default function ArabicPegonPage() {
  const [tab, setTab] = useState<"pegon" | "arab" | "keyboard">("pegon");
  const [input, setInput] = useState("");
  const [copied, setCopied] = useState(false);
  const output = tab === "pegon" ? latinToPegon(input) : latinToArabic(input);

  const copy = () => {
    navigator.clipboard?.writeText(output).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className="space-y-5">
      <PageHeader icon={Languages} title="Arabic Pegon & Keyboard Arab" desc="Konversi teks Latin ke huruf Pegon (Jawa/Sunda/Melayu) dan Arab, plus keyboard virtual" />
      <div className="flex gap-1 bg-slate-100 p-1 rounded-xl w-fit">
        {([["pegon", "Latin → Pegon"], ["arab", "Latin → Arab"], ["keyboard", "Keyboard Arab"]] as const).map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} className={cn("px-4 py-1.5 rounded-lg text-sm font-medium", tab === k ? "bg-emerald-600 text-white shadow-sm" : "text-slate-600")}>{l}</button>
        ))}
      </div>

      {tab === "keyboard" ? <ArabicKeyboard /> : (
        <Card className="border-emerald-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">{tab === "pegon" ? "Konverter Arabic Pegon" : "Transliterasi Fonetik Latin → Arab"}</CardTitle>
            <p className="text-xs text-slate-500">
              {tab === "pegon"
                ? "Mendukung huruf khas Pegon: ڠ (ng), ۑ (ny), چ (c), ڤ (p), ڮ (g), ڎ (dh), ڟ (th)."
                : "Gunakan sy, kh, dz, ts, gh, sh, dh, th, zh dan ' (ain). Contoh: \"assalamu'alaikum\"."}
            </p>
          </CardHeader>
          <CardContent className="space-y-3">
            <textarea value={input} onChange={(e) => setInput(e.target.value)} rows={4} placeholder="Ketik teks latin di sini..." className={inputClass} />
            <div className="flex flex-wrap gap-1.5">
              {SAMPLES.map((s) => (
                <button key={s} onClick={() => setInput(s)} className="text-xs px-2.5 py-1 rounded-full border border-emerald-200 text-emerald-700 hover:bg-emerald-50">{s}</button>
              ))}
            </div>
            <div className="rounded-xl border border-emerald-200 bg-emerald-50/40 p-4 min-h-24 text-3xl leading-loose text-right font-serif" dir="rtl">{output || "…"}</div>
            <div className="flex flex-wrap gap-2">
              <Button size="sm" onClick={copy} disabled={!output} className="bg-emerald-600 hover:bg-emerald-700 text-white">
                {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />} {copied ? "Tersalin" : "Salin"}
              </Button>
              <Button size="sm" variant="outline" disabled={!output} onClick={() => downloadFile(`${tab}-alhikmah.txt`, output)} className="border-emerald-300 text-emerald-700"><Download className="h-4 w-4 mr-1" /> Unduh .txt</Button>
              <Button size="sm" variant="outline" onClick={() => setInput("")} className="border-slate-300 text-slate-600"><Trash2 className="h-4 w-4 mr-1" /> Hapus</Button>
            </div>
          </CardContent>
        </Card>
      )}
      <CategoryArticles category="Arabic Pegon" />
    </div>
  );
}
