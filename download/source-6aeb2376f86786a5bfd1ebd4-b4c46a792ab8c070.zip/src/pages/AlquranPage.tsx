import { useEffect, useMemo, useRef, useState } from "react";
import { BookMarked, Pause, Play, Search, SkipBack, SkipForward, Volume2, Copy, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { fetchSurah, fetchSurahList, QARI_EQURAN, useAsync } from "@/lib/islamic";
import { PageHeader, Spinner, ErrorBox, inputClass, CategoryArticles } from "./_shared";

const LAST_READ = "alhikmah:last-read";

export default function AlquranPage() {
  const [retry, setRetry] = useState(0);
  const list = useAsync(fetchSurahList, [retry]);
  const [surah, setSurah] = useState<number>(() => Number(localStorage.getItem(LAST_READ)) || 1);
  const [query, setQuery] = useState("");
  const [qari, setQari] = useState("05");
  const [showLatin, setShowLatin] = useState(true);
  const [showTrans, setShowTrans] = useState(true);
  const [fontSize, setFontSize] = useState(28);
  const detail = useAsync(() => fetchSurah(surah), [surah, retry]);

  const [playing, setPlaying] = useState<number | null>(null); // nomor ayat, 0 = full surah
  const [continuous, setContinuous] = useState(true);
  const [copied, setCopied] = useState<number | null>(null);
  const audioRef = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    localStorage.setItem(LAST_READ, String(surah));
    setPlaying(null);
    audioRef.current?.pause();
  }, [surah]);

  const filtered = useMemo(() => {
    const q = query.toLowerCase().trim();
    return (list.data ?? []).filter((s) => !q || s.namaLatin.toLowerCase().includes(q) || s.arti.toLowerCase().includes(q) || String(s.nomor) === q);
  }, [list.data, query]);

  const play = (ayat: number | 0) => {
    const audio = audioRef.current;
    const d = detail.data;
    if (!audio || !d) return;
    const src = ayat === 0 ? d.audioFull[qari] : d.ayat.find((a) => a.nomorAyat === ayat)?.audio[qari];
    if (!src) return;
    if (playing === ayat && !audio.paused) { audio.pause(); setPlaying(null); return; }
    audio.src = src;
    audio.play().catch(() => setPlaying(null));
    setPlaying(ayat);
    if (ayat > 0) document.getElementById(`ayat-${ayat}`)?.scrollIntoView({ behavior: "smooth", block: "center" });
  };

  const onEnded = () => {
    const d = detail.data;
    if (!d || playing === null) return;
    if (playing > 0 && continuous && playing < d.jumlahAyat) play(playing + 1);
    else if (continuous && surah < 114 && (playing === 0 || playing === d.jumlahAyat)) setSurah(surah + 1);
    else setPlaying(null);
  };

  const copyAyat = (n: number, text: string) => {
    navigator.clipboard?.writeText(text).catch(() => {});
    setCopied(n);
    setTimeout(() => setCopied(null), 1500);
  };

  return (
    <div className="space-y-5">
      <PageHeader icon={BookMarked} title="Al-Qur'an Digital" desc="114 surah lengkap · teks Arab, latin, terjemah Indonesia & audio per ayat" />
      <audio ref={audioRef} onEnded={onEnded} preload="none" />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-emerald-200 md:col-span-1">
          <CardHeader className="pb-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-emerald-400" />
              <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Cari surah..." className={cn(inputClass, "pl-8")} />
            </div>
          </CardHeader>
          <CardContent className="p-2 max-h-[32rem] overflow-y-auto">
            {list.loading && <Spinner />}
            {list.error && <ErrorBox message={list.error} onRetry={() => setRetry((r) => r + 1)} />}
            {filtered.map((s) => (
              <button
                key={s.nomor}
                onClick={() => setSurah(s.nomor)}
                className={cn("w-full flex items-center gap-3 rounded-lg px-2.5 py-2 text-left transition-colors", surah === s.nomor ? "bg-emerald-600 text-white" : "hover:bg-emerald-50")}
              >
                <span className={cn("h-8 w-8 rounded-lg flex items-center justify-center text-xs font-bold shrink-0", surah === s.nomor ? "bg-white/20" : "bg-emerald-100 text-emerald-700")}>{s.nomor}</span>
                <span className="flex-1 min-w-0">
                  <span className="block text-sm font-semibold truncate">{s.namaLatin}</span>
                  <span className={cn("block text-xs truncate", surah === s.nomor ? "text-emerald-100" : "text-slate-500")}>{s.arti} · {s.jumlahAyat} ayat</span>
                </span>
                <span className="font-serif text-lg" dir="rtl">{s.nama}</span>
              </button>
            ))}
          </CardContent>
        </Card>

        <div className="md:col-span-2 space-y-4">
          {detail.loading && <Spinner label="Memuat surah..." />}
          {detail.error && <ErrorBox message={detail.error} onRetry={() => setRetry((r) => r + 1)} />}
          {detail.data && (
            <>
              <Card className="border-0 bg-gradient-to-br from-emerald-700 to-teal-800 text-white">
                <CardContent className="p-5 space-y-3">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="text-xs text-emerald-200">Surah ke-{detail.data.nomor} · {detail.data.tempatTurun}</p>
                      <h3 className="text-2xl font-bold font-serif">{detail.data.namaLatin}</h3>
                      <p className="text-sm text-emerald-100">{detail.data.arti} · {detail.data.jumlahAyat} ayat</p>
                    </div>
                    <p className="text-4xl font-serif" dir="rtl">{detail.data.nama}</p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <Button size="sm" variant="outline" disabled={surah <= 1} onClick={() => setSurah(surah - 1)} className="bg-transparent border-emerald-300 text-white hover:bg-emerald-600"><SkipBack className="h-4 w-4" /></Button>
                    <Button size="sm" onClick={() => play(0)} className="bg-white text-emerald-800 hover:bg-emerald-50">
                      {playing === 0 ? <Pause className="h-4 w-4 mr-1" /> : <Play className="h-4 w-4 mr-1" />} Putar Full Surah
                    </Button>
                    <Button size="sm" variant="outline" disabled={surah >= 114} onClick={() => setSurah(surah + 1)} className="bg-transparent border-emerald-300 text-white hover:bg-emerald-600"><SkipForward className="h-4 w-4" /></Button>
                    <select value={qari} onChange={(e) => setQari(e.target.value)} className="h-9 rounded-md bg-emerald-900/60 border border-emerald-500 text-sm px-2">
                      {QARI_EQURAN.map((q) => <option key={q.id} value={q.id}>{q.name}</option>)}
                    </select>
                  </div>
                  <div className="flex flex-wrap gap-3 text-xs">
                    <label className="flex items-center gap-1.5"><input type="checkbox" checked={continuous} onChange={(e) => setContinuous(e.target.checked)} /> Putar berlanjut</label>
                    <label className="flex items-center gap-1.5"><input type="checkbox" checked={showLatin} onChange={(e) => setShowLatin(e.target.checked)} /> Latin</label>
                    <label className="flex items-center gap-1.5"><input type="checkbox" checked={showTrans} onChange={(e) => setShowTrans(e.target.checked)} /> Terjemah</label>
                    <label className="flex items-center gap-1.5">Ukuran Arab <input type="range" min={20} max={44} value={fontSize} onChange={(e) => setFontSize(Number(e.target.value))} /></label>
                  </div>
                </CardContent>
              </Card>

              {surah !== 1 && surah !== 9 && (
                <p className="text-center text-3xl font-serif text-emerald-900 py-2" dir="rtl">بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ</p>
              )}

              <div className="space-y-3">
                {detail.data.ayat.map((a) => (
                  <Card key={a.nomorAyat} id={`ayat-${a.nomorAyat}`} className={cn("border transition-all", playing === a.nomorAyat ? "border-emerald-400 bg-emerald-50 shadow-md" : "border-slate-200")}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between gap-2">
                        <Badge className="bg-emerald-100 text-emerald-800 hover:bg-emerald-100">{detail.data!.nomor}:{a.nomorAyat}</Badge>
                        <div className="flex gap-1">
                          <Button size="icon" variant="ghost" className="h-8 w-8 text-emerald-700" onClick={() => play(a.nomorAyat)} title="Putar ayat">
                            {playing === a.nomorAyat ? <Volume2 className="h-4 w-4 animate-pulse" /> : <Play className="h-4 w-4" />}
                          </Button>
                          <Button size="icon" variant="ghost" className="h-8 w-8 text-emerald-700" title="Salin ayat"
                            onClick={() => copyAyat(a.nomorAyat, `${a.teksArab}\n\n${a.teksIndonesia} (QS. ${detail.data!.namaLatin}: ${a.nomorAyat})`)}>
                            {copied === a.nomorAyat ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                          </Button>
                        </div>
                      </div>
                      <p className="text-right leading-[2.2] text-slate-900 mt-3 font-serif" dir="rtl" style={{ fontSize }}>{a.teksArab}</p>
                      {showLatin && <p className="text-sm italic text-emerald-700 mt-2">{a.teksLatin}</p>}
                      {showTrans && <p className="text-sm text-slate-600 mt-1">{a.teksIndonesia}</p>}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </>
          )}
        </div>
      </div>
      <CategoryArticles category="Alqur'an Digital" />
    </div>
  );
}

