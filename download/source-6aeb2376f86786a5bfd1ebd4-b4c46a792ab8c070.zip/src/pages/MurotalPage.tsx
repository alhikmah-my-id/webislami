import { useEffect, useRef, useState } from "react";
import { Headphones, Pause, Play, SkipBack, SkipForward, Repeat } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { fetchJuz, QARI_JUZ, useAsync } from "@/lib/islamic";
import { PageHeader, Spinner, ErrorBox, CategoryArticles } from "./_shared";

const JUZ_START = [
  "Al-Fatihah 1", "Al-Baqarah 142", "Al-Baqarah 253", "Ali 'Imran 93", "An-Nisa' 24", "An-Nisa' 148",
  "Al-Ma'idah 83", "Al-An'am 111", "Al-A'raf 88", "Al-Anfal 41", "At-Taubah 93", "Hud 6",
  "Yusuf 53", "Al-Hijr 1", "Al-Isra' 1", "Al-Kahf 75", "Al-Anbiya' 1", "Al-Mu'minun 1",
  "Al-Furqan 21", "An-Naml 56", "Al-'Ankabut 46", "Al-Ahzab 31", "Yasin 28", "Az-Zumar 32",
  "Fussilat 47", "Al-Ahqaf 1", "Az-Zariyat 31", "Al-Mujadilah 1", "Al-Mulk 1", "An-Naba' 1",
];

export default function MurotalPage() {
  const [juz, setJuz] = useState(30);
  const [qari, setQari] = useState(QARI_JUZ[0].id);
  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [autoNextJuz, setAutoNextJuz] = useState(true);
  const [retry, setRetry] = useState(0);
  const audioRef = useRef<HTMLAudioElement>(null);
  const resumeRef = useRef(false);

  const data = useAsync(() => fetchJuz(juz, qari), [juz, qari, retry]);
  const ayahs = data.data ?? [];
  const current = ayahs[index];

  useEffect(() => { setIndex(0); }, [juz, qari]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio || !current) return;
    audio.src = current.audio;
    if (playing || resumeRef.current) {
      resumeRef.current = false;
      audio.play().then(() => setPlaying(true)).catch(() => setPlaying(false));
    }
    document.getElementById(`juz-ayah-${index}`)?.scrollIntoView({ behavior: "smooth", block: "nearest" });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [current?.audio]);

  const toggle = () => {
    const audio = audioRef.current;
    if (!audio || !current) return;
    if (playing) { audio.pause(); setPlaying(false); }
    else { if (!audio.src) audio.src = current.audio; audio.play().then(() => setPlaying(true)).catch(() => setPlaying(false)); }
  };

  const onEnded = () => {
    if (index < ayahs.length - 1) setIndex(index + 1);
    else if (autoNextJuz && juz < 30) { resumeRef.current = true; setJuz(juz + 1); }
    else setPlaying(false);
  };

  return (
    <div className="space-y-5">
      <PageHeader icon={Headphones} title="Murotal 30 Juz" desc="Dengarkan tilawah Al-Qur'an per juz secara berurutan, ayat demi ayat" />
      <audio ref={audioRef} onEnded={onEnded} preload="none" />

      <Card className="border-emerald-200">
        <CardContent className="p-4">
          <p className="text-xs font-medium text-slate-600 mb-2">Pilih Juz</p>
          <div className="grid grid-cols-6 sm:grid-cols-10 gap-1.5">
            {Array.from({ length: 30 }, (_, i) => i + 1).map((j) => (
              <button key={j} onClick={() => { setJuz(j); setPlaying(false); audioRef.current?.pause(); }} title={`Mulai: ${JUZ_START[j - 1]}`}
                className={cn("h-10 rounded-lg text-sm font-semibold border transition-all", juz === j ? "bg-emerald-600 text-white border-emerald-600 shadow" : "bg-white border-emerald-200 text-emerald-800 hover:bg-emerald-50")}>
                {j}
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="border-0 bg-gradient-to-br from-emerald-800 to-teal-900 text-white sticky top-14 z-10 shadow-lg">
        <CardContent className="p-4 space-y-3">
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div>
              <p className="text-xs text-emerald-200">Juz {juz} · dimulai {JUZ_START[juz - 1]}</p>
              <p className="font-bold">{current ? `${current.surah.englishName} : ${current.numberInSurah}` : "—"}</p>
            </div>
            <select value={qari} onChange={(e) => setQari(e.target.value)} className="h-9 rounded-md bg-emerald-900/60 border border-emerald-500 text-sm px-2">
              {QARI_JUZ.map((q) => <option key={q.id} value={q.id}>{q.name}</option>)}
            </select>
          </div>
          <div className="flex items-center gap-2">
            <Button size="icon" variant="outline" onClick={() => setIndex(Math.max(0, index - 1))} className="bg-transparent border-emerald-400 text-white hover:bg-emerald-700"><SkipBack className="h-4 w-4" /></Button>
            <Button size="icon" onClick={toggle} disabled={!current} className="h-12 w-12 rounded-full bg-white text-emerald-800 hover:bg-emerald-50">
              {playing ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5 ml-0.5" />}
            </Button>
            <Button size="icon" variant="outline" onClick={() => setIndex(Math.min(ayahs.length - 1, index + 1))} className="bg-transparent border-emerald-400 text-white hover:bg-emerald-700"><SkipForward className="h-4 w-4" /></Button>
            <button onClick={() => setAutoNextJuz((a) => !a)} className={cn("ml-auto text-xs px-3 py-1.5 rounded-full border flex items-center gap-1", autoNextJuz ? "bg-emerald-500 border-emerald-400" : "border-emerald-400")}>
              <Repeat className="h-3 w-3" /> Lanjut juz berikutnya {autoNextJuz ? "ON" : "OFF"}
            </button>
          </div>
          <div className="h-1.5 rounded-full bg-emerald-950 overflow-hidden">
            <div className="h-full bg-emerald-300 transition-all" style={{ width: ayahs.length ? `${((index + 1) / ayahs.length) * 100}%` : 0 }} />
          </div>
          <p className="text-xs text-emerald-200">Ayat {ayahs.length ? index + 1 : 0} dari {ayahs.length} dalam juz ini</p>
        </CardContent>
      </Card>

      {data.loading && <Spinner label={`Memuat Juz ${juz}...`} />}
      {data.error && <ErrorBox message={data.error} onRetry={() => setRetry((r) => r + 1)} />}

      <div className="space-y-2 max-h-[40rem] overflow-y-auto pr-1">
        {ayahs.map((a, i) => {
          const showHeader = i === 0 || a.numberInSurah === 1;
          return (
            <div key={a.number}>
              {showHeader && (
                <div className="my-3 rounded-xl bg-emerald-50 border border-emerald-200 p-3 flex items-center justify-between">
                  <Badge className="bg-emerald-600 hover:bg-emerald-600">Surah {a.surah.number}</Badge>
                  <span className="font-semibold text-emerald-900">{a.surah.englishName}</span>
                  <span className="font-serif text-xl" dir="rtl">{a.surah.name}</span>
                </div>
              )}
              <button id={`juz-ayah-${i}`} onClick={() => { if (i === index) toggle(); else { resumeRef.current = true; setIndex(i); } }}
                className={cn("w-full text-right rounded-lg border p-3 transition-all", i === index ? "border-emerald-400 bg-emerald-50 shadow-sm" : "border-slate-100 bg-white hover:bg-emerald-50/50")}>
                <span className="flex items-start justify-between gap-3">
                  <Badge variant="secondary" className="bg-emerald-100 text-emerald-700 shrink-0">{a.surah.number}:{a.numberInSurah}</Badge>
                  <span className="text-2xl leading-loose font-serif text-slate-900" dir="rtl">{a.text}</span>
                </span>
              </button>
            </div>
          );
        })}
      </div>
      <CategoryArticles category="Murotal 30 Juz" />
    </div>
  );
}
