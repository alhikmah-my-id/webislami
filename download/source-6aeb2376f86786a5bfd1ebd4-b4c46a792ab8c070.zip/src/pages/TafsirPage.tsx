import { useMemo, useState } from "react";
import { BookText, Search } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { fetchSurah, fetchSurahList, fetchTafsir, useAsync } from "@/lib/islamic";
import { PageHeader, Spinner, ErrorBox, inputClass, CategoryArticles } from "./_shared";

export default function TafsirPage() {
  const [surah, setSurah] = useState(1);
  const [ayatFilter, setAyatFilter] = useState("");
  const [retry, setRetry] = useState(0);
  const list = useAsync(fetchSurahList, [retry]);
  const tafsir = useAsync(() => Promise.all([fetchTafsir(surah), fetchSurah(surah)]), [surah, retry]);

  const items = useMemo(() => {
    if (!tafsir.data) return [];
    const [t, s] = tafsir.data;
    const n = Number(ayatFilter);
    return t.tafsir
      .filter((x) => !n || x.ayat === n)
      .map((x) => ({ ...x, ayat: x.ayat, arab: s.ayat.find((a) => a.nomorAyat === x.ayat)?.teksArab ?? "", arti: s.ayat.find((a) => a.nomorAyat === x.ayat)?.teksIndonesia ?? "" }));
  }, [tafsir.data, ayatFilter]);

  const meta = list.data?.find((s) => s.nomor === surah);

  return (
    <div className="space-y-5">
      <PageHeader icon={BookText} title="Tafsir Web" desc="Tafsir Al-Qur'an per ayat (Kemenag RI) untuk 114 surah" />
      <Card className="border-emerald-200">
        <CardContent className="p-4 grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="sm:col-span-2">
            <label className="text-xs font-medium text-slate-600 mb-1 block">Surah</label>
            <select value={surah} onChange={(e) => { setSurah(Number(e.target.value)); setAyatFilter(""); }} className={inputClass}>
              {(list.data ?? [{ nomor: 1, namaLatin: "Al-Fatihah", jumlahAyat: 7 }]).map((s) => (
                <option key={s.nomor} value={s.nomor}>{s.nomor}. {s.namaLatin} ({s.jumlahAyat} ayat)</option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-slate-600 mb-1 block">Lompat ke ayat</label>
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-emerald-400" />
              <input type="number" min={1} max={meta?.jumlahAyat} value={ayatFilter} onChange={(e) => setAyatFilter(e.target.value)} placeholder="Semua ayat" className={`${inputClass} pl-8`} />
            </div>
          </div>
        </CardContent>
      </Card>

      {tafsir.loading && <Spinner label="Memuat tafsir..." />}
      {tafsir.error && <ErrorBox message={tafsir.error} onRetry={() => setRetry((r) => r + 1)} />}
      {tafsir.data && (
        <Card className="border-0 bg-gradient-to-br from-emerald-700 to-teal-800 text-white">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold font-serif">{tafsir.data[0].namaLatin} — {tafsir.data[0].arti}</h3>
              <span className="text-3xl font-serif" dir="rtl">{tafsir.data[0].nama}</span>
            </div>
            <p className="text-sm text-emerald-100 mt-2" dangerouslySetInnerHTML={{ __html: tafsir.data[1].deskripsi }} />
          </CardContent>
        </Card>
      )}

      <div className="space-y-3">
        {items.map((x) => (
          <Card key={x.ayat} className="border-slate-200">
            <CardContent className="p-4 space-y-2">
              <Badge className="bg-emerald-100 text-emerald-800 hover:bg-emerald-100">Ayat {x.ayat}</Badge>
              <p className="text-right text-2xl leading-loose font-serif" dir="rtl">{x.arab}</p>
              <p className="text-sm italic text-emerald-800">"{x.arti}"</p>
              <div className="rounded-lg bg-slate-50 border border-slate-100 p-3 text-sm text-slate-700 leading-relaxed whitespace-pre-line">{x.teks}</div>
            </CardContent>
          </Card>
        ))}
      </div>
      <CategoryArticles category="Tafsir Web" />
    </div>
  );
}
