import type { ComponentType, ReactNode } from "react";
import { BookOpen, Calendar, Timer, TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link, articlePath } from "@/lib/router";
import { ARTICLES, type Article } from "@/data/articles";

export function PageHeader({ icon: Icon, title, desc, children }: { icon: ComponentType<{ className?: string }>; title: string; desc: string; children?: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3 flex-wrap">
      <div className="flex items-center gap-3">
        <div className="h-11 w-11 rounded-xl bg-gradient-to-br from-emerald-600 to-teal-600 flex items-center justify-center shadow-sm shrink-0">
          <Icon className="h-5 w-5 text-white" />
        </div>
        <div>
          <h2 className="text-xl font-bold font-serif text-slate-900">{title}</h2>
          <p className="text-xs text-slate-500">{desc}</p>
        </div>
      </div>
      {children}
    </div>
  );
}

export function ArticleLinkCard({ article }: { article: Article }) {
  return (
    <Link to={articlePath(article.slug)} className="block">
      <Card className="cursor-pointer border-slate-200 hover:border-emerald-300 hover:shadow-md transition-all group">
        <CardContent className="p-5">
          <div className="flex items-start gap-4">
            <div className="hidden sm:flex h-16 w-16 rounded-xl bg-gradient-to-br from-emerald-100 to-teal-100 items-center justify-center shrink-0">
              <BookOpen className="h-7 w-7 text-emerald-600" />
            </div>
            <div className="flex-1 min-w-0">
              <Badge variant="secondary" className="bg-emerald-50 text-emerald-700 text-xs mb-2">{article.category}</Badge>
              <h4 className="font-bold text-slate-900 group-hover:text-emerald-700 transition-colors leading-snug">{article.title}</h4>
              <p className="text-sm text-slate-500 mt-1.5 line-clamp-2">{article.excerpt}</p>
              <div className="flex flex-wrap items-center gap-3 mt-3 text-xs text-slate-400">
                <span className="flex items-center gap-1"><Calendar className="h-3 w-3" /> {article.date}</span>
                <span className="flex items-center gap-1"><Timer className="h-3 w-3" /> {article.readTime}</span>
                <span className="flex items-center gap-1"><TrendingUp className="h-3 w-3" /> {article.views.toLocaleString("id-ID")}</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}

export function CategoryArticles({ category, title = "Artikel Terkait" }: { category: string; title?: string }) {
  const items = ARTICLES.filter((a) => a.category === category);
  const list = items.length ? items : ARTICLES.slice(0, 3);
  return (
    <section className="space-y-3">
      <h3 className="text-lg font-bold font-serif text-slate-900">{items.length ? title : "Artikel Pilihan"}</h3>
      {list.map((a) => <ArticleLinkCard key={a.id} article={a} />)}
    </section>
  );
}

export const inputClass =
  "w-full rounded-lg border border-emerald-200 bg-white p-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400";

export function Spinner({ label = "Memuat..." }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-2 py-10 text-sm text-emerald-700">
      <span className="h-4 w-4 rounded-full border-2 border-emerald-500 border-t-transparent animate-spin" /> {label}
    </div>
  );
}

export function ErrorBox({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 flex items-center justify-between gap-3">
      <span>Gagal memuat data: {message}. Periksa koneksi internet.</span>
      {onRetry && <button onClick={onRetry} className="underline font-medium">Coba lagi</button>}
    </div>
  );
}
