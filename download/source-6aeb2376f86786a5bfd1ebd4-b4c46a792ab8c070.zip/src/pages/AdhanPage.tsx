import { useEffect, useMemo, useRef, useState } from "react";
import { Bell, BellOff, Pause, Play, Volume2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { ADHAN_AUDIO_LIST, computePrayerTimes, formatCountdown, nextPrayer, toHijri, useGeoLocation, WAJIB, DAY_NAMES, MASEHI_MONTHS } from "@/lib/islamic";
import { LocationPicker } from "@/components/LocationPicker";
import { QiblaCompass } from "@/components/QiblaCompass";
import { PageHeader, CategoryArticles } from "./_shared";

const ALARM_KEY = "alhikmah:adhan-alarm";

export default function AdhanPage() {
  const geo = useGeoLocation();
  const { loc } = geo;
  const [now, setNow] = useState(new Date());
  const [alarm, setAlarm] = useState(() => localStorage.getItem(ALARM_KEY) === "1");
  const [audioId, setAudioId] = useState(ADHAN_AUDIO_LIST[0].id);
  const [playing, setPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);
  const firedRef = useRef<string>("");

  useEffect(() => { const t = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(t); }, []);

  const dayKey = now.toDateString();
  const times = useMemo(() => computePrayerTimes(new Date(dayKey), loc.lat, loc.lng), [dayKey, loc.lat, loc.lng]);
  const next = nextPrayer(now, loc.lat, loc.lng);
  const weekly = useMemo(() => Array.from({ length: 7 }, (_, i) => {
    const d = new Date(new Date(dayKey).getTime() + i * 86400000);
    return { d, t: computePrayerTimes(d, loc.lat, loc.lng) };
  }), [dayKey, loc.lat, loc.lng]);
  const hijri = toHijri(now);

  const playAdhan = () => {
    const audio = audioRef.current;
    if (!audio) return;
    if (playing) { audio.pause(); audio.currentTime = 0; setPlaying(false); return; }
    audio.src = ADHAN_AUDIO_LIST.find((a) => a.id === audioId)!.url;
    audio.play().then(() => setPlaying(true)).catch(() => setPlaying(false));
  };

  // Alarm: putar adzan & kirim notifikasi saat masuk waktu sholat wajib
  useEffect(() => {
    if (!alarm) return;
    const hit = times.find((p) => WAJIB.includes(p.name) && now.getTime() >= p.date.getTime() && now.getTime() - p.date.getTime() < 60000);
    if (hit && firedRef.current !== hit.name + dayKey) {
      firedRef.current = hit.name + dayKey;
      if (!playing) playAdhan();
      if ("Notification" in window && Notification.permission === "granted") {
        new Notification(`Waktu ${hit.name} telah tiba`, { body: `${hit.label} · ${loc.label}`, icon: "https://alhikmah.my.id/images.jpg" });
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [now, alarm]);

  const toggleAlarm = async () => {
    const v = !alarm;
    if (v && "Notification" in window && Notification.permission === "default") {
      try { await Notification.requestPermission(); } catch { /* abaikan */ }
    }
    setAlarm(v);
    localStorage.setItem(ALARM_KEY, v ? "1" : "0");
  };

  return (
    <div className="space-y-5">
      <PageHeader icon={Bell} title="Adhan & Jadwal Sholat" desc="Jadwal sholat akurat sesuai lokasi (parameter Kemenag RI), alarm adzan & kompas kiblat" />
      <LocationPicker {...geo} />
      <audio ref={audioRef} onEnded={() => setPlaying(false)} preload="none" />

      <Card className="border-0 bg-gradient-to-br from-emerald-700 via-teal-700 to-emerald-900 text-white overflow-hidden">
        <CardContent className="p-6 text-center relative">
          <p className="text-xs text-emerald-200">{DAY_NAMES[now.getDay()]}, {now.getDate()} {MASEHI_MONTHS[now.getMonth()]} {now.getFullYear()} · {hijri.day} {hijri.monthName} {hijri.year} H</p>
          <p className="text-4xl font-bold tabular-nums mt-1">{now.toLocaleTimeString("id-ID", { hour12: false })}</p>
          <p className="text-xs uppercase tracking-widest text-emerald-200 mt-4">Menuju {next.name} ({next.label})</p>
          <p className="text-3xl font-extrabold tabular-nums tracking-wider">{formatCountdown(next.date.getTime() - now.getTime())}</p>
          <div className="flex flex-wrap justify-center gap-2 mt-4">
            <Button onClick={toggleAlarm} className={cn("text-sm", alarm ? "bg-white text-emerald-800 hover:bg-emerald-50" : "bg-emerald-600 hover:bg-emerald-500 text-white")}>
              {alarm ? <Bell className="h-4 w-4 mr-1.5" /> : <BellOff className="h-4 w-4 mr-1.5" />} Alarm Adzan {alarm ? "AKTIF" : "NONAKTIF"}
            </Button>
            <select value={audioId} onChange={(e) => setAudioId(e.target.value)} className="h-9 rounded-md bg-emerald-900/60 border border-emerald-500 text-sm px-2">
              {ADHAN_AUDIO_LIST.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
            </select>
            <Button onClick={playAdhan} variant="outline" className="bg-transparent border-emerald-300 text-white hover:bg-emerald-600">
              {playing ? <Pause className="h-4 w-4 mr-1.5" /> : <Play className="h-4 w-4 mr-1.5" />} {playing ? "Stop" : "Dengarkan Adzan"}
            </Button>
          </div>
          {alarm && <p className="text-[11px] text-emerald-200 mt-2">Biarkan halaman ini terbuka agar adzan otomatis berkumandang saat waktu sholat tiba.</p>}
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {times.map((t) => (
          <div key={t.name} className={cn("rounded-xl border p-3 text-center", t.name === next.name ? "bg-emerald-600 text-white border-emerald-600 shadow" : WAJIB.includes(t.name) ? "bg-white border-emerald-200" : "bg-slate-50 border-slate-200")}>
            <p className="text-xs font-medium opacity-80">{t.name}</p>
            <p className="text-xl font-bold tabular-nums">{t.label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <QiblaCompass loc={loc} />
        <Card className="border-slate-200">
          <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><Volume2 className="h-4 w-4 text-emerald-600" /> Jadwal 7 Hari</CardTitle></CardHeader>
          <CardContent className="overflow-x-auto">
            <table className="w-full text-xs tabular-nums">
              <thead><tr className="text-emerald-700">{["Tgl", ...WAJIB].map((h) => <th key={h} className="py-1 text-left">{h}</th>)}</tr></thead>
              <tbody>
                {weekly.map(({ d, t }) => (
                  <tr key={d.toISOString()} className="border-t border-slate-100">
                    <td className="py-1.5 font-medium">{d.getDate()}/{d.getMonth() + 1}</td>
                    {WAJIB.map((w) => <td key={w}>{t.find((x) => x.name === w)?.label}</td>)}
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      </div>
      <CategoryArticles category="Adhan" />
    </div>
  );
}
