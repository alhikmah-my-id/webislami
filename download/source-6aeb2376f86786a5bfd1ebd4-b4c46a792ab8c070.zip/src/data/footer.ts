export type FooterLink = { label: string; title: string; url: string };

/** Menu navigasi footer, ditampilkan di semua halaman. */
export const FOOTER_LINKS: FooterLink[] = [
  { label: "Aplikasi", title: "aplikasi", url: "https://app.alhikmah.my.id" },
  { label: "Website", title: "Patner Blogger", url: "/" },
  { label: "About Us", title: "About Us Blogger", url: "https://www.alhikmah.my.id/p/about-us.html" },
  { label: "Kontak Us", title: "Contact Us Blogger", url: "https://www.alhikmah.my.id/p/kontak.html" },
  { label: "Privacy", title: "privacy Blogger", url: "https://www.alhikmah.my.id/p/privacy.html" },
  { label: "Disclaimers", title: "disclamer Blogger", url: "https://www.alhikmah.my.id/p/disclaimers.html" },
  { label: "Terms Conditions", title: "terms conditions Blogger", url: "https://www.alhikmah.my.id/p/terms-conditions-generator.html" },
  { label: "License", title: "license Blogger", url: "https://www.alhikmah.my.id/p/license.html" },
  { label: "Sitemap", title: "Sitemap", url: "https://www.alhikmah.my.id/p/sitemap.html" },
  { label: "DOWNLOAD VERSI HP ANDROID", title: "Android", url: "https://github.com/rumus-music/rumus-music.github.io/raw/refs/heads/main/alhikmah.apk" },
  { label: "Disclaimer", title: "Disclaimer", url: "https://www.alhikmah.eu.org/p/disclaimer.html" },
  { label: "Privacy Policy", title: "Privacy Policy", url: "https://www.alhikmah.eu.org/p/privacy-policy.html" },
  { label: "Contact Personal", title: "Contact Personal", url: "https://www.alhikmah.eu.org/p/logo.html" },
  { label: "About Us (EU)", title: "About Us", url: "https://www.alhikmah.eu.org/p/about-us.html" },
];
