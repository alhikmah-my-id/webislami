(function () {
  'use strict';

  var CATEGORIES = [
    'Home', 'Aplikasi', 'Kisah Hikmah', 'Kitab/Buku', 'Pendidikan',
    'Sholawat', 'Khutbah', 'Kisah dan Tokoh', 'Informasi', 'Vidio',
    'Adhan', "Iqro'", 'Tafsir Web', 'Perpustakaan', 'Arabic Pegon',
    'Arabic Calligraphy', 'Kalender', 'Timer', 'Murotal 30 Juz',
    "Alqur'an Digital", 'WebOffice', 'CorelDRAW Arabic'
  ];

  var QUICK_MENU = ['ADZKAR', "AL-QUR'AN", 'TAKLIM', 'HADIST', 'SHOLAWAT', 'ARABIC'];

  var ARTICLES = [
    { id: 1, slug: 'adab-menuntut-ilmu', title: 'Adab Menuntut Ilmu dalam Islam', category: 'Pendidikan', excerpt: 'Panduan lengkap adab penuntut ilmu berdasarkan Al-Qur\'an dan Sunnah.', author: 'ADMIN ALHIKMAH', date: '12 Jan 2025', views: 1840 },
    { id: 2, slug: 'kisah-nabi-yusuf', title: 'Kisah Nabi Yusuf: Pelajaran Kesabaran', category: 'Kisah dan Tokoh', excerpt: 'Meneladani kesabaran Nabi Yusuf AS dalam menghadapi ujian hidup.', author: 'ADMIN ALHIKMAH', date: '11 Jan 2025', views: 2310 },
    { id: 3, slug: 'keutamaan-sholawat', title: 'Keutamaan Sholawat Nabi', category: 'Sholawat', excerpt: 'Fadhilah membaca sholawat dan waktu terbaik mengamalkannya.', author: 'ADMIN ALHIKMAH', date: '10 Jan 2025', views: 1520 },
    { id: 4, slug: 'tafsir-al-fatihah', title: 'Tafsir Surah Al-Fatihah', category: 'Tafsir Web', excerpt: 'Kajian mendalam makna setiap ayat dalam Surah Al-Fatihah.', author: 'ADMIN ALHIKMAH', date: '09 Jan 2025', views: 3120 },
    { id: 5, slug: 'arabic-pegon-dasar', title: 'Belajar Arabic Pegon dari Dasar', category: 'Arabic Pegon', excerpt: 'Metode praktis menulis dan membaca tulisan Arab Pegon.', author: 'ADMIN ALHIKMAH', date: '08 Jan 2025', views: 980 },
    { id: 6, slug: 'khutbah-jumat-singkat', title: 'Khutbah Jumat Singkat Pilihan', category: 'Khutbah', excerpt: 'Kumpulan khutbah Jumat ringkas untuk khatib pemula.', author: 'ADMIN ALHIKMAH', date: '07 Jan 2025', views: 1240 }
  ];

  function el(tag, className, html) {
    var node = document.createElement(tag);
    if (className) node.className = className;
    if (html !== undefined) node.innerHTML = html;
    return node;
  }

  function renderHeader() {
    var root = document.getElementById('header-root');
    if (!root) return;
    var nav = QUICK_MENU.map(function (m) {
      return '<a href="#" class="nav-link">' + m + '</a>';
    }).join('');
    root.innerHTML =
      '<header class="site-header">' +
        '<div class="header-inner">' +
          '<a href="/" class="brand">' +
            '<img src="https://alhikmah.my.id/images.jpg" alt="ALHIKMAH" class="brand-logo" />' +
            '<span class="brand-name">ALHIKMAH</span>' +
          '</a>' +
          '<nav class="quick-nav">' + nav + '</nav>' +
        '</div>' +
      '</header>';
  }

  function renderArticles() {
    var root = document.getElementById('articles-root');
    if (!root) return;
    var html = '<h2 class="section-title">Artikel Terbaru</h2><div class="article-grid">';
    ARTICLES.forEach(function (a) {
      html +=
        '<article class="article-card">' +
          '<span class="chip">' + a.category + '</span>' +
          '<h3><a href="/views/article.html?slug=' + a.slug + '">' + a.title + '</a></h3>' +
          '<p>' + a.excerpt + '</p>' +
          '<div class="meta"><span>' + a.date + '</span><span>' + a.views + ' views</span></div>' +
        '</article>';
    });
    html += '</div>';
    root.innerHTML = html;
  }

  function renderSidebar() {
    var root = document.getElementById('sidebar-root');
    if (!root) return;
    var popular = ARTICLES.slice(0, 4).map(function (a) {
      return '<li><a href="/views/article.html?slug=' + a.slug + '">' + a.title + '</a></li>';
    }).join('');
    var archive = ['Januari 2025', 'Desember 2024', 'November 2024']
      .map(function (m) { return '<li><a href="#">' + m + '</a></li>'; }).join('');
    root.innerHTML =
      '<div class="widget"><h4>News Update</h4><p>Ikuti kabar terbaru seputar dunia Islam.</p></div>' +
      '<div class="widget"><h4>Popular Post</h4><ul>' + popular + '</ul></div>' +
      '<div class="widget"><h4>Archive</h4><ul>' + archive + '</ul></div>' +
      '<div class="widget ad-widget"><div data-tappx-slot>Memuat iklan...</div></div>';
  }

  function renderFooter() {
    var root = document.getElementById('footer-root');
    if (!root) return;
    root.innerHTML =
      '<footer class="site-footer">' +
        '<div class="footer-links">' +
          '<a href="#">About Us</a><a href="#">Kontak Kami</a><a href="#">Privacy Policy</a>' +
          '<a href="#">Disclaimers</a><a href="#">Sitemap</a><a href="#">Terms &amp; Conditions</a>' +
        '</div>' +
        '<p class="copyright">Design By ADMIN ALHIKMAH | Copyright 2025 All Application International Islamic (ALHIKMAH.MY.ID - Portal Islam terpercaya untuk pendidikan, sejarah, sosial, dan budaya).</p>' +
      '</footer>';
  }

  document.addEventListener('DOMContentLoaded', function () {
    renderHeader();
    renderArticles();
    renderSidebar();
    renderFooter();
    if (window.AlHikmahAds) window.AlHikmahAds.rotateAll();
  });

  window.AlHikmahData = { CATEGORIES: CATEGORIES, ARTICLES: ARTICLES };
})();