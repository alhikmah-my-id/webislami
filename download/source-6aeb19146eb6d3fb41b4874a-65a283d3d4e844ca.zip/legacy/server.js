const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const path = require("path");
const fs = require("fs");
const apiRoutes = require("./routes/api");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.json({ limit: "2mb" }));
app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname, "public")));

app.get("/ads.txt", (_req, res) => {
  res.type("text/plain");
  res.sendFile(path.join(__dirname, "public", "ads.txt"));
});

app.get("/app-ads.txt", (_req, res) => {
  res.type("text/plain");
  res.sendFile(path.join(__dirname, "public", "app-ads.txt"));
});

app.get("/manifest.json", (_req, res) => {
  res.type("application/manifest+json");
  res.sendFile(path.join(__dirname, "public", "manifest.json"));
});

app.get("/robots.txt", (_req, res) => {
  res.type("text/plain");
  res.send(
    "User-agent: *\nAllow: /\nSitemap: https://alhikmah.my.id/sitemap.xml\n"
  );
});

app.get("/sitemap.xml", (_req, res) => {
  res.type("application/xml");
  const urls = [
    "https://alhikmah.my.id/",
    "https://alhikmah.my.id/artikel",
    "https://alhikmah.my.id/kategori",
    "https://alhikmah.my.id/tools",
  ];
  const body = urls
    .map((u) => `  <url><loc>${u}</loc><changefreq>daily</changefreq></url>`)
    .join("\n");
  res.send(
    `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${body}\n</urlset>`
  );
});

app.use("/api", apiRoutes);

app.get("*", (_req, res) => {
  const index = path.join(__dirname, "public", "index.html");
  if (fs.existsSync(index)) return res.sendFile(index);
  res.status(404).json({ ok: false, message: "Not Found" });
});

app.listen(PORT, () => {
  console.log(`[ALHIKMAH] Server running on http://localhost:${PORT}`);
});

module.exports = app;