const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const path = require("path");
const apiRoutes = require("./routes/api");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

const publicDir = path.join(__dirname, "public");
app.use(express.static(publicDir));

app.get("/ads.txt", (req, res) => {
  res.type("text/plain").sendFile(path.join(publicDir, "ads.txt"));
});

app.get("/app-ads.txt", (req, res) => {
  res.type("text/plain").sendFile(path.join(publicDir, "app-ads.txt"));
});

app.get("/manifest.json", (req, res) => {
  res.type("application/json").sendFile(path.join(publicDir, "manifest.json"));
});

app.use("/api", apiRoutes);

app.get("/health", (req, res) => {
  res.json({ status: "ok", service: "ALHIKMAH", domain: "alhikmah.my.id" });
});

app.use((req, res) => {
  res.status(404).json({ error: "Not Found", path: req.path });
});

app.listen(PORT, () => {
  console.log(`ALHIKMAH server running on http://localhost:${PORT}`);
});

module.exports = app;