const express = require("express");
const router = express.Router();

const TAPPX_KEYS = [
  "pub-65263-android-0300",
  "pub-57747-android-0996",
  "pub-60567-android-4416",
  "pub-65262-android-8892",
  "pub-79956-android-6297",
  "pub-79955-android-5582",
];

const CATEGORIES = [
  "Home", "Aplikasi", "Kisah Hikmah", "Kitab/Buku", "Pendidikan",
  "Sholawat", "Khutbah", "Kisah dan Tokoh", "Informasi", "Vidio",
  "Adhan", "Iqro'", "Tafsir Web", "Perpustakaan", "Arabic Pegon",
  "Arabic Calligraphy", "Kalender", "Timer", "Murotal 30 Juz",
  "Alqur'an Digital", "WebOffice", "CorelDRAW Arabic",
];

const ARTICLES = [
  {
    id: "1",
    slug: "keutamaan-membaca-alquran",
    title: "Keutamaan Membaca Al-Qur'an Setiap Hari",
    category: "Alqur'an Digital",
    excerpt: "Setiap huruf Al-Qur'an bernilai satu kebaikan yang dilipatgandakan sepuluh kali.",
    content: "Al-Qur'an adalah kalamullah yang diturunkan kepada Nabi Muhammad ﷺ melalui perantaraan Jibril.",
    readTime: "8 menit",
    views: "12.4K",
    author: "ADMIN ALHIKMAH",
    date: "2025-12-01",
    tags: ["Al-Qur'an", "Tilawah", "Ibadah"],
  },
  {
    id: "2",
    slug: "sejarah-peradaban-islam-nusantara",
    title: "Sejarah Peradaban Islam di Nusantara",
    category: "Kisah dan Tokoh",
    excerpt: "Jejak dakwah Wali Songo yang membentuk karakter Islam Nusantara.",
    content: "Islam masuk ke Nusantara melalui jalur perdagangan, perkawinan, tasawuf, dan pendidikan pesantren.",
    readTime: "12 menit",
    views: "9.8K",
    author: "ADMIN ALHIKMAH",
    date: "2025-11-28",
    tags: ["Sejarah", "Wali Songo", "Nusantara"],
  },
  {
    id: "3",
    slug: "panduan-lengkap-sholat-tahajud",
    title: "Panduan Lengkap Sholat Tahajud",
    category: "Pendidikan",
    excerpt: "Tata cara, waktu terbaik, dan keutamaan sholat tahajud berdasarkan dalil.",
    content: "Sholat tahajud adalah sholat sunnah yang dikerjakan pada malam hari setelah tidur.",
    readTime: "6 menit",
    views: "15.2K",
    author: "ADMIN ALHIKMAH",
    date: "2025-11-25",
    tags: ["Sholat", "Tahajud", "Fiqih"],
  },
];

let keyIndex = 0;

router.get("/articles", (req, res) => {
  const { category, q } = req.query;
  let result = ARTICLES;
  if (category) {
    result = result.filter(
      (a) => a.category.toLowerCase() === String(category).toLowerCase()
    );
  }
  if (q) {
    const query = String(q).toLowerCase();
    result = result.filter(
      (a) =>
        a.title.toLowerCase().includes(query) ||
        a.excerpt.toLowerCase().includes(query) ||
        a.tags.some((t) => t.toLowerCase().includes(query))
    );
  }
  res.json({ total: result.length, data: result });
});

router.get("/articles/:slug", (req, res) => {
  const article = ARTICLES.find((a) => a.slug === req.params.slug);
  if (!article) return res.status(404).json({ error: "Article not found" });
  res.json({ data: article });
});

router.get("/categories", (req, res) => {
  res.json({
    total: CATEGORIES.length,
    data: CATEGORIES.map((name) => ({
      name,
      slug: name.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
    })),
  });
});

router.get("/tools", (req, res) => {
  res.json({
    data: [
      { id: "arabic-pegon", name: "Konverter Arabic Pegon" },
      { id: "kalender", name: "Kalender Hijriyah" },
      { id: "timer", name: "Timer Adzan" },
      { id: "quran", name: "Al-Qur'an Digital" },
      { id: "murotal", name: "Murotal 30 Juz" },
      { id: "coreldraw", name: "CorelDRAW Arabic Assets" },
    ],
  });
});

router.get("/ads/tappx", (req, res) => {
  const key = TAPPX_KEYS[keyIndex % TAPPX_KEYS.length];
  keyIndex = (keyIndex + 1) % TAPPX_KEYS.length;
  res.json({ key, total: TAPPX_KEYS.length });
});

router.get("/ads/tappx/all", (req, res) => {
  res.json({ data: TAPPX_KEYS });
});

module.exports = router;