"""ALHIKMAH Islamic Tools Backend - Arabic Pegon, Kalender, CorelDRAW assets."""

import json
import os
from datetime import datetime, timedelta
from typing import Dict, List

PEGON_MAP = {
    "a": "ا", "b": "ب", "t": "ت", "ts": "ث", "j": "ج", "h": "ح",
    "kh": "خ", "d": "د", "dz": "ذ", "r": "ر", "z": "ز", "s": "س",
    "sy": "ش", "sh": "ص", "dh": "ض", "th": "ط", "zh": "ظ", "ng": "ڠ",
    "f": "ف", "q": "ق", "k": "ك", "l": "ل", "m": "م", "n": "ن",
    "w": "و", "y": "ي", "ny": "ڽ", "p": "ڤ", "g": "ݢ", "v": "ۏ",
    "e": "ي", "i": "ي", "o": "و", "u": "و",
}

HIJRI_MONTHS = [
    "Muharram", "Safar", "Rabiul Awal", "Rabiul Akhir",
    "Jumadil Awal", "Jumadil Akhir", "Rajab", "Sya'ban",
    "Ramadhan", "Syawal", "Dzulqa'dah", "Dzulhijjah",
]


class ArabicPegonConverter:
    """Convert Latin Indonesian text to Arabic Pegon script."""

    def convert(self, text: str) -> str:
        result = []
        i = 0
        lower = text.lower()
        while i < len(lower):
            matched = False
            for length in (3, 2, 1):
                chunk = lower[i:i + length]
                if chunk in PEGON_MAP:
                    result.append(PEGON_MAP[chunk])
                    i += length
                    matched = True
                    break
            if not matched:
                result.append(text[i])
                i += 1
        return "".join(result)


class HijriCalendar:
    """Simple Hijri calendar converter (approximate)."""

    def __init__(self, offset_days: int = 0):
        self.offset_days = offset_days

    def to_hijri(self, date: datetime) -> Dict:
        approx_days = int((date - datetime(622, 7, 16)).days * 33 / 32) + self.offset_days
        year = 1 + approx_days // 354
        remaining = approx_days % 354
        month = min(12, 1 + remaining // 30)
        day = 1 + remaining % 30
        return {
            "day": day,
            "month": month,
            "month_name": HIJRI_MONTHS[month - 1],
            "year": year,
            "formatted": f"{day} {HIJRI_MONTHS[month - 1]} {year} H",
        }

    def today(self) -> Dict:
        return self.to_hijri(datetime.utcnow())


class CorelDrawArabicAssets:
    """Manage CorelDRAW Arabic design assets."""

    def __init__(self, base_dir: str = "assets/coreldraw"):
        self.base_dir = base_dir

    def list_assets(self) -> List[Dict]:
        if not os.path.isdir(self.base_dir):
            return []
        return [
            {"name": f, "path": os.path.join(self.base_dir, f)}
            for f in sorted(os.listdir(self.base_dir))
        ]

    def register(self, name: str, metadata: Dict) -> str:
        os.makedirs(self.base_dir, exist_ok=True)
        path = os.path.join(self.base_dir, f"{name}.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(metadata, f, ensure_ascii=False, indent=2)
        return path


def run_tools_demo() -> None:
    pegon = ArabicPegonConverter()
    print("Pegon:", pegon.convert("alhikmah portal islam"))

    cal = HijriCalendar()
    print("Hijri today:", cal.today()["formatted"])

    assets = CorelDrawArabicAssets()
    print("CorelDRAW assets:", assets.list_assets())


if __name__ == "__main__":
    run_tools_demo()