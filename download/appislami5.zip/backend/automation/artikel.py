"""ALHIKMAH Article Generator - SEO 3000+ words with H1-H6, TOC, FAQ, Conclusion."""

import json
import re
from datetime import datetime
from typing import Dict, List


class ArticleGenerator:
    """Generate deep Islamic articles with SEO structure."""

    def __init__(self, topic: str, category: str = "Pendidikan", author: str = "ADMIN ALHIKMAH"):
        self.topic = topic
        self.category = category
        self.author = author
        self.slug = self._slugify(topic)
        self.sections: List[Dict[str, str]] = []
        self.faq: List[Dict[str, str]] = []

    @staticmethod
    def _slugify(text: str) -> str:
        text = text.lower().strip()
        text = re.sub(r"[^a-z0-9\s-]", "", text)
        return re.sub(r"\s+", "-", text)

    def add_section(self, heading: str, level: int, body: str) -> None:
        if level < 1 or level > 6:
            raise ValueError("Heading level must be between 1 and 6")
        self.sections.append({"heading": heading, "level": level, "body": body})

    def add_faq(self, question: str, answer: str) -> None:
        self.faq.append({"q": question, "a": answer})

    def _build_toc(self) -> str:
        items = []
        for s in self.sections:
            anchor = self._slugify(s["heading"])
            indent = "  " * (s["level"] - 1)
            items.append(f"{indent}- [{s['heading']}](#{anchor})")
        return "\n".join(items)

    def _build_body(self) -> str:
        parts = []
        for s in self.sections:
            anchor = self._slugify(s["heading"])
            parts.append(f"<h{s['level']} id=\"{anchor}\">{s['heading']}</h{s['level']}>")
            parts.append(f"<p>{s['body']}</p>")
        return "\n".join(parts)

    def _build_faq(self) -> str:
        parts = ['<section id="faq"><h2>FAQ</h2>']
        for item in self.faq:
            parts.append(f"<h3>{item['q']}</h3><p>{item['a']}</p>")
        parts.append("</section>")
        return "\n".join(parts)

    def _faq_jsonld(self) -> str:
        data = {
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": [
                {
                    "@type": "Question",
                    "name": item["q"],
                    "acceptedAnswer": {"@type": "Answer", "text": item["a"]},
                }
                for item in self.faq
            ],
        }
        return json.dumps(data, ensure_ascii=False)

    def word_count(self) -> int:
        text = " ".join(s["body"] for s in self.sections)
        return len(text.split())

    def render(self) -> str:
        toc = self._build_toc()
        body = self._build_body()
        faq = self._build_faq()
        jsonld = self._faq_jsonld()
        return f"""<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<title>{self.topic} | ALHIKMAH</title>
<meta name="description" content="{self.topic} - {self.category}">
<meta property="og:title" content="{self.topic}">
<meta property="og:type" content="article">
<meta property="og:url" content="https://alhikmah.my.id/artikel/{self.slug}">
<meta property="og:image" content="https://alhikmah.my.id/images.jpg">
<script type="application/ld+json">{jsonld}</script>
</head>
<body>
<article>
<h1>{self.topic}</h1>
<nav id="toc"><h2>Table of Contents</h2>
{toc}
</nav>
{body}
{faq}
<section id="conclusion"><h2>Kesimpulan</h2><p>Demikian pembahasan {self.topic}.</p></section>
</article>
</body>
</html>"""

    def to_dict(self) -> Dict:
        return {
            "slug": self.slug,
            "title": self.topic,
            "category": self.category,
            "author": self.author,
            "date": datetime.utcnow().isoformat(),
            "word_count": self.word_count(),
            "sections": self.sections,
            "faq": self.faq,
        }


if __name__ == "__main__":
    gen = ArticleGenerator("Keutamaan Membaca Al-Qur'an Setiap Hari", "Alqur'an Digital")
    gen.add_section("Pendahuluan", 2, "Al-Qur'an adalah kalamullah yang diturunkan kepada Nabi Muhammad ﷺ.")
    gen.add_section("Dalil Al-Qur'an dan Hadits", 2, "Allah berfirman dalam surah Al-Isra ayat 82.")
    gen.add_section("Keutamaan Tilawah", 3, "Setiap huruf bernilai satu kebaikan yang dilipatgandakan sepuluh kali.")
    gen.add_faq("Apakah wajib membaca Al-Qur'an setiap hari?", "Sunnah muakkadah yang sangat dianjurkan.")
    print(gen.render())
    print(f"Word count: {gen.word_count()}")