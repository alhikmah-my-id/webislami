"""ALHIKMAH Content Seeder - Generate 30 initial articles across categories."""

import json
import os
from datetime import datetime, timedelta
from artikel import ArticleGenerator

CATEGORIES = [
    "Aplikasi", "Kisah Hikmah", "Kitab/Buku", "Pendidikan", "Sholawat",
    "Khutbah", "Kisah dan Tokoh", "Informasi", "Vidio", "Adhan",
    "Iqro'", "Tafsir Web", "Perpustakaan", "Arabic Pegon",
    "Arabic Calligraphy", "Kalender", "Timer", "Murotal 30 Juz",
    "Alqur'an Digital", "WebOffice", "CorelDRAW Arabic",
]

TOPICS = [
    ("Keutamaan Membaca Al-Qur'an Setiap Hari", "Alqur'an Digital"),
    ("Sejarah Peradaban Islam di Nusantara", "Kisah dan Tokoh"),
    ("Panduan Lengkap Sholat Tahajud", "Pendidikan"),
    ("Doa Sebelum Tidur Lengkap Arab & Latin", "Adhan"),
    ("10 Sholawat Pembuka Rezeki", "Sholawat"),
    ("Cara Cepat Belajar Iqro' untuk Pemula", "Iqro'"),
    ("Tafsir Surah Al-Fatihah Lengkap", "Tafsir Web"),
    ("Kumpulan Khutbah Jumat Singkat", "Khutbah"),
    ("Kalender Hijriyah 1447 H Terbaru", "Kalender"),
    ("Aplikasi Muslim Wajib di Smartphone", "Aplikasi"),
    ("Kisah Nabi Yusuf dan Keteladanannya", "Kisah Hikmah"),
    ("Kitab Riyadhus Shalihin dan Penjelasannya", "Kitab/Buku"),
    ("Adab Menuntut Ilmu dalam Islam", "Pendidikan"),
    ("Murotal 30 Juz Lengkap dan Merdu", "Murotal 30 Juz"),
    ("Sejarah Masjid Nabawi dan Keutamaannya", "Kisah dan Tokoh"),
    ("Panduan Zakat Fitrah dan Zakat Mal", "Informasi"),
    ("Video Kajian Islam Terbaik 2025", "Vidio"),
    ("Belajar Bahasa Arab Pegon untuk Pemula", "Arabic Pegon"),
    ("Seni Kaligrafi Arab dan Tekniknya", "Arabic Calligraphy"),
    ("Timer Adzan dan Pengingat Sholat", "Timer"),
    ("Perpustakaan Digital Islam Terlengkap", "Perpustakaan"),
    ("WebOffice untuk Administrasi Pesantren", "WebOffice"),
    ("Desain Undangan dengan CorelDRAW Arabic", "CorelDRAW Arabic"),
    ("Keutamaan Sholat Berjamaah di Masjid", "Pendidikan"),
    ("Kisah Wali Songo dan Metode Dakwahnya", "Kisah dan Tokoh"),
    ("Doa Pagi dan Petang Sesuai Sunnah", "Adhan"),
    ("Sholawat Nariyah dan Fadhilahnya", "Sholawat"),
    ("Tafsir Surah Yasin Ayat 1-83", "Tafsir Web"),
    ("Panduan Puasa Sunnah Senin Kamis", "Pendidikan"),
    ("Tips Menghafal Al-Qur'an dengan Cepat", "Alqur'an Digital"),
]


def build_article(topic: str, category: str, index: int) -> ArticleGenerator:
    gen = ArticleGenerator(topic, category)
    gen.add_section("Pendahuluan", 2, f"Pembahasan mendalam tentang {topic} berdasarkan dalil Al-Qur'an dan hadits shahih.")
    gen.add_section("Dalil Al-Qur'an dan Hadits", 2, "Allah berfirman dalam Al-Qur'an dan Rasulullah ﷺ bersabda dalam hadits shahih.")
    gen.add_section("Keutamaan dan Manfaat", 3, "Banyak keutamaan yang dijanjikan Allah bagi yang mengamalkannya dengan ikhlas.")
    gen.add_section("Adab dan Tata Cara", 3, "Terdapat adab dan tata cara yang perlu diperhatikan sesuai sunnah Nabi ﷺ.")
    gen.add_section("Praktik Harian", 2, "Amalkan secara konsisten setiap hari agar menjadi kebiasaan yang membawa berkah.")
    gen.add_section("Studi Kasus", 4, "Contoh penerapan dalam kehidupan sehari-hari umat Islam modern.")
    gen.add_section("Referensi Ulama", 5, "Pendapat para ulama salaf dan khalaf tentang topik ini.")
    gen.add_section("Catatan Tambahan", 6, "Catatan penting untuk dipahami sebelum mengamalkan.")
    gen.add_faq(f"Apakah {topic} wajib dilakukan?", "Hukumnya bervariasi, namun sangat dianjurkan dalam Islam.")
    gen.add_faq("Apa dalil utamanya?", "Terdapat dalam Al-Qur'an dan hadits shahih yang diriwayatkan para imam.")
    gen.add_faq("Bagaimana cara memulainya?", "Mulailah dari langkah kecil secara konsisten setiap hari.")
    return gen


def seed(output_dir: str = "output") -> None:
    os.makedirs(output_dir, exist_ok=True)
    manifest = []
    base_date = datetime.utcnow()

    for i, (topic, category) in enumerate(TOPICS):
        gen = build_article(topic, category, i)
        html = gen.render()
        path = os.path.join(output_dir, f"{gen.slug}.html")
        with open(path, "w", encoding="utf-8") as f:
            f.write(html)

        data = gen.to_dict()
        data["date"] = (base_date - timedelta(days=i)).isoformat()
        manifest.append(data)
        print(f"[{i + 1}/{len(TOPICS)}] Generated: {gen.slug} ({gen.word_count()} words)")

    with open(os.path.join(output_dir, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)

    print(f"\n✅ Seeded {len(manifest)} articles into '{output_dir}/'")


if __name__ == "__main__":
    seed()