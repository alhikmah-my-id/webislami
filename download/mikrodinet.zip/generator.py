#!/usr/bin/env python3
"""MIKRODINET static site generator.

    python3 generator.py                      # build into ./public
    python3 generator.py --out dist --base-url https://example.com

Creates every page as <subfolder>/index.html (articles, categories, tools,
information pages), plus sitemap.xml, rss.xml, atom.xml, robots.txt, ads.txt,
app-ads.txt, manifest.json and the Google verification file.  Uses only the
Python standard library, so Netlify can run it directly as the build command.
"""
import argparse
import datetime as dt
import json
import os
import random
import shutil
import sys
from xml.sax.saxutils import escape as xesc

from mkgen import config as cfg
from mkgen import layout as L
from mkgen.article_engine import build_article, esc, slugify, title_case
from mkgen.assets import ICON_SVG, LOGO_SVG, figure_svg, icon_png
from mkgen.categories import CATEGORIES
from mkgen.pages import HW_FEATURES, INFO, SECTION_INTRO
from mkgen.tools import GROUP_EXTERNALS, GROUPS, TOOLS

ROOT = os.path.dirname(os.path.abspath(__file__))
TODAY = dt.date(2026, 10, 28)
OUT = "public"
written = []  # (path, lastmod) for sitemap.xml


def write(path, content, lastmod=None, sitemap=True):
    """Write OUT/<path>.  Paths ending in "/" become <path>/index.html."""
    rel = path.lstrip("/")
    fs = os.path.join(OUT, rel, "index.html") if path.endswith("/") or not rel else os.path.join(OUT, rel)
    os.makedirs(os.path.dirname(fs), exist_ok=True)
    mode = "wb" if isinstance(content, bytes) else "w"
    with open(fs, mode, **({} if mode == "wb" else {"encoding": "utf-8"})) as f:
        f.write(content)
    if sitemap and (path.endswith("/") or path == "/"):
        written.append((path, (lastmod or TODAY).isoformat()))


def fmt_date(d):
    return d.strftime("%B %d, %Y").replace(" 0", " ")


# ------------------------------------------------------------------ data model
def build_model():
    cats = []
    for c in CATEGORIES:
        c = dict(c)
        c["count"] = len(c["topics"])
        cats.append(c)
    posts = []
    n_cats = len(cats)
    for ci, c in enumerate(cats):
        for ti, (title, kw) in enumerate(c["topics"]):
            g = ti * n_cats + ci  # interleave categories so recent posts are mixed
            date = TODAY - dt.timedelta(days=g * 3)
            slug = slugify(title)
            base = f"/img/articles/{c['slug']}/{slug}"
            posts.append({
                "title": title, "kw": kw, "slug": slug, "cat": c, "date": date, "date_h": fmt_date(date),
                "url": f"/{c['slug']}/{slug}/", "thumb": f"{base}-1.svg", "img_base": base,
                "desc": f"A complete, practical guide to {kw}: definition, history, key drivers, global perspectives, "
                        f"risks, a checklist, FAQs and the outlook for {cfg.SITE_NAME} readers.",
            })
    posts.sort(key=lambda p: p["date"], reverse=True)
    r = random.Random("popular")
    archive = {}
    for p in posts:
        k = p["date"].strftime("%Y-%m")
        archive.setdefault(k, []).append(p)
    site = {
        "categories": cats, "posts": posts, "year": TODAY.year,
        "popular": r.sample(posts[:120], 5),
        "oldest": list(reversed(posts[-5:])),
        "archive_posts": archive,
        "archive": [(k, dt.datetime.strptime(k, "%Y-%m").strftime("%B %Y"), len(v)) for k, v in archive.items()],
        "tool_picks": ["dns-lookup", "what-is-my-ip", "ssl-certificate-checker", "qr-code-generator",
                       "json-viewer", "random-password-generator", "seo-performance-analyzer", "internet-speed-test"],
    }
    return site


def card(p):
    return (f'<article class="card"><a href="{p["url"]}" class="card-img"><img src="{p["thumb"]}" alt="{esc(p["title"])} — illustration" '
            f'width="1200" height="630" loading="lazy" decoding="async" /></a><div class="card-body">'
            f'<a class="pill" href="{L.cat_url(p["cat"]["slug"])}">{esc(p["cat"]["name"])}</a>'
            f'<h3><a href="{p["url"]}">{esc(p["title"])}</a></h3><p>{esc(p["desc"][:150])}…</p>'
            f'<time datetime="{p["date"].isoformat()}">{p["date_h"]}</time></div></article>')


def tool_card(s):
    n, d, e = TOOLS[s]
    return f'<a class="tool-card" href="{L.tool_url(s)}"><span class="t-ico" aria-hidden="true">{e}</span><strong>{esc(n)}</strong><small>{esc(d)}</small></a>'


# ------------------------------------------------------------------ articles
def build_articles(site):
    posts = site["posts"]
    by_cat = {}
    for p in posts:
        by_cat.setdefault(p["cat"]["slug"], []).append(p)
    all_tools = list(TOOLS)
    for idx, p in enumerate(posts):
        c = p["cat"]
        same = [q for q in by_cat[c["slug"]] if q is not p]
        others = [q for q in posts if q["cat"] is not c]
        r = random.Random(p["slug"])
        s4 = r.sample(same, 4)
        o2 = r.sample(others, 2)
        tool = r.choice(all_tools)
        internal = [(s4[0]["title"], s4[0]["url"]), (o2[0]["title"], o2[0]["url"]), (s4[1]["title"], s4[1]["url"]),
                    (f"our free {TOOLS[tool][0]} tool", L.tool_url(tool)), (o2[1]["title"], o2[1]["url"]),
                    (s4[2]["title"], s4[2]["url"]), (s4[3]["title"], s4[3]["url"])]
        kw_t = title_case(p["kw"])
        captions = [f"Overview: {kw_t} explained", f"Key factors that drive {p['kw']}", f"Global outlook for {p['kw']}"]
        images = []
        for i in range(3):
            src = f"{p['img_base']}-{i + 1}.svg"
            write(src, figure_svg(f"{p['slug']}{i}", c["hue"], kw_t if i == 0 else captions[i].split(":")[0][:60],
                                  c["name"] + " · " + captions[i]), sitemap=False)
            images.append({"src": src, "alt": f"{captions[i]} — {c['name']} illustration by {cfg.SITE_NAME}",
                           "caption": captions[i]})
        art = build_article(c, p["title"], p["kw"], p["slug"], internal, c["externals"], images)
        p["words"] = art["words"]
        toc = "".join(f'<li class="toc-l{lvl}"><a href="#{hid}">{esc(t)}</a></li>' for lvl, t, hid in art["toc"])
        crumbs = [("Home", "/"), (c["name"], L.cat_url(c["slug"])), (p["title"], None)]
        related = "".join(card(q) for q in same[:3])
        prev_p = posts[idx + 1] if idx + 1 < len(posts) else None
        next_p = posts[idx - 1] if idx > 0 else None
        nav = '<nav class="prevnext">' + (
            f'<a href="{prev_p["url"]}" rel="prev">← {esc(prev_p["title"])}</a>' if prev_p else "<span></span>") + (
            f'<a href="{next_p["url"]}" rel="next">{esc(next_p["title"])} →</a>' if next_p else "") + "</nav>"
        minutes = max(1, round(art["words"] / 230))
        jsonld = [
            {"@context": "https://schema.org", "@type": "Article", "headline": p["title"], "description": p["desc"],
             "image": [L.url(im["src"]) for im in images], "datePublished": p["date"].isoformat(),
             "dateModified": TODAY.isoformat(), "wordCount": art["words"], "articleSection": c["name"],
             "keywords": f"{p['kw']}, {c['name']}, " + ", ".join(c["terms"][:4]),
             "author": {"@type": "Organization", "name": f"{cfg.SITE_NAME} Editorial Team", "url": L.url("/about-us/")},
             "publisher": {"@type": "Organization", "name": cfg.SITE_NAME, "logo": {"@type": "ImageObject", "url": L.url("/icon-512.png")}},
             "mainEntityOfPage": L.url(p["url"])},
            {"@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [
                {"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in art["faqs"]]},
            L.breadcrumb_ld(crumbs),
        ]
        main = f"""{L.breadcrumb(crumbs)}
<article class="post">
<header class="post-head">
<a class="pill" href="{L.cat_url(c['slug'])}">{esc(c['name'])}</a>
<h1>{esc(p['title'])}</h1>
<p class="lede">{esc(p['desc'])}</p>
<p class="meta">By <a href="/editorial/">{cfg.SITE_NAME} Editorial Team</a> · <time datetime="{p['date'].isoformat()}">{p['date_h']}</time> · {minutes} min read · {art['words']:,} words</p>
{L.share(p['url'], p['title'])}
</header>
<details class="toc" open><summary>Table of Contents</summary><ol>{toc}</ol></details>
{L.ad()}
<div class="post-body">
{art['body']}
</div>
{L.ad()}
{L.share(p['url'], p['title'])}
<div class="author-box"><img src="/icon-192.png" alt="{cfg.SITE_NAME} Editorial Team" width="64" height="64" loading="lazy" /><div><strong>{cfg.SITE_NAME} Editorial Team</strong><p>Our editors research and update long-form guides on {esc(c['field'])} and 24 other subject areas. <a href="/editorial/">Read our editorial policy</a>.</p></div></div>
{nav}
</article>
<section class="related"><h2>Related in {esc(c['name'])}</h2><div class="grid">{related}</div></section>
"""
        head = L.head(p["title"], p["desc"], p["url"], keywords=f"{p['kw']}, {c['name'].lower()}, " + ", ".join(c["terms"]),
                      og_type="article", image=images[0]["src"], jsonld=jsonld,
                      extra=f'<meta property="article:published_time" content="{p["date"].isoformat()}" />\n<meta property="article:section" content="{esc(c["name"])}" />')
        write(p["url"], L.page(site, head, main), lastmod=TODAY)


# ------------------------------------------------------------------ listings
def build_home(site):
    posts = site["posts"]
    feat = posts[0]
    latest = "".join(card(p) for p in posts[1:13])
    sections = ""
    for c in site["categories"]:
        ps = [p for p in posts if p["cat"] is c][:3]
        sections += (f'<section class="cat-block"><div class="cat-head"><h2><a href="{L.cat_url(c["slug"])}">{esc(c["name"])}</a></h2>'
                     f'<a class="more" href="{L.cat_url(c["slug"])}">View all →</a></div><div class="grid">{"".join(card(p) for p in ps)}</div></section>')
    tools = "".join(tool_card(s) for s in site["tool_picks"])
    main = f"""<section class="hero">
<div class="hero-text"><p class="kicker">{esc(cfg.TAGLINE)}</p>
<h1>{cfg.SITE_NAME}: In-Depth Guides &amp; Free Online Tools</h1>
<p>{esc(cfg.DESCRIPTION)}</p>
<div class="hero-cta"><a class="btn" href="#latest">Read the latest</a><a class="btn ghost" href="/tools/">Explore 80+ tools</a></div></div>
<a class="hero-feat" href="{feat['url']}"><img src="{feat['thumb']}" alt="{esc(feat['title'])} — featured illustration" width="1200" height="630" /><span class="pill">{esc(feat['cat']['name'])}</span><strong>{esc(feat['title'])}</strong></a>
</section>
{L.ad()}
<section id="latest"><h2 class="sec-title">Latest Articles</h2><div class="grid">{latest}</div></section>
<section><h2 class="sec-title">Popular Tools</h2><div class="tool-grid">{tools}</div><p><a class="more" href="/tools/">Browse all tools →</a></p></section>
{L.ad()}
{sections}
"""
    jsonld = [{"@context": "https://schema.org", "@type": "WebSite", "name": cfg.SITE_NAME, "url": cfg.BASE_URL + "/",
               "potentialAction": {"@type": "SearchAction", "target": cfg.BASE_URL + "/search/?q={search_term_string}",
                                   "query-input": "required name=search_term_string"}}]
    write("/", L.page(site, L.head(f"{cfg.SITE_NAME} — In-Depth Guides & Free Online Tools", cfg.DESCRIPTION, "/", jsonld=jsonld), main))


def build_categories(site):
    for c in site["categories"]:
        ps = [p for p in site["posts"] if p["cat"] is c]
        crumbs = [("Home", "/"), ("Articles", "/archive/"), (c["name"], None)]
        main = (f'{L.breadcrumb(crumbs)}<header class="page-head"><h1>{esc(c["name"])}</h1><p>{esc(c["desc"])}</p></header>'
                f'<div class="grid">{"".join(card(p) for p in ps)}</div>{L.ad()}')
        ld = [L.breadcrumb_ld(crumbs), {"@context": "https://schema.org", "@type": "CollectionPage", "name": c["name"],
                                        "description": c["desc"], "url": L.url(L.cat_url(c["slug"]))}]
        write(L.cat_url(c["slug"]), L.page(site, L.head(f"{c['name']} Articles", c["desc"], L.cat_url(c["slug"]),
                                                       keywords=", ".join([c["name"].lower()] + c["terms"]), jsonld=ld), main))


def build_archive(site):
    blocks = ""
    for k, label, n in site["archive"]:
        items = "".join(f'<li><time datetime="{p["date"].isoformat()}">{p["date_h"]}</time> <a href="{p["url"]}">{esc(p["title"])}</a> <span class="pill sm">{esc(p["cat"]["name"])}</span></li>'
                        for p in site["archive_posts"][k])
        blocks += f'<section class="arch" id="{k}"><h2>{esc(label)} <small>({n})</small></h2><ul>{items}</ul></section>'
    crumbs = [("Home", "/"), ("Archive", None)]
    main = f'{L.breadcrumb(crumbs)}<header class="page-head"><h1>Archive</h1><p>Every article on {cfg.SITE_NAME}, newest first.</p></header>{blocks}'
    write("/archive/", L.page(site, L.head("Archive", f"Browse all {len(site['posts'])} {cfg.SITE_NAME} articles by month.", "/archive/",
                                           jsonld=[L.breadcrumb_ld(crumbs)]), main))


def build_search(site):
    index = [{"t": p["title"], "u": p["url"], "c": p["cat"]["name"], "d": p["desc"], "i": p["thumb"]} for p in site["posts"]]
    index += [{"t": n, "u": L.tool_url(s), "c": "Tool", "d": d, "e": e} for s, (n, d, e) in TOOLS.items()]
    write("/search-index.json", json.dumps(index, ensure_ascii=False, separators=(",", ":")), sitemap=False)
    main = ('<header class="page-head"><h1>Search</h1><p>Search articles and tools.</p></header>'
            '<form class="side-search big" action="/search/" method="get" role="search"><input type="search" name="q" id="q" aria-label="Search query" placeholder="Type a keyword…" />'
            '<button class="btn" type="submit">Search</button></form><p id="search-status" aria-live="polite"></p><div id="search-results" class="search-results"></div>')
    head = L.head("Search", f"Search all {cfg.SITE_NAME} articles and online tools.", "/search/",
                  extra='<meta name="robots" content="noindex, follow" />')
    write("/search/", L.page(site, head, main), sitemap=False)


# ------------------------------------------------------------------ tools
GUIDE_INPUT = {
    "dns-tools": "a domain name such as example.com", "ip-tools": "an IP address or domain",
    "network-tools": "a host, MAC address or ASN", "cyber-security-tools": "a domain or password",
    "designer-tools": "a color value", "developer-tools": "a URL, host or text",
    "domain-tools": "a domain name", "webmaster-tools": "a website URL", "performance-tools": "a URL, file or numbers",
    "dns-server-database": "nothing — browse the table", "operational-tools": "text, code or URLs",
}


def tool_group(slug):
    for g in GROUPS:
        if slug in g[2]:
            return g
    return GROUPS[0]


def build_tools(site):
    posts = site["posts"]
    for slug, (name, desc, emoji) in TOOLS.items():
        g = tool_group(slug)
        r = random.Random(slug)
        others = [s for s in g[2] if s != slug] or list(TOOLS)[:6]
        more = r.sample([s for s in TOOLS if s != slug and s not in others], 8)
        arts = r.sample(posts, 4)
        int_tools = (others + more)[:3]
        internal = [(a["title"], a["url"]) for a in arts] + [(TOOLS[s][0], L.tool_url(s)) for s in int_tools]
        ext = GROUP_EXTERNALS.get(g[0], GROUP_EXTERNALS["default"])
        what = GUIDE_INPUT.get(g[0], "your input")
        img = f"/img/tools/{slug}.svg"
        write(img, figure_svg(slug, 210 + (sum(map(ord, slug)) % 120), name, f"Free online tool · {g[1]}"), sitemap=False)
        crumbs = [("Home", "/"), ("Tools", "/tools/"), (g[1], L.group_url(g[0])), (name, None)]
        faqs = [
            (f"Is the {name} free to use?", f"Yes. The {name} on {cfg.SITE_NAME} is completely free, with no sign-up required."),
            (f"Is my data safe when I use the {name}?", "Tools that work offline process everything in your browser. Network checks send only the host or URL you enter, and queries are not stored."),
            (f"How accurate is the {name}?", "Results come from live public data or standard algorithms at the moment you run the check. For critical decisions, confirm results with a second source."),
        ]
        ilinks = ", ".join(f'<a href="{u}">{esc(t)}</a>' for t, u in internal)
        xlinks = "".join(f'<li><a href="{x[1]}" target="_blank" rel="noopener">{esc(x[0])}</a></li>' for x in ext)
        main = f"""{L.breadcrumb(crumbs)}
<article class="tool-page">
<header class="page-head"><span class="t-ico big" aria-hidden="true">{emoji}</span><h1>{esc(name)}</h1><p class="lede">{esc(desc)}</p>{L.share(L.tool_url(slug), name)}</header>
<section class="tool-app" id="tool-app" data-tool="{slug}" aria-label="{esc(name)}"><noscript>This tool needs JavaScript enabled.</noscript></section>
{L.ad()}
<section class="guide">
<h2>How to Use the {esc(name)}</h2>
<ol>
<li>Enter {what} in the field above. Example values are pre-filled where helpful.</li>
<li>Press the main action button to run the tool. Most results appear instantly.</li>
<li>Review the results. Values can be selected and copied; some tools offer a download button.</li>
<li>Adjust the input or options and run again to compare results.</li>
</ol>
<h3>What the {esc(name)} Does</h3>
<p>{esc(desc)} It is part of the {esc(g[1])} collection on {cfg.SITE_NAME}, a growing set of free utilities for site owners, developers, network administrators and curious users.</p>
<h3>When to Use It</h3>
<p>Use the {esc(name)} when troubleshooting, auditing a website, preparing a launch, learning how the underlying technology works or double-checking results from another service. Combining it with related tools gives a fuller picture.</p>
<figure class="art-fig"><img src="{img}" alt="{esc(name)} — free online tool by {cfg.SITE_NAME}" width="1200" height="630" loading="lazy" /><figcaption>{esc(name)} — part of the {esc(g[1])} collection</figcaption></figure>
<h3>Related Reading and Tools</h3>
<p>Continue with {ilinks}.</p>
<h3>External References</h3>
<ul class="ext-links">{xlinks}</ul>
<h2>Frequently Asked Questions</h2>
{''.join(f'<div class="faq"><h3>{esc(q)}</h3><p>{esc(a)}</p></div>' for q, a in faqs)}
</section>
<section class="related"><h2>Other {esc(g[1])}</h2><div class="tool-grid">{''.join(tool_card(s) for s in others[:8])}</div>
<h2>More Tools</h2><div class="tool-grid">{''.join(tool_card(s) for s in more)}</div></section>
{L.share(L.tool_url(slug), name)}
</article>
"""
        jsonld = [
            {"@context": "https://schema.org", "@type": "WebApplication", "name": name, "description": desc,
             "url": L.url(L.tool_url(slug)), "applicationCategory": "UtilitiesApplication", "operatingSystem": "Any",
             "offers": {"@type": "Offer", "price": "0", "priceCurrency": "USD"}},
            {"@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [
                {"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in faqs]},
            L.breadcrumb_ld(crumbs),
        ]
        head = L.head(f"{name} — Free Online Tool", desc, L.tool_url(slug), keywords=f"{name.lower()}, free {name.lower()}, online {g[1].lower()}, mikrodinet tools",
                      image=img, jsonld=jsonld)
        write(L.tool_url(slug), L.page(site, head, main, with_sidebar=False, scripts='<script src="/js/tools.js" defer></script>\n'))

    # group pages + index
    for gslug, gname, slugs in GROUPS:
        crumbs = [("Home", "/"), ("Tools", "/tools/"), (gname, None)]
        main = (f'{L.breadcrumb(crumbs)}<header class="page-head"><h1>{esc(gname)}</h1><p>{len(slugs)} free {esc(gname.lower())} by {cfg.SITE_NAME}.</p></header>'
                f'<div class="tool-grid">{"".join(tool_card(s) for s in slugs)}</div>{L.ad()}')
        write(L.group_url(gslug), L.page(site, L.head(gname, f"Free online {gname} from {cfg.SITE_NAME}: " + ", ".join(TOOLS[s][0] for s in slugs[:6]) + ".",
                                                      L.group_url(gslug), jsonld=[L.breadcrumb_ld(crumbs)]), main))
    blocks = "".join(f'<section class="tool-group"><h2><a href="{L.group_url(gs)}">{esc(gn)}</a></h2><div class="tool-grid">{"".join(tool_card(s) for s in sl)}</div></section>'
                     for gs, gn, sl in GROUPS if gs != "equipment")
    crumbs = [("Home", "/"), ("Tools", None)]
    main = f'{L.breadcrumb(crumbs)}<header class="page-head"><h1>Free Online Tools</h1><p>{len(TOOLS)} free DNS, IP, developer, designer, network, security, webmaster and productivity tools.</p></header>{L.ad()}{blocks}'
    write("/tools/", L.page(site, L.head("Free Online Tools", f"{len(TOOLS)} free online tools: DNS lookup, IP location, SSL checker, QR code generator, JSON viewer and more.",
                                         "/tools/", jsonld=[L.breadcrumb_ld(crumbs)]), main, with_sidebar=False))


# ------------------------------------------------------------------ static pages
def build_info_pages(site):
    for slug, (title, desc, sections) in INFO.items():
        body = "".join(f"<h2>{esc(h)}</h2><p>{esc(t)}</p>" for h, t in sections)
        if slug == "contact-us":
            body += "<h2>Send Us a Message</h2>" + L.contact_form("contact", compact=False)
        if slug == "forum":
            body += '<h2>Start a Topic</h2>' + L.contact_form("forum-topic", compact=False)
        crumbs = [("Home", "/"), (title, None)]
        main = f'{L.breadcrumb(crumbs)}<article class="page"><header class="page-head"><h1>{esc(title)}</h1><p class="lede">{esc(desc)}</p></header>{body}<p class="updated">Last updated: {fmt_date(TODAY)}</p></article>'
        write(L.page_url(slug), L.page(site, L.head(title, desc, L.page_url(slug), jsonld=[L.breadcrumb_ld(crumbs)]), main))
    main = '<article class="page"><header class="page-head"><h1>Thank You!</h1><p class="lede">Your message has been sent. We will get back to you soon.</p></header><p><a class="btn" href="/">Back to Home</a></p></article>'
    write("/thank-you/", L.page(site, L.head("Thank You", "Your message was sent.", "/thank-you/", extra='<meta name="robots" content="noindex" />'), main), sitemap=False)
    main = '<article class="page"><header class="page-head"><h1>404 — Page Not Found</h1><p class="lede">The page you are looking for does not exist or has moved.</p></header><form class="side-search big" action="/search/" method="get"><input type="search" name="q" aria-label="Search" placeholder="Search the site…" /><button class="btn">Search</button></form><p><a class="btn" href="/">Back to Home</a></p></article>'
    write("/404.html", L.page(site, L.head("Page Not Found", "Page not found.", "/404.html", extra='<meta name="robots" content="noindex" />'), main), sitemap=False)


def build_sections(site):
    for section, items in (("hardware", cfg.HARDWARE), ("software", cfg.SOFTWARE)):
        label = section.capitalize()
        for name in items:
            path = L.section_item_url(section, name)
            crumbs = [("Home", "/"), (label, f"/{section}/"), (name, None)]
            feats = "".join(f"<li>{esc(f)}</li>" for f in HW_FEATURES)
            siblings = "".join(f'<li><a href="{L.section_item_url(section, n)}">{esc(n)}</a></li>' for n in items if n != name)
            main = f"""{L.breadcrumb(crumbs)}<article class="page"><header class="page-head"><h1>{esc(name)}</h1><p class="lede">{esc(SECTION_INTRO[section])}</p></header>
<h2>Overview of {esc(name)}</h2><p>This guide covers {esc(name.lower())} for home labs, small businesses, ISPs and enterprise networks. Use it to understand what the category includes, how products differ and which questions to ask before you deploy.</p>
<h2>What This Guide Covers</h2><ul>{feats}</ul>
<h2>Helpful Tools</h2><div class="tool-grid">{tool_card('port-checker')}{tool_card('mac-address-lookup')}{tool_card('dns-lookup')}{tool_card('internet-speed-test')}</div>
<h2>More in {label}</h2><ul class="cols">{siblings}</ul>
{L.share(path, name)}</article>"""
            write(path, L.page(site, L.head(f"{name} — {label}", f"{name}: {SECTION_INTRO[section]}", path, jsonld=[L.breadcrumb_ld(crumbs)]), main))
        crumbs = [("Home", "/"), (label, None)]
        lis = "".join(f'<li><a href="{L.section_item_url(section, n)}">{esc(n)}</a></li>' for n in items)
        main = f'{L.breadcrumb(crumbs)}<article class="page"><header class="page-head"><h1>{label}</h1><p class="lede">{esc(SECTION_INTRO[section])}</p></header><ul class="cols">{lis}</ul></article>'
        write(f"/{section}/", L.page(site, L.head(label, SECTION_INTRO[section], f"/{section}/", jsonld=[L.breadcrumb_ld(crumbs)]), main))


def build_sitemap_page(site):
    cats = "".join(f'<section><h2><a href="{L.cat_url(c["slug"])}">{esc(c["name"])}</a></h2><ul>' + "".join(
        f'<li><a href="{p["url"]}">{esc(p["title"])}</a></li>' for p in site["posts"] if p["cat"] is c) + "</ul></section>"
        for c in site["categories"])
    tools = "".join(f'<section><h2><a href="{L.group_url(gs)}">{esc(gn)}</a></h2><ul>' + "".join(
        f'<li><a href="{L.tool_url(s)}">{esc(TOOLS[s][0])}</a></li>' for s in sl) + "</ul></section>" for gs, gn, sl in GROUPS)
    pages = "".join(f'<li><a href="{L.page_url(s)}">{esc(t)}</a></li>' for s, t in cfg.INFO_PAGES)
    crumbs = [("Home", "/"), ("Sitemap", None)]
    main = (f'{L.breadcrumb(crumbs)}<header class="page-head"><h1>Sitemap</h1><p>All pages on {cfg.SITE_NAME}. Machine-readable versions: '
            '<a href="/sitemap.xml">sitemap.xml</a>, <a href="/rss.xml">RSS</a>, <a href="/atom.xml">Atom</a>.</p></header>'
            f'<h2>Pages</h2><ul class="cols">{pages}</ul><div class="sitemap-grid">{cats}</div><h2>Tools</h2><div class="sitemap-grid">{tools}</div>')
    write("/sitemap/", L.page(site, L.head("Sitemap", f"HTML sitemap of every {cfg.SITE_NAME} article, tool and page.", "/sitemap/",
                                           jsonld=[L.breadcrumb_ld(crumbs)]), main, with_sidebar=False))


# ------------------------------------------------------------------ feeds & root files
def build_feeds(site):
    latest = site["posts"][:50]
    items = "".join(
        f"<item><title>{xesc(p['title'])}</title><link>{L.url(p['url'])}</link><guid isPermaLink=\"true\">{L.url(p['url'])}</guid>"
        f"<category>{xesc(p['cat']['name'])}</category><pubDate>{dt.datetime.combine(p['date'], dt.time(8)).strftime('%a, %d %b %Y %H:%M:%S +0000')}</pubDate>"
        f"<description>{xesc(p['desc'])}</description></item>\n" for p in latest)
    write("/rss.xml", f"""<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom"><channel>
<title>{cfg.SITE_NAME}</title><link>{cfg.BASE_URL}/</link><description>{xesc(cfg.DESCRIPTION)}</description><language>en</language>
<atom:link href="{L.url('/rss.xml')}" rel="self" type="application/rss+xml" />
{items}</channel></rss>
""", sitemap=False)
    entries = "".join(
        f"<entry><title>{xesc(p['title'])}</title><link href=\"{L.url(p['url'])}\" /><id>{L.url(p['url'])}</id>"
        f"<updated>{p['date'].isoformat()}T08:00:00Z</updated><category term=\"{xesc(p['cat']['name'])}\" /><summary>{xesc(p['desc'])}</summary></entry>\n"
        for p in latest)
    write("/atom.xml", f"""<?xml version="1.0" encoding="UTF-8"?>
<feed xmlns="http://www.w3.org/2005/Atom"><title>{cfg.SITE_NAME}</title><subtitle>{xesc(cfg.TAGLINE)}</subtitle>
<link href="{cfg.BASE_URL}/" /><link href="{L.url('/atom.xml')}" rel="self" /><id>{cfg.BASE_URL}/</id>
<updated>{TODAY.isoformat()}T08:00:00Z</updated><author><name>{cfg.SITE_NAME}</name></author>
{entries}</feed>
""", sitemap=False)


def build_root_files():
    write("/robots.txt", f"User-agent: *\nAllow: /\nDisallow: /search/\n\nSitemap: {L.url('/sitemap.xml')}\n", sitemap=False)
    write("/ads.txt", cfg.ADS_TXT, sitemap=False)
    write("/app-ads.txt", cfg.ADS_TXT, sitemap=False)
    write("/" + cfg.GOOGLE_VERIFY_FILE, f"google-site-verification: {cfg.GOOGLE_VERIFY_FILE}", sitemap=False)
    write("/manifest.json", json.dumps({
        "name": cfg.SITE_NAME, "short_name": cfg.SITE_SHORT, "description": cfg.DESCRIPTION,
        "start_url": "/", "scope": "/", "display": "standalone", "background_color": "#ffffff",
        "theme_color": cfg.THEME_COLOR, "lang": "en",
        "icons": [{"src": "/icon-192.png", "sizes": "192x192", "type": "image/png"},
                  {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any maskable"},
                  {"src": "/favicon.svg", "sizes": "any", "type": "image/svg+xml"}],
    }, indent=2), sitemap=False)
    write("/favicon.svg", ICON_SVG, sitemap=False)
    write("/favicon.png", icon_png(48), sitemap=False)
    write("/icon-192.png", icon_png(192), sitemap=False)
    write("/icon-512.png", icon_png(512), sitemap=False)
    write("/img/logo.svg", LOGO_SVG.replace("currentColor", "#0b1b3a"), sitemap=False)
    write("/img/logo-light.svg", LOGO_SVG.replace("currentColor", "#ffffff"), sitemap=False)
    write("/img/og-default.svg", figure_svg("og", 215, cfg.SITE_NAME, cfg.TAGLINE), sitemap=False)


def build_sitemap_xml():
    urls = "".join(f"<url><loc>{L.url(p)}</loc><lastmod>{m}</lastmod><changefreq>{'daily' if p == '/' else 'weekly'}</changefreq>"
                   f"<priority>{'1.0' if p == '/' else '0.7'}</priority></url>\n" for p, m in written)
    write("/sitemap.xml", f'<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n{urls}</urlset>\n', sitemap=False)


def main():
    global OUT
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", default="public", help="output folder (default: public)")
    ap.add_argument("--base-url", help="absolute site URL for canonical links and sitemaps")
    args = ap.parse_args()
    if args.base_url:
        cfg.BASE_URL = args.base_url.rstrip("/")
    OUT = os.path.join(ROOT, args.out) if not os.path.isabs(args.out) else args.out
    if os.path.isdir(OUT):
        shutil.rmtree(OUT)
    shutil.copytree(os.path.join(ROOT, "static"), OUT)

    site = build_model()
    build_root_files()
    build_articles(site)
    build_home(site)
    build_categories(site)
    build_archive(site)
    build_search(site)
    build_tools(site)
    build_info_pages(site)
    build_sections(site)
    build_sitemap_page(site)
    build_feeds(site)
    build_sitemap_xml()
    words = [p["words"] for p in site["posts"]]
    print(f"Built {len(written)} pages into {OUT} — {len(site['posts'])} articles "
          f"({min(words)}–{max(words)} words), {len(TOOLS)} tools. Base URL: {cfg.BASE_URL}")


if __name__ == "__main__":
    sys.exit(main())
