// Network checks for the MIKRODINET tools that cannot run in a browser
// (raw TCP, TLS certificates, cross-origin HTTP). Called as
// /.netlify/functions/check?action=<name>&target=<host or url>[&port=]
import net from "node:net";
import tls from "node:tls";
import dns from "node:dns/promises";

const UA = "Mozilla/5.0 (compatible; MikrodinetChecker/1.0; +https://mikrodinet.netlify.app/)";
const MAX_BODY = 1_500_000;

const json = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json", "access-control-allow-origin": "*", "cache-control": "no-store" },
  });

function isPrivate(ip: string): boolean {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split(".").map(Number);
    return a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127) || a >= 224;
  }
  const v = ip.toLowerCase();
  if (v.startsWith("::ffff:")) return isPrivate(v.slice(7));
  return v === "::1" || v === "::" || v.startsWith("fc") || v.startsWith("fd") || v.startsWith("fe80");
}

async function assertPublic(host: string) {
  if (!host || host.length > 253) throw new Error("Enter a valid host name");
  const addrs = net.isIP(host) ? [{ address: host }] : await dns.lookup(host, { all: true });
  if (!addrs.length) throw new Error("Host does not resolve");
  for (const a of addrs) if (isPrivate(a.address)) throw new Error("Private or reserved addresses are not allowed");
  return addrs.map((a) => a.address);
}

function toUrl(target: string): URL {
  const u = new URL(/^https?:\/\//i.test(target) ? target : `https://${target}`);
  if (!/^https?:$/.test(u.protocol)) throw new Error("Only http and https URLs are supported");
  return u;
}

function hostOf(target: string): string {
  return target.replace(/^[a-z]+:\/\//i, "").split(/[/?#:]/)[0].trim().toLowerCase();
}

async function safeFetch(url: URL, init: RequestInit = {}) {
  await assertPublic(url.hostname);
  return fetch(url, {
    ...init,
    redirect: "manual",
    signal: AbortSignal.timeout(12000),
    headers: { "user-agent": UA, accept: "*/*", ...(init.headers || {}) },
  });
}

async function followRedirects(start: URL, max = 10) {
  const chain: { url: string; status: number; location?: string; ms: number }[] = [];
  let url = start;
  for (let i = 0; i <= max; i++) {
    const t = Date.now();
    const res = await safeFetch(url);
    const loc = res.headers.get("location") || undefined;
    chain.push({ url: url.href, status: res.status, location: loc, ms: Date.now() - t });
    if (res.status >= 300 && res.status < 400 && loc) {
      await res.body?.cancel();
      url = new URL(loc, url);
      continue;
    }
    return { chain, final: res, finalUrl: url };
  }
  throw new Error("Too many redirects");
}

async function readBody(res: Response) {
  const reader = res.body?.getReader();
  if (!reader) return { text: "", bytes: 0 };
  const chunks: Uint8Array[] = [];
  let bytes = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    bytes += value.length;
    if (bytes <= MAX_BODY) chunks.push(value);
    else { await reader.cancel(); break; }
  }
  return { text: Buffer.concat(chunks).toString("utf8"), bytes };
}

const headersObj = (h: Headers) => Object.fromEntries([...h.entries()]);

function tcpProbe(host: string, port: number, timeout = 6000) {
  return new Promise<{ open: boolean; ms: number; error?: string }>((resolve) => {
    const t = Date.now();
    const s = net.connect({ host, port });
    const done = (open: boolean, error?: string) => { s.destroy(); resolve({ open, ms: Date.now() - t, error }); };
    s.setTimeout(timeout, () => done(false, "timeout"));
    s.once("connect", () => done(true));
    s.once("error", (e) => done(false, (e as NodeJS.ErrnoException).code || e.message));
  });
}

function smtpSession(host: string, port: number) {
  return new Promise<{ log: string[]; ms: number }>((resolve, reject) => {
    const t = Date.now();
    const log: string[] = [];
    const s = net.connect({ host, port });
    let stage = 0;
    let buf = "";
    s.setTimeout(10000, () => { s.destroy(); log.length ? resolve({ log, ms: Date.now() - t }) : reject(new Error("Connection timed out (port may be blocked)")); });
    s.on("error", (e) => reject(e));
    s.on("data", (d) => {
      buf += d.toString();
      if (!/(^|\n)\d{3} [^\n]*\r?\n$/.test(buf)) return; // wait for the final line of a reply
      log.push(...buf.trim().split(/\r?\n/).map((l) => "S: " + l));
      buf = "";
      if (stage === 0) { log.push("C: EHLO mikrodinet.checker"); s.write("EHLO mikrodinet.checker\r\n"); stage = 1; }
      else if (stage === 1) { log.push("C: QUIT"); s.write("QUIT\r\n"); stage = 2; }
      else { s.end(); resolve({ log, ms: Date.now() - t }); }
    });
    s.on("close", () => resolve({ log, ms: Date.now() - t }));
  });
}

function sslInfo(host: string, port = 443) {
  return new Promise<Record<string, unknown>>((resolve, reject) => {
    const s = tls.connect({ host, port, servername: host, rejectUnauthorized: false, timeout: 10000 }, () => {
      const c = s.getPeerCertificate(true);
      const validTo = new Date(c.valid_to);
      resolve({
        host, port, authorized: s.authorized, authorizationError: s.authorizationError || null,
        protocol: s.getProtocol(), cipher: s.getCipher()?.name,
        subject: c.subject, issuer: c.issuer, validFrom: c.valid_from, validTo: c.valid_to,
        daysRemaining: Math.floor((validTo.getTime() - Date.now()) / 86400000),
        serialNumber: c.serialNumber, fingerprint256: c.fingerprint256,
        altNames: (c.subjectaltname || "").split(", ").map((x) => x.replace(/^DNS:/, "")).filter(Boolean),
        chain: (() => {
          const out: string[] = [];
          let cur: tls.DetailedPeerCertificate | undefined = c;
          const seen = new Set<string>();
          while (cur && cur.fingerprint256 && !seen.has(cur.fingerprint256)) {
            seen.add(cur.fingerprint256);
            out.push(cur.subject?.CN || cur.subject?.O || "(unnamed)");
            cur = cur.issuerCertificate;
          }
          return out;
        })(),
      });
      s.end();
    });
    s.on("timeout", () => { s.destroy(); reject(new Error("TLS handshake timed out")); });
    s.on("error", reject);
  });
}

function detectStack(h: Headers, html: string) {
  const server = h.get("server") || "";
  const powered = h.get("x-powered-by") || "";
  const all = `${server} ${powered}`.toLowerCase();
  let os = "Unknown (hidden by server)";
  if (/win|iis|asp\.net/.test(all)) os = "Windows Server";
  else if (/ubuntu/.test(all)) os = "Linux (Ubuntu)";
  else if (/debian/.test(all)) os = "Linux (Debian)";
  else if (/centos|red hat|rhel|fedora/.test(all)) os = "Linux (Red Hat family)";
  else if (/freebsd/.test(all)) os = "FreeBSD";
  else if (/unix|linux|nginx|apache|litespeed|openresty|caddy/.test(all)) os = "Linux / Unix (likely)";
  const tech: string[] = [];
  const add = (cond: boolean, name: string) => cond && !tech.includes(name) && tech.push(name);
  add(/cloudflare/.test(all) || h.has("cf-ray"), "Cloudflare");
  add(h.has("x-nf-request-id") || /netlify/.test(all), "Netlify");
  add(h.has("x-vercel-id"), "Vercel");
  add(/nginx/.test(all), "Nginx"); add(/apache/.test(all), "Apache"); add(/litespeed/.test(all), "LiteSpeed");
  add(/iis/.test(all), "Microsoft IIS"); add(/php/.test(all), "PHP"); add(/express/.test(all), "Express (Node.js)");
  add(/asp\.net/.test(all) || h.has("x-aspnet-version"), "ASP.NET");
  add(/wp-content|wordpress/i.test(html), "WordPress"); add(/blogger|blogspot/i.test(html), "Blogger");
  add(/cdn\.shopify|shopify/i.test(html), "Shopify"); add(/__next|_next\/static/.test(html), "Next.js");
  add(/wix\.com/i.test(html), "Wix"); add(/squarespace/i.test(html), "Squarespace"); add(/joomla/i.test(html), "Joomla");
  add(/drupal/i.test(html), "Drupal"); add(/react/i.test(html) && /data-reactroot|__react/i.test(html), "React");
  add(/googletagmanager\.com/.test(html), "Google Tag Manager"); add(/adsbygoogle/.test(html), "Google AdSense");
  const gen = html.match(/<meta[^>]+name=["']generator["'][^>]*content=["']([^"']+)/i)?.[1];
  if (gen) add(true, `Generator: ${gen}`);
  return { server: server || null, poweredBy: powered || null, os, tech };
}

export default async (req: Request) => {
  const q = new URL(req.url).searchParams;
  const action = q.get("action") || "";
  const target = (q.get("target") || "").trim();
  if (!target) return json({ error: "Missing target" }, 400);
  try {
    switch (action) {
      case "headers": {
        const u = toUrl(target);
        const t = Date.now();
        const res = await safeFetch(u);
        await res.body?.cancel();
        return json({ url: u.href, status: res.status, statusText: res.statusText, ms: Date.now() - t, headers: headersObj(res.headers) });
      }
      case "redirect": {
        const { chain, final } = await followRedirects(toUrl(target));
        await final.body?.cancel();
        return json({ chain });
      }
      case "fetch": {
        const t = Date.now();
        const { chain, final, finalUrl } = await followRedirects(toUrl(target));
        const body = await readBody(final);
        return json({ url: finalUrl.href, status: final.status, ms: Date.now() - t, redirects: chain.length - 1,
          headers: headersObj(final.headers), bytes: body.bytes, body: body.text });
      }
      case "gzip": {
        const u = toUrl(target);
        const plain = await safeFetch(u, { headers: { "accept-encoding": "identity" } });
        const plainBody = await readBody(plain);
        const comp = await safeFetch(u, { headers: { "accept-encoding": "gzip, deflate, br" } });
        const enc = comp.headers.get("content-encoding");
        const len = Number(comp.headers.get("content-length")) || null;
        await comp.body?.cancel();
        return json({ url: u.href, status: comp.status, encoding: enc, compressedBytes: len, uncompressedBytes: plainBody.bytes,
          vary: comp.headers.get("vary"), contentType: comp.headers.get("content-type") });
      }
      case "os": {
        const { final } = await followRedirects(toUrl(target));
        const body = await readBody(final);
        return json({ status: final.status, ...detectStack(final.headers, body.text), headers: headersObj(final.headers) });
      }
      case "down": {
        const u = toUrl(target);
        const t = Date.now();
        try {
          const { final } = await followRedirects(u);
          await final.body?.cancel();
          return json({ url: u.href, up: final.status < 500, status: final.status, ms: Date.now() - t });
        } catch (e) {
          return json({ url: u.href, up: false, error: (e as Error).message, ms: Date.now() - t });
        }
      }
      case "ssl": {
        const host = hostOf(target);
        await assertPublic(host);
        return json(await sslInfo(host, Number(q.get("port")) || 443));
      }
      case "port": {
        const host = hostOf(target);
        const ips = await assertPublic(host);
        const ports = (q.get("port") || "80").split(",").map((p) => parseInt(p, 10)).filter((p) => p > 0 && p < 65536).slice(0, 12);
        const results = await Promise.all(ports.map(async (port) => ({ port, ...(await tcpProbe(ips[0], port)) })));
        return json({ host, ip: ips[0], results });
      }
      case "smtp": {
        const host = hostOf(target);
        const ips = await assertPublic(host);
        const port = Number(q.get("port")) || 25;
        return json({ host, ip: ips[0], port, ...(await smtpSession(ips[0], port)) });
      }
      case "mac": {
        const mac = target.replace(/[^0-9a-f]/gi, "").slice(0, 6);
        if (mac.length < 6) return json({ error: "Enter at least the first 6 hex digits" }, 400);
        const r = await fetch(`https://api.macvendors.com/${mac}`, { signal: AbortSignal.timeout(8000) });
        return json({ oui: mac.toUpperCase().match(/../g)!.join(":"), vendor: r.ok ? (await r.text()).trim() : null, status: r.status });
      }
      default:
        return json({ error: "Unknown action" }, 400);
    }
  } catch (e) {
    return json({ error: (e as Error).message || "Check failed" }, 502);
  }
};
