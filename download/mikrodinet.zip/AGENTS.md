# AGENTS.md

Read **PLAN.md** first — it lists what is done and what remains.

## Architecture
- `generator.py` — entry point; builds every page into `public/<path>/index.html`, plus feeds, sitemap, root files. `public/` is a build artifact (gitignored).
- `mkgen/layout.py` — shared head/header/sidebar/footer; every page must go through `L.head()` + `L.page()` so required meta tags stay on all files.
- `mkgen/article_engine.py` — deterministic long-form article templates (seeded by slug).
- `mkgen/assets.py` — SVG figures/logo and PNG icons, no external deps.
- `static/js/tools*.js` — tool apps registered as `MK.reg[slug] = fn(root)`; helpers live on `window.MK` in `tools.js`. Tool pages render `<section id="tool-app" data-tool="slug">`.
- `netlify/functions/check.mts` — server-side checks (headers, redirect, fetch, gzip, os, down, ssl, port, smtp, mac); blocks private IPs.

## Conventions
- Python: stdlib only (Netlify build runs plain `python3`). Escape all text with `esc()`.
- JS: ES5-style IIFEs, no bundler. Browser-side DNS uses DNS-over-HTTPS.
- Do not run build commands in agent sessions; Netlify builds on deploy.

## Non-obvious
- `tools-b.js` exists but is not yet included on tool pages (see PLAN.md step 8).
- Forms post via fetch to `/` and redirect to `/thank-you/`.
