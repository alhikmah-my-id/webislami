"""Copy for the footer information pages and the Hardware / Software sections."""

S = "MIKRODINET"

INFO = {
    "about-us": ("About MIKRODINET", "Who we are, what we publish and the free tools we build.", [
        ("Our Mission", f"{S} exists to make complex subjects understandable and to give everyone access to professional-grade online tools for free. We publish long-form explainers across 25 categories — from the macro economy and public policy to culture, science and sport — and we maintain more than 80 browser-based utilities for DNS, IP, networking, security, design and webmaster work."),
        ("What We Publish", "Our articles are structured reference guides. Each one defines its subject, traces its history, explains the forces that drive it, compares regional perspectives and finishes with a checklist, FAQs and a clear conclusion. We link to authoritative outside sources so readers can verify facts and go deeper."),
        ("Our Tools", "Most tools run entirely in your browser, so the data you type never leaves your device. Tools that need a network connection, such as port, SSL or HTTP header checks, run through a lightweight serverless checker that does not store your queries."),
        ("Independence", f"{S} is funded by advertising. Advertisers never influence editorial decisions, and sponsored content, when published, is always clearly labelled."),
    ]),
    "contact-us": ("Contact Us", "Send a message to the MIKRODINET team.", [
        ("Get in Touch", "Questions, corrections, partnership proposals or tool requests — we read every message. Use the form below and we will reply by email, usually within two business days."),
        ("Corrections", "If you spot a factual error in an article, please include the page address and a source for the correct information. We review every correction request and update articles where appropriate."),
    ]),
    "privacy-policy": ("Privacy Policy", "How MIKRODINET collects, uses and protects information.", [
        ("Information We Collect", "We collect the information you choose to send through our contact forms (name, email address and message). Our hosting provider records standard server logs such as IP address, browser type and pages visited for security and performance purposes."),
        ("Cookies and Advertising", "We use Google AdSense to display advertisements. Google and its partners use cookies to serve ads based on your prior visits to this and other websites. Google's use of advertising cookies enables it and its partners to serve ads based on your visits. You may opt out of personalised advertising by visiting Google Ads Settings at https://adssettings.google.com/. Third-party vendors may also use cookies; you can opt out of some vendors at https://www.aboutads.info/."),
        ("Tools and Your Data", "Most tools process data locally in your browser. Network tools send only the hostname, URL or IP address you enter to our checker in order to return a result; these queries are not stored or shared."),
        ("Your Rights", "Depending on where you live, you may have the right to access, correct or delete personal data we hold about you. Contact us through the Contact page to make a request."),
        ("Changes", "We may update this policy from time to time. The latest version is always published on this page."),
    ]),
    "license": ("License", "Terms for reusing MIKRODINET content and tools.", [
        ("Content License", f"Unless otherwise stated, articles on {S} may be quoted in short excerpts with a visible link back to the original page. Republishing full articles requires written permission."),
        ("Tools", "Our online tools are free for personal and commercial use. Automated, high-volume access that degrades service for other users is not permitted."),
        ("Trademarks", "Product names, logos and brands mentioned on this site are the property of their respective owners and are used for identification purposes only."),
    ]),
    "terms-and-conditions": ("Terms and Conditions", "The rules for using MIKRODINET.", [
        ("Acceptance", f"By using {S} you agree to these terms. If you do not agree, please do not use the site."),
        ("Use of the Site", "You agree not to misuse the site, attempt to disrupt its services, scan networks you are not authorised to test, or use our tools for unlawful purposes."),
        ("No Warranty", "Content and tools are provided as is, without warranties of any kind. Results from tools are informational and should be verified before you rely on them for critical decisions."),
        ("Limitation of Liability", f"{S} is not liable for any loss arising from the use of this site or its tools to the maximum extent permitted by law."),
    ]),
    "choices": ("Your Privacy Choices", "Control cookies and personalised advertising.", [
        ("Personalised Ads", "You can turn off personalised advertising from Google at https://adssettings.google.com/. Visitors in the EEA, UK and Switzerland are shown a consent message where required."),
        ("Browser Controls", "Most browsers let you block or delete cookies. Blocking all cookies may affect how some features work."),
        ("Do Not Sell or Share", "We do not sell personal information. To exercise your choices under applicable state privacy laws, contact us through the Contact page."),
    ]),
    "disclaimer": ("Disclaimer", "Important information about our content.", [
        ("General Information", f"Articles on {S} are for general information and education. They are not financial, legal, medical or professional advice. Always consult a qualified professional for advice specific to your situation."),
        ("External Links", "We link to external websites for reference. We are not responsible for the content or practices of those sites."),
        ("Tool Results", "Network and security tools return results based on public data at the time of the check and may not reflect every configuration."),
    ]),
    "partner": ("Partner With Us", "Collaborate with MIKRODINET.", [
        ("Partnership Opportunities", "We work with universities, research organisations, software companies and media outlets on content partnerships, tool integrations and co-branded resources."),
        ("How to Start", "Tell us about your organisation and your idea through the Contact page. We respond to every serious proposal."),
    ]),
    "editorial": ("Editorial Policy", "How we research, write and update articles.", [
        ("Standards", "Every article is structured to be accurate, balanced and useful. We cite reputable primary sources, distinguish fact from opinion and avoid sensational claims."),
        ("Updates and Corrections", "Articles are reviewed and updated as new evidence emerges. Significant corrections are noted at the end of the article."),
        ("Opinion Content", "Pieces in our Commentary section reflect the views of their authors and are labelled accordingly."),
    ]),
    "advertise": ("Advertise", "Reach readers interested in business, technology and global affairs.", [
        ("Our Audience", f"{S} reaches professionals, students, developers and decision makers looking for in-depth explainers and practical tools."),
        ("Formats", "Display advertising is served through Google AdSense. Sponsorships of tool pages and newsletters are available on request."),
        ("Contact", "Send an enquiry through the Contact page with your campaign goals and timeline."),
    ]),
    "join-the-team": ("Join the Team", "Write, research or build tools with MIKRODINET.", [
        ("Writers and Researchers", "We welcome experienced writers and subject-matter experts in economics, technology, policy, culture and science."),
        ("Developers", "Help us build and improve free tools for the web community. Experience with JavaScript, networking or security is a plus."),
        ("Apply", "Send a short introduction and samples of your work through the Contact page."),
    ]),
    "news-update": ("News Update", "Latest updates from MIKRODINET.", [
        ("What's New", "We regularly add new explainers and tools. Follow our RSS or Atom feed to be notified of every new article."),
        ("Recent Additions", "Our latest release includes 250 long-form guides across 25 categories and more than 80 online tools."),
    ]),
    "academy": ("MIKRODINET Academy", "Structured learning paths built from our guides and tools.", [
        ("Learning Paths", "The Academy groups our articles into learning paths — Economics Fundamentals, Digital Infrastructure, Web Publishing and Public Policy — so you can learn step by step."),
        ("Hands-On Practice", "Each path pairs reading with practical tools, such as DNS lookups or SEO audits, so you can apply what you learn immediately."),
    ]),
    "e-course": ("E-Course", "Self-paced online courses.", [
        ("Available Courses", "Networking Basics, DNS and Domain Management, Website Security Essentials and SEO for Beginners are in preparation."),
        ("Register Interest", "Use the Contact page to be notified when enrolment opens."),
    ]),
    "training": ("Training", "Workshops for teams and organisations.", [
        ("Corporate Training", "We offer practical workshops on network troubleshooting, web security hygiene and data-driven publishing."),
        ("Custom Programmes", "Tell us about your team's needs and we will design a programme to match."),
    ]),
    "private": ("Private Consulting", "One-to-one guidance for businesses and site owners.", [
        ("Services", "Website audits, DNS and email deliverability reviews, AdSense readiness checks and content strategy sessions."),
        ("Book a Session", "Request a consultation through the Contact page."),
    ]),
    "forum": ("Community Forum", "Connect with other MIKRODINET readers.", [
        ("Join the Conversation", "Our community forum is a place to ask questions about networking, web publishing and the topics we cover. Share tips, request tools and help others."),
        ("Community Guidelines", "Be respectful, stay on topic and never share personal data or credentials publicly."),
    ]),
}

HW_FEATURES = [
    "Typical use cases and deployment scenarios",
    "Key specifications to compare before buying",
    "Power, mounting and environmental considerations",
    "Licensing levels and software features",
    "Compatible accessories and modules",
    "Configuration tips for first-time setup",
]

SECTION_INTRO = {
    "hardware": "Networking hardware guide: what each product family does, what to look for and how to choose.",
    "software": "Networking software resources: operating systems, management utilities, downloads and release notes.",
}
