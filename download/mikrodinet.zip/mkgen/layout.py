"""Shared page chrome: <head>, header + dropdown navbar, sidebar, footer."""
import json
from urllib.parse import quote

from . import config as cfg
from .article_engine import esc
from .tools import GROUPS, TOOLS


def url(path):
    return cfg.BASE_URL + path


def tool_url(slug):
    return f"/tools/{slug}/"


def group_url(slug):
    return f"/tools/category/{slug}/"


def cat_url(slug):
    return f"/category/{slug}/"


def page_url(slug):
    return f"/{slug}/"


def section_item_url(section, name):
    from .article_engine import slugify
    return f"/{section}/{slugify(name)}/"


# ---------------------------------------------------------------- head
def head(title, desc, path, keywords=None, og_type="website", image="/img/og-default.svg",
         jsonld=None, extra=""):
    full_title = title if cfg.SITE_NAME in title else f"{title} | {cfg.SITE_NAME}"
    canonical = url(path)
    img = image if image.startswith("http") else url(image)
    ld = [{
        "@context": "https://schema.org", "@type": "Organization", "name": cfg.SITE_NAME,
        "url": cfg.BASE_URL + "/", "logo": url("/icon-512.png"),
        "sameAs": [s[1] for s in cfg.SOCIAL[:5]],
    }]
    ld += jsonld or []
    ld_html = "\n".join(
        '<script type="application/ld+json">' + json.dumps(x, ensure_ascii=False).replace("</", "<\\/") + "</script>"
        for x in ld)
    return f"""<!DOCTYPE html>
<html lang="{cfg.LANG}">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>{esc(full_title)}</title>
<meta name="title" content="{esc(full_title)}" />
<meta name="description" content="{esc(desc)}" />
<meta name="keywords" content="{esc(keywords or cfg.KEYWORDS)}" />
<meta name="robots" content="index, follow, max-image-preview:large" />
<meta name="author" content="{cfg.SITE_NAME}" />
<meta name="theme-color" content="{cfg.THEME_COLOR}" />
{cfg.HEAD_VERIFICATION}
<link rel="icon" type="image/png" href="/favicon.png" />
<link rel="icon" type="image/svg+xml" href="/favicon.svg" />
<link rel="apple-touch-icon" href="/icon-192.png" />
<link rel="canonical" href="{canonical}" />
<link rel="manifest" href="/manifest.json" />
<link rel="alternate" type="application/rss+xml" title="{cfg.SITE_NAME} RSS" href="/rss.xml" />
<link rel="alternate" type="application/atom+xml" title="{cfg.SITE_NAME} Atom" href="/atom.xml" />
<meta property="og:site_name" content="{cfg.SITE_NAME}" />
<meta property="og:type" content="{og_type}" />
<meta property="og:title" content="{esc(full_title)}" />
<meta property="og:description" content="{esc(desc)}" />
<meta property="og:url" content="{canonical}" />
<meta property="og:image" content="{img}" />
<meta property="og:locale" content="en_US" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="{esc(full_title)}" />
<meta name="twitter:description" content="{esc(desc)}" />
<meta name="twitter:image" content="{img}" />
{ld_html}
<link rel="stylesheet" href="/css/site.css" />
{extra}
</head>
<body>
"""


# ---------------------------------------------------------------- header
def _dd(label, items, mega=False):
    lis = "".join(f'<li><a href="{u}">{esc(n)}</a></li>' for n, u in items)
    cls = "dd mega" if mega else "dd"
    return (f'<li class="has-dd"><button type="button" class="dd-toggle" aria-expanded="false">{esc(label)}'
            f'<span class="caret" aria-hidden="true">▾</span></button><ul class="{cls}">{lis}</ul></li>')


def header(site):
    cats = [(c["name"], cat_url(c["slug"])) for c in site["categories"]]
    news = [(n, cat_url(cfg.LABEL_ALIASES[n])) for n in ["News", "Politics", "Economy", "Tech", "Sports", "International"]]
    culture = [(n, cat_url(cfg.LABEL_ALIASES[n])) for n in ["Culture", "History", "Arts", "Story", "Zodiac"]]
    tools = [(g[1], group_url(g[0])) for g in GROUPS] + [("All Tools", "/tools/")]
    hw = [(n, section_item_url("hardware", n)) for n in cfg.HARDWARE]
    sw = [(n, section_item_url("software", n)) for n in cfg.SOFTWARE] + [("Connectivity", group_url("network-tools")), ("Back to Home", "/")]
    wm = [(TOOLS[s][0], tool_url(s)) for g in GROUPS if g[0] in ("webmaster-tools", "performance-tools") for s in g[2]]
    return f"""<a class="skip" href="#main">Skip to content</a>
<header class="site-header">
<div class="wrap hdr">
<a class="logo" href="/" title="{cfg.SITE_NAME} — Home"><img src="/img/logo.svg" alt="{cfg.SITE_NAME} logo — go to home page" width="208" height="45" /></a>
<form class="hdr-search" action="/search/" method="get" role="search"><input type="search" name="q" placeholder="Search articles &amp; tools…" aria-label="Search" /><button type="submit" aria-label="Search">🔍</button></form>
<button type="button" class="nav-toggle" aria-expanded="false" aria-controls="nav">☰<span class="sr">Menu</span></button>
</div>
<nav id="nav" class="nav" aria-label="Main">
<ul class="wrap menu">
<li><a href="/">Home</a></li>
{_dd("Articles", cats, mega=True)}
{_dd("News", news)}
{_dd("Culture & Literature", culture)}
{_dd("Tools", tools, mega=True)}
{_dd("Webmaster", wm, mega=True)}
{_dd("Hardware", hw, mega=True)}
{_dd("Software", sw)}
<li><a href="/contact-us/">Contact</a></li>
</ul>
</nav>
</header>
"""


# ---------------------------------------------------------------- ads / share
def ad(label="Advertisement"):
    if not cfg.ADSENSE_SLOT:
        # Auto ads (enabled by the head script) fill the page; this marks the slot.
        return '<div class="ad-slot ad-auto" aria-hidden="true"></div>'
    return (f'<div class="ad-slot"><span class="ad-label">{label}</span>'
            f'<ins class="adsbygoogle" style="display:block" data-ad-client="{cfg.ADSENSE_CLIENT}" '
            f'data-ad-slot="{cfg.ADSENSE_SLOT}" data-ad-format="auto" data-full-width-responsive="true"></ins>'
            '<script>(adsbygoogle = window.adsbygoogle || []).push({});</script></div>')


def share(path, title):
    u = quote(url(path), safe="")
    t = quote(title, safe="")
    links = [
        ("Facebook", f"https://www.facebook.com/sharer/sharer.php?u={u}", "fb"),
        ("X", f"https://x.com/intent/post?url={u}&text={t}", "x"),
        ("LinkedIn", f"https://www.linkedin.com/sharing/share-offsite/?url={u}", "in"),
        ("WhatsApp", f"https://wa.me/?text={t}%20{u}", "wa"),
        ("Telegram", f"https://t.me/share/url?url={u}&text={t}", "tg"),
        ("Pinterest", f"https://pinterest.com/pin/create/button/?url={u}&description={t}", "pin"),
        ("Reddit", f"https://www.reddit.com/submit?url={u}&title={t}", "rd"),
        ("Email", f"mailto:?subject={t}&body={u}", "em"),
    ]
    a = "".join(f'<a class="sh sh-{c}" href="{h}" target="_blank" rel="noopener" aria-label="Share on {n}">{n}</a>' for n, h, c in links)
    return f'<div class="share"><strong>Share:</strong>{a}<button type="button" class="sh sh-copy" data-copy="{url(path)}">Copy link</button></div>'


def breadcrumb(items):
    lis = "".join(
        f'<li><a href="{u}">{esc(n)}</a></li>' if u else f'<li aria-current="page">{esc(n)}</li>' for n, u in items)
    return f'<nav class="crumbs" aria-label="Breadcrumb"><ol>{lis}</ol></nav>'


def breadcrumb_ld(items):
    return {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [
        {"@type": "ListItem", "position": i + 1, "name": n, **({"item": url(u)} if u else {})}
        for i, (n, u) in enumerate(items)]}


# ---------------------------------------------------------------- sidebar
def _post_list(posts):
    return "<ul class=\"post-list\">" + "".join(
        f'<li><a href="{p["url"]}"><img src="{p["thumb"]}" alt="{esc(p["title"])}" width="72" height="38" loading="lazy" />'
        f'<span>{esc(p["title"])}<small>{p["date_h"]}</small></span></a></li>' for p in posts) + "</ul>"


def contact_form(name="quick-contact", compact=True):
    msg_rows = 3 if compact else 7
    subject = "" if compact else '<label>Subject<input type="text" name="subject" required /></label>'
    return f"""<form class="contact-form" name="{name}" method="POST" action="/thank-you/" data-netlify="true" netlify-honeypot="bot-field">
<input type="hidden" name="form-name" value="{name}" />
<p class="hp"><label>Leave empty<input name="bot-field" /></label></p>
<label>Name<input type="text" name="name" required autocomplete="name" /></label>
<label>Email<input type="email" name="email" required autocomplete="email" /></label>
{subject}
<label>Message<textarea name="message" rows="{msg_rows}" required></textarea></label>
<button type="submit" class="btn">Send message</button>
</form>"""


def sidebar(site):
    social = "".join(f'<a class="soc soc-{c}" href="{u}" target="_blank" rel="noopener">{esc(n)}</a>' for n, u, c in cfg.SOCIAL)
    archive = "".join(f'<li><a href="/archive/#{k}">{esc(label)}</a> <span>({n})</span></li>' for k, label, n in site["archive"])
    labels = "".join(f'<a class="tag" href="{cat_url(c["slug"])}">{esc(c["name"])} <span>{c["count"]}</span></a>' for c in site["categories"])
    picks = "".join(f'<li><a href="{tool_url(s)}">{TOOLS[s][2]} {esc(TOOLS[s][0])}</a></li>' for s in site["tool_picks"])
    return f"""<aside class="sidebar">
<section class="widget"><h2 class="w-title">Search</h2>
<form action="/search/" method="get" role="search" class="side-search"><input type="search" name="q" placeholder="Search…" aria-label="Search the site" /><button type="submit" class="btn">Search</button></form>
<h3 class="w-sub">Follow us</h3><div class="socials">{social}</div></section>
{ad()}
<section class="widget"><h2 class="w-title">Popular Posts</h2>{_post_list(site["popular"])}</section>
<section class="widget"><h2 class="w-title">Archive</h2><ul class="archive-list">{archive}</ul></section>
<section class="widget"><h2 class="w-title">Labels</h2><div class="tags">{labels}</div></section>
<section class="widget"><h2 class="w-title">Tool Picks</h2><ul class="tool-picks">{picks}</ul><a class="more" href="/tools/">All tools →</a></section>
{ad()}
<section class="widget"><h2 class="w-title">Contact Form</h2>{contact_form()}</section>
<section class="widget"><h2 class="w-title">Oldest Posts</h2>{_post_list(site["oldest"])}</section>
</aside>"""


# ---------------------------------------------------------------- footer
def _col(title, items):
    return f'<div class="f-col"><h3>{esc(title)}</h3><ul>' + "".join(
        f'<li><a href="{u}">{esc(n)}</a></li>' for n, u in items) + "</ul></div>"


def footer(site):
    info = dict(cfg.INFO_PAGES)
    main_links = [("Home", "/"), ("About Us", "/about-us/"), ("Sitemaps", "/sitemap/"), ("Sitemap XML", "/sitemap.xml"),
                  ("RSS XML", "/rss.xml"), ("Atom XML", "/atom.xml"), ("Contact Us", "/contact-us/")]
    main_links += [(info[s], page_url(s)) for s in [
        "privacy-policy", "license", "terms-and-conditions", "choices", "disclaimer", "partner", "editorial",
        "advertise", "join-the-team", "news-update", "academy", "e-course", "training", "private"]]
    main_links.append(("Contact Forum Komunitas", "/forum/"))
    cols = [_col("Mikrodinet", main_links)]
    for gslug, gname, slugs in GROUPS:
        cols.append(_col(gname, [(TOOLS[s][0], tool_url(s)) for s in slugs]))
    cols.append(_col("Hardware", [(n, section_item_url("hardware", n)) for n in cfg.HARDWARE]))
    cols.append(_col("Software", [(n, section_item_url("software", n)) for n in cfg.SOFTWARE] + [("Back to Home", "/"), ("Connectivity", group_url("network-tools"))]))
    cols.append(_col("News Category", [(n, cat_url(cfg.LABEL_ALIASES[n])) for n in ["News", "Politics", "Economy", "Tech", "Sports", "International"]]))
    cols.append(_col("Culture & Literature", [(n, cat_url(cfg.LABEL_ALIASES[n])) for n in ["Culture", "History", "Arts", "Story", "Zodiac"]]))
    cols.append(_col("Tool Categories", [(g[1], group_url(g[0])) for g in GROUPS]))
    cols.append(_col("Article Categories", [(c["name"], cat_url(c["slug"])) for c in site["categories"]]))
    return f"""<footer class="site-footer">
<div class="wrap f-top">
<a class="logo f-logo" href="/"><img src="/img/logo-light.svg" alt="{cfg.SITE_NAME} logo" width="208" height="45" loading="lazy" /></a>
<p class="f-desc">{esc(cfg.DESCRIPTION)}</p>
</div>
<div class="wrap f-grid">{''.join(cols)}</div>
<div class="f-bottom"><div class="wrap">© {site["year"]} <a href="/">Mikrodinet</a> - All Rights Reserved</div></div>
</footer>
<script src="/js/site.js" defer></script>
"""


def page(site, head_html, main_html, with_sidebar=True, scripts=""):
    side = sidebar(site) if with_sidebar else ""
    layout = "layout" if with_sidebar else "layout full"
    return (head_html + header(site) + f'<div class="wrap {layout}"><main id="main">{main_html}</main>{side}</div>'
            + footer(site) + scripts + "</body>\n</html>\n")
