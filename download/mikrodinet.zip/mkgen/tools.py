"""Online tools registry.

Each tool is rendered at /tools/<slug>/ with its interactive app (static/js/tools.js
implements the app for every slug), a usage guide, related tools and share links.
"""

# slug: (name, short description, emoji)
TOOLS = {
    # DNS
    "dns-checker": ("DNS Checker", "Compare DNS answers for a domain across several public resolvers to check propagation.", "🌐"),
    "reverse-ip-lookup": ("Reverse IP Lookup", "Find the PTR (reverse DNS) hostname registered for an IPv4 or IPv6 address.", "🔁"),
    "dns-lookup": ("DNS Lookup", "Query A, AAAA, CNAME, MX, NS, TXT, SOA, CAA and SRV records for any domain.", "🔎"),
    "ns-lookup": ("NS Lookup", "List the authoritative name servers that answer for a domain.", "🗂️"),
    "mx-lookup": ("MX Lookup", "See the mail servers and priorities that receive email for a domain.", "📮"),
    "dns-health-checker": ("Domain DNS Health Checker", "Run a quick health report: A, NS, MX, SPF, DMARC, CAA and DNSSEC.", "🩺"),
    # IP
    "what-is-my-ip": ("What is My IP Address", "Show your public IP address, ISP, approximate location and browser details.", "📍"),
    "ip-location-lookup": ("IP Location Lookup", "Find the country, city, ISP and ASN for any public IP address.", "🗺️"),
    "email-header-analyzer": ("Trace Email (Header Analyzer)", "Paste raw email headers to trace hops, delays, SPF/DKIM/DMARC results.", "✉️"),
    "ip-blacklist-check": ("IP Blacklist & Email Blacklist Check", "Check an IP address against popular DNS blocklists (DNSBL).", "🚫"),
    "ip-whois-lookup": ("IP WHOIS Lookup", "Look up the network owner, range and registry for an IP address via RDAP.", "🏢"),
    "domain-to-ip": ("Domain to IP Lookup", "Resolve a domain name to its IPv4 and IPv6 addresses.", "➡️"),
    # Developer
    "http-headers-check": ("HTTP Headers Check", "Fetch a URL and inspect the full HTTP response headers and status.", "📑"),
    "website-os-check": ("Check Website Operating System", "Detect the web server, operating system hints and technology stack of a site.", "🖥️"),
    "md5-base64-generator": ("MD5 & Base64 Generator", "Create MD5, SHA hashes and encode or decode Base64 text instantly.", "#️⃣"),
    "smtp-test": ("SMTP Test", "Connect to a mail server and read its SMTP banner and EHLO capabilities.", "📨"),
    "binary-translator": ("Binary Translator", "Convert text to binary, hex, octal and decimal — and back again.", "0️⃣"),
    "json-viewer": ("JSON Viewer, Beautifier & Minifier", "Validate, pretty-print, minify and explore JSON as a collapsible tree.", "🧾"),
    # Designer
    "rgb-to-colortone": ("RGB to Colortone", "Convert RGB values to every color format and generate tints, shades and tones.", "🎨"),
    "hex-to-colortone": ("HEX to Colortone", "Convert HEX colors to RGB, HSL, HSV, CMYK and build a tone palette.", "🖌️"),
    "cmyk-to-colortone": ("CMYK to Colortone", "Convert print CMYK values to screen colors and matching tones.", "🖨️"),
    "hsv-to-colortone": ("HSV to Colortone", "Convert HSV/HSB values to HEX and RGB with a full tone ramp.", "🌈"),
    # Network
    "port-checker": ("Port Checker", "Test whether a TCP port is open and reachable on a host.", "🔌"),
    "mac-address-lookup": ("MAC Address Lookup", "Identify the hardware vendor from a MAC address OUI prefix.", "🏷️"),
    "mac-address-generator": ("MAC Address Generator", "Generate random, unicast or locally administered MAC addresses in any format.", "🎲"),
    "asn-whois-lookup": ("ASN WHOIS Lookup", "Look up an autonomous system number and its registered organisation.", "🛰️"),
    # Security
    "ssl-certificate-checker": ("SSL Certificate Checker", "Inspect a site's TLS certificate: issuer, validity dates, SANs and protocol.", "🔒"),
    "password-encryption": ("Password Encryption Online", "Hash a password with SHA-1, SHA-256, SHA-384, SHA-512 and PBKDF2.", "🔐"),
    "random-password-generator": ("Random Password Generator", "Generate strong random passwords and passphrases in your browser.", "🔑"),
    "password-strength-checker": ("Password Strength Checker", "Estimate password entropy, crack time and get improvement tips.", "🛡️"),
    # Productivity
    "qr-scanner": ("QR Scanner", "Scan QR codes from your camera or an uploaded image.", "📷"),
    "credit-card-checker": ("Credit Card Checker", "Validate a card number format with the Luhn algorithm and detect the brand.", "💳"),
    "reverse-image-search": ("Reverse Image Search", "Search an image URL across Google Lens, Bing, Yandex and TinEye at once.", "🖼️"),
    "name-checker": ("Name Checker", "Check a username or brand name across popular social networks and domains.", "🙋"),
    "morse-code-translator": ("Morse Code Translator", "Translate text to Morse code and back, with audio playback.", "📡"),
    "image-to-text": ("Image to Text Converter", "Extract text from photos and screenshots with in-browser OCR.", "🔤"),
    # DNS server database
    "global-dns-providers": ("Global DNS Providers", "Reference list of major public DNS resolvers with features and addresses.", "🌍"),
    "australian-dns-servers": ("Australian DNS Servers", "Public DNS servers operated in Australia.", "🇦🇺"),
    "uk-dns-servers": ("United Kingdom DNS Servers", "Public DNS servers operated in the United Kingdom.", "🇬🇧"),
    "us-dns-servers": ("United States DNS Servers", "Public DNS servers operated in the United States.", "🇺🇸"),
    # Webmaster
    "robots-txt-checker": ("Check Robots.txt", "Fetch and parse a site's robots.txt and test whether a path is allowed.", "🤖"),
    "favicon-generator": ("Favicon Generator", "Create favicons in every size from text, emoji or an uploaded image.", "⭐"),
    "ssl-checker": ("SSL Checker", "Quickly verify that HTTPS is configured and the certificate is valid.", "✅"),
    "xml-sitemap-validator": ("XML Sitemap Validator", "Fetch and validate an XML sitemap or sitemap index.", "🧭"),
    "responsive-checker": ("Responsive Checker", "Preview a website at phone, tablet, laptop and desktop widths.", "📱"),
    "domain-expiration-checker": ("Domain Expiration Checker", "See when a domain was registered and when it expires.", "⏳"),
    "gzip-compression-check": ("Check Gzip Compression", "Test whether a page is served with gzip or Brotli compression and how much is saved.", "🗜️"),
    "image-compression": ("PNG/JPG Compression", "Compress and resize PNG, JPG and WebP images privately in your browser.", "🪶"),
    "dummy-image-generator": ("Dummy Image Generator", "Create placeholder images of any size, color and label.", "🧱"),
    "redirect-checker": ("Redirect Checker Tool", "Follow a URL's redirect chain and see each status code.", "↪️"),
    "site-down-checker": ("Site Drop Or Not", "Check if a website is down for everyone or just you.", "📉"),
    "ab-test-calculator": ("A/B Test Calculator", "Calculate conversion lift and statistical significance for A/B tests.", "📊"),
    "qr-code-generator": ("Free QR Code Generator", "Create QR codes for links, text, Wi-Fi and contacts; download as PNG.", "🔳"),
    "english-spell-check": ("English Spell Check", "Check English spelling and grammar and get suggestions.", "📝"),
    # Operational
    "screen-resolution": ("Check My Screen Resolution", "Show your screen size, viewport, pixel ratio and color depth.", "🖥"),
    "share-link-creator": ("Creator Share Link", "Generate share links for Facebook, X, WhatsApp, LinkedIn and more.", "🔗"),
    "lorem-ipsum-generator": ("Lorem Ipsum Generator", "Generate placeholder paragraphs, sentences or words.", "📄"),
    "multiple-url-opener": ("Multiple URL Opener", "Open a list of URLs in new tabs with one click.", "🗃️"),
    "js-css-minifier": ("JS & CSS Minifier", "Minify JavaScript and CSS to reduce file size.", "⚡"),
    "js-css-parser": ("JS & CSS Parser", "Beautify and format JavaScript and CSS for readability.", "🧩"),
    "amp-validator": ("AMP Validator", "Validate AMP HTML markup with the official AMP validator.", "⚡️"),
    "domain-name-generator": ("Domain Name Generator", "Brainstorm brandable domain names from keywords.", "💡"),
    # Studio tools
    "online-code-editor": ("Online Code Editor", "Write HTML, CSS and JavaScript with a live preview.", "💻"),
    "color-code-generator": ("Color Code Generator", "Generate random and harmonious color palettes with codes.", "🎯"),
    "audio-equalizer-generator": ("Equalizer & Audio Generator", "Generate test tones and noise, and visualise audio with a live equalizer.", "🎚️"),
    "multilingual-keyboard": ("Keyboard Multi Bahasa", "On-screen keyboard for Arabic, Russian, Greek, Hebrew, Hindi and more.", "⌨️"),
    "arabic-calligraphy": ("Arabic Calligraphy Tool", "Render Arabic text in calligraphic fonts and download as PNG.", "🖋️"),
    "quranclip-studio": ("QuranClip Studio Live", "Create shareable verse cards from any ayah with translation.", "🎬"),
    "postal-code-finder": ("Postal Code Finder", "Look up places by postal code or postal codes by place.", "📫"),
    "interactive-maps-search": ("Interactive Maps Search", "Search any address or landmark on an interactive map.", "🗺"),
    "seo-performance-analyzer": ("SEO Performance Analyzer", "Audit a page's title, meta tags, headings, links, images and speed signals.", "🚀"),
    "quran-play": ("Quran Play", "Listen to Quran recitation surah by surah with Arabic text.", "🎧"),
    # Domain
    "whois-lookup": ("WHOIS Lookup", "Look up domain registration details: registrar, dates, status and name servers.", "📇"),
    "domain-age-checker": ("Domain Age Checker", "Find out how old a domain is from its registration date.", "📅"),
    "domain-adsense-eligibility": ("Domain AdSense Eligibility", "Check a site against common AdSense readiness requirements.", "💰"),
    "domain-price": ("Domain Price", "Compare typical registration and renewal prices for popular TLDs.", "🏷"),
    "search-engine-submitter": ("Domain Open to 100 Search Engines", "Open your domain in 100 search engines and index checkers with one click.", "📣"),
    # Productivity (extra)
    "bimi-checker": ("BIMI Checker & Generator", "Check a domain's BIMI record and generate a valid one.", "🏵️"),
    "runic-translator": ("Runic Translator", "Transliterate Latin text into Elder Futhark, Younger Futhark and Anglo-Saxon runes.", "ᚱ"),
    "invisible-text-generator": ("Invisible Character & Text Generator", "Copy invisible Unicode characters and blank text.", "👻"),
    "internet-speed-test": ("Internet Speed Test", "Test your download speed, upload speed and latency.", "🏎️"),
    "wifi-qr-scanner": ("WiFi QR Scanner", "Scan a Wi-Fi QR code to reveal the network name and password.", "📶"),
    # Gaming
    "minecraft-color-codes": ("Minecraft Color Codes", "Minecraft § format and color codes with a live MOTD preview.", "⛏️"),
}

# (slug, group name, tool slugs) — order matches the menus in the brief.
GROUPS = [
    ("dns-tools", "DNS Tools", ["dns-checker", "reverse-ip-lookup", "dns-lookup", "ns-lookup", "mx-lookup", "dns-health-checker"]),
    ("ip-tools", "IP Tools", ["what-is-my-ip", "ip-location-lookup", "email-header-analyzer", "ip-blacklist-check", "ip-whois-lookup", "domain-to-ip"]),
    ("developer-tools", "Developer Tools", ["http-headers-check", "website-os-check", "md5-base64-generator", "smtp-test", "binary-translator", "json-viewer"]),
    ("designer-tools", "Designer Tools", ["rgb-to-colortone", "hex-to-colortone", "cmyk-to-colortone", "hsv-to-colortone"]),
    ("network-tools", "Network Tools", ["port-checker", "mac-address-lookup", "mac-address-generator", "asn-whois-lookup"]),
    ("cyber-security-tools", "Cyber Security Tools", ["ssl-certificate-checker", "password-encryption", "random-password-generator", "password-strength-checker"]),
    ("productivity-tools", "Productivity Tools", ["qr-scanner", "credit-card-checker", "reverse-image-search", "name-checker", "morse-code-translator", "image-to-text", "bimi-checker", "runic-translator", "invisible-text-generator", "internet-speed-test", "wifi-qr-scanner"]),
    ("dns-server-database", "DNS Server Database", ["global-dns-providers", "australian-dns-servers", "uk-dns-servers", "us-dns-servers"]),
    ("webmaster-tools", "Webmasters Tools", ["robots-txt-checker", "favicon-generator", "ssl-checker", "xml-sitemap-validator", "responsive-checker", "domain-expiration-checker"]),
    ("performance-tools", "Performance Tools", ["gzip-compression-check", "image-compression", "dummy-image-generator", "redirect-checker", "site-down-checker", "ab-test-calculator", "qr-code-generator", "english-spell-check"]),
    ("operational-tools", "Operational Tools", ["screen-resolution", "share-link-creator", "lorem-ipsum-generator", "multiple-url-opener", "js-css-minifier", "js-css-parser", "amp-validator", "domain-name-generator"]),
    ("equipment", "Equipment", ["image-compression", "qr-code-generator", "share-link-creator", "domain-expiration-checker", "site-down-checker", "multiple-url-opener"]),
    ("studio-tools", "Tools", ["online-code-editor", "qr-code-generator", "color-code-generator", "audio-equalizer-generator", "multilingual-keyboard", "arabic-calligraphy", "quranclip-studio", "postal-code-finder", "interactive-maps-search", "seo-performance-analyzer", "quran-play"]),
    ("domain-tools", "Domain Tools", ["whois-lookup", "domain-age-checker", "domain-expiration-checker", "dns-checker", "reverse-ip-lookup", "domain-to-ip", "domain-adsense-eligibility", "domain-price", "search-engine-submitter"]),
    ("gaming-tools", "Gaming Tools", ["minecraft-color-codes"]),
]

# Reference links shown on tool pages, by group.
GROUP_EXTERNALS = {
    "default": [
        ("MDN Web Docs", "https://developer.mozilla.org/"), ("IETF RFC Index", "https://www.rfc-editor.org/"),
        ("ICANN", "https://www.icann.org/"), ("Cloudflare Learning Center", "https://www.cloudflare.com/learning/"),
        ("Google Search Central", "https://developers.google.com/search"), ("W3C", "https://www.w3.org/"),
        ("OWASP", "https://owasp.org/"),
    ],
    "dns-tools": [("Cloudflare: What is DNS?", "https://www.cloudflare.com/learning/dns/what-is-dns/"), ("RFC 1035", "https://www.rfc-editor.org/rfc/rfc1035"),
                  ("Google Public DNS", "https://developers.google.com/speed/public-dns"), ("ICANN", "https://www.icann.org/"),
                  ("IANA Root Zone", "https://www.iana.org/domains/root"), ("DNSViz", "https://dnsviz.net/"), ("MDN: DNS", "https://developer.mozilla.org/en-US/docs/Glossary/DNS")],
    "ip-tools": [("IANA Number Resources", "https://www.iana.org/numbers"), ("ARIN", "https://www.arin.net/"), ("RIPE NCC", "https://www.ripe.net/"),
                 ("APNIC", "https://www.apnic.net/"), ("Spamhaus", "https://www.spamhaus.org/"), ("RFC 5322", "https://www.rfc-editor.org/rfc/rfc5322"), ("MaxMind", "https://www.maxmind.com/")],
    "cyber-security-tools": [("OWASP", "https://owasp.org/"), ("NIST Digital Identity Guidelines", "https://pages.nist.gov/800-63-3/"), ("Let's Encrypt", "https://letsencrypt.org/"),
                             ("Have I Been Pwned", "https://haveibeenpwned.com/"), ("SSL Labs", "https://www.ssllabs.com/"), ("CISA", "https://www.cisa.gov/"), ("Mozilla Observatory", "https://developer.mozilla.org/en-US/observatory")],
    "designer-tools": [("W3C CSS Color", "https://www.w3.org/TR/css-color-4/"), ("Adobe Color", "https://color.adobe.com/"), ("Coolors", "https://coolors.co/"),
                       ("WebAIM Contrast Checker", "https://webaim.org/resources/contrastchecker/"), ("Material Design Color", "https://m3.material.io/styles/color/overview"),
                       ("Pantone", "https://www.pantone.com/"), ("MDN: color", "https://developer.mozilla.org/en-US/docs/Web/CSS/color_value")],
}
