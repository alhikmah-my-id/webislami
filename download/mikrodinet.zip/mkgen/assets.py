"""Image assets generated without external dependencies: SVG article figures,
the site logo, and PNG icons for the favicon and web manifest."""
import html
import random
import struct
import zlib


def figure_svg(seed, hue, label, sub):
    r = random.Random(seed)
    h2 = (hue + r.randint(25, 70)) % 360
    shapes = []
    for _ in range(14):
        x, y = r.randint(0, 1200), r.randint(0, 630)
        rad = r.randint(30, 190)
        op = r.uniform(0.05, 0.22)
        shapes.append(f'<circle cx="{x}" cy="{y}" r="{rad}" fill="#fff" opacity="{op:.2f}"/>')
    pts = " ".join(f"{i * 100},{r.randint(330, 520)}" for i in range(13))
    bars = "".join(
        f'<rect x="{760 + i * 48}" y="{560 - v}" width="30" height="{v}" rx="4" fill="#fff" opacity=".55"/>'
        for i, v in enumerate(r.randint(60, 260) for _ in range(8)))
    label = html.escape(label[:60])
    sub = html.escape(sub[:80])
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 630" width="1200" height="630" role="img" aria-label="{label}">
<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="hsl({hue},70%,32%)"/><stop offset="1" stop-color="hsl({h2},75%,48%)"/></linearGradient></defs>
<rect width="1200" height="630" fill="url(#g)"/>{''.join(shapes)}
<polyline points="{pts}" fill="none" stroke="#fff" stroke-width="5" opacity=".6"/>{bars}
<text x="60" y="110" font-family="Georgia,serif" font-size="54" font-weight="700" fill="#fff">{label}</text>
<text x="60" y="165" font-family="Arial,sans-serif" font-size="28" fill="#fff" opacity=".9">{sub}</text>
<text x="60" y="590" font-family="Arial,sans-serif" font-size="24" font-weight="700" fill="#fff" letter-spacing="4">MIKRODINET</text>
</svg>'''


LOGO_SVG = '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 260 56" width="260" height="56" role="img" aria-label="MIKRODINET">
<defs><linearGradient id="lg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#0b3d91"/><stop offset="1" stop-color="#1fa2ff"/></linearGradient></defs>
<rect x="2" y="4" width="48" height="48" rx="12" fill="url(#lg)"/>
<path d="M13 40V16l13 13 13-13v24" fill="none" stroke="#fff" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
<text x="60" y="38" font-family="Georgia,serif" font-size="27" font-weight="700" fill="currentColor" letter-spacing="1">MIKRODINET</text>
</svg>'''

ICON_SVG = '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="#0b3d91"/>
<path d="M15 47V18l17 17 17-17v29" fill="none" stroke="#fff" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/></svg>'''

# 9x9 bitmap of the "M" glyph used for PNG icons.
_M = [
    "000000000",
    "010000010",
    "011000110",
    "010101010",
    "010010010",
    "010000010",
    "010000010",
    "010000010",
    "000000000",
]


def icon_png(size):
    bg, fg = (11, 61, 145), (255, 255, 255)
    cell = size / 9
    rows = []
    for y in range(size):
        row = bytearray([0])
        gy = min(8, int(y / cell))
        for x in range(size):
            gx = min(8, int(x / cell))
            row += bytes(fg if _M[gy][gx] == "1" else bg)
        rows.append(bytes(row))
    raw = zlib.compress(b"".join(rows), 9)

    def chunk(tag, data):
        c = struct.pack(">I", len(data)) + tag + data
        return c + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", raw) + chunk(b"IEND", b""))
