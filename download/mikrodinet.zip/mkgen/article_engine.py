"""Long-form article builder.

Turns a (headline, keyword, category) triple into a structured English article
with H2-H6 headings, a table of contents, a data table, three figures, seven
internal links, seven external links, a quiz, six FAQs and a conclusion.
Text is assembled from editorial templates; variants are chosen
deterministically from the article slug so rebuilds are stable.
"""
import html
import random
import re

YEAR = 2026


def esc(s):
    return html.escape(s, quote=True)


def slugify(s):
    s = re.sub(r"[^a-zA-Z0-9]+", "-", s.lower()).strip("-")
    return re.sub(r"-+", "-", s)


def cap(s):
    return s[:1].upper() + s[1:]


def title_case(s):
    small = {"and", "or", "the", "of", "in", "on", "for", "to", "a", "an", "at", "by", "with", "versus"}
    out = []
    for i, w in enumerate(s.split()):
        if w.isupper() or any(c.isupper() for c in w[1:]):
            out.append(w)
        elif i and w.lower() in small:
            out.append(w.lower())
        else:
            out.append(w[:1].upper() + w[1:])
    return " ".join(out)


# ---------------------------------------------------------------------------
# Templates.  Placeholders: {k} keyword, {K} capitalised keyword, {field},
# {cat}, {t1}..{t6} key concepts, {a1}..{a4} stakeholders, {year}.
# Sentences avoid using {k} as a grammatical subject so singular and plural
# keywords both read naturally.
# ---------------------------------------------------------------------------

INTRO_1 = [
    "Few subjects in {field} attract as much attention, or as much confusion, as {k}. The topic appears in headlines, in boardroom presentations and in conversations around the kitchen table, yet the details are often lost somewhere between slogans and statistics. This guide sets out to change that. Over the following sections we unpack what {k} means, where the idea came from, how it works in practice and why it matters to {a1}, {a2} and {a3} alike. The goal is not to tell you what to think, but to give you a clear framework you can use to read the news, weigh the evidence and make better decisions of your own.",
    "If you follow {field} even casually, you have almost certainly come across {k}. It is one of those subjects that seems simple until you try to explain it, and then it turns out to rest on a web of assumptions, data and history. In this in-depth guide we take the topic apart piece by piece. We start with definitions, move through the historical background, examine the forces that drive outcomes and finish with practical advice and an honest look at what may come next. Along the way we connect {k} to wider themes such as {t1}, {t2} and {t3}.",
    "Ask ten people to explain {k} and you are likely to hear ten different answers. Some will focus on {t1}, others on {t2}, and a few will point to the decisions of {a1}. Each of those answers captures part of the truth, but none tells the whole story. This article brings the pieces together. It is designed as a complete reference: long enough to cover the subject properly, structured so you can jump straight to the part you need, and grounded in the research and data that specialists in {field} rely on every day.",
]
INTRO_2 = [
    "Why does this matter now? In {year}, {field} is being reshaped by rapid technological change, shifting demographics and a more uncertain global environment. Decisions made today by {a1} and {a2} will echo for years. Understanding {k} helps you see past short-term noise and recognise the structural trends underneath. It also helps you ask better questions: who benefits, who bears the cost, what evidence supports a claim and what would change the picture. Those questions form the backbone of everything that follows.",
    "The timing is important. Over the past few years, conditions in {field} have shifted faster than many forecasters expected, and {k} has moved from a specialist concern to a mainstream one. That change brings opportunity as well as risk. Readers who understand the underlying mechanics are better placed to spot trends early, avoid common mistakes and engage constructively with debates that affect their work, their money and their communities.",
]
INTRO_3 = [
    "This article is written for curious readers rather than specialists, but it does not shy away from detail. Where useful we include tables, step-by-step explanations, a short quiz and frequently asked questions. You can jump to any section using the table of contents, or read from start to finish for a complete picture. If you only have a few minutes, the conclusion summarises the key takeaways and the checklist offers practical next steps you can apply straight away.",
    "To keep things practical, each section ends with ideas you can use. We have also included a comparison table, a checklist, a quick quiz to test your understanding and answers to the questions readers ask most often. Links throughout the text point to related guides on MIKRODINET and to authoritative outside sources, so you can go deeper on any point that interests you.",
]

DEF_1 = [
    "At its core, {k} refers to the set of ideas, practices and outcomes that determine how {field} responds to a particular challenge or opportunity. Specialists sometimes use narrower, more technical definitions, and those can be useful in research. For most readers, however, a practical definition works better: the subject is about how choices made by {a1} and {a2} add up to results that everyone else experiences. Seen this way, {k} is less an abstract concept and more a lens for understanding cause and effect in the real world.",
    "Put simply, {k} describes a pattern of behaviour and results within {field}. Textbooks may offer precise formulas or formal models, but the everyday meaning is more intuitive. When people talk about {k}, they are usually asking how a system works, why it produces the outcomes it does and what could be changed to improve them. Holding onto that plain-language definition makes the more technical material later in this guide much easier to follow.",
]
DEF_CORE = [
    "Three building blocks appear again and again in serious discussions of {k}. The first is {t1}, which sets the basic conditions everything else depends on. The second is {t2}, which determines how quickly change can happen and who can respond. The third is {t3}, which often decides whether gains are shared widely or captured by a few. These elements do not operate in isolation. They reinforce or offset one another, which is why simple, single-cause explanations so often fail to predict what actually happens.",
    "It helps to think of {k} as the product of several interacting parts. {T1} provides the foundation. {T2} acts as an accelerator or a brake. {T3} shapes the distribution of results. When analysts disagree about the subject, they are usually disagreeing about the relative weight of these parts rather than about whether they matter at all. Keeping all three in view is the single most useful habit for anyone trying to make sense of new developments.",
]
DEF_MEASURE = [
    "Measurement matters because what gets measured tends to get managed. Analysts usually look at a mix of quantitative indicators and qualitative evidence. Quantitative data might include changes in {t1}, trends in {t2} and survey results from {a3}. Qualitative evidence comes from case studies, interviews and expert judgement. No single number tells the whole story, so the most reliable assessments triangulate several sources and look at trends over time rather than isolated data points.",
    "There is no single official yardstick for {k}, but there are well-established ways to track it. Researchers combine headline statistics with more detailed indicators, compare results across countries and time periods, and test their conclusions against what {a3} and {a4} report on the ground. When numbers and lived experience point in the same direction, confidence rises. When they diverge, that gap is itself a valuable clue that something important is being missed.",
]
GLOSS = [
    "a foundational factor that sets the starting conditions",
    "a lever that decision makers can adjust over time",
    "a source of both opportunity and risk",
    "an indicator analysts watch for early warning signs",
    "a force that shapes who gains and who loses",
    "a long-term structural trend rather than a short-term shock",
    "a practical consideration that often decides success or failure",
    "a factor that varies strongly between regions",
]

HISTORY = [
    ("Early Foundations",
     ["Interest in {k} is not new. Long before modern data existed, merchants, scholars and officials were grappling with versions of the same questions. Their tools were limited, but their observations were often sharp. They noticed that {t1} could change fortunes quickly and that decisions made by a small number of actors could affect entire communities. Many of the principles still used today can be traced back to these early attempts to bring order to a complicated world.",
      "The roots of today's thinking about {k} reach back further than most people assume. Early records show communities experimenting with rules, institutions and customs designed to manage {t1} and {t2}. Not every experiment worked, but the successful ones were copied and refined. That slow process of trial and error laid the groundwork for the more systematic approaches that followed."]),
    ("The Twentieth-Century Turning Point",
     ["The twentieth century transformed the study of {k}. New institutions, new statistics and new academic disciplines made it possible to measure what had previously only been guessed at. Crises played a role too: periods of disruption exposed weaknesses in existing approaches and forced {a1} and {a2} to rethink their assumptions. By the end of the century, a broad professional consensus had emerged, even if fierce debates continued over the details.",
      "Industrialisation, global conflict and the growth of modern government all left their mark on {k}. Each upheaval tested established ideas, and each recovery brought fresh thinking. Professional bodies, research centres and international organisations began to collect comparable data, allowing lessons from one place to inform decisions in another. Much of the vocabulary used today, including the language around {t3}, became standard during this period."]),
    ("The Digital Era",
     ["The arrival of the internet and cheap computing changed the speed and scale of everything connected to {k}. Information that once took months to gather became available in seconds. That brought obvious benefits, such as better forecasting and greater transparency, but also new challenges, including information overload and the rapid spread of misleading claims. The digital era also lowered barriers to entry, giving smaller players and individuals a voice that was previously reserved for large institutions.",
      "Digital technology rewired the subject from the ground up. Real-time data, online platforms and automated analysis allowed {a1} to respond faster than ever, while {a3} gained access to tools and information that were once out of reach. At the same time, faster feedback loops meant that mistakes could spread more quickly too. Learning to balance speed with judgement has been one of the defining challenges of this period."]),
    ("Where We Stand in {year}",
     ["Today, {k} sits at the intersection of several powerful trends: changing demographics, new technologies, environmental pressures and a more fragmented global order. The old playbooks still contain valuable lessons, but they need updating. The most thoughtful practitioners are those who combine historical perspective with an openness to new evidence, recognising that the future rarely looks exactly like the past.",
      "In {year}, the conversation around {k} is more informed and more contested than ever. Better data has settled some old arguments while opening new ones. Attention has shifted toward {t5} and {t6}, reflecting broader concerns about resilience and fairness. For readers, this means there is more good information available than at any point in history, and also more need for careful judgement in deciding what to trust."]),
]

DRIVER = [
    "{T} is one of the most important levers. When conditions around {t} improve, the effects ripple outward: {a1} gain room to plan, {a2} adjust their expectations and the wider system becomes more resilient. When they deteriorate, the reverse happens, often faster than people expect. The relationship is rarely linear. Small changes in {t} can have outsized effects when a system is already under strain, while large changes may be absorbed quietly when conditions are stable. Watching {t} closely therefore gives an early signal of where {k} is heading.",
    "The role of {t} is often underestimated. It works quietly in the background, shaping incentives and constraints long before its effects show up in headline figures. Crucially, {t} interacts with other factors, especially {o}, so its impact depends on context. In one setting it may amplify positive trends; in another it may expose hidden weaknesses. Good analysis treats {t} not as a fixed input but as a moving part whose influence changes over time.",
    "Consider {t} as an example of how structural forces shape outcomes. Unlike sudden shocks, changes in {t} tend to build gradually, which makes them easy to overlook and hard to reverse. Over several years, however, they can redraw the landscape entirely. {A3} who recognise these shifts early are better positioned to adapt, while those who wait for certainty often find that the window for easy action has already closed.",
    "Discussions of {k} that ignore {t} are incomplete. Evidence from research and from practitioners in {field} consistently shows that {t} affects both the size and the distribution of outcomes. Where it is handled well, benefits tend to spread more widely; where it is neglected, gains concentrate and frustration grows. That is why so many reform proposals, whatever their political flavour, eventually return to the question of how to manage {t} more effectively.",
]
STEPS = [
    ("Recognising the Starting Conditions",
     "Every situation involving {k} begins with a set of initial conditions. These include the current state of {t1}, the resources available to {a1} and the expectations held by {a3}. Taking an honest inventory at the outset prevents later surprises. It also creates a baseline against which progress can be measured, which is essential for learning what actually works."),
    ("Mapping the Stakeholders",
     "Next comes understanding who is involved and what each party wants. {A1}, {a2}, {a3} and {a4} rarely share identical goals. Some prioritise stability, others growth, others fairness or speed. Mapping these interests makes it easier to anticipate reactions, build coalitions and design approaches that are durable rather than fragile."),
    ("Weighing the Options",
     "With a clear picture of conditions and stakeholders, the options can be compared. Each choice involves trade-offs between short-term and long-term effects, between certainty and flexibility, and between different groups. The best decisions are rarely perfect; they are the ones whose costs are understood, acknowledged and managed."),
    ("Implementing and Adjusting",
     "Implementation is where theory meets reality. Plans that look elegant on paper often run into practical obstacles: limited capacity, unexpected behaviour, or changes in {t2}. Successful approaches build in feedback loops so that early results can inform adjustments. Flexibility at this stage is a strength, not a weakness."),
    ("Reviewing the Results",
     "Finally, results need to be reviewed honestly. Did the approach achieve its goals? Were there side effects? What would be done differently next time? This review closes the loop and turns individual experiences with {k} into shared knowledge that improves future decisions across {field}."),
]
BENEFITS = [
    ("Greater Stability", "A well-understood approach to {k} brings predictability. When {a1} and {a2} know what to expect, they can plan with confidence, invest for the long term and avoid costly overreactions. Stability is not the same as stagnation; it is the foundation on which healthy change can be built."),
    ("Better Decisions", "Clear frameworks lead to clearer choices. Understanding the mechanics of {k} helps decision makers separate signal from noise, focus on the factors that genuinely matter and avoid being swayed by fashionable but unsupported claims. The payoff is fewer mistakes and faster recovery when mistakes do happen."),
    ("New Opportunities for {A3}", "Change creates openings. Shifts in {t1} and {t2} can lower barriers, open new markets or create demand for fresh ideas and skills. {A3} who understand the dynamics of {k} are well placed to spot these openings early and act on them before they become crowded."),
    ("Long-Term Resilience", "Perhaps the biggest benefit is resilience. Systems that manage {k} thoughtfully tend to absorb shocks better and recover faster. That resilience protects the most vulnerable, preserves trust and keeps options open for the future."),
]
RISKS = [
    ("Unequal Impacts", "The effects of {k} are rarely shared evenly. Some groups gain while others bear disproportionate costs, and those patterns can persist for years. Ignoring distribution can undermine public support even for approaches that look successful on average."),
    ("Data Gaps and Uncertainty", "Good decisions depend on good information, yet data on {k} is often incomplete, delayed or revised. Uncertainty is unavoidable, but overconfidence is optional. The wisest practitioners treat forecasts as ranges rather than precise predictions."),
    ("Short-Termism", "Pressure for quick results can push {a1} toward choices that look good this quarter or this year but create problems later. Balancing immediate needs with long-term health remains one of the hardest challenges in {field}."),
    ("Unintended Consequences", "Complex systems respond in surprising ways. Measures intended to improve {t3} can inadvertently harm {t4}, or shift problems from one group to another. Careful monitoring and a willingness to change course are the best defences."),
]
REGIONS = [
    ("Asia-Pacific", "Southeast Asia",
     "The Asia-Pacific region offers some of the most dynamic examples of {k}. Rapid urbanisation, young populations in some countries and ageing ones in others create a striking diversity of conditions. Governments and businesses across the region have experimented boldly, and the results provide valuable lessons for the rest of the world.",
     "In Southeast Asia, including Indonesia, Malaysia, Vietnam and the Philippines, the interaction between {t1} and {t2} is particularly visible. Fast-growing digital adoption and a rising middle class are changing expectations quickly, while infrastructure and institutions work to keep pace."),
    ("Europe", "Northern and Southern Europe",
     "Europe's approach to {k} tends to emphasise coordination, regulation and social protection. Shared institutions encourage common standards, but national differences remain significant. The European experience shows both the benefits of collective action and the difficulty of finding solutions that fit very different economies and cultures.",
     "Northern European countries often lead on {t5}, while Southern European economies have faced tougher trade-offs around {t2}. The contrast highlights how history, institutions and public expectations shape outcomes even within a single union."),
    ("The Americas", "Latin America",
     "Across the Americas, approaches to {k} range from market-led to strongly state-directed. The United States and Canada benefit from deep capital markets and large research bases, while Latin American countries often combine remarkable entrepreneurial energy with greater exposure to external shocks.",
     "In Latin America, volatility in {t1} has historically been a defining feature, encouraging innovative responses from {a3} and {a4}. Recent reforms in several countries show how credible institutions can reduce that volatility over time."),
    ("Africa and the Middle East", "Sub-Saharan Africa",
     "Africa and the Middle East include some of the world's fastest-growing populations and most rapidly evolving markets. Mobile technology has allowed parts of the region to leapfrog older infrastructure, creating new models that others now study closely.",
     "In Sub-Saharan Africa, young demographics and rapid adoption of digital services are reshaping {k}. Challenges around {t6} remain, but local innovation is increasingly setting the agenda rather than simply following trends from elsewhere."),
]
ACTOR = [
    "{A} play a central role. Their decisions set the tone for everyone else, and their expectations influence behaviour long before formal action is taken. When {a} communicate clearly and act consistently, uncertainty falls and confidence rises. When they send mixed signals, the resulting confusion can be costly.",
    "For {a}, the subject of {k} is not abstract: it shapes daily choices and long-term plans. Their collective behaviour can amplify or dampen trends, which is why surveys and feedback from {a} are watched so closely by analysts across {field}.",
    "{A} bring expertise, resources and accountability. They often act as a bridge between high-level strategy and practical reality, translating broad goals into concrete steps. Their perspective is especially valuable when assessing whether an approach is working on the ground.",
    "{A} are sometimes treated as passive recipients of change, but in practice they are active participants. Their choices, preferences and feedback steer outcomes in ways that top-down plans frequently underestimate.",
]
CHECKLIST = [
    "Define clearly what {k} means in your own context before drawing conclusions.",
    "Track at least three indicators, including {t1} and {t2}, rather than relying on one headline number.",
    "Compare current data with long-term trends to separate noise from genuine change.",
    "Identify which stakeholders, such as {a1} and {a3}, are most exposed to change.",
    "Read at least two independent sources before accepting a strong claim.",
    "Consider second-order effects: what might change as a result of the first change?",
    "Write down your assumptions so you can revisit them when new evidence arrives.",
    "Review your position regularly — at least once a quarter — and update it honestly.",
]
MYTHS = [
    ("{K} only matters to experts.", "In reality, the effects reach almost everyone. Specialists may study the details, but the outcomes show up in prices, jobs, services and opportunities that shape ordinary lives."),
    ("There is one simple fix.", "Complex systems rarely have single solutions. Lasting progress usually comes from combining several measures, adjusting them over time and paying attention to how {t3} and {t4} interact."),
    ("Past patterns always repeat.", "History offers valuable lessons, but conditions change. New technologies, demographics and institutions mean that old rules of thumb need to be tested against current evidence rather than applied mechanically."),
]
OUTLOOK = [
    ("The Next Twelve Months", "In the short term, expect developments in {k} to be driven largely by {t1} and {t2}. Headlines will swing between optimism and concern, but the underlying direction is likely to be gradual rather than dramatic. Watch for revisions to official data, changes in tone from {a1} and early signals from {a3}."),
    ("The Next Five Years", "Over a five-year horizon, structural forces take centre stage. Technology, demographics and climate-related pressures will increasingly shape {k}, and the importance of {t5} is likely to grow. Organisations that invest now in skills, data and flexible strategies will be best positioned to benefit."),
]

QUIZ = [
    ("Which of the following is described in this guide as a foundational building block of {k}?",
     ["{T1}", "Random chance alone", "Weather on a single day", "None of the above"], 0),
    ("What is the best way to assess developments in {k}?",
     ["Rely on one headline number", "Track several indicators over time", "Ignore historical data", "Follow social media trends only"], 1),
    ("Which stakeholder group is highlighted as a key actor in {field}?",
     ["Only foreign tourists", "{A1}", "Nobody in particular", "Only fictional characters"], 1),
]


class Ctx:
    """Fills templates for one article."""

    def __init__(self, cat, title, keyword, slug):
        self.r = random.Random(slug)
        t = cat["terms"]
        a = cat["actors"]
        self.v = {
            "k": keyword, "K": cap(keyword), "title": title, "field": cat["field"],
            "cat": cat["name"], "year": YEAR,
        }
        for i in range(6):
            self.v[f"t{i + 1}"] = t[i]
            self.v[f"T{i + 1}"] = cap(t[i])
        for i in range(4):
            self.v[f"a{i + 1}"] = a[i]
            self.v[f"A{i + 1}"] = cap(a[i])

    def f(self, s, **extra):
        v = dict(self.v)
        v.update(extra)
        return s.format(**v)

    def pick(self, options, **extra):
        return self.f(self.r.choice(options), **extra)


def _p(text):
    return f"<p>{text}</p>\n"


def build_article(cat, title, keyword, slug, internal, externals, images):
    """Return dict(body, toc, faqs, words).

    internal: list of 7 (title, url); externals: list of 7 dict(name,url);
    images: list of 3 dict(src, alt, caption).
    """
    c = Ctx(cat, title, keyword, slug)
    K = c.v["K"]
    toc = []
    out = []
    used_ids = set()

    def h(level, text, in_toc=True):
        hid = slugify(text)[:60] or "section"
        base, n = hid, 2
        while hid in used_ids:
            hid = f"{base}-{n}"
            n += 1
        used_ids.add(hid)
        if in_toc and level <= 3:
            toc.append((level, text, hid))
        out.append(f'<h{level} id="{hid}">{esc(text)}</h{level}>\n')

    def ilink(i):
        t, u = internal[i % len(internal)]
        return f'<a href="{u}">{esc(t)}</a>'

    def xlink(i):
        x = externals[i % len(externals)]
        return f'<a href="{x["url"]}" target="_blank" rel="noopener">{esc(x["name"])}</a>'

    def figure(i):
        im = images[i]
        out.append(
            f'<figure class="art-fig"><img src="{im["src"]}" alt="{esc(im["alt"])}" width="1200" height="630" loading="lazy" decoding="async">'
            f'<figcaption>{esc(im["caption"])}</figcaption></figure>\n')

    # Introduction
    h(2, f"Introduction to {title_case(keyword)}")
    out.append(_p(c.pick(INTRO_1)))
    out.append(_p(c.pick(INTRO_2) + f" For a related perspective, see our guide to {ilink(0)}."))
    figure(0)
    out.append(_p(c.pick(INTRO_3)))

    # Definition
    h(2, f"Understanding {title_case(keyword)}: A Clear Definition")
    out.append(_p(c.pick(DEF_1)))
    h(3, "The Core Building Blocks")
    out.append(_p(c.pick(DEF_CORE) + f" Reference material from {xlink(0)} is a reliable starting point for the formal definitions."))
    h(3, "How Specialists Measure It")
    out.append(_p(c.pick(DEF_MEASURE) + f" Datasets published by {xlink(1)} are widely used for this kind of comparison."))
    h(3, "Key Terms You Will Encounter")
    gloss = list(GLOSS)
    c.r.shuffle(gloss)
    out.append("<ul class=\"terms\">\n" + "".join(
        f"<li><strong>{esc(cap(term))}</strong> — {gloss[i]}.</li>\n" for i, term in enumerate(cat["terms"])) + "</ul>\n")

    # History
    h(2, f"A Brief History of {title_case(keyword)}")
    for i, (head, paras) in enumerate(HISTORY):
        h(3, c.f(head))
        extra = f" Our explainer on {ilink(1)} covers a parallel story." if i == 2 else ""
        out.append(_p(c.pick(paras) + extra))

    # Drivers
    h(2, "Key Factors That Drive Outcomes")
    out.append(_p(c.f("Several forces shape {k}. Some act quickly and visibly; others work slowly beneath the surface. The six factors below appear most often in research and in the experience of practitioners across {field}. Understanding each one, and how they interact, is the key to interpreting new developments with confidence.")))
    terms = cat["terms"]
    for i, term in enumerate(terms):
        h(3, f"{cap(term)} and Its Influence")
        para = c.pick(DRIVER, t=term, T=cap(term), o=terms[(i + 2) % 6])
        if i == 1:
            para += f" Analysis from {xlink(2)} explores this relationship in more depth."
        if i == 3:
            para += f" We look at a closely related issue in {ilink(2)}."
        out.append(_p(para))
        if i == 0:
            h(4, f"What to Watch in {cap(term)}")
            out.append(_p(c.f("Practical signals include changes in direction, sudden accelerations and divergence between official figures and what {a3} report. A sustained shift across several months is far more meaningful than a single surprising data point.")))
    figure(1)

    # Table
    h(2, f"{title_case(keyword)} at a Glance: Comparison Table")
    out.append(_p(c.f("The table below summarises how each major factor tends to influence {k} over different time horizons and which groups feel the effects most directly. Treat it as a simplified guide rather than a precise model; real-world conditions vary by country, sector and period.")))
    effects = ["Low", "Moderate", "High", "Variable", "Significant", "Gradual"]
    rows = []
    for i, term in enumerate(terms):
        rows.append(
            f"<tr><td>{esc(cap(term))}</td><td>{c.r.choice(effects)}</td><td>{c.r.choice(effects)}</td>"
            f"<td>{esc(cap(cat['actors'][i % 4]))}</td><td>{c.r.choice(['Rising', 'Stable', 'Mixed', 'Growing focus'])}</td></tr>")
    out.append('<div class="table-wrap"><table><caption>' + esc(f"How key factors shape {keyword}") +
               '</caption><thead><tr><th>Factor</th><th>Short-term impact</th><th>Long-term impact</th>'
               '<th>Most affected</th><th>' + str(YEAR) + ' trend</th></tr></thead><tbody>' + "".join(rows) + "</tbody></table></div>\n")

    # How it works
    h(2, "How It Works in Practice: Step by Step")
    out.append(_p(c.f("Abstract explanations only go so far. To see how {k} plays out in reality, it helps to walk through the typical sequence of events, from the initial conditions to the final review. While every case is different, this five-step pattern appears again and again.")))
    for i, (head, para) in enumerate(STEPS):
        h(3, f"Step {i + 1}: {head}")
        extra = f" For practical tools that support this kind of analysis, try {ilink(3)}." if i == 2 else ""
        out.append(_p(c.f(para) + extra))

    # Benefits / risks
    h(2, "Benefits and Opportunities")
    for i, (head, para) in enumerate(BENEFITS):
        h(3, c.f(head))
        extra = f" Research by {xlink(3)} highlights similar findings." if i == 1 else ""
        out.append(_p(c.f(para) + extra))
    h(2, "Risks, Challenges and Criticisms")
    for i, (head, para) in enumerate(RISKS):
        h(3, head)
        extra = f" Read more in our coverage of {ilink(4)}." if i == 2 else ""
        out.append(_p(c.f(para) + extra))

    # Regions (H3 -> H4 -> H5 -> H6)
    h(2, f"Global Perspectives on {title_case(keyword)}")
    for i, (region, sub, p1, p2) in enumerate(REGIONS):
        h(3, region)
        out.append(_p(c.f(p1)))
        h(4, sub, in_toc=False)
        extra = f" Regional reports from {xlink(4)} provide useful context." if i == 0 else ""
        out.append(_p(c.f(p2) + extra))
        if i == 0:
            h(5, "Indicator to Watch", in_toc=False)
            out.append(_p(c.f("Keep an eye on how {t2} evolves relative to {t1}. A widening gap between the two has historically preceded important shifts in the region.")))
            h(6, "Editor's Note", in_toc=False)
            out.append(_p("Regional comparisons are illustrative. Local conditions, data quality and definitions vary, so always check the latest national sources."))

    # Stakeholders
    h(2, "Who Shapes the Outcome? The Main Stakeholders")
    for i, actor in enumerate(cat["actors"]):
        h(3, cap(actor))
        out.append(_p(c.pick(ACTOR, a=actor, A=cap(actor))))
    out.append(f'<blockquote><p>{esc(c.f("Understanding {k} is less about predicting the future perfectly and more about being prepared for a range of possible futures."))}</p><cite>MIKRODINET Editorial Team</cite></blockquote>\n')
    figure(2)

    # Checklist
    h(2, "A Practical Checklist")
    out.append(_p(c.f("Use this checklist whenever you need to evaluate news, a proposal or a decision related to {k}. It distils the main lessons of this guide into concrete steps.")))
    out.append("<ol class=\"checklist\">\n" + "".join(f"<li>{esc(c.f(x))}</li>\n" for x in CHECKLIST) + "</ol>\n")
    out.append(_p(f"Want to keep exploring? Browse {ilink(5)} for another in-depth guide."))

    # Myths
    h(2, "Common Myths and Misconceptions")
    for i, (myth, truth) in enumerate(MYTHS):
        h(3, f"Myth {i + 1}: {c.f(myth)}")
        extra = f" Independent fact-checking from {xlink(5)} is a good way to test claims like this." if i == 0 else ""
        out.append(_p(c.f(truth) + extra))

    # Outlook
    h(2, f"The Future of {title_case(keyword)}")
    for head, para in OUTLOOK:
        h(3, head)
        out.append(_p(c.f(para)))
    h(3, "Signals to Watch")
    out.append("<ul>\n" + "".join(f"<li>{esc(c.f(s))}</li>\n" for s in [
        "Sustained changes in {t1} over several quarters",
        "Shifts in tone or priorities among {a1}",
        "New data or research on {t5}",
        "Technology adoption trends affecting {field}",
        "Feedback and sentiment from {a3}",
    ]) + "</ul>\n")

    # Quiz
    h(2, "Quick Quiz: Test Your Understanding")
    for qi, (q, opts, ans) in enumerate(QUIZ):
        lis = "".join(f'<li><button type="button" class="quiz-opt" data-correct="{"1" if j == ans else "0"}">{esc(c.f(o))}</button></li>'
                      for j, o in enumerate(opts))
        out.append(f'<div class="quiz"><p class="quiz-q"><strong>Question {qi + 1}:</strong> {esc(c.f(q))}</p><ul class="quiz-opts">{lis}</ul><p class="quiz-result" aria-live="polite"></p></div>\n')

    # FAQ
    faqs = [
        (c.f("What is {k} in simple terms?"),
         c.f("In plain language, {k} describes how decisions and conditions within {field} combine to produce real-world results. It is best understood as a way of connecting causes, such as changes in {t1} and {t2}, with effects felt by {a3} and {a4}.")),
        (c.f("Why does {k} matter in {year}?"),
         c.f("Rapid technological change, shifting demographics and global uncertainty have made {k} more relevant than ever. Understanding it helps readers interpret news, make better personal and professional decisions and take part in public debate with confidence.")),
        (c.f("How does {t1} affect {k}?"),
         c.f("{T1} sets many of the starting conditions. Improvements tend to create room for positive change, while deterioration can quickly increase pressure across the system. The size of the effect depends on how {t1} interacts with factors such as {t3}.")),
        (c.f("Who is most affected by changes in {k}?"),
         c.f("Effects reach almost everyone, but {a3} and {a4} often feel them most directly. The distribution of impacts depends on local conditions, institutions and how well decision makers anticipate change.")),
        (c.f("What are the biggest risks associated with {k}?"),
         c.f("The main risks include unequal impacts, incomplete data, short-term thinking and unintended consequences. Careful monitoring, diverse sources of evidence and a willingness to adjust course reduce these risks.")),
        (c.f("Where can I learn more about {k}?"),
         f"Start with the further reading in this article, including {esc(externals[6]['name'])} and {esc(externals[0]['name'])}, and explore related guides in the {esc(cat['name'])} section of MIKRODINET."),
    ]
    h(2, "Frequently Asked Questions")
    for q, a in faqs:
        out.append(f'<div class="faq"><h3>{esc(q)}</h3>{_p(esc(a) if "<" not in a else a)}</div>\n')

    # Conclusion
    h(2, "Conclusion")
    out.append(_p(c.f("The subject of {k} rewards careful attention. As this guide has shown, it is shaped by a handful of powerful factors — above all {t1}, {t2} and {t3} — and by the choices of {a1}, {a2}, {a3} and {a4}. History offers useful lessons, global comparisons reveal a wide range of approaches, and the evidence consistently favours patient, well-informed decision making over quick fixes.")))
    out.append(_p(c.f("Looking ahead, the most important habit is to stay curious and keep updating your understanding as new evidence emerges. Use the checklist, revisit the signals to watch and return to trusted sources regularly.") +
                  f" Continue with {ilink(6)}, and for official data visit {xlink(6)}."))
    out.append("<div class=\"takeaways\"><h3 id=\"key-takeaways\">Key Takeaways</h3><ul>\n" + "".join(
        f"<li>{esc(c.f(s))}</li>\n" for s in [
            "{K} is best understood as a lens for connecting causes and effects in {field}.",
            "{T1}, {t2} and {t3} are the core building blocks.",
            "Track several indicators over time rather than reacting to single data points.",
            "Effects are uneven; pay attention to who gains and who bears the costs.",
            "Stay flexible and update your view as new evidence emerges.",
        ]) + "</ul></div>\n")

    body = "".join(out)
    words = len(re.findall(r"\b\w+\b", re.sub(r"<[^>]+>", " ", body)))
    return {"body": body, "toc": toc, "faqs": faqs, "words": words}
