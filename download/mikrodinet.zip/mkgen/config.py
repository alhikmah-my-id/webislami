"""Site-wide settings for the MIKRODINET generator.

Edit the values here, then run `python3 generator.py` to rebuild every page.
"""
import os

SITE_NAME = "MIKRODINET"
SITE_SHORT = "Mikrodinet"
TAGLINE = "Global insight, practical guides and free online tools"
DESCRIPTION = (
    "MIKRODINET publishes long-form explainers on the global economy, business, "
    "technology, culture and public life, plus 80+ free DNS, IP, developer, "
    "network, security and webmaster tools."
)
KEYWORDS = (
    "mikrodinet, macro economy, business news, explainers, dns tools, ip tools, "
    "webmaster tools, developer tools, seo tools, network tools"
)

# Base URL used for canonical links, sitemaps and feeds.  Netlify sets URL
# during builds; override with --base-url or the SITE_URL env variable.
BASE_URL = (
    os.environ.get("SITE_URL")
    or os.environ.get("URL")
    or "https://responsive-website-42867e.netlify.app"
).rstrip("/")

LANG = "en"
THEME_COLOR = "#0b3d91"
ADSENSE_CLIENT = "ca-pub-6718454554209533"
# Optional AdSense ad unit id.  Leave empty to rely on Auto ads.
ADSENSE_SLOT = os.environ.get("ADSENSE_SLOT", "")

# Verification and ad tags required on every page (deduplicated from the brief).
HEAD_VERIFICATION = f"""<meta name="google-site-verification" content="_cIzXXc36JQpFAdNi1A8HnhUc-5lEb3AxlbNyJiK2ZU" />
<meta name="google-site-verification" content="QT96Rd0InOuqkb4s1Wu5BlgGD_pCNOy8CsCtveF1zEA" />
<meta name="google-site-verification" content="e1adJE3Uadivc1NAhHfSiG1YcUSbTFCJ0gQ9T4nDj_U" />
<meta name="msvalidate.01" content="A6BC1DD96D711E50BC95B39A1FA4C33E" />
<meta name="google-adsense-account" content="{ADSENSE_CLIENT}" />
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client={ADSENSE_CLIENT}" crossorigin="anonymous"></script>
<script async custom-element="amp-ad" src="https://cdn.ampproject.org/v0/amp-ad-0.1.js"></script>"""

GOOGLE_VERIFY_FILE = "googleae02f36cacd29223.html"
ADS_TXT = f"google.com, {ADSENSE_CLIENT.replace('ca-', '')}, DIRECT, f08c47fec0942fa0\n"

SOCIAL = [
    ("Facebook", "https://www.facebook.com/", "fb"),
    ("X / Twitter", "https://x.com/", "x"),
    ("Instagram", "https://www.instagram.com/", "ig"),
    ("YouTube", "https://www.youtube.com/", "yt"),
    ("LinkedIn", "https://www.linkedin.com/", "in"),
    ("TikTok", "https://www.tiktok.com/", "tt"),
    ("Telegram", "https://t.me/", "tg"),
    ("WhatsApp", "https://www.whatsapp.com/", "wa"),
    ("Pinterest", "https://www.pinterest.com/", "pin"),
    ("Reddit", "https://www.reddit.com/", "rd"),
]

# Article label aliases from the "News Category" and "Culture & Literature"
# menus, mapped onto the article categories that cover them.
LABEL_ALIASES = {
    "News": "business-news",
    "Politics": "politics",
    "Economy": "macro-economy",
    "Tech": "tech-media",
    "Sports": "sports",
    "International": "international",
    "Culture": "culture",
    "History": "explainers",
    "Arts": "arts",
    "Story": "commentary",
    "Zodiac": "lifestyle",
}

# Footer information pages: (slug, title)
INFO_PAGES = [
    ("about-us", "About Us"),
    ("contact-us", "Contact Us"),
    ("privacy-policy", "Privacy Policy"),
    ("license", "License"),
    ("terms-and-conditions", "Terms and Conditions"),
    ("choices", "Your Privacy Choices"),
    ("disclaimer", "Disclaimer"),
    ("partner", "Partner With Us"),
    ("editorial", "Editorial Policy"),
    ("advertise", "Advertise"),
    ("join-the-team", "Join the Team"),
    ("news-update", "News Update"),
    ("academy", "Academy"),
    ("e-course", "E-Course"),
    ("training", "Training"),
    ("private", "Private Consulting"),
    ("forum", "Community Forum"),
]

HARDWARE = [
    "New", "Search", "Ethernet routers", "Switches", "Wireless systems",
    "Indoor Wireless", "LTE/5G products", "IoT products", "60 GHz products",
    "RouterBOARD", "Enclosures", "Interfaces", "Accessories", "Antennas", "SFP/QSFP",
]
SOFTWARE = ["Downloads", "Changelogs", "RouterOS", "WinBox", "Mobile apps"]
