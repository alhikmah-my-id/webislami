/* MIKRODINET tools — designer, network, security, productivity, DNS database. */
(function () {
  'use strict';
  var MK = window.MK, R = MK.reg, h = MK.h, esc = MK.esc, input = MK.input, select = MK.select, btn = MK.btn, out = MK.out,
    table = MK.table, kv = MK.kv, raw = MK.raw, pre = MK.pre, loading = MK.loading, fail = MK.fail, api = MK.api, getJSON = MK.getJSON,
    copy = MK.copy, download = MK.download, onEnter = MK.onEnter, domainForm = MK.domainForm, doh = MK.doh, cleanDomain = MK.cleanDomain;

  /* ---------- Color conversion ---------- */
  function clamp(v, a, b) { return Math.min(b, Math.max(a, v)); }
  function rgb2hex(r, g, b) { return '#' + [r, g, b].map(function (x) { return ('0' + Math.round(clamp(x, 0, 255)).toString(16)).slice(-2); }).join('').toUpperCase(); }
  function hex2rgb(hx) {
    hx = hx.replace('#', '').trim(); if (hx.length === 3) hx = hx.split('').map(function (c) { return c + c; }).join('');
    if (!/^[0-9a-f]{6}$/i.test(hx)) throw new Error('Enter a valid HEX color like #1FA2FF');
    return [parseInt(hx.slice(0, 2), 16), parseInt(hx.slice(2, 4), 16), parseInt(hx.slice(4, 6), 16)];
  }
  function rgb2hsl(r, g, b) {
    r /= 255; g /= 255; b /= 255; var mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2, hh = 0, s = 0, d = mx - mn;
    if (d) { s = l > .5 ? d / (2 - mx - mn) : d / (mx + mn); hh = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; hh *= 60; }
    return [Math.round(hh), Math.round(s * 100), Math.round(l * 100)];
  }
  function hsl2rgb(hh, s, l) {
    s /= 100; l /= 100; var k = function (n) { return (n + hh / 30) % 12; }, a = s * Math.min(l, 1 - l);
    var f = function (n) { return l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1))); };
    return [f(0) * 255, f(8) * 255, f(4) * 255].map(Math.round);
  }
  function rgb2hsv(r, g, b) {
    r /= 255; g /= 255; b /= 255; var mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn, hh = 0;
    if (d) hh = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
    hh = Math.round(hh * 60); if (hh < 0) hh += 360;
    return [hh, Math.round(mx ? d / mx * 100 : 0), Math.round(mx * 100)];
  }
  function hsv2rgb(hh, s, v) {
    s /= 100; v /= 100; var f = function (n) { var k = (n + hh / 60) % 6; return v - v * s * Math.max(0, Math.min(k, 4 - k, 1)); };
    return [f(5) * 255, f(3) * 255, f(1) * 255].map(Math.round);
  }
  function rgb2cmyk(r, g, b) {
    var k = 1 - Math.max(r, g, b) / 255; if (k === 1) return [0, 0, 0, 100];
    return [(1 - r / 255 - k) / (1 - k), (1 - g / 255 - k) / (1 - k), (1 - b / 255 - k) / (1 - k), k].map(function (x) { return Math.round(x * 100); });
  }
  function cmyk2rgb(c, m, y, k) { return [c, m, y].map(function (x) { return Math.round(255 * (1 - x / 100) * (1 - k / 100)); }); }
  function lum(rgb) { var a = rgb.map(function (v) { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }); return .2126 * a[0] + .7152 * a[1] + .0722 * a[2]; }
  function contrast(a, b) { var x = lum(a), y = lum(b); return ((Math.max(x, y) + .05) / (Math.min(x, y) + .05)).toFixed(2); }
  function mix(a, b, t) { return a.map(function (v, i) { return v + (b[i] - v) * t; }); }
  function swatches(list) {
    return '<div class="swatches">' + list.map(function (c) { var hx = rgb2hex(c[0], c[1], c[2]); return '<div class="sw" style="background:' + hx + '" data-hex="' + hx + '">' + hx + '</div>'; }).join('') + '</div>';
  }
  function colorReport(rgb, o) {
    var hx = rgb2hex(rgb[0], rgb[1], rgb[2]), hsl = rgb2hsl.apply(null, rgb), hsv = rgb2hsv.apply(null, rgb), cmyk = rgb2cmyk.apply(null, rgb);
    var tints = [], shades = [], tones = [];
    for (var i = 1; i <= 8; i++) { tints.push(mix(rgb, [255, 255, 255], i / 9)); shades.push(mix(rgb, [0, 0, 0], i / 9)); tones.push(mix(rgb, [128, 128, 128], i / 9)); }
    var comp = hsl2rgb((hsl[0] + 180) % 360, hsl[1], hsl[2]), tri1 = hsl2rgb((hsl[0] + 120) % 360, hsl[1], hsl[2]), tri2 = hsl2rgb((hsl[0] + 240) % 360, hsl[1], hsl[2]);
    o.innerHTML = '<div style="display:flex;gap:16px;align-items:center;flex-wrap:wrap"><div style="width:120px;height:120px;border-radius:16px;background:' + hx + ';box-shadow:inset 0 0 0 1px rgba(0,0,0,.1)"></div><div>' +
      table(['Format', 'Value'], [['HEX', hx], ['RGB', 'rgb(' + rgb.join(', ') + ')'], ['HSL', 'hsl(' + hsl[0] + ', ' + hsl[1] + '%, ' + hsl[2] + '%)'], ['HSV / HSB', hsv[0] + '°, ' + hsv[1] + '%, ' + hsv[2] + '%'],
        ['CMYK', cmyk.join('%, ') + '%'], ['Contrast vs white', contrast(rgb, [255, 255, 255]) + ':1'], ['Contrast vs black', contrast(rgb, [0, 0, 0]) + ':1']]) + '</div></div>' +
      '<h3>Tints</h3>' + swatches(tints) + '<h3>Shades</h3>' + swatches(shades) + '<h3>Tones</h3>' + swatches(tones) + '<h3>Harmonies</h3>' + swatches([rgb, comp, tri1, tri2]) +
      '<p><small>Click any swatch to copy its HEX code.</small></p>';
    o.querySelectorAll('.sw').forEach(function (s) { s.addEventListener('click', function () { copy(s.getAttribute('data-hex'), s); }); });
  }
  MK.color = { rgb2hex: rgb2hex, hex2rgb: hex2rgb, hsl2rgb: hsl2rgb, rgb2hsl: rgb2hsl, swatches: swatches };
  function colorTool(fields, toRgb, defaults) {
    return function (root) {
      var ins = fields.map(function (f, i) { return input(f, { type: fields.length > 1 ? 'number' : 'text', value: defaults[i] }); });
      var picker = h('input', { type: 'color', value: '#1fa2ff', 'aria-label': 'Pick a color', style: 'width:60px;height:44px;border:0;background:none' });
      var o = out();
      var run = function () { try { colorReport(toRgb(ins.map(function (x) { return x.el.value; })).map(function (v) { return clamp(Math.round(v), 0, 255); }), o); } catch (e) { fail(o, e); } };
      ins.forEach(function (x) { x.el.addEventListener('input', run); });
      picker.addEventListener('input', function () {
        var rgb = hex2rgb(picker.value), vals;
        if (fields.length === 1) vals = [picker.value.toUpperCase()];
        else if (fields[0][0] === 'R') vals = rgb;
        else if (fields[0][0] === 'C') vals = rgb2cmyk.apply(null, rgb);
        else vals = rgb2hsv.apply(null, rgb);
        ins.forEach(function (x, i) { x.el.value = vals[i]; }); run();
      });
      root.append(h('div', { class: 'row' }, ins, h('div', null, h('label', { text: 'Picker' }), picker)), o);
      run();
    };
  }
  R['rgb-to-colortone'] = colorTool(['Red (0-255)', 'Green (0-255)', 'Blue (0-255)'], function (v) { return v.map(Number); }, [31, 162, 255]);
  R['hex-to-colortone'] = colorTool(['HEX color'], function (v) { return hex2rgb(v[0]); }, ['#1FA2FF']);
  R['cmyk-to-colortone'] = colorTool(['Cyan %', 'Magenta %', 'Yellow %', 'Key (black) %'], function (v) { return cmyk2rgb.apply(null, v.map(Number)); }, [88, 36, 0, 0]);
  R['hsv-to-colortone'] = colorTool(['Hue (0-360)', 'Saturation %', 'Value %'], function (v) { return hsv2rgb.apply(null, v.map(Number)); }, [205, 88, 100]);

  /* ---------- Network ---------- */
  R['port-checker'] = function (root) {
    var p = input('Ports (comma separated, max 12)', { value: '21,22,25,53,80,110,143,443,587,993,3306,8080' });
    domainForm(root, { label: 'Host or IP', value: 'example.com', extras: [p], button: 'Check ports' }, function (v, o) {
      loading(o, 'Probing ports…');
      api('port', v, { port: p.el.value }).then(function (j) {
        o.innerHTML = '<p>Host <strong>' + esc(j.host) + '</strong> (' + esc(j.ip) + ')</p>' + table(['Port', 'Status', 'Time', 'Detail'], j.results.map(function (r) {
          return [r.port, raw(r.open ? '<span class="ok">OPEN</span>' : '<span class="bad">CLOSED</span>'), r.ms + ' ms', r.error || ''];
        }));
      }).catch(function (e) { fail(o, e); });
    });
  };
  R['mac-address-lookup'] = function (root) {
    domainForm(root, { label: 'MAC address', value: '00:1A:2B:3C:4D:5E', placeholder: '00:1A:2B:3C:4D:5E', button: 'Find vendor' }, function (v, o) {
      loading(o);
      api('mac', v).then(function (j) {
        var first = parseInt(j.oui.slice(0, 2), 16);
        o.innerHTML = kv({ 'OUI prefix': j.oui, 'Vendor': j.vendor || 'Not found in the IEEE registry', 'Address type': first & 1 ? 'Multicast' : 'Unicast', 'Administration': first & 2 ? 'Locally administered' : 'Globally unique (OUI enforced)' });
      }).catch(function (e) { fail(o, e); });
    });
  };
  R['mac-address-generator'] = function (root) {
    var n = input('How many', { type: 'number', value: 10, min: 1, max: 500 });
    var fmt = select('Format', [[':', 'AA:BB:CC:DD:EE:FF'], ['-', 'AA-BB-CC-DD-EE-FF'], ['.', 'AABB.CCDD.EEFF (Cisco)'], ['', 'AABBCCDDEEFF']], ':');
    var kind = select('Type', [['local', 'Locally administered unicast'], ['uni', 'Random unicast'], ['any', 'Fully random']], 'local');
    var pre_ = input('Prefix (optional)', { placeholder: '00:1A:2B' });
    var caseSel = select('Case', [['u', 'Uppercase'], ['l', 'Lowercase']], 'u');
    var o = h('textarea', { rows: 10, readonly: true, 'aria-label': 'Generated MAC addresses' });
    var gen = function () {
      var list = [], pfx = pre_.el.value.replace(/[^0-9a-f]/gi, '').slice(0, 10);
      for (var i = 0; i < Math.min(500, +n.el.value || 1); i++) {
        var b = Array.from(crypto.getRandomValues(new Uint8Array(6)));
        if (kind.el.value === 'local') b[0] = (b[0] & 0xfc) | 2; else if (kind.el.value === 'uni') b[0] &= 0xfe;
        var hex = b.map(function (x) { return ('0' + x.toString(16)).slice(-2); }).join('');
        hex = (pfx + hex.slice(pfx.length)).slice(0, 12);
        if (caseSel.el.value === 'u') hex = hex.toUpperCase();
        var sep = fmt.el.value;
        list.push(sep === '.' ? hex.match(/.{4}/g).join('.') : hex.match(/../g).join(sep));
      }
      o.value = list.join('\n');
    };
    root.append(h('div', { class: 'row' }, n, fmt, kind), h('div', { class: 'row' }, pre_, caseSel), h('div', { class: 'actions' }, btn('Generate', gen), btn('Copy', function (e) { copy(o.value, e.target); }, 'ghost')), o);
    gen();
  };
  R['asn-whois-lookup'] = function (root) {
    domainForm(root, { label: 'AS number', value: 'AS15169', button: 'Lookup ASN' }, function (v, o) {
      var n = v.replace(/^as/i, '');
      if (!/^\d+$/.test(n)) return fail(o, 'Enter an AS number such as AS13335.');
      loading(o);
      getJSON('https://rdap.org/autnum/' + n).then(function (j) {
        var ents = (j.entities || []).map(function (e) { var vc = e.vcardArray && e.vcardArray[1] || []; var fn = vc.filter(function (x) { return x[0] === 'fn'; })[0]; return (fn ? fn[3] : e.handle) + ' (' + (e.roles || []).join(', ') + ')'; });
        var ev = function (a) { return ((j.events || []).filter(function (e) { return e.eventAction === a; })[0] || {}).eventDate || '—'; };
        o.innerHTML = kv({ 'ASN': 'AS' + n, 'Name': j.name, 'Handle': j.handle, 'Country': j.country || '—', 'Status': (j.status || []).join(', '), 'Registered': ev('registration'), 'Last changed': ev('last changed'), 'Entities': ents.join('; '), 'Source': j.port43 || 'RDAP' });
      }).catch(function (e) { fail(o, e); });
    });
  };

  /* ---------- Security ---------- */
  function sslTool(root) {
    domainForm(root, { label: 'Domain', value: 'letsencrypt.org', button: 'Check SSL' }, function (v, o) {
      loading(o, 'Opening TLS connection…');
      api('ssl', v).then(function (j) {
        var cls = !j.authorized ? 'bad' : j.daysRemaining < 15 ? 'warn' : 'ok';
        o.innerHTML = '<p class="' + cls + '">' + (j.authorized ? '✔ Certificate is valid and trusted' : '✘ Certificate problem: ' + esc(j.authorizationError)) + ' — ' + j.daysRemaining + ' days remaining</p>' +
          kv({ 'Common name': j.subject && j.subject.CN, 'Issuer': j.issuer && (j.issuer.O + ' — ' + j.issuer.CN), 'Valid from': j.validFrom, 'Valid until': j.validTo, 'Protocol': j.protocol, 'Cipher': j.cipher,
            'Subject alternative names': (j.altNames || []).join(', '), 'Chain': (j.chain || []).join(' → '), 'Serial': j.serialNumber, 'SHA-256 fingerprint': j.fingerprint256 });
      }).catch(function (e) { fail(o, e); });
    });
  }
  R['ssl-certificate-checker'] = sslTool;
  R['ssl-checker'] = sslTool;
  R['password-encryption'] = function (root) {
    var p = input('Password or text', { type: 'text', value: 'MySecret#2026' });
    var salt = input('Salt for PBKDF2 (optional)', { value: '' });
    var o = out();
    var run = function () {
      var v = p.el.value, s = salt.el.value || Array.from(crypto.getRandomValues(new Uint8Array(8))).map(function (x) { return ('0' + x.toString(16)).slice(-2); }).join('');
      salt.el.value = s;
      Promise.all([MK.sha('SHA-1', v), MK.sha('SHA-256', v), MK.sha('SHA-384', v), MK.sha('SHA-512', v),
        crypto.subtle.importKey('raw', new TextEncoder().encode(v), 'PBKDF2', false, ['deriveBits']).then(function (k) {
          return crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: new TextEncoder().encode(s), iterations: 100000 }, k, 256);
        }).then(function (b) { return Array.from(new Uint8Array(b)).map(function (x) { return ('0' + x.toString(16)).slice(-2); }).join(''); })
      ]).then(function (r) {
        o.innerHTML = table(['Algorithm', 'Hash'], [['MD5 (legacy)', MK.md5(v)], ['SHA-1 (legacy)', r[0]], ['SHA-256', r[1]], ['SHA-384', r[2]], ['SHA-512', r[3]], ['PBKDF2-SHA256 (100k, salt ' + s + ')', r[4]]]) +
          '<p><small>Everything is computed locally in your browser. For storing passwords, use a slow, salted algorithm such as PBKDF2, bcrypt or Argon2.</small></p>';
      });
    };
    root.append(h('div', { class: 'row' }, p, salt, btn('Encrypt / Hash', run)), o);
    run();
  };
  var WORDS = 'apple river stone cloud tiger maple ocean silver rocket garden falcon cotton lemon planet thunder velvet canyon harbor meadow pixel quartz shadow summit tunnel violet walnut yellow zebra anchor bamboo cactus dolphin ember forest glacier hazel island jungle koala lantern marble nectar orbit pepper quiver raven saffron tulip umber vortex willow xenon yonder zephyr'.split(' ');
  function rand(n) { return crypto.getRandomValues(new Uint32Array(1))[0] % n; }
  R['random-password-generator'] = function (root) {
    var len = input('Length', { type: 'number', value: 20, min: 4, max: 128 });
    var count = input('How many', { type: 'number', value: 5, min: 1, max: 50 });
    var opts = [['upper', 'A–Z', true], ['lower', 'a–z', true], ['digits', '0–9', true], ['symbols', '!@#$', true], ['similar', 'Exclude look-alikes (0O1lI)', false], ['phrase', 'Passphrase (words)', false]];
    var boxes = {};
    var checks = h('div', { class: 'row' }, opts.map(function (x) { var c = h('input', { type: 'checkbox', checked: x[2] }); boxes[x[0]] = c; return h('label', { style: 'font-weight:500' }, c, ' ' + x[1]); }));
    var o = out();
    var gen = function () {
      var sets = { upper: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', lower: 'abcdefghijklmnopqrstuvwxyz', digits: '0123456789', symbols: '!@#$%^&*()-_=+[]{};:,.<>?/' }, pool = '';
      Object.keys(sets).forEach(function (k) { if (boxes[k].checked) pool += sets[k]; });
      if (boxes.similar.checked) pool = pool.replace(/[0O1lI]/g, '');
      if (!pool && !boxes.phrase.checked) return fail(o, 'Select at least one character set.');
      var list = [];
      for (var i = 0; i < Math.min(50, +count.el.value || 1); i++) {
        var pw = '';
        if (boxes.phrase.checked) { var w = []; for (var j = 0; j < Math.max(3, Math.round(+len.el.value / 5)); j++) w.push(WORDS[rand(WORDS.length)]); pw = w.join('-') + '-' + rand(100); }
        else for (var k = 0; k < Math.min(128, +len.el.value || 16); k++) pw += pool[rand(pool.length)];
        list.push(pw);
      }
      o.innerHTML = '<ul style="list-style:none;padding:0">' + list.map(function (p) { return '<li style="display:flex;gap:8px;margin:6px 0"><code class="mono" style="flex:1;padding:8px 12px">' + esc(p) + '</code><button type="button" class="btn sm ghost" data-pw="' + esc(p) + '">Copy</button></li>'; }).join('') + '</ul>';
      o.querySelectorAll('[data-pw]').forEach(function (b) { b.addEventListener('click', function () { copy(b.getAttribute('data-pw'), b); }); });
    };
    root.append(h('div', { class: 'row' }, len, count), checks, h('div', { class: 'actions' }, btn('Generate passwords', gen)), o);
    gen();
  };
  function strength(pw) {
    var pool = 0;
    if (/[a-z]/.test(pw)) pool += 26; if (/[A-Z]/.test(pw)) pool += 26; if (/\d/.test(pw)) pool += 10; if (/[^a-zA-Z0-9]/.test(pw)) pool += 33;
    var bits = pw.length * Math.log2(pool || 1), tips = [];
    if (/(.)\1{2,}/.test(pw)) { bits -= 10; tips.push('Avoid repeated characters.'); }
    if (/(password|qwerty|123456|admin|letmein|welcome|iloveyou|abc123)/i.test(pw)) { bits = Math.min(bits, 10); tips.push('Contains a very common password pattern.'); }
    if (/(0123|1234|2345|3456|4567|5678|6789|abcd|bcde|cdef)/i.test(pw)) { bits -= 8; tips.push('Avoid sequences like 1234 or abcd.'); }
    if (pw.length < 12) tips.push('Use at least 12–16 characters.');
    if (!/[^a-zA-Z0-9]/.test(pw)) tips.push('Add symbols.'); if (!/\d/.test(pw)) tips.push('Add numbers.'); if (!/[A-Z]/.test(pw) || !/[a-z]/.test(pw)) tips.push('Mix upper and lower case.');
    bits = Math.max(0, bits);
    var secs = Math.pow(2, bits) / 1e10, t;
    t = secs < 1 ? 'instantly' : secs < 3600 ? Math.round(secs / 60) + ' minutes' : secs < 86400 * 365 ? Math.round(secs / 86400) + ' days' : secs < 3.15e7 * 1e6 ? Math.round(secs / 3.15e7).toLocaleString() + ' years' : 'millions of years +';
    var lvl = bits < 28 ? ['Very weak', '#c8312b', 10] : bits < 36 ? ['Weak', '#e07a1f', 30] : bits < 60 ? ['Fair', '#b7791f', 55] : bits < 80 ? ['Strong', '#3c9d5d', 80] : ['Very strong', '#11875d', 100];
    return { bits: Math.round(bits), time: t, level: lvl, tips: tips };
  }
  MK.strength = strength;
  R['password-strength-checker'] = function (root) {
    var p = input('Password', { type: 'password', placeholder: 'Type a password to test', autocomplete: 'off' });
    var show = h('label', { style: 'font-weight:500' }, h('input', { type: 'checkbox', onchange: function (e) { p.el.type = e.target.checked ? 'text' : 'password'; } }), ' Show');
    var o = out();
    var run = function () {
      if (!p.el.value) { o.innerHTML = '<p>Your password never leaves this page.</p>'; return; }
      var s = strength(p.el.value);
      o.innerHTML = '<div class="meter"><i style="width:' + s.level[2] + '%;background:' + s.level[1] + '"></i></div><p style="color:' + s.level[1] + ';font-weight:800;font-size:1.3rem">' + s.level[0] + '</p>' +
        kv({ 'Length': p.el.value.length, 'Estimated entropy': s.bits + ' bits', 'Time to crack (10 billion guesses/s)': s.time }) +
        (s.tips.length ? '<h3>Tips</h3><ul>' + s.tips.map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('') + '</ul>' : '<p class="ok">Great password!</p>');
    };
    p.el.addEventListener('input', run);
    root.append(p, show, o); run();
  };

  /* ---------- Productivity ---------- */
  var JSQR = 'https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.js';
  function scanner(root, onResult) {
    var video = h('video', { playsinline: true, muted: true, style: 'width:100%;max-width:480px;border-radius:12px;background:#000;display:none' });
    var file = h('input', { type: 'file', accept: 'image/*' });
    var o = out(), stream = null, canvas = document.createElement('canvas'), ctx = canvas.getContext('2d', { willReadFrequently: true });
    var decode = function (src, w, hgt) {
      canvas.width = w; canvas.height = hgt; ctx.drawImage(src, 0, 0, w, hgt);
      var d = ctx.getImageData(0, 0, w, hgt), r = window.jsQR(d.data, w, hgt);
      return r && r.data;
    };
    var stop = function () { if (stream) stream.getTracks().forEach(function (t) { t.stop(); }); stream = null; video.style.display = 'none'; };
    var tick = function () {
      if (!stream) return;
      if (video.readyState === 4) { var r = decode(video, video.videoWidth, video.videoHeight); if (r) { stop(); return onResult(r, o); } }
      requestAnimationFrame(tick);
    };
    var cam = function () {
      MK.loadScript(JSQR).then(function () { return navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } }); }).then(function (s) {
        stream = s; video.srcObject = s; video.style.display = 'block'; video.play(); o.innerHTML = '<p>Point your camera at a QR code…</p>'; tick();
      }).catch(function (e) { fail(o, 'Camera unavailable: ' + e.message); });
    };
    file.addEventListener('change', function () {
      var f = file.files[0]; if (!f) return;
      MK.loadScript(JSQR).then(function () {
        var img = new Image(); img.onload = function () {
          var sc = Math.min(1, 1200 / Math.max(img.width, img.height)), r = decode(img, Math.round(img.width * sc), Math.round(img.height * sc));
          r ? onResult(r, o) : fail(o, 'No QR code found in this image.');
        }; img.src = URL.createObjectURL(f);
      });
    });
    root.append(h('div', { class: 'actions' }, btn('📷 Start camera', cam), btn('Stop', stop, 'ghost')), h('label', { text: 'Or upload an image' }), file, video, o);
  }
  R['qr-scanner'] = function (root) {
    scanner(root, function (r, o) {
      var isUrl = /^https?:\/\//i.test(r);
      o.innerHTML = '<p class="ok">✔ QR code decoded</p>' + pre(r) + (isUrl ? '<p><a class="btn" href="' + esc(r) + '" target="_blank" rel="noopener nofollow">Open link</a></p>' : '');
    });
  };
  R['wifi-qr-scanner'] = function (root) {
    scanner(root, function (r, o) {
      if (!/^WIFI:/i.test(r)) return o.innerHTML = '<p class="warn">This QR code is not a Wi-Fi code.</p>' + pre(r);
      var get = function (k) { var m = r.match(new RegExp('[:;]' + k + ':((?:\\\\.|[^;])*)')); return m ? m[1].replace(/\\(.)/g, '$1') : ''; };
      o.innerHTML = '<p class="ok">✔ Wi-Fi network found</p>' + kv({ 'Network (SSID)': get('S'), 'Security': get('T') || 'None', 'Password': get('P') || '(none)', 'Hidden': get('H') === 'true' ? 'Yes' : 'No' });
    });
  };
  R['credit-card-checker'] = function (root) {
    var c = input('Card number', { placeholder: '4111 1111 1111 1111', inputmode: 'numeric', autocomplete: 'off' });
    var o = out();
    var brands = [['Visa', /^4/], ['Mastercard', /^(5[1-5]|2[2-7])/], ['American Express', /^3[47]/], ['Discover', /^(6011|65|64[4-9])/], ['JCB', /^35/], ['Diners Club', /^3(0[0-5]|[68])/], ['UnionPay', /^62/], ['Maestro', /^(50|5[6-9]|6)/]];
    var run = function () {
      var n = c.el.value.replace(/\D/g, '');
      if (!n) return o.innerHTML = '<p>Numbers are checked locally and never sent anywhere. Use test numbers only.</p>';
      var sum = 0; for (var i = 0; i < n.length; i++) { var d = +n[n.length - 1 - i]; if (i % 2) { d *= 2; if (d > 9) d -= 9; } sum += d; }
      var b = (brands.filter(function (x) { return x[1].test(n); })[0] || ['Unknown'])[0], ok = sum % 10 === 0 && n.length >= 12 && n.length <= 19;
      o.innerHTML = '<p class="' + (ok ? 'ok' : 'bad') + '">' + (ok ? '✔ Valid number format (passes Luhn check)' : '✘ Invalid number') + '</p>' + kv({ 'Brand': b, 'Length': n.length, 'IIN / BIN': n.slice(0, 6), 'Luhn checksum': sum % 10 === 0 ? 'Pass' : 'Fail' }) +
        '<p><small>This only validates the number format; it does not check whether a card is active.</small></p>';
    };
    c.el.addEventListener('input', run); root.append(c, o); run();
  };
  R['reverse-image-search'] = function (root) {
    var u = input('Image URL', { placeholder: 'https://example.com/photo.jpg' });
    var o = out();
    var go = function () {
      var v = encodeURIComponent(u.el.value.trim()); if (!v) return fail(o, 'Paste a public image URL.');
      var engines = [['Google Lens', 'https://lens.google.com/uploadbyurl?url=' + v], ['Bing Visual Search', 'https://www.bing.com/images/search?view=detailv2&iss=sbi&q=imgurl:' + v],
        ['Yandex Images', 'https://yandex.com/images/search?rpt=imageview&url=' + v], ['TinEye', 'https://tineye.com/search?url=' + v], ['Baidu Images', 'https://graph.baidu.com/details?isfromtusoupc=1&tn=pc&carousel=0&image=' + v],
        ['SauceNAO', 'https://saucenao.com/search.php?url=' + v]];
      o.innerHTML = '<img src="' + esc(u.el.value) + '" alt="Image preview" style="max-height:200px;border-radius:10px;margin-bottom:10px">' +
        '<div class="actions">' + engines.map(function (e) { return '<a class="btn" target="_blank" rel="noopener" href="' + e[1] + '">' + e[0] + '</a>'; }).join('') + '</div>';
    };
    onEnter(u.el, go); root.append(h('div', { class: 'row' }, u, btn('Search', go)), o);
  };
  R['name-checker'] = function (root) {
    domainForm(root, { label: 'Username or brand name', value: 'mikrodinet', button: 'Check name' }, function (v, o) {
      var n = v.replace(/[^a-z0-9_.-]/gi, '');
      var sites = [['Instagram', 'https://www.instagram.com/' + n], ['X / Twitter', 'https://x.com/' + n], ['Facebook', 'https://www.facebook.com/' + n], ['TikTok', 'https://www.tiktok.com/@' + n],
        ['YouTube', 'https://www.youtube.com/@' + n], ['GitHub', 'https://github.com/' + n], ['Reddit', 'https://www.reddit.com/user/' + n], ['Pinterest', 'https://www.pinterest.com/' + n],
        ['LinkedIn', 'https://www.linkedin.com/in/' + n], ['Telegram', 'https://t.me/' + n], ['Twitch', 'https://www.twitch.tv/' + n], ['Medium', 'https://medium.com/@' + n],
        ['Threads', 'https://www.threads.net/@' + n], ['Snapchat', 'https://www.snapchat.com/add/' + n], ['Behance', 'https://www.behance.net/' + n], ['Dribbble', 'https://dribbble.com/' + n]];
      var tlds = ['com', 'net', 'org', 'io', 'co', 'id', 'my.id', 'app'];
      o.innerHTML = '<h3>Social profiles</h3><p><small>Open each link — a “page not found” means the name is probably free.</small></p><div class="tool-grid">' +
        sites.map(function (s) { return '<a class="tool-card" target="_blank" rel="noopener nofollow" href="' + s[1] + '"><strong>' + s[0] + '</strong><small>' + esc(s[1].replace(/^https:\/\//, '')) + '</small></a>'; }).join('') +
        '</div><h3>Domains</h3><div id="nc-dom">' + table(['Domain', 'Status'], tlds.map(function (t) { return [n + '.' + t, raw('<span data-d="' + esc(n + '.' + t) + '">checking…</span>')]; })) + '</div>';
      o.querySelectorAll('[data-d]').forEach(function (s) {
        fetch('https://rdap.org/domain/' + s.getAttribute('data-d')).then(function (r) {
          s.innerHTML = r.status === 404 ? '<span class="ok">Likely available</span>' : r.ok ? '<span class="bad">Registered</span>' : '<span class="warn">Unknown</span>';
        }).catch(function () { s.innerHTML = '<span class="warn">Unknown</span>'; });
      });
    });
  };
  var MORSE = { A: '.-', B: '-...', C: '-.-.', D: '-..', E: '.', F: '..-.', G: '--.', H: '....', I: '..', J: '.---', K: '-.-', L: '.-..', M: '--', N: '-.', O: '---', P: '.--.', Q: '--.-', R: '.-.', S: '...', T: '-', U: '..-', V: '...-', W: '.--', X: '-..-', Y: '-.--', Z: '--..',
    0: '-----', 1: '.----', 2: '..---', 3: '...--', 4: '....-', 5: '.....', 6: '-....', 7: '--...', 8: '---..', 9: '----.', '.': '.-.-.-', ',': '--..--', '?': '..--..', "'": '.----.', '!': '-.-.--', '/': '-..-.', '(': '-.--.', ')': '-.--.-', '&': '.-...', ':': '---...', ';': '-.-.-.', '=': '-...-', '+': '.-.-.', '-': '-....-', '_': '..--.-', '"': '.-..-.', '$': '...-..-', '@': '.--.-.' };
  R['morse-code-translator'] = function (root) {
    var rev = {}; Object.keys(MORSE).forEach(function (k) { rev[MORSE[k]] = k; });
    var t = input('Text', { tag: 'textarea', rows: 3, value: 'SOS MIKRODINET' });
    var m = input('Morse code', { tag: 'textarea', rows: 3 });
    var enc = function () { m.el.value = t.el.value.toUpperCase().split(' ').map(function (w) { return w.split('').map(function (c) { return MORSE[c] || ''; }).filter(Boolean).join(' '); }).join(' / '); };
    var dec = function () { t.el.value = m.el.value.trim().split(/\s*\/\s*|\s{3,}/).map(function (w) { return w.split(/\s+/).map(function (c) { return rev[c] || ''; }).join(''); }).join(' '); };
    var play = function () {
      var ac = new (window.AudioContext || window.webkitAudioContext)(), time = ac.currentTime + .1, u = .08;
      m.el.value.split('').forEach(function (c) {
        if (c === '.' || c === '-') { var osc = ac.createOscillator(), g = ac.createGain(); osc.frequency.value = 650; osc.connect(g); g.connect(ac.destination); var d = c === '.' ? u : u * 3; g.gain.setValueAtTime(.3, time); osc.start(time); osc.stop(time + d); time += d + u; }
        else time += c === '/' ? u * 4 : u * 2;
      });
    };
    t.el.addEventListener('input', enc); m.el.addEventListener('input', dec);
    root.append(t, m, h('div', { class: 'actions' }, btn('▶ Play sound', play), btn('Copy Morse', function (e) { copy(m.el.value, e.target); }, 'ghost'))); enc();
  };
  function ocrTool(root) {
    var file = h('input', { type: 'file', accept: 'image/*' });
    var lang = select('Language', [['eng', 'English'], ['ind', 'Indonesian'], ['ara', 'Arabic'], ['spa', 'Spanish'], ['fra', 'French'], ['deu', 'German'], ['chi_sim', 'Chinese (Simplified)'], ['jpn', 'Japanese']], 'eng');
    var o = out(), res = h('textarea', { rows: 10, 'aria-label': 'Extracted text' });
    var run = function () {
      var f = file.files[0]; if (!f) return fail(o, 'Choose an image first.');
      loading(o, 'Loading OCR engine…');
      MK.loadScript('https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js').then(function () {
        return window.Tesseract.recognize(f, lang.el.value, { logger: function (m) { if (m.status) o.innerHTML = '<p>⏳ ' + esc(m.status) + (m.progress ? ' ' + Math.round(m.progress * 100) + '%' : '') + '</p>'; } });
      }).then(function (r) { res.value = r.data.text; o.innerHTML = '<p class="ok">✔ Done — confidence ' + Math.round(r.data.confidence) + '%</p>'; }).catch(function (e) { fail(o, e); });
    };
    root.append(h('div', { class: 'row' }, h('div', null, h('label', { text: 'Image' }), file), lang, btn('Extract text', run)), o, res, h('div', { class: 'actions' }, btn('Copy text', function (e) { copy(res.value, e.target); }, 'ghost')));
  }
  R['image-to-text'] = ocrTool;
  R['bimi-checker'] = function (root) {
    var logo = input('Logo SVG URL (for generator)', { placeholder: 'https://example.com/logo.svg' });
    var vmc = input('VMC certificate URL (optional)', { placeholder: 'https://example.com/vmc.pem' });
    var gen = out();
    var f = domainForm(root, { value: 'cnn.com', button: 'Check BIMI' }, function (d, o) {
      loading(o);
      Promise.all([doh('default._bimi.' + d, 'TXT'), doh('_dmarc.' + d, 'TXT')]).then(function (r) {
        var b = r[0].answers.map(function (a) { return a.data.replace(/"/g, ''); }).filter(function (t) { return /v=BIMI1/i.test(t); })[0];
        var dm = r[1].answers.map(function (a) { return a.data.replace(/"/g, ''); }).filter(function (t) { return /v=DMARC1/i.test(t); })[0];
        var pol = dm && (dm.match(/p=(\w+)/i) || [])[1];
        var l = b && (b.match(/l=([^;\s]+)/) || [])[1];
        o.innerHTML = table(['Check', 'Result'], [['BIMI record', raw(b ? '<span class="ok">Found</span> <code>' + esc(b) + '</code>' : '<span class="bad">Not found</span>')],
          ['DMARC policy', raw(pol ? (/(quarantine|reject)/i.test(pol) ? '<span class="ok">' : '<span class="bad">') + esc(pol) + '</span> (BIMI needs quarantine or reject)' : '<span class="bad">No DMARC record</span>')],
          ['Logo', raw(l ? '<img src="' + esc(l) + '" alt="BIMI logo" style="width:64px;height:64px;border-radius:50%">' : '—')]]);
      }).catch(function (e) { fail(o, e); });
    });
    root.append(h('h3', { text: 'BIMI record generator' }), h('div', { class: 'row' }, logo, vmc, btn('Generate', function () {
      var rec = 'v=BIMI1; l=' + logo.el.value.trim() + ';' + (vmc.el.value.trim() ? ' a=' + vmc.el.value.trim() + ';' : '');
      gen.innerHTML = '<p>Add this TXT record at <code>default._bimi.' + esc(cleanDomain(f.input.value) || 'yourdomain.com') + '</code>:</p>' + pre(rec);
    }, 'ghost')), gen);
  };
  var RUNES = {
    elder: { a: 'ᚨ', b: 'ᛒ', c: 'ᚲ', d: 'ᛞ', e: 'ᛖ', f: 'ᚠ', g: 'ᚷ', h: 'ᚺ', i: 'ᛁ', j: 'ᛃ', k: 'ᚲ', l: 'ᛚ', m: 'ᛗ', n: 'ᚾ', o: 'ᛟ', p: 'ᛈ', q: 'ᚲ', r: 'ᚱ', s: 'ᛊ', t: 'ᛏ', u: 'ᚢ', v: 'ᚹ', w: 'ᚹ', x: 'ᚲᛊ', y: 'ᛃ', z: 'ᛉ', th: 'ᚦ', ng: 'ᛜ' },
    younger: { a: 'ᛅ', b: 'ᛒ', c: 'ᚴ', d: 'ᛏ', e: 'ᛁ', f: 'ᚠ', g: 'ᚴ', h: 'ᚼ', i: 'ᛁ', j: 'ᛁ', k: 'ᚴ', l: 'ᛚ', m: 'ᛘ', n: 'ᚾ', o: 'ᚬ', p: 'ᛒ', q: 'ᚴ', r: 'ᚱ', s: 'ᛋ', t: 'ᛏ', u: 'ᚢ', v: 'ᚢ', w: 'ᚢ', x: 'ᚴᛋ', y: 'ᚢ', z: 'ᛋ', th: 'ᚦ', ng: 'ᚾᚴ' },
    anglo: { a: 'ᚪ', b: 'ᛒ', c: 'ᚳ', d: 'ᛞ', e: 'ᛖ', f: 'ᚠ', g: 'ᚷ', h: 'ᚻ', i: 'ᛁ', j: 'ᛄ', k: 'ᛣ', l: 'ᛚ', m: 'ᛗ', n: 'ᚾ', o: 'ᚩ', p: 'ᛈ', q: 'ᛢ', r: 'ᚱ', s: 'ᛋ', t: 'ᛏ', u: 'ᚢ', v: 'ᚠ', w: 'ᚹ', x: 'ᛉ', y: 'ᚣ', z: 'ᛋ', th: 'ᚦ', ng: 'ᛝ' },
  };
  R['runic-translator'] = function (root) {
    var t = input('Latin text', { tag: 'textarea', rows: 3, value: 'Mikrodinet' });
    var al = select('Rune alphabet', [['elder', 'Elder Futhark'], ['younger', 'Younger Futhark'], ['anglo', 'Anglo-Saxon Futhorc']], 'elder');
    var o = h('div', { style: 'font-size:2.2rem;letter-spacing:.1em;padding:16px;background:#fff;border-radius:12px;border:1px solid #d6e2fb;min-height:80px;word-break:break-word' });
    var run = function () {
      var map = RUNES[al.el.value], s = t.el.value.toLowerCase(), r = '';
      for (var i = 0; i < s.length; i++) {
        var two = s.slice(i, i + 2);
        if (map[two]) { r += map[two]; i++; } else if (map[s[i]]) r += map[s[i]]; else r += s[i] === ' ' ? '᛫' : s[i];
      }
      o.textContent = r;
    };
    t.el.addEventListener('input', run); al.el.addEventListener('change', run);
    root.append(t, al, h('label', { text: 'Runes' }), o, h('div', { class: 'actions' }, btn('Copy runes', function (e) { copy(o.textContent, e.target); }))); run();
  };
  R['invisible-text-generator'] = function (root) {
    var chars = [['Hangul Filler', 'ㅤ', 'U+3164'], ['Braille Blank', '⠀', 'U+2800'], ['Zero Width Space', '​', 'U+200B'], ['Zero Width Non-Joiner', '‌', 'U+200C'],
      ['Zero Width Joiner', '‍', 'U+200D'], ['Word Joiner', '⁠', 'U+2060'], ['En Space', ' ', 'U+2002'], ['Em Space', ' ', 'U+2003'], ['Ideographic Space', '　', 'U+3000'], ['Mongolian Vowel Separator', '᠎', 'U+180E']];
    var n = input('Number of characters', { type: 'number', value: 5, min: 1, max: 1000 });
    var pick = select('Character', chars.map(function (c, i) { return [String(i), c[0] + ' (' + c[2] + ')']; }), '0');
    var o = out();
    root.append(h('div', { class: 'row' }, n, pick, btn('Copy invisible text', function (e) { copy(chars[+pick.el.value][1].repeat(Math.min(1000, +n.el.value || 1)), e.target); })),
      h('h3', { text: 'Single characters' }), o);
    o.innerHTML = table(['Name', 'Code', ''], chars.map(function (c, i) { return [c[0], c[2], raw('<button type="button" class="btn sm ghost" data-i="' + i + '">Copy</button>')]; }));
    o.querySelectorAll('[data-i]').forEach(function (b) { b.addEventListener('click', function () { copy(chars[+b.getAttribute('data-i')][1], b); }); });
  };
  R['internet-speed-test'] = function (root) {
    var o = out();
    var gauge = h('div', { style: 'font-size:3rem;font-weight:800;text-align:center;margin:10px 0', text: '— Mbps' });
    var run = function () {
      var CF = 'https://speed.cloudflare.com';
      var res = {};
      loading(o, 'Measuring latency…');
      var pings = [], i = 0;
      var ping = function () {
        var t = performance.now();
        return fetch(CF + '/__down?bytes=0&r=' + Math.random(), { cache: 'no-store' }).then(function () { pings.push(performance.now() - t); });
      };
      var chain = Promise.resolve();
      for (i = 0; i < 6; i++) chain = chain.then(ping);
      chain.then(function () {
        pings.sort(function (a, b) { return a - b; }); res.ping = pings[Math.floor(pings.length / 2)];
        var jit = 0; for (var k = 1; k < pings.length; k++) jit += Math.abs(pings[k] - pings[k - 1]); res.jitter = jit / (pings.length - 1);
        o.innerHTML = '<p>⏳ Testing download…</p>';
        var sizes = [1e6, 5e6, 10e6, 25e6], speeds = [], dl = Promise.resolve();
        sizes.forEach(function (s) {
          dl = dl.then(function () {
            var t = performance.now();
            return fetch(CF + '/__down?bytes=' + s + '&r=' + Math.random(), { cache: 'no-store' }).then(function (r) { return r.arrayBuffer(); }).then(function (b) {
              var mbps = b.byteLength * 8 / ((performance.now() - t) / 1000) / 1e6; speeds.push(mbps); gauge.textContent = mbps.toFixed(1) + ' Mbps ↓';
            });
          });
        });
        return dl.then(function () { res.down = Math.max.apply(null, speeds.slice(-2)); });
      }).then(function () {
        o.innerHTML = '<p>⏳ Testing upload…</p>';
        var up = Promise.resolve(), speeds = [];
        [1e6, 3e6, 5e6].forEach(function (s) {
          up = up.then(function () {
            var t = performance.now();
            return fetch(CF + '/__up', { method: 'POST', body: new Uint8Array(s) }).then(function () {
              var mbps = s * 8 / ((performance.now() - t) / 1000) / 1e6; speeds.push(mbps); gauge.textContent = mbps.toFixed(1) + ' Mbps ↑';
            });
          });
        });
        return up.then(function () { res.up = Math.max.apply(null, speeds); });
      }).then(function () {
        gauge.textContent = res.down.toFixed(1) + ' Mbps';
        o.innerHTML = kv({ 'Download': res.down.toFixed(2) + ' Mbps', 'Upload': res.up.toFixed(2) + ' Mbps', 'Latency (ping)': res.ping.toFixed(0) + ' ms', 'Jitter': res.jitter.toFixed(1) + ' ms', 'Test server': 'Cloudflare edge (speed.cloudflare.com)' });
      }).catch(function (e) { fail(o, 'Speed test failed: ' + e.message); });
    };
    root.append(gauge, h('div', { class: 'actions', style: 'justify-content:center' }, btn('▶ Start speed test', run)), o);
  };

  /* ---------- DNS server database ---------- */
  var DNSDB = {
    'global-dns-providers': [['Google Public DNS', '8.8.8.8', '8.8.4.4', '2001:4860:4860::8888', 'Fast, global anycast, DNSSEC'], ['Cloudflare', '1.1.1.1', '1.0.0.1', '2606:4700:4700::1111', 'Privacy-first, very fast'],
      ['Cloudflare for Families', '1.1.1.3', '1.0.0.3', '2606:4700:4700::1113', 'Blocks malware + adult content'], ['Quad9', '9.9.9.9', '149.112.112.112', '2620:fe::fe', 'Malware blocking, non-profit'],
      ['OpenDNS', '208.67.222.222', '208.67.220.220', '2620:119:35::35', 'Cisco, phishing protection'], ['OpenDNS FamilyShield', '208.67.222.123', '208.67.220.123', '—', 'Adult content filtering'],
      ['AdGuard DNS', '94.140.14.14', '94.140.15.15', '2a10:50c0::ad1:ff', 'Ad and tracker blocking'], ['CleanBrowsing Security', '185.228.168.9', '185.228.169.9', '2a0d:2a00:1::2', 'Security filter'],
      ['Control D', '76.76.2.0', '76.76.10.0', '2606:1a40::', 'Customisable filtering'], ['DNS.Watch', '84.200.69.80', '84.200.70.40', '2001:1608:10:25::1c04:b12f', 'No logging, Germany'],
      ['Comodo Secure DNS', '8.26.56.26', '8.20.247.20', '—', 'Malware protection'], ['Level3 / Lumen', '4.2.2.1', '4.2.2.2', '—', 'Legacy, widely used'],
      ['Yandex DNS', '77.88.8.8', '77.88.8.1', '2a02:6b8::feed:0ff', 'Russia-based'], ['AliDNS', '223.5.5.5', '223.6.6.6', '2400:3200::1', 'Alibaba, Asia'],
      ['NextDNS', '45.90.28.0', '45.90.30.0', '2a07:a8c0::', 'Configurable privacy filtering'], ['Mullvad DNS', '194.242.2.2', '—', '2a07:e340::2', 'No logging, DoH/DoT']],
    'australian-dns-servers': [['Telstra', '139.130.4.5', '203.50.2.71', '—', 'National ISP'], ['Optus', '211.29.132.12', '198.142.0.51', '—', 'National ISP'],
      ['TPG', '203.12.160.35', '203.12.160.36', '—', 'ISP resolver'], ['Aussie Broadband', '202.142.142.142', '202.142.142.242', '—', 'ISP resolver'],
      ['iiNet', '203.0.178.191', '203.215.29.191', '—', 'ISP resolver'], ['Cloudflare (Sydney anycast)', '1.1.1.1', '1.0.0.1', '2606:4700:4700::1111', 'Local PoPs'],
      ['Quad9 (Australia)', '9.9.9.9', '149.112.112.112', '2620:fe::fe', 'Local PoPs'], ['Google (Australia)', '8.8.8.8', '8.8.4.4', '2001:4860:4860::8888', 'Local PoPs']],
    'uk-dns-servers': [['BT', '62.6.40.178', '62.6.40.162', '—', 'National ISP'], ['Sky Broadband', '90.207.238.97', '90.207.238.99', '—', 'ISP resolver'],
      ['Virgin Media', '194.168.4.100', '194.168.8.100', '—', 'ISP resolver'], ['TalkTalk', '62.24.134.1', '62.24.134.2', '—', 'ISP resolver'],
      ['Zen Internet', '212.23.3.100', '212.23.6.100', '—', 'ISP resolver'], ['Andrews & Arnold', '217.169.20.20', '217.169.20.21', '2001:8b0::2020', 'ISP resolver'],
      ['Cloudflare (London anycast)', '1.1.1.1', '1.0.0.1', '2606:4700:4700::1111', 'Local PoPs'], ['Quad9 (UK)', '9.9.9.9', '149.112.112.112', '2620:fe::fe', 'Local PoPs']],
    'us-dns-servers': [['Google Public DNS', '8.8.8.8', '8.8.4.4', '2001:4860:4860::8888', 'Mountain View, CA'], ['Cloudflare', '1.1.1.1', '1.0.0.1', '2606:4700:4700::1111', 'San Francisco, CA'],
      ['OpenDNS (Cisco)', '208.67.222.222', '208.67.220.220', '2620:119:35::35', 'San Jose, CA'], ['Quad9', '9.9.9.9', '149.112.112.112', '2620:fe::fe', 'Berkeley, CA'],
      ['Level3 / Lumen', '4.2.2.1', '4.2.2.2', '—', 'Broomfield, CO'], ['Verizon', '4.2.2.3', '4.2.2.4', '—', 'ISP resolver'],
      ['Comcast Xfinity', '75.75.75.75', '75.75.76.76', '2001:558:feed::1', 'ISP resolver'], ['Spectrum', '209.18.47.61', '209.18.47.62', '—', 'ISP resolver'],
      ['Hurricane Electric', '74.82.42.42', '—', '2001:470:20::2', 'Fremont, CA'], ['Neustar UltraDNS', '64.6.64.6', '64.6.65.6', '2620:74:1b::1:1', 'Sterling, VA']],
  };
  Object.keys(DNSDB).forEach(function (k) {
    R[k] = function (root) {
      var f = input('Filter', { placeholder: 'Type to filter…' }), o = out();
      var render = function () {
        var q = f.el.value.toLowerCase();
        o.innerHTML = table(['Provider', 'Primary IPv4', 'Secondary IPv4', 'IPv6', 'Notes'], DNSDB[k].filter(function (r) { return r.join(' ').toLowerCase().indexOf(q) > -1; }));
      };
      f.el.addEventListener('input', render); root.append(f, o); render();
      o.insertAdjacentHTML('afterend', '<p><small>Addresses are published by each provider and may change; verify with the provider before configuring critical systems. Test any resolver with our <a href="/tools/dns-checker/">DNS Checker</a>.</small></p>');
    };
  });
})();
