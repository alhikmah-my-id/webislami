/* MIKRODINET tools — core helpers + DNS, IP and developer tools.
 * Each tool registers MK.reg[slug] = function (root) { ...build UI... }.
 * tools-b.js and tools-c.js add the remaining tools; init runs on DOMContentLoaded. */
(function () {
  'use strict';
  var MK = window.MK = { reg: {} };
  var API = '/.netlify/functions/check';

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function h(tag, props) {
    var el = document.createElement(tag);
    if (props) Object.keys(props).forEach(function (k) {
      var v = props[k];
      if (k === 'class') el.className = v;
      else if (k === 'html') el.innerHTML = v;
      else if (k === 'text') el.textContent = v;
      else if (k.slice(0, 2) === 'on') el.addEventListener(k.slice(2), v);
      else if (v !== false && v != null) el.setAttribute(k, v === true ? '' : v);
    });
    for (var i = 2; i < arguments.length; i++) {
      var c = arguments[i];
      if (c == null || c === false) continue;
      (Array.isArray(c) ? c : [c]).forEach(function (x) { el.appendChild(typeof x === 'string' ? document.createTextNode(x) : x); });
    }
    return el;
  }
  function input(label, props) {
    props = props || {};
    var tag = props.tag || 'input'; delete props.tag;
    if (tag === 'input' && !props.type) props.type = 'text';
    var el = h(tag, props);
    var wrap = h('div', null, h('label', { text: label }), el);
    wrap.el = el;
    return wrap;
  }
  function select(label, options, value) {
    var el = h('select');
    options.forEach(function (o) { var v = Array.isArray(o) ? o[0] : o, t = Array.isArray(o) ? o[1] : o; el.appendChild(h('option', { value: v, text: t, selected: v === value })); });
    var wrap = h('div', null, h('label', { text: label }), el);
    wrap.el = el;
    return wrap;
  }
  function btn(text, fn, cls) { return h('button', { type: 'button', class: 'btn ' + (cls || ''), text: text, onclick: fn }); }
  function out() { return h('div', { class: 'out', 'aria-live': 'polite' }); }
  function table(head, rows) {
    return '<div class="table-wrap"><table><thead><tr>' + head.map(function (x) { return '<th>' + esc(x) + '</th>'; }).join('') +
      '</tr></thead><tbody>' + rows.map(function (r) { return '<tr>' + r.map(function (c) { return '<td>' + (c && c.raw != null ? c.raw : esc(c)) + '</td>'; }).join('') + '</tr>'; }).join('') + '</tbody></table></div>';
  }
  function kv(obj) { return table(['Field', 'Value'], Object.keys(obj).map(function (k) { return [k, obj[k]]; })); }
  function raw(s) { return { raw: s }; }
  function pre(s) { return '<pre>' + esc(s) + '</pre>'; }
  function loading(o, msg) { o.innerHTML = '<p>⏳ ' + esc(msg || 'Working…') + '</p>'; }
  function fail(o, e) { o.innerHTML = '<p class="bad">⚠ ' + esc(e && e.message ? e.message : e) + '</p>'; }
  function api(action, target, extra) {
    var q = new URLSearchParams(Object.assign({ action: action, target: target }, extra || {}));
    return fetch(API + '?' + q).then(function (r) { return r.json(); }).then(function (j) { if (j.error) throw new Error(j.error); return j; });
  }
  function getJSON(url, opts) {
    return fetch(url, opts).then(function (r) { if (!r.ok) throw new Error('Request failed (' + r.status + ')'); return r.json(); });
  }
  var scripts = {};
  function loadScript(src) {
    if (!scripts[src]) scripts[src] = new Promise(function (res, rej) {
      var s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = function () { rej(new Error('Could not load ' + src)); };
      document.head.appendChild(s);
    });
    return scripts[src];
  }
  function loadCSS(href) { if (!document.querySelector('link[href="' + href + '"]')) document.head.appendChild(h('link', { rel: 'stylesheet', href: href })); }
  function cleanDomain(v) { return String(v || '').trim().replace(/^[a-z]+:\/\//i, '').split(/[\/?#]/)[0].replace(/:\d+$/, '').replace(/\.$/, '').toLowerCase(); }
  function copy(text, b) {
    navigator.clipboard.writeText(text).then(function () { if (b) { var t = b.textContent; b.textContent = 'Copied!'; setTimeout(function () { b.textContent = t; }, 1200); } });
  }
  function download(name, dataUrl) { var a = h('a', { href: dataUrl, download: name }); document.body.appendChild(a); a.click(); a.remove(); }
  function onEnter(inp, fn) { inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); fn(); } }); }
  function fmtBytes(n) { if (n == null) return '—'; var u = ['B', 'KB', 'MB', 'GB'], i = 0; while (n >= 1024 && i < 3) { n /= 1024; i++; } return n.toFixed(i ? 1 : 0) + ' ' + u[i]; }

  /* ---------- DNS over HTTPS ---------- */
  var TYPES = { 1: 'A', 2: 'NS', 5: 'CNAME', 6: 'SOA', 12: 'PTR', 15: 'MX', 16: 'TXT', 28: 'AAAA', 33: 'SRV', 43: 'DS', 46: 'RRSIG', 48: 'DNSKEY', 257: 'CAA', 65: 'HTTPS' };
  var RESOLVERS = [
    ['Google Public DNS', 'https://dns.google/resolve'],
    ['Cloudflare 1.1.1.1', 'https://cloudflare-dns.com/dns-query'],
    ['AliDNS', 'https://dns.alidns.com/resolve'],
    ['Quad9', 'https://dns.quad9.net:5053/dns-query'],
    ['AdGuard DNS', 'https://dns.adguard-dns.com/resolve'],
  ];
  function doh(name, type, resolver) {
    var url = (resolver || RESOLVERS[0][1]) + '?name=' + encodeURIComponent(name) + '&type=' + encodeURIComponent(type);
    return getJSON(url, { headers: { accept: 'application/dns-json' } }).then(function (j) {
      j.answers = (j.Answer || []).map(function (a) { return { name: a.name, type: TYPES[a.type] || a.type, ttl: a.TTL, data: a.data }; });
      return j;
    });
  }
  var RCODE = { 0: 'NOERROR', 1: 'FORMERR', 2: 'SERVFAIL', 3: 'NXDOMAIN', 5: 'REFUSED' };
  function answersTable(ans) {
    if (!ans.length) return '<p class="warn">No records found.</p>';
    return table(['Name', 'Type', 'TTL', 'Value'], ans.map(function (a) { return [a.name, a.type, a.ttl, a.data]; }));
  }
  function ptrName(ip) {
    if (ip.indexOf(':') < 0) return ip.split('.').reverse().join('.') + '.in-addr.arpa';
    var parts = ip.split('::'), head = parts[0] ? parts[0].split(':') : [], tail = parts[1] ? parts[1].split(':') : [];
    var full = head.concat(Array(8 - head.length - tail.length).fill('0'), tail).map(function (x) { return ('0000' + x).slice(-4); }).join('');
    return full.split('').reverse().join('.') + '.ip6.arpa';
  }
  function isIP(v) { return /^\d{1,3}(\.\d{1,3}){3}$/.test(v) || /^[0-9a-f:]+$/i.test(v) && v.indexOf(':') > -1; }
  function resolveIP(v) {
    v = cleanDomain(v);
    if (isIP(v)) return Promise.resolve(v);
    return doh(v, 'A').then(function (j) {
      var a = j.answers.filter(function (x) { return x.type === 'A'; })[0];
      if (!a) throw new Error('Could not resolve ' + v);
      return a.data;
    });
  }

  function domainForm(root, opts, run) {
    var d = input(opts.label || 'Domain name', { placeholder: opts.placeholder || 'example.com', value: opts.value || '' });
    var extras = opts.extras || [];
    var o = out();
    var go = function () { var v = cleanDomain(d.el.value); if (!v) return fail(o, 'Please enter a value.'); run(v, o, extras); };
    onEnter(d.el, go);
    root.append(h('div', { class: 'row' }, d, extras, btn(opts.button || 'Check', go)), o);
    return { input: d.el, out: o, go: go };
  }

  Object.assign(MK, { esc: esc, h: h, input: input, select: select, btn: btn, out: out, table: table, kv: kv, raw: raw, pre: pre, loading: loading, fail: fail,
    api: api, getJSON: getJSON, loadScript: loadScript, loadCSS: loadCSS, cleanDomain: cleanDomain, copy: copy, download: download, onEnter: onEnter,
    fmtBytes: fmtBytes, doh: doh, answersTable: answersTable, domainForm: domainForm, resolveIP: resolveIP, isIP: isIP, ptrName: ptrName, RCODE: RCODE });

  var R = MK.reg;

  /* ---------- DNS tools ---------- */
  R['dns-checker'] = function (root) {
    var type = select('Record type', ['A', 'AAAA', 'CNAME', 'MX', 'NS', 'TXT', 'SOA', 'CAA'], 'A');
    domainForm(root, { value: 'google.com', extras: [type], button: 'Check propagation' }, function (d, o) {
      loading(o, 'Querying ' + RESOLVERS.length + ' resolvers…');
      Promise.all(RESOLVERS.map(function (r) {
        return doh(d, type.el.value, r[1]).then(function (j) { return [r[0], raw('<span class="ok">✔</span>'), j.answers.map(function (a) { return a.data; }).join('\n') || '(no records)']; },
          function () { return [r[0], raw('<span class="warn">—</span>'), 'Resolver unreachable from your browser']; });
      })).then(function (rows) {
        o.innerHTML = table(['Resolver', 'Status', 'Answer'], rows).replace(/\n/g, '<br>');
      });
    });
  };
  R['dns-lookup'] = function (root) {
    var type = select('Record type', ['ALL', 'A', 'AAAA', 'CNAME', 'MX', 'NS', 'TXT', 'SOA', 'CAA', 'SRV', 'DS', 'DNSKEY', 'HTTPS'], 'ALL');
    domainForm(root, { value: 'example.com', extras: [type], button: 'Lookup' }, function (d, o) {
      loading(o);
      var types = type.el.value === 'ALL' ? ['A', 'AAAA', 'CNAME', 'MX', 'NS', 'TXT', 'SOA', 'CAA'] : [type.el.value];
      Promise.all(types.map(function (t) { return doh(d, t).then(function (j) { return j.answers.filter(function (a) { return a.type === t || types.length === 1; }); }, function () { return []; }); }))
        .then(function (lists) { o.innerHTML = answersTable([].concat.apply([], lists)); }).catch(function (e) { fail(o, e); });
    });
  };
  function nsOrMx(kind) {
    return function (root) {
      domainForm(root, { value: 'gmail.com', button: kind + ' Lookup' }, function (d, o) {
        loading(o);
        doh(d, kind).then(function (j) {
          var recs = j.answers.filter(function (a) { return a.type === kind; });
          if (!recs.length) return o.innerHTML = '<p class="warn">No ' + kind + ' records found (' + (RCODE[j.Status] || j.Status) + ').</p>';
          return Promise.all(recs.map(function (r) {
            var parts = String(r.data).split(' '), host = (kind === 'MX' ? parts[1] : parts[0]).replace(/\.$/, '');
            return doh(host, 'A').then(function (a) { return a.answers.filter(function (x) { return x.type === 'A'; }).map(function (x) { return x.data; }).join(', '); }, function () { return '—'; })
              .then(function (ips) { return kind === 'MX' ? [parts[0], host, ips, r.ttl] : [host, ips, r.ttl]; });
          })).then(function (rows) {
            if (kind === 'MX') rows.sort(function (a, b) { return a[0] - b[0]; });
            o.innerHTML = table(kind === 'MX' ? ['Priority', 'Mail server', 'IP address', 'TTL'] : ['Name server', 'IP address', 'TTL'], rows);
          });
        }).catch(function (e) { fail(o, e); });
      });
    };
  }
  R['ns-lookup'] = nsOrMx('NS');
  R['mx-lookup'] = nsOrMx('MX');
  R['reverse-ip-lookup'] = function (root) {
    domainForm(root, { label: 'IP address', value: '8.8.8.8', placeholder: '8.8.8.8 or 2001:4860:4860::8888', button: 'Reverse lookup' }, function (v, o) {
      loading(o);
      resolveIP(v).then(function (ip) {
        return doh(ptrName(ip), 'PTR').then(function (j) {
          var ptr = j.answers.filter(function (a) { return a.type === 'PTR'; });
          o.innerHTML = kv({ 'IP address': ip, 'PTR query': ptrName(ip), 'Hostname(s)': ptr.length ? ptr.map(function (p) { return p.data; }).join(', ') : 'No PTR record found' });
        });
      }).catch(function (e) { fail(o, e); });
    });
  };
  R['domain-to-ip'] = function (root) {
    domainForm(root, { value: 'wikipedia.org', button: 'Get IP' }, function (d, o) {
      loading(o);
      Promise.all([doh(d, 'A'), doh(d, 'AAAA')]).then(function (r) {
        var rows = r[0].answers.concat(r[1].answers).map(function (a) { return [a.type, a.data, a.ttl, raw('<a href="/tools/ip-location-lookup/?q=' + encodeURIComponent(a.data) + '">Locate</a>')]; });
        o.innerHTML = rows.length ? table(['Type', 'Address', 'TTL', ''], rows) : '<p class="warn">No addresses found.</p>';
      }).catch(function (e) { fail(o, e); });
    });
  };
  R['dns-health-checker'] = function (root) {
    domainForm(root, { value: 'github.com', button: 'Run health check' }, function (d, o) {
      loading(o, 'Running 8 checks…');
      var q = function (n, t) { return doh(n, t).catch(function () { return { answers: [], Status: -1 }; }); };
      Promise.all([q(d, 'A'), q(d, 'AAAA'), q(d, 'NS'), q(d, 'MX'), q(d, 'TXT'), q('_dmarc.' + d, 'TXT'), q(d, 'CAA'), q(d, 'SOA'), q(d, 'DS')]).then(function (r) {
        var txt = r[4].answers.map(function (a) { return a.data; }), spf = txt.filter(function (t) { return /v=spf1/i.test(t); });
        var dmarc = r[5].answers.map(function (a) { return a.data; }).filter(function (t) { return /v=DMARC1/i.test(t); });
        var ns = r[2].answers.filter(function (a) { return a.type === 'NS'; });
        var checks = [
          ['IPv4 (A) record', r[0].answers.some(function (a) { return a.type === 'A'; }), r[0].answers.map(function (a) { return a.data; }).join(', ')],
          ['IPv6 (AAAA) record', r[1].answers.some(function (a) { return a.type === 'AAAA'; }), r[1].answers.map(function (a) { return a.data; }).join(', ') || 'Optional but recommended'],
          ['At least 2 name servers', ns.length >= 2, ns.map(function (a) { return a.data; }).join(', ')],
          ['Mail (MX) records', r[3].answers.length > 0, r[3].answers.map(function (a) { return a.data; }).join(', ') || 'No MX — domain cannot receive email'],
          ['SPF record', spf.length === 1, spf.join(' ') || 'Missing — add a v=spf1 TXT record'],
          ['DMARC policy', dmarc.length > 0, dmarc.join(' ') || 'Missing — add a TXT record at _dmarc'],
          ['CAA record', r[6].answers.length > 0, r[6].answers.map(function (a) { return a.data; }).join(', ') || 'Optional — restricts which CAs may issue certificates'],
          ['SOA record', r[7].answers.length > 0, r[7].answers.map(function (a) { return a.data; }).join(' ')],
          ['DNSSEC (DS record)', r[8].answers.length > 0 || r[0].AD, r[8].answers.length ? 'Signed' : 'Not signed (optional)'],
        ];
        var pass = checks.filter(function (c) { return c[1]; }).length;
        o.innerHTML = '<p><strong>Score: ' + pass + '/' + checks.length + '</strong></p>' + table(['Check', 'Result', 'Details'], checks.map(function (c) {
          return [c[0], raw(c[1] ? '<span class="ok">PASS</span>' : '<span class="bad">WARN</span>'), c[2]];
        }));
      });
    });
  };

  /* ---------- IP tools ---------- */
  function ipInfo(ip) {
    return getJSON('https://ipwho.is/' + (ip ? encodeURIComponent(ip) : '')).then(function (j) {
      if (j.success === false) throw new Error(j.message || 'Lookup failed');
      return j;
    });
  }
  function ipTable(j) {
    var c = j.connection || {};
    return kv({ 'IP address': j.ip, 'Type': j.type, 'Country': (j.flag && j.flag.emoji ? j.flag.emoji + ' ' : '') + (j.country || ''), 'Region': j.region, 'City': j.city,
      'Postal code': j.postal, 'Latitude / Longitude': j.latitude + ', ' + j.longitude, 'Time zone': j.timezone && j.timezone.id,
      'ISP': c.isp, 'Organisation': c.org, 'ASN': c.asn ? 'AS' + c.asn : '', 'Domain': c.domain }) +
      (j.latitude != null ? '<iframe title="Map" style="width:100%;height:300px;border:0;border-radius:12px;margin-top:10px" loading="lazy" src="https://www.openstreetmap.org/export/embed.html?bbox=' +
        (j.longitude - 0.3) + ',' + (j.latitude - 0.2) + ',' + (j.longitude + 0.3) + ',' + (j.latitude + 0.2) + '&layer=mapnik&marker=' + j.latitude + ',' + j.longitude + '"></iframe>' : '');
  }
  R['what-is-my-ip'] = function (root) {
    var o = out(); root.append(o); loading(o, 'Detecting your IP…');
    ipInfo().then(function (j) {
      var nav = navigator;
      o.innerHTML = '<p style="font-size:2rem;font-weight:800;margin:0">' + esc(j.ip) + '</p>' + ipTable(j) +
        '<h3>Your browser</h3>' + kv({ 'User agent': nav.userAgent, 'Language': nav.language, 'Platform': nav.platform, 'Screen': screen.width + '×' + screen.height,
          'Cookies enabled': nav.cookieEnabled ? 'Yes' : 'No', 'Do Not Track': nav.doNotTrack === '1' ? 'On' : 'Off' });
      fetch('https://api64.ipify.org?format=json').then(function (r) { return r.json(); }).then(function (x) {
        if (x.ip && x.ip !== j.ip) o.insertAdjacentHTML('afterbegin', '<p>Also detected: <strong>' + esc(x.ip) + '</strong></p>');
      }).catch(function () {});
    }).catch(function (e) { fail(o, e); });
  };
  R['ip-location-lookup'] = function (root) {
    var f = domainForm(root, { label: 'IP address or domain', value: new URLSearchParams(location.search).get('q') || '1.1.1.1', button: 'Locate' }, function (v, o) {
      loading(o);
      resolveIP(v).then(ipInfo).then(function (j) { o.innerHTML = ipTable(j); }).catch(function (e) { fail(o, e); });
    });
    if (location.search.indexOf('q=') > -1) f.go();
  };
  R['ip-whois-lookup'] = function (root) {
    domainForm(root, { label: 'IP address', value: '8.8.8.8', button: 'WHOIS' }, function (v, o) {
      loading(o);
      resolveIP(v).then(function (ip) { return getJSON('https://rdap.org/ip/' + ip); }).then(function (j) {
        var ents = (j.entities || []).map(function (e) { var vc = e.vcardArray && e.vcardArray[1] || []; var fn = vc.filter(function (x) { return x[0] === 'fn'; })[0]; return (fn ? fn[3] : e.handle) + ' (' + (e.roles || []).join(', ') + ')'; });
        o.innerHTML = kv({ 'Handle': j.handle, 'Name': j.name, 'Range': (j.startAddress || '') + ' – ' + (j.endAddress || ''), 'Type': j.type, 'Country': j.country,
          'Parent': j.parentHandle, 'Entities': ents.join('; '), 'Registered': ((j.events || []).filter(function (e) { return e.eventAction === 'registration'; })[0] || {}).eventDate,
          'Last changed': ((j.events || []).filter(function (e) { return e.eventAction === 'last changed'; })[0] || {}).eventDate, 'Source': j.port43 || 'RDAP' });
      }).catch(function (e) { fail(o, e); });
    });
  };
  var DNSBL = ['zen.spamhaus.org', 'bl.spamcop.net', 'b.barracudacentral.org', 'dnsbl.sorbs.net', 'psbl.surriel.com', 'dnsbl-1.uceprotect.net',
    'bl.mailspike.net', 'dnsbl.dronebl.org', 'ix.dnsbl.manitu.net', 'all.s5h.net', 'db.wpbl.info', 'spam.dnsbl.anonmails.de', 'bl.0spam.org', 'rbl.interserver.net', 'truncate.gbudb.net'];
  R['ip-blacklist-check'] = function (root) {
    domainForm(root, { label: 'IPv4 address or domain', value: '127.0.0.2', button: 'Check blacklists' }, function (v, o) {
      loading(o, 'Checking ' + DNSBL.length + ' blocklists…');
      resolveIP(v).then(function (ip) {
        if (ip.indexOf(':') > -1) throw new Error('Most DNSBLs only support IPv4 addresses.');
        var rev = ip.split('.').reverse().join('.');
        return Promise.all(DNSBL.map(function (z) {
          return doh(rev + '.' + z, 'A').then(function (j) {
            var a = j.answers.filter(function (x) { return x.type === 'A'; }).map(function (x) { return x.data; });
            if (a.some(function (x) { return /^127\.255\.255\./.test(x); })) return [z, raw('<span class="warn">Not queried</span>'), 'List refuses public resolvers'];
            return [z, raw(a.length ? '<span class="bad">LISTED</span>' : '<span class="ok">Clean</span>'), a.join(', ') || '—'];
          }, function () { return [z, raw('<span class="warn">Timeout</span>'), '—']; });
        })).then(function (rows) {
          var listed = rows.filter(function (r) { return /LISTED/.test(r[1].raw); }).length;
          o.innerHTML = '<p><strong>' + esc(ip) + '</strong> is listed on <strong class="' + (listed ? 'bad' : 'ok') + '">' + listed + '</strong> of ' + rows.length + ' lists.</p>' + table(['Blocklist', 'Status', 'Response'], rows);
        });
      }).catch(function (e) { fail(o, e); });
    });
  };
  R['email-header-analyzer'] = function (root) {
    var t = input('Paste the full raw email headers', { tag: 'textarea', rows: 10, placeholder: 'Received: from mail.example.com ...\nFrom: ...\nSubject: ...' });
    var o = out();
    root.append(t, h('div', { class: 'actions' }, btn('Analyze headers', function () {
      var text = t.el.value.replace(/\r/g, '').replace(/\n[ \t]+/g, ' ');
      if (!text.trim()) return fail(o, 'Paste headers first.');
      var lines = text.split('\n'), hdr = {};
      lines.forEach(function (l) { var m = l.match(/^([\w-]+):\s*(.*)$/); if (m) { var k = m[1].toLowerCase(); (hdr[k] = hdr[k] || []).push(m[2]); } });
      var rec = (hdr['received'] || []).slice().reverse(), prev = null;
      var rows = rec.map(function (r, i) {
        var from = (r.match(/from\s+([^\s;]+)/i) || [])[1] || '', by = (r.match(/by\s+([^\s;]+)/i) || [])[1] || '';
        var ip = (r.match(/\[(\d{1,3}(?:\.\d{1,3}){3}|[0-9a-f:]+)\]/i) || [])[1] || '';
        var d = new Date((r.split(';').pop() || '').trim()), delay = prev && !isNaN(d) ? Math.round((d - prev) / 1000) + 's' : '—';
        if (!isNaN(d)) prev = d;
        return [i + 1, from, by, ip, isNaN(d) ? '' : d.toISOString().replace('T', ' ').slice(0, 19), delay];
      });
      var auth = (hdr['authentication-results'] || []).join(' ');
      var res = function (k) { var m = auth.match(new RegExp(k + '=(\\w+)', 'i')); return m ? raw('<span class="' + (m[1].toLowerCase() === 'pass' ? 'ok' : 'bad') + '">' + esc(m[1]) + '</span>') : 'not found'; };
      var g = function (k) { return (hdr[k] || [''])[0]; };
      o.innerHTML = '<h3>Summary</h3>' + table(['Field', 'Value'], [['From', g('from')], ['To', g('to')], ['Subject', g('subject')], ['Date', g('date')], ['Message-ID', g('message-id')],
        ['Return-Path', g('return-path')], ['SPF', res('spf')], ['DKIM', res('dkim')], ['DMARC', res('dmarc')]]) +
        '<h3>Delivery path (' + rows.length + ' hops)</h3>' + (rows.length ? table(['Hop', 'From', 'By', 'IP', 'Time (UTC)', 'Delay'], rows) : '<p>No Received headers found.</p>');
    })), o);
  };

  /* ---------- Developer tools ---------- */
  function urlTool(action, button, render, value) {
    return function (root) {
      var u = input('Website URL', { placeholder: 'https://example.com', value: value || 'https://www.netlify.com' });
      var o = out();
      var go = function () { if (!u.el.value.trim()) return fail(o, 'Enter a URL.'); loading(o); api(action, u.el.value.trim()).then(function (j) { render(j, o); }).catch(function (e) { fail(o, e); }); };
      onEnter(u.el, go);
      root.append(h('div', { class: 'row' }, u, btn(button, go)), o);
    };
  }
  MK.urlTool = urlTool;
  R['http-headers-check'] = urlTool('headers', 'Get headers', function (j, o) {
    o.innerHTML = '<p>Status: <strong class="' + (j.status < 400 ? 'ok' : 'bad') + '">' + j.status + ' ' + esc(j.statusText) + '</strong> · ' + j.ms + ' ms</p>' + kv(j.headers);
  });
  R['website-os-check'] = urlTool('os', 'Detect', function (j, o) {
    o.innerHTML = kv({ 'Operating system': j.os, 'Web server': j.server || 'Hidden', 'X-Powered-By': j.poweredBy || 'Hidden', 'HTTP status': j.status }) +
      '<h3>Detected technologies</h3>' + (j.tech.length ? '<ul>' + j.tech.map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('') + '</ul>' : '<p>No common technologies detected.</p>');
  });
  R['smtp-test'] = function (root) {
    var port = select('Port', [['25', '25 (SMTP)'], ['587', '587 (Submission)'], ['465', '465 (SMTPS)'], ['2525', '2525 (Alt)']], '587');
    domainForm(root, { label: 'Mail server host', value: 'smtp.gmail.com', extras: [port], button: 'Test SMTP' }, function (v, o) {
      loading(o, 'Connecting…');
      api('smtp', v, { port: port.el.value }).then(function (j) {
        o.innerHTML = '<p class="ok">Connected to ' + esc(j.host) + ' (' + esc(j.ip) + ':' + j.port + ') in ' + j.ms + ' ms</p>' + pre(j.log.join('\n') || 'No banner received (port 465 needs TLS first).');
      }).catch(function (e) { fail(o, e); });
    });
  };
  // Compact MD5 (public-domain algorithm by Joseph Myers)
  function md5(str) {
    function add(a, b) { return (a + b) & 0xffffffff; }
    function cmn(q, a, b, x, s, t) { a = add(add(a, q), add(x, t)); return add((a << s) | (a >>> (32 - s)), b); }
    function ff(a, b, c, d, x, s, t) { return cmn((b & c) | (~b & d), a, b, x, s, t); }
    function gg(a, b, c, d, x, s, t) { return cmn((b & d) | (c & ~d), a, b, x, s, t); }
    function hh(a, b, c, d, x, s, t) { return cmn(b ^ c ^ d, a, b, x, s, t); }
    function ii(a, b, c, d, x, s, t) { return cmn(c ^ (b | ~d), a, b, x, s, t); }
    var bytes = unescape(encodeURIComponent(str)), n = bytes.length, i, words = [];
    for (i = 0; i < n; i++) words[i >> 2] |= bytes.charCodeAt(i) << ((i % 4) * 8);
    words[n >> 2] |= 0x80 << ((n % 4) * 8);
    var len = (((n + 8) >> 6) + 1) * 16; for (i = 0; i < len; i++) words[i] = words[i] | 0;
    words[len - 2] = n * 8;
    var a = 1732584193, b = -271733879, c = -1732584194, d = 271733878;
    var S = [7, 12, 17, 22, 5, 9, 14, 20, 4, 11, 16, 23, 6, 10, 15, 21], K = [];
    for (i = 0; i < 64; i++) K[i] = Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296) | 0;
    for (i = 0; i < len; i += 16) {
      var oa = a, ob = b, oc = c, od = d, j, f, g, t;
      for (j = 0; j < 64; j++) {
        if (j < 16) { f = ff; g = j; } else if (j < 32) { f = gg; g = (5 * j + 1) % 16; } else if (j < 48) { f = hh; g = (3 * j + 5) % 16; } else { f = ii; g = (7 * j) % 16; }
        t = f(a, b, c, d, words[i + g], S[(j >> 4) * 4 + (j % 4)], K[j]);
        a = d; d = c; c = b; b = t;
      }
      a = add(a, oa); b = add(b, ob); c = add(c, oc); d = add(d, od);
    }
    return [a, b, c, d].map(function (v) { var s = ''; for (var k = 0; k < 4; k++) s += ('0' + ((v >>> (k * 8)) & 255).toString(16)).slice(-2); return s; }).join('');
  }
  MK.md5 = md5;
  function sha(alg, text) {
    return crypto.subtle.digest(alg, new TextEncoder().encode(text)).then(function (b) { return Array.from(new Uint8Array(b)).map(function (x) { return ('0' + x.toString(16)).slice(-2); }).join(''); });
  }
  MK.sha = sha;
  function b64enc(s) { return btoa(unescape(encodeURIComponent(s))); }
  function b64dec(s) { return decodeURIComponent(escape(atob(s.trim()))); }
  R['md5-base64-generator'] = function (root) {
    var t = input('Text', { tag: 'textarea', rows: 5, value: 'Hello MIKRODINET' });
    var o = out();
    var hash = function () {
      var v = t.el.value;
      Promise.all([sha('SHA-1', v), sha('SHA-256', v), sha('SHA-512', v)]).then(function (s) {
        o.innerHTML = table(['Algorithm', 'Output'], [['MD5', md5(v)], ['SHA-1', s[0]], ['SHA-256', s[1]], ['SHA-512', s[2]], ['Base64', b64enc(v)]]);
      });
    };
    root.append(t, h('div', { class: 'actions' }, btn('Generate hashes', hash), btn('Base64 encode', function () { t.el.value = b64enc(t.el.value); }, 'ghost'),
      btn('Base64 decode', function () { try { t.el.value = b64dec(t.el.value); } catch (e) { fail(o, 'Input is not valid Base64.'); } }, 'ghost')), o);
    t.el.addEventListener('input', hash); hash();
  };
  R['binary-translator'] = function (root) {
    var t = input('Text', { tag: 'textarea', rows: 4, value: 'Hi!' });
    var mode = select('Format', [['2', 'Binary'], ['16', 'Hexadecimal'], ['8', 'Octal'], ['10', 'Decimal']], '2');
    var r = input('Encoded', { tag: 'textarea', rows: 4 });
    var pad = { 2: 8, 16: 2, 8: 3, 10: 0 };
    var enc = function () {
      var base = +mode.el.value;
      r.el.value = Array.from(new TextEncoder().encode(t.el.value)).map(function (b) { var s = b.toString(base); return pad[base] ? ('00000000' + s).slice(-pad[base]) : s; }).join(' ');
    };
    var dec = function () {
      var base = +mode.el.value;
      try { t.el.value = new TextDecoder().decode(new Uint8Array(r.el.value.trim().split(/[\s,]+/).filter(Boolean).map(function (x) { var n = parseInt(x, base); if (isNaN(n)) throw 0; return n; }))); }
      catch (e) { alert('Invalid input for the selected format.'); }
    };
    t.el.addEventListener('input', enc); mode.el.addEventListener('change', enc);
    root.append(t, mode, h('div', { class: 'actions' }, btn('Text → Code ↓', enc), btn('Code → Text ↑', dec, 'ghost')), r);
    enc();
  };
  function jsonTree(v, key) {
    var label = key != null ? '<span style="color:#7aa2ff">' + esc(key) + '</span>: ' : '';
    if (v && typeof v === 'object') {
      var isArr = Array.isArray(v), keys = Object.keys(v);
      return '<details open><summary>' + label + (isArr ? '[' + keys.length + ']' : '{' + keys.length + '}') + '</summary><div style="padding-left:18px">' +
        keys.map(function (k) { return jsonTree(v[k], k); }).join('') + '</div></details>';
    }
    var color = typeof v === 'string' ? '#9be29b' : typeof v === 'number' ? '#ffcf70' : '#ff9a9a';
    return '<div>' + label + '<span style="color:' + color + '">' + esc(JSON.stringify(v)) + '</span></div>';
  }
  R['json-viewer'] = function (root) {
    var t = input('JSON', { tag: 'textarea', rows: 10, value: '{"site":"MIKRODINET","tools":82,"tags":["dns","ip","seo"],"active":true,"owner":{"name":"Mikrodinet","since":2026}}' });
    var o = out();
    var parse = function () { try { return JSON.parse(t.el.value); } catch (e) { fail(o, 'Invalid JSON: ' + e.message); return undefined; } };
    root.append(t, h('div', { class: 'actions' },
      btn('Beautify', function () { var v = parse(); if (v !== undefined) { t.el.value = JSON.stringify(v, null, 2); o.innerHTML = '<p class="ok">✔ Valid JSON</p>'; } }),
      btn('Minify', function () { var v = parse(); if (v !== undefined) { t.el.value = JSON.stringify(v); o.innerHTML = '<p class="ok">✔ Minified (' + t.el.value.length + ' chars)</p>'; } }, 'ghost'),
      btn('Tree view', function () { var v = parse(); if (v !== undefined) o.innerHTML = '<div class="mono">' + jsonTree(v) + '</div>'; }, 'ghost'),
      btn('Copy', function (e) { copy(t.el.value, e.target); }, 'ghost')), o);
  };

  document.addEventListener('DOMContentLoaded', function () {
    var root = document.getElementById('tool-app');
    if (!root) return;
    var fn = MK.reg[root.getAttribute('data-tool')];
    root.innerHTML = '';
    if (fn) { try { fn(root); } catch (e) { root.textContent = 'This tool failed to start: ' + e.message; } }
    else root.textContent = 'This tool is coming soon.';
  });
})();
