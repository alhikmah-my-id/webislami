(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  // Mobile menu
  var toggle = $('.nav-toggle'), nav = $('#nav');
  if (toggle && nav) toggle.addEventListener('click', function () {
    var open = nav.classList.toggle('open');
    toggle.setAttribute('aria-expanded', open);
  });

  // Dropdowns (click/tap; hover handled in CSS on desktop)
  $$('.dd-toggle').forEach(function (b) {
    b.addEventListener('click', function (e) {
      e.stopPropagation();
      var li = b.parentNode, open = !li.classList.contains('open');
      $$('.has-dd.open').forEach(function (x) { if (x !== li) { x.classList.remove('open'); x.firstChild.setAttribute('aria-expanded', 'false'); } });
      li.classList.toggle('open', open);
      b.setAttribute('aria-expanded', open);
    });
  });
  document.addEventListener('click', function () {
    $$('.has-dd.open').forEach(function (x) { x.classList.remove('open'); });
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') $$('.has-dd.open').forEach(function (x) { x.classList.remove('open'); });
  });

  // Copy link
  $$('[data-copy]').forEach(function (b) {
    b.addEventListener('click', function () {
      navigator.clipboard.writeText(b.getAttribute('data-copy')).then(function () {
        var t = b.textContent; b.textContent = 'Copied!'; setTimeout(function () { b.textContent = t; }, 1500);
      });
    });
  });

  // Quiz
  $$('.quiz').forEach(function (q) {
    var res = $('.quiz-result', q);
    $$('.quiz-opt', q).forEach(function (o) {
      o.addEventListener('click', function () {
        var right = o.getAttribute('data-correct') === '1';
        $$('.quiz-opt', q).forEach(function (x) { x.classList.remove('right', 'wrong'); if (x.getAttribute('data-correct') === '1') x.classList.add('right'); });
        if (!right) o.classList.add('wrong');
        res.textContent = right ? '✔ Correct — well done!' : '✘ Not quite. The highlighted answer is correct.';
      });
    });
  });

  // Netlify Forms: submit via fetch, then show the thank-you page
  $$('form.contact-form').forEach(function (f) {
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      var btn = $('button[type=submit]', f); btn.disabled = true; btn.textContent = 'Sending…';
      fetch('/', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(new FormData(f)).toString() })
        .then(function (r) { if (!r.ok) throw new Error(r.status); location.href = '/thank-you/'; })
        .catch(function () { btn.disabled = false; btn.textContent = 'Send message'; alert('Sorry, the message could not be sent. Please try again.'); });
    });
  });

  // Search page
  var results = $('#search-results');
  if (results) {
    var q = new URLSearchParams(location.search).get('q') || '';
    var input = $('#q'); if (input) input.value = q;
    var status = $('#search-status');
    if (!q.trim()) { status.textContent = 'Enter a keyword to search ' + 'articles and tools.'; return; }
    status.textContent = 'Searching…';
    fetch('/search-index.json').then(function (r) { return r.json(); }).then(function (idx) {
      var terms = q.toLowerCase().split(/\s+/).filter(Boolean);
      var hits = idx.map(function (it) {
        var hay = (it.t + ' ' + it.c + ' ' + it.d).toLowerCase(), score = 0;
        terms.forEach(function (t) { if (hay.indexOf(t) > -1) score += it.t.toLowerCase().indexOf(t) > -1 ? 3 : 1; });
        return { it: it, s: score };
      }).filter(function (h) { return h.s >= terms.length; }).sort(function (a, b) { return b.s - a.s; }).slice(0, 60);
      status.textContent = hits.length + ' result' + (hits.length === 1 ? '' : 's') + ' for “' + q + '”';
      results.innerHTML = '';
      hits.forEach(function (h) {
        var it = h.it, el = document.createElement('article');
        el.className = 'card';
        var media = it.i ? '<a class="card-img" href="' + it.u + '"><img src="' + it.i + '" alt="" width="1200" height="630" loading="lazy"></a>' : '';
        el.innerHTML = media + '<div class="card-body"><span class="pill">' + (it.e ? it.e + ' ' : '') + '</span><h3><a href="' + it.u + '"></a></h3><p></p></div>';
        $('.pill', el).textContent += it.c; $('h3 a', el).textContent = it.t; $('p', el).textContent = it.d;
        results.appendChild(el);
      });
    });
  }
})();
