# MIKRODINET build plan

1. **Done** — Python generator (`generator.py` + `mkgen/`) that builds the whole site into `public/` with auto subfolders; Netlify build command configured.
2. **Done** — Shared `<head>` on every page (all verification tags, AdSense, AMP ad script, canonical, title/description/keywords, Open Graph, Twitter, JSON-LD, manifest, favicon).
3. **Done** — Header (logo img + alt + home link, dropdown/mega navbar), sidebar (search, social buttons, ads, popular posts, archive, labels, tool picks, contact form, oldest posts), footer with all requested links.
4. **Done** — 250 articles (25 categories × 10) with H1–H6, TOC, table, 3 images, 7 internal + 7 external links, quiz, 6 FAQs, conclusion, share buttons.
5. **Done** — Category, archive, search, sitemap (HTML + XML), RSS, Atom, robots.txt, ads.txt, app-ads.txt, Google verification file, info pages, hardware/software pages, 404, thank-you.
6. **Done** — Tool pages for all 82 tools (guide, links, related tools, FAQ, share) and serverless checker `netlify/functions/check.mts`.
7. **Done (code written)** — Interactive apps for DNS, IP, developer, designer, network, security, productivity and DNS-database tools (`static/js/tools.js`, `static/js/tools-b.js`).
8. **Next** — Load `tools-b.js` (and the future `tools-c.js`) on tool pages: in `generator.py` `build_tools`, add `<script src="/js/tools-b.js" defer>` and `tools-c.js` after `tools.js`.
9. **Next** — Write `static/js/tools-c.js` for the remaining tools: webmaster (robots.txt, favicon, sitemap validator, responsive, domain expiry), performance (gzip, image compression, dummy image, redirect, site down, A/B, QR generator, spell check), operational (screen resolution, share links, lorem ipsum, URL opener, minifier/parser, AMP validator, domain name generator), studio tools (code editor, color generator, audio, keyboard, calligraphy, QuranClip, postal code, maps, SEO analyzer, Quran Play), domain tools (WHOIS, age, AdSense eligibility, price, search-engine submitter), Minecraft color codes.
10. **Next** — Enable Netlify Forms: run `node /opt/buildhome/.claude/skills/netlify-forms/scripts/enable.cjs` and enable form detection.
11. **Later** — Set `ADSENSE_SLOT` env var for manual ad units; point the custom domain and set `SITE_URL`.
