import { Users, Clock, Wallet } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface Employee {
  id: string;
  name: string;
  role: string;
  baseSalary: number;
  commissionRate: number;
  sales: number;
  daysPresent: number;
}

const EMPLOYEES: Employee[] = [
  { id: "e1", name: "Andi Saputra", role: "Kasir", baseSalary: 2500000, commissionRate: 2, sales: 42500000, daysPresent: 24 },
  { id: "e2", name: "Siti Aminah", role: "Kasir", baseSalary: 2500000, commissionRate: 2, sales: 38200000, daysPresent: 22 },
  { id: "e3", name: "Budi Santoso", role: "Gudang", baseSalary: 2300000, commissionRate: 0, sales: 0, daysPresent: 25 },
  { id: "e4", name: "Rina Wati", role: "Sales", baseSalary: 2000000, commissionRate: 3, sales: 51800000, daysPresent: 20 },
];

const rupiah = (n: number) => "Rp " + n.toLocaleString("id-ID");

export default function EmployeesPage() {
  const payroll = EMPLOYEES.map((e) => {
    const commission = (e.sales * e.commissionRate) / 100;
    return { ...e, commission, net: e.baseSalary + commission };
  });

  const totalPayroll = payroll.reduce((s, e) => s + e.net, 0);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="flex items-center gap-4 p-5">
            <div className="grid h-11 w-11 place-items-center rounded-xl bg-emerald-50 text-emerald-700">
              <Users className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500">Total Karyawan</p>
              <p className="font-serif text-xl font-bold text-slate-900">{EMPLOYEES.length}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="flex items-center gap-4 p-5">
            <div className="grid h-11 w-11 place-items-center rounded-xl bg-sky-50 text-sky-700">
              <Clock className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500">Rata-rata Kehadiran</p>
              <p className="font-serif text-xl font-bold text-slate-900">23 hari</p>
            </div>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="flex items-center gap-4 p-5">
            <div className="grid h-11 w-11 place-items-center rounded-xl bg-amber-50 text-amber-700">
              <Wallet className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500">Total Gaji Bulan Ini</p>
              <p className="font-serif text-xl font-bold text-slate-900">{rupiah(totalPayroll)}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardHeader className="border-b border-slate-100 pb-4">
          <CardTitle className="text-base text-slate-900">Laporan Gaji & Komisi</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 pt-4">
          {payroll.map((e) => (
            <div
              key={e.id}
              className="flex flex-col gap-3 rounded-xl border border-slate-100 bg-slate-50/60 p-4 lg:flex-row lg:items-center lg:justify-between"
            >
              <div className="flex items-center gap-3">
                <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-emerald-100 text-sm font-bold text-emerald-700">
                  {e.name.charAt(0)}
                </div>
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-slate-800">{e.name}</p>
                  <p className="text-xs text-slate-500">
                    {e.role} · {e.daysPresent} hari hadir
                  </p>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4 text-right">
                <div>
                  <p className="text-xs text-slate-500">Gaji Pokok</p>
                  <p className="text-sm font-semibold text-slate-800">{rupiah(e.baseSalary)}</p>
                </div>
                <div>
                  <p className="text-xs text-slate-500">Komisi ({e.commissionRate}%)</p>
                  <p className="text-sm font-semibold text-slate-800">{rupiah(e.commission)}</p>
                </div>
                <div>
                  <p className="text-xs text-slate-500">Gaji Bersih</p>
                  <p className="text-sm font-bold text-emerald-700">{rupiah(e.net)}</p>
                </div>
              </div>
              <Badge className="w-fit rounded-full bg-emerald-100 text-emerald-700 hover:bg-emerald-100">
                Siap Dibayar
              </Badge>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}