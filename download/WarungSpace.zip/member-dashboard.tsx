import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { PRODUCTS, DEBTS, EMPLOYEES, REVENUE, formatIDR, calcSalary } from "@/lib/warung-data";
import { MessageCircle, Wallet, Package, Users, TrendingUp, MapPin, AlertTriangle } from "lucide-react";

export function MemberDashboard() {
  const totalDebt = DEBTS.reduce((s, d) => s + d.amount, 0);
  const lowStock = PRODUCTS.filter((p) => p.stock <= 10);
  const todayOmzet = REVENUE[REVENUE.length - 1].omzet;
  const maxOmzet = Math.max(...REVENUE.map((r) => r.omzet));

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-2 text-slate-500">
              <TrendingUp className="h-4 w-4" />
              <span className="text-xs font-semibold uppercase tracking-wide">Omzet Hari Ini</span>
            </div>
            <p className="mt-3 font-serif text-3xl font-bold text-slate-900">{formatIDR(todayOmzet)}</p>
            <p className="mt-1 text-xs text-emerald-600">+12% vs kemarin</p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-2 text-slate-500">
              <Wallet className="h-4 w-4" />
              <span className="text-xs font-semibold uppercase tracking-wide">Total Piutang</span>
            </div>
            <p className="mt-3 font-serif text-3xl font-bold text-rose-600">{formatIDR(totalDebt)}</p>
            <p className="mt-1 text-xs text-slate-400">{DEBTS.length} pelanggan berutang</p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-2 text-slate-500">
              <Package className="h-4 w-4" />
              <span className="text-xs font-semibold uppercase tracking-wide">Stok Menipis</span>
            </div>
            <p className="mt-3 font-serif text-3xl font-bold text-amber-600">{lowStock.length}</p>
            <p className="mt-1 text-xs text-slate-400">produk perlu restock</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-5">
        <Card className="rounded-2xl border-slate-200 shadow-sm lg:col-span-3">
          <CardHeader className="border-b border-slate-100 pb-4">
            <CardTitle className="text-lg font-bold text-slate-900">Grafik Omzet 7 Hari</CardTitle>
          </CardHeader>
          <CardContent className="p-5">
            <div className="flex h-48 items-end gap-3">
              {REVENUE.map((r) => (
                <div key={r.day} className="flex flex-1 flex-col items-center gap-2">
                  <div className="flex w-full flex-1 items-end">
                    <div
                      className="w-full rounded-t-lg bg-gradient-to-t from-emerald-600 to-teal-400 transition-all hover:opacity-80"
                      style={{ height: `${(r.omzet / maxOmzet) * 100}%` }}
                    />
                  </div>
                  <span className="text-xs font-medium text-slate-500">{r.day}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-2xl border-slate-200 shadow-sm lg:col-span-2">
          <CardHeader className="border-b border-slate-100 pb-4">
            <CardTitle className="text-lg font-bold text-slate-900">Stok Menipis</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-slate-100">
              {lowStock.map((p) => (
                <div key={p.id} className="flex items-center gap-3 px-5 py-3.5">
                  <span className="text-xl">{p.emoji}</span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-slate-800">{p.name}</p>
                    <p className="font-mono text-xs text-slate-400">{p.sku}</p>
                  </div>
                  <Badge variant="outline" className="border-amber-200 bg-amber-50 text-amber-700">
                    {p.stock} {p.unit}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardHeader className="border-b border-slate-100 pb-4">
          <CardTitle className="text-lg font-bold text-slate-900">Buku Utang Pelanggan</CardTitle>
          <p className="text-xs text-slate-500">Kirim tagihan via Bot WhatsApp</p>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y divide-slate-100">
            {DEBTS.map((d) => (
              <div key={d.id} className="flex flex-wrap items-center gap-3 px-5 py-4 transition hover:bg-slate-50">
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold text-slate-800">{d.customer}</p>
                  <p className="text-xs text-slate-400">
                    Jatuh tempo {new Date(d.dueDate).toLocaleDateString("id-ID", { day: "numeric", month: "short" })}
                  </p>
                </div>
                <span className="text-sm font-semibold text-rose-600">{formatIDR(d.amount)}</span>
                <Badge
                  variant="outline"
                  className={cn(
                    d.status === "unpaid" && "border-rose-200 bg-rose-50 text-rose-600",
                    d.status === "partial" && "border-amber-200 bg-amber-50 text-amber-700",
                    d.status === "paid" && "border-emerald-200 bg-emerald-50 text-emerald-700"
                  )}
                >
                  {d.status === "unpaid" ? "Belum Bayar" : d.status === "partial" ? "Cicilan" : "Lunas"}
                </Badge>
                <Button size="sm" className="rounded-lg bg-emerald-600 hover:bg-emerald-700">
                  <MessageCircle className="mr-1.5 h-3.5 w-3.5" /> Tagih WA
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardHeader className="border-b border-slate-100 pb-4">
          <CardTitle className="text-lg font-bold text-slate-900">Karyawan & Gaji</CardTitle>
          <p className="text-xs text-slate-500">Gaji pokok + komisi otomatis</p>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y divide-slate-100">
            {EMPLOYEES.map((e) => {
              const { commission, total } = calcSalary(e);
              return (
                <div key={e.id} className="px-5 py-4 transition hover:bg-slate-50">
                  <div className="flex flex-wrap items-center gap-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-full bg-emerald-50 text-sm font-bold text-emerald-700 ring-1 ring-emerald-100">
                      {e.name.charAt(0)}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-semibold text-slate-800">{e.name}</p>
                      <p className="flex items-center gap-1 text-xs text-slate-400">
                        <MapPin className="h-3 w-3" /> {e.gps} · PIN {e.pin}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold text-slate-900">{formatIDR(total)}</p>
                      <p className="text-xs text-slate-400">
                        {e.presentDays} hari · komisi {formatIDR(commission)}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}