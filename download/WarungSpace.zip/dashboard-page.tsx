import { TrendingUp, TrendingDown, Wallet, ShoppingCart, Package, Users } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useVertical } from "@/lib/vertical-context";

const RECENT = [
  { id: "INV-1042", customer: "Bu Siti", total: "Rp 145.000", method: "Tunai", tone: "ok" as const },
  { id: "INV-1041", customer: "Pak Budi", total: "Rp 320.000", method: "Utang", tone: "warn" as const },
  { id: "INV-1040", customer: "Umum", total: "Rp 78.500", method: "Transfer", tone: "info" as const },
  { id: "INV-1039", customer: "Bu Rina", total: "Rp 210.000", method: "Tunai", tone: "ok" as const },
];

const toneStyle = {
  ok: "bg-emerald-100 text-emerald-700 hover:bg-emerald-100",
  warn: "bg-amber-100 text-amber-700 hover:bg-amber-100",
  info: "bg-sky-100 text-sky-700 hover:bg-sky-100",
};

export default function DashboardPage() {
  const { vertical } = useVertical();

  const stats = [
    { label: vertical.kpis[0].label, value: vertical.kpis[0].value, delta: vertical.kpis[0].delta, icon: ShoppingCart, up: true },
    { label: vertical.kpis[1].label, value: vertical.kpis[1].value, delta: vertical.kpis[1].delta, icon: Package, up: true },
    { label: vertical.kpis[2].label, value: vertical.kpis[2].value, delta: vertical.kpis[2].delta, icon: Wallet, up: false },
    { label: "Karyawan Aktif", value: "6 orang", delta: "+1", icon: Users, up: true },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <Card key={s.label} className="rounded-2xl border-slate-200 shadow-sm">
              <CardContent className="p-5">
                <div className="flex items-start justify-between">
                  <div className="grid h-10 w-10 place-items-center rounded-xl bg-emerald-50 text-emerald-700">
                    <Icon className="h-5 w-5" />
                  </div>
                  <span
                    className={`flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold ${
                      s.up ? "bg-emerald-100 text-emerald-700" : "bg-rose-100 text-rose-700"
                    }`}
                  >
                    {s.up ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                    {s.delta}
                  </span>
                </div>
                <p className="mt-4 text-xs font-medium text-slate-500">{s.label}</p>
                <p className="mt-1 font-serif text-xl font-bold text-slate-900">{s.value}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-5">
        <Card className="rounded-2xl border-slate-200 shadow-sm lg:col-span-3">
          <CardHeader className="border-b border-slate-100 pb-4">
            <CardTitle className="text-base text-slate-900">Transaksi Terbaru</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 pt-4">
            {RECENT.map((r) => (
              <div
                key={r.id}
                className="flex items-center justify-between rounded-xl border border-slate-100 bg-slate-50/60 p-3"
              >
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-slate-800">{r.customer}</p>
                  <p className="text-xs text-slate-500">{r.id}</p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-semibold text-slate-800">{r.total}</span>
                  <Badge className={`rounded-full ${toneStyle[r.tone]}`}>{r.method}</Badge>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="rounded-2xl border-slate-200 shadow-sm lg:col-span-2">
          <CardHeader className="border-b border-slate-100 pb-4">
            <CardTitle className="text-base text-slate-900">Ringkasan Bulan Ini</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 pt-4">
            <div className="rounded-xl bg-emerald-50 p-4">
              <p className="text-xs font-medium text-emerald-700">Total Omzet</p>
              <p className="mt-1 font-serif text-2xl font-bold text-emerald-900">Rp 128.400.000</p>
            </div>
            <div className="rounded-xl bg-amber-50 p-4">
              <p className="text-xs font-medium text-amber-700">Piutang Belum Tertagih</p>
              <p className="mt-1 font-serif text-2xl font-bold text-amber-900">Rp 8.650.000</p>
            </div>
            <div className="rounded-xl bg-sky-50 p-4">
              <p className="text-xs font-medium text-sky-700">Laba Kotor Estimasi</p>
              <p className="mt-1 font-serif text-2xl font-bold text-sky-900">Rp 41.200.000</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}