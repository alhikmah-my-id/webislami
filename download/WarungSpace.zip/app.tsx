import { useState } from "react";
import {
  LayoutDashboard,
  ShoppingCart,
  Package,
  Wallet,
  CreditCard,
  Folder,
  Users,
  Activity,
  Clock,
  MessageCircle,
  QrCode,
  ChefHat,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { StoreProvider } from "@/lib/store";
import { RoleProvider, useRole, ROLE_META, type Role } from "@/lib/roles";
import { VerticalProvider } from "@/lib/vertical-context";
import VerticalSwitcher from "@/components/VerticalSwitcher";
import DashboardPage from "@/pages/DashboardPage";
import PosPage from "@/pages/PosPage";
import InventoryPage from "@/pages/InventoryPage";
import DebtsPage from "@/pages/DebtsPage";
import PricingPage from "@/pages/PricingPage";
import ArchitecturePage from "@/pages/ArchitecturePage";
import AdminPage from "@/pages/AdminPage";
import StaffPage from "@/pages/StaffPage";
import OrderPage from "@/pages/OrderPage";
import KitchenPage from "@/pages/KitchenPage";

type Tab =
  | "dashboard"
  | "pos"
  | "inventory"
  | "debts"
  | "pricing"
  | "architecture"
  | "admin"
  | "staff"
  | "order"
  | "kitchen";

const NAV: { id: Tab; label: string; icon: typeof LayoutDashboard; roles: Role[] }[] = [
  { id: "admin", label: "SaaS Admin", icon: Activity, roles: ["saas_admin"] },
  { id: "dashboard", label: "Ringkasan", icon: LayoutDashboard, roles: ["member"] },
  { id: "pos", label: "Kasir", icon: ShoppingCart, roles: ["member", "staff"] },
  { id: "kitchen", label: "Dapur", icon: ChefHat, roles: ["member", "staff"] },
  { id: "inventory", label: "Stok", icon: Package, roles: ["member"] },
  { id: "debts", label: "Utang", icon: Wallet, roles: ["member"] },
  { id: "staff", label: "Absensi", icon: Clock, roles: ["staff"] },
  { id: "order", label: "Menu QR", icon: QrCode, roles: ["member", "staff"] },
  { id: "pricing", label: "Langganan", icon: CreditCard, roles: ["member"] },
  { id: "architecture", label: "Struktur", icon: Folder, roles: ["saas_admin", "member", "staff"] },
];

function Shell() {
  const { role, setRole } = useRole();
  const [tab, setTab] = useState<Tab>("dashboard");

  const visibleNav = NAV.filter((n) => n.roles.includes(role));
  const activeTab = visibleNav.some((n) => n.id === tab) ? tab : visibleNav[0]?.id;

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900">
      <div className="mx-auto flex min-h-screen max-w-6xl flex-col md:flex-row">
        <aside className="md:w-64 shrink-0 bg-emerald-900 text-emerald-50 md:min-h-screen">
          <div className="flex items-center gap-3 border-b border-emerald-800/60 px-6 py-5">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-emerald-500 font-bold text-emerald-950 shadow-md">
              W
            </div>
            <div className="leading-tight">
              <p className="font-serif text-lg font-bold">WarungOS</p>
              <p className="text-xs text-emerald-300">ERP UMKM All-in-One</p>
            </div>
          </div>

          <div className="px-4 pt-4">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-emerald-400">
              Industri
            </p>
            <VerticalSwitcher />
          </div>

          <div className="px-4 pt-4">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-emerald-400">
              Mode Akses
            </p>
            <div className="space-y-2">
              {(Object.keys(ROLE_META) as Role[]).map((r) => {
                const meta = ROLE_META[r];
                const active = role === r;
                return (
                  <button
                    key={r}
                    onClick={() => {
                      setRole(r);
                      setTab(r === "saas_admin" ? "admin" : r === "staff" ? "staff" : "dashboard");
                    }}
                    className={cn(
                      "flex w-full items-center gap-3 rounded-xl px-3 py-2 text-left transition",
                      active ? "bg-emerald-800 ring-1 ring-emerald-500" : "hover:bg-emerald-800/60"
                    )}
                  >
                    <span className={cn("h-2.5 w-2.5 shrink-0 rounded-full", meta.accent)} />
                    <span className="min-w-0">
                      <span className="block text-sm font-semibold">{meta.label}</span>
                      <span className="block truncate text-xs text-emerald-300">{meta.desc}</span>
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          <nav className="flex gap-1 overflow-x-auto p-3 md:flex-col md:overflow-visible md:p-4">
            {visibleNav.map((item) => {
              const Icon = item.icon;
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setTab(item.id)}
                  className={cn(
                    "flex shrink-0 items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium transition",
                    active
                      ? "bg-emerald-500 text-emerald-950 shadow-sm"
                      : "text-emerald-100 hover:bg-emerald-800/70"
                  )}
                >
                  <Icon className="h-4 w-4" />
                  {item.label}
                </button>
              );
            })}
          </nav>

          <div className="hidden px-4 pb-6 md:block">
            <div className="rounded-2xl bg-emerald-800/60 p-4">
              <div className="flex items-center gap-2 text-emerald-200">
                <Users className="h-4 w-4" />
                <span className="text-xs font-semibold uppercase tracking-wide">Paket Aktif</span>
              </div>
              <p className="mt-2 text-sm font-bold text-white">Free Trial</p>
              <p className="text-xs text-emerald-300">Berakhir dalam 7 hari</p>
              <button
                onClick={() => {
                  setRole("member");
                  setTab("pricing");
                }}
                className="mt-3 w-full rounded-lg bg-emerald-500 py-2 text-xs font-bold text-emerald-950 transition hover:bg-emerald-400"
              >
                Upgrade Pro
              </button>
            </div>
            <div className="mt-4 flex items-center gap-2 rounded-xl bg-emerald-800/40 px-3 py-2 text-xs text-emerald-200">
              <MessageCircle className="h-3.5 w-3.5" />
              Bot WA Reminder aktif
            </div>
          </div>
        </aside>

        <main className="flex-1 p-4 md:p-8">
          {activeTab === "dashboard" && <DashboardPage />}
          {activeTab === "pos" && <PosPage />}
          {activeTab === "kitchen" && <KitchenPage />}
          {activeTab === "inventory" && <InventoryPage />}
          {activeTab === "debts" && <DebtsPage />}
          {activeTab === "pricing" && <PricingPage />}
          {activeTab === "architecture" && <ArchitecturePage />}
          {activeTab === "admin" && <AdminPage />}
          {activeTab === "staff" && <StaffPage />}
          {activeTab === "order" && <OrderPage />}
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <RoleProvider>
        <VerticalProvider>
          <Shell />
        </VerticalProvider>
      </RoleProvider>
    </StoreProvider>
  );
}