import { createContext, useContext, useState, type ReactNode } from "react";
import { VERTICALS, DEFAULT_VERTICAL, type Vertical, type VerticalId } from "@/lib/verticals";

interface VerticalContextValue {
  vertical: Vertical;
  setVerticalId: (id: VerticalId) => void;
}

const VerticalContext = createContext<VerticalContextValue | null>(null);

export function VerticalProvider({ children }: { children: ReactNode }) {
  const [id, setId] = useState<VerticalId>(DEFAULT_VERTICAL);
  const vertical = VERTICALS.find((v) => v.id === id) ?? VERTICALS[0];
  return (
    <VerticalContext.Provider value={{ vertical, setVerticalId: setId }}>
      {children}
    </VerticalContext.Provider>
  );
}

export function useVertical() {
  const ctx = useContext(VerticalContext);
  if (!ctx) throw new Error("useVertical must be used within VerticalProvider");
  return ctx;
}