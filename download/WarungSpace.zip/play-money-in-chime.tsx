import { nowStamp, type Claim, type DisbursementStatus } from "@/lib/disbursement-data";

type StatusListener = (claim: Claim) => void;

class DisbursementEngine {
  private listeners = new Set<StatusListener>();
  private timers = new Map<number, ReturnType<typeof setTimeout>>();

  on(cb: StatusListener) {
    this.listeners.add(cb);
    return () => this.listeners.delete(cb);
  }

  private emit(claim: Claim) {
    this.listeners.forEach((cb) => cb(claim));
  }

  /** Simulates POST /api/admin/disburse -> gateway payout queue */
  initiate(claim: Claim): Claim {
    const gatewayRefId = `xnd_pay_${Math.floor(10000 + Math.random() * 89999)}`;
    const queued: Claim = {
      ...claim,
      status: "QUEUED",
      gatewayRefId,
    };
    this.emit(queued);

    const delay = 3500 + Math.random() * 5000;
    const timer = setTimeout(() => {
      this.timers.delete(claim.id);
      const failed = Math.random() < 0.15;
      const finalStatus: DisbursementStatus = failed ? "FAILED" : "SUCCESS";
      this.emit({
        ...queued,
        status: finalStatus,
        errorMessage: failed ? "ACCOUNT_INVALID — nomor tujuan tidak terdaftar" : undefined,
      });
    }, delay);
    this.timers.set(claim.id, timer);

    return queued;
  }

  cancel(id: number) {
    const t = this.timers.get(id);
    if (t) {
      clearTimeout(t);
      this.timers.delete(id);
    }
  }
}

export const disbursementEngine = new DisbursementEngine();

export function playMoneyInChime() {
  try {
    const Ctx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    const now = ctx.currentTime;
    [659.25, 987.77].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "triangle";
      osc.frequency.value = freq;
      const start = now + i * 0.16;
      gain.gain.setValueAtTime(0, start);
      gain.gain.linearRampToValueAtTime(0.16, start + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, start + 0.32);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(start);
      osc.stop(start + 0.34);
    });
    setTimeout(() => ctx.close().catch(() => {}), 1200);
  } catch {
    /* audio unavailable */
  }
}

export function stamp(): string {
  return nowStamp();
}