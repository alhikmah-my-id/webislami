import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { TENANTS, SERVER_NODES, formatIDR, type Tenant } from "@/lib/warung-data";
import { TrendingUp, Users, Server, Ban, Gift, CheckCircle2, Cpu, MemoryStick } from "lucide-react";

const planStyles: Record<Tenant["plan"], string> = {
  active: "border-emerald-200 bg-emerald-50 text-emerald-700",
  free_trial: "border-sky-200 bg-sky-50 text-sky-700",
  expired: "border-amber-200 bg-amber-50 text-amber-700",
  blocked: "border-rose-200 bg-rose-50 text-rose-600",
};

const planLabels: Record<Tenant["plan"], string> = {
  active: "Aktif",
  free_trial: "Trial",
  expired: "Kedaluwarsa",
  blocked: "Diblokir",
};

export function AdminPanel() {
  const [tenants, setTenants] = useState<Tenant[]>(TENANTS);

  const mrr = tenants.filter((t) => t.plan === "active").reduce((s, t) => s + t.mrr, 0);
  const activeCount = tenants.filter((t) => t.plan === "active").length;

  function setPlan(id: string, plan: Tenant["plan"]) {
    setTenants((prev) => prev.map((t) => (t.id === id ? { ...t, plan } : t)));
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card className="rounded-2xl border-slate-200 bg-gradient-to-br from-emerald-600 to-teal-600 text-white shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-2 text-emerald-50">
              <TrendingUp className="h-4 w-4" />
              <span className="text-xs font-semibold uppercase tracking-wide">MRR</span>
            </div>
            <p className="mt-3 font-serif text-3xl font-bold">{formatIDR(mrr)}</p>
            <p className="mt-1 text-xs text-emerald-100">via DANA / QRIS</p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-2 text-slate-500">
              <Users className="h-4 w-4" />
              <span className="text-xs font-semibold uppercase tracking-wide">Tenant Aktif</span>
            </div>
            <p className="mt-3 font-serif text-3xl font-bold text-slate-900">{activeCount}</p>
            <p className="mt-1 text-xs text-slate-400">dari {tenants.length} toko terdaftar</p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-2 text-slate-500">
              <Server className="h-4 w-4" />
              <span className="text-xs font-semibold uppercase tracking-wide">Server</span>
            </div>
            <p className="mt-3 font-serif text-3xl font-bold text-slate-900">Normal</p>
            <p className="mt-1 text-xs text-slate-400">4 node terpantau</p>
          </CardContent>
        </Card>
      </div>

      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardHeader className="border-b border-slate-100 pb-4">
          <CardTitle className="text-lg font-bold text-slate-900">Manajemen Tenant</CardTitle>
          <p className="text-xs text-slate-500">Blokir, aktifkan, atau beri trial gratis</p>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y divide-slate-100">
            {tenants.map((t) => (
              <div key={t.id} className="flex flex-wrap items-center gap-3 px-5 py-4 transition hover:bg-slate-50">
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold text-slate-800">{t.businessName}</p>
                  <p className="text-xs text-slate-400">
                    {t.owner} · s/d {new Date(t.subscriptionUntil).toLocaleDateString("id-ID", { day: "numeric", month: "short", year: "numeric" })}
                  </p>
                </div>
                <span className="text-sm font-semibold text-slate-700">
                  {t.mrr > 0 ? formatIDR(t.mrr) + "/bln" : "—"}
                </span>
                <Badge variant="outline" className={cn("shrink-0", planStyles[t.plan])}>
                  {planLabels[t.plan]}
                </Badge>
                <div className="flex gap-1.5">
                  {t.plan !== "blocked" ? (
                    <Button size="sm" variant="outline" onClick={() => setPlan(t.id, "blocked")} className="rounded-lg text-rose-600 hover:text-rose-700">
                      <Ban className="mr-1 h-3.5 w-3.5" /> Blokir
                    </Button>
                  ) : (
                    <Button size="sm" variant="outline" onClick={() => setPlan(t.id, "active")} className="rounded-lg text-emerald-600 hover:text-emerald-700">
                      <CheckCircle2 className="mr-1 h-3.5 w-3.5" /> Aktifkan
                    </Button>
                  )}
                  <Button size="sm" variant="outline" onClick={() => setPlan(t.id, "free_trial")} className="rounded-lg">
                    <Gift className="mr-1 h-3.5 w-3.5" /> Trial
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardHeader className="border-b border-slate-100 pb-4">
          <CardTitle className="text-lg font-bold text-slate-900">Server Monitor</CardTitle>
          <p className="text-xs text-slate-500">Terintegrasi Cloud Shell</p>
        </CardHeader>
        <CardContent className="p-5">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            {SERVER_NODES.map((n) => (
              <div key={n.name} className="rounded-xl border border-slate-200 bg-slate-50/60 p-4">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-sm font-semibold text-slate-800">{n.name}</span>
                  <span className={cn("h-2 w-2 rounded-full", n.status === "normal" ? "bg-emerald-500" : "bg-amber-500")} />
                </div>
                <div className="mt-3 space-y-2">
                  <div>
                    <div className="flex items-center justify-between text-xs text-slate-500">
                      <span className="flex items-center gap-1"><Cpu className="h-3 w-3" /> CPU</span>
                      <span>{n.cpu}%</span>
                    </div>
                    <div className="mt-1 h-1.5 w-full rounded-full bg-slate-200">
                      <div className={cn("h-1.5 rounded-full", n.cpu > 80 ? "bg-amber-500" : "bg-emerald-500")} style={{ width: `${n.cpu}%` }} />
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between text-xs text-slate-500">
                      <span className="flex items-center gap-1"><MemoryStick className="h-3 w-3" /> RAM</span>
                      <span>{n.ram}%</span>
                    </div>
                    <div className="mt-1 h-1.5 w-full rounded-full bg-slate-200">
                      <div className={cn("h-1.5 rounded-full", n.ram > 80 ? "bg-amber-500" : "bg-emerald-500")} style={{ width: `${n.ram}%` }} />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}