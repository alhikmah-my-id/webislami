import { useState } from "react";
import { Plus, Minus, Trash2, ShoppingCart } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface Product {
  id: string;
  name: string;
  price: number;
  unit: string;
}

const PRODUCTS: Product[] = [
  { id: "p1", name: "Beras Premium 5kg", price: 68000, unit: "sak" },
  { id: "p2", name: "Minyak Goreng 2L", price: 36000, unit: "pouch" },
  { id: "p3", name: "Gula Pasir 1kg", price: 15000, unit: "kg" },
  { id: "p4", name: "Telur Ayam 1kg", price: 28000, unit: "kg" },
  { id: "p5", name: "Kopi Sachet (10pcs)", price: 12000, unit: "pack" },
  { id: "p6", name: "Sabun Mandi", price: 4500, unit: "pcs" },
];

const rupiah = (n: number) => "Rp " + n.toLocaleString("id-ID");

export default function PosPage() {
  const [cart, setCart] = useState<Record<string, number>>({});

  const add = (id: string) => setCart((c) => ({ ...c, [id]: (c[id] ?? 0) + 1 }));
  const sub = (id: string) =>
    setCart((c) => {
      const next = { ...c };
      if (!next[id]) return next;
      next[id] -= 1;
      if (next[id] <= 0) delete next[id];
      return next;
    });
  const remove = (id: string) =>
    setCart((c) => {
      const next = { ...c };
      delete next[id];
      return next;
    });

  const items = Object.entries(cart).map(([id, qty]) => {
    const p = PRODUCTS.find((x) => x.id === id)!;
    return { ...p, qty, subtotal: p.price * qty };
  });
  const total = items.reduce((s, i) => s + i.subtotal, 0);

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-5">
      <Card className="rounded-2xl border-slate-200 shadow-sm lg:col-span-3">
        <CardHeader className="border-b border-slate-100 pb-4">
          <CardTitle className="text-base text-slate-900">Pilih Produk</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 gap-3 pt-4 sm:grid-cols-2">
          {PRODUCTS.map((p) => (
            <button
              key={p.id}
              onClick={() => add(p.id)}
              className="flex items-center justify-between rounded-xl border border-slate-100 bg-slate-50/60 p-4 text-left transition hover:border-emerald-300 hover:bg-emerald-50"
            >
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold text-slate-800">{p.name}</p>
                <p className="text-xs text-slate-500">
                  {rupiah(p.price)} / {p.unit}
                </p>
              </div>
              <div className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-emerald-600 text-white">
                <Plus className="h-4 w-4" />
              </div>
            </button>
          ))}
        </CardContent>
      </Card>

      <Card className="rounded-2xl border-slate-200 shadow-sm lg:col-span-2">
        <CardHeader className="flex flex-row items-center justify-between border-b border-slate-100 pb-4">
          <CardTitle className="text-base text-slate-900">Keranjang</CardTitle>
          <Badge className="rounded-full bg-emerald-100 text-emerald-700 hover:bg-emerald-100">
            {items.length} item
          </Badge>
        </CardHeader>
        <CardContent className="space-y-3 pt-4">
          {items.length === 0 ? (
            <div className="flex flex-col items-center gap-2 py-10 text-center">
              <div className="grid h-12 w-12 place-items-center rounded-2xl bg-slate-100 text-slate-400">
                <ShoppingCart className="h-6 w-6" />
              </div>
              <p className="text-sm font-medium text-slate-600">Keranjang masih kosong</p>
              <p className="text-xs text-slate-400">Pilih produk di sebelah kiri</p>
            </div>
          ) : (
            items.map((i) => (
              <div
                key={i.id}
                className="flex items-center gap-3 rounded-xl border border-slate-100 bg-slate-50/60 p-3"
              >
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold text-slate-800">{i.name}</p>
                  <p className="text-xs text-slate-500">{rupiah(i.subtotal)}</p>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => sub(i.id)}
                    className="grid h-7 w-7 place-items-center rounded-lg bg-white text-slate-600 shadow-sm transition hover:bg-slate-100"
                  >
                    <Minus className="h-3.5 w-3.5" />
                  </button>
                  <span className="w-6 text-center text-sm font-semibold text-slate-800">{i.qty}</span>
                  <button
                    onClick={() => add(i.id)}
                    className="grid h-7 w-7 place-items-center rounded-lg bg-white text-slate-600 shadow-sm transition hover:bg-slate-100"
                  >
                    <Plus className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={() => remove(i.id)}
                    className="grid h-7 w-7 place-items-center rounded-lg bg-rose-50 text-rose-600 transition hover:bg-rose-100"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}

          <div className="mt-2 rounded-xl bg-emerald-900 p-4 text-white">
            <div className="flex items-center justify-between">
              <span className="text-sm text-emerald-200">Total Bayar</span>
              <span className="font-serif text-2xl font-bold">{rupiah(total)}</span>
            </div>
            <Button
              disabled={items.length === 0}
              className="mt-4 w-full rounded-xl bg-emerald-500 py-5 font-semibold text-white hover:bg-emerald-400 disabled:opacity-40"
            >
              Proses Pembayaran
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}