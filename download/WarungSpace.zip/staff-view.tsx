import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { PRODUCTS, formatIDR, type Product } from "@/lib/warung-data";
import { Camera, ScanBarcode, Trash2, CheckCircle2, ShoppingCart, Plus, Minus } from "lucide-react";

type PayMethod = "Tunai" | "Transfer" | "Utang";

interface CartLine {
  product: Product;
  qty: number;
}

export function StaffView() {
  const [cart, setCart] = useState<CartLine[]>([]);
  const [method, setMethod] = useState<PayMethod>("Tunai");
  const [clockedIn, setClockedIn] = useState(false);
  const [receipt, setReceipt] = useState<string | null>(null);

  const total = cart.reduce((s, l) => s + l.product.priceRetail * l.qty, 0);

  function add(p: Product) {
    setCart((prev) => {
      const found = prev.find((l) => l.product.id === p.id);
      if (found) return prev.map((l) => (l.product.id === p.id ? { ...l, qty: l.qty + 1 } : l));
      return [...prev, { product: p, qty: 1 }];
    });
  }

  function changeQty(id: string, delta: number) {
    setCart((prev) =>
      prev
        .map((l) => (l.product.id === id ? { ...l, qty: l.qty + delta } : l))
        .filter((l) => l.qty > 0)
    );
  }

  function checkout() {
    if (cart.length === 0) return;
    setReceipt(`INV-${Math.floor(Math.random() * 90000) + 10000}`);
    setCart([]);
  }

  return (
    <div className="space-y-5">
      {/* Absen */}
      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardContent className="flex flex-wrap items-center gap-4 p-5">
          <div className={cn("flex h-12 w-12 items-center justify-center rounded-xl", clockedIn ? "bg-emerald-50 text-emerald-600 ring-1 ring-emerald-100" : "bg-slate-100 text-slate-500")}>
            <Camera className="h-6 w-6" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="font-semibold text-slate-800">Absen Masuk</p>
            <p className="text-xs text-slate-400">
              {clockedIn ? "Clock in 07:58 · GPS terekam" : "Ambil selfie untuk mulai shift"}
            </p>
          </div>
          {clockedIn ? (
            <Badge variant="outline" className="border-emerald-200 bg-emerald-50 text-emerald-700">
              <CheckCircle2 className="mr-1 h-3.5 w-3.5" /> Sudah Absen
            </Badge>
          ) : (
            <Button onClick={() => setClockedIn(true)} className="rounded-xl bg-emerald-600 hover:bg-emerald-700">
              <Camera className="mr-2 h-4 w-4" /> Clock In
            </Button>
          )}
        </CardContent>
      </Card>

      {receipt && (
        <div className="flex items-center gap-3 rounded-xl border border-emerald-200 bg-emerald-50 px-5 py-3.5">
          <CheckCircle2 className="h-5 w-5 text-emerald-600" />
          <p className="text-sm font-medium text-emerald-800">
            Transaksi berhasil · Struk {receipt} tercetak
          </p>
        </div>
      )}

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        {/* Products */}
        <div className="lg:col-span-2">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="font-semibold text-slate-800">Pilih Produk</h3>
            <Button size="sm" variant="outline" className="rounded-lg">
              <ScanBarcode className="mr-1.5 h-4 w-4" /> Scan Barcode
            </Button>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {PRODUCTS.map((p) => (
              <button
                key={p.id}
                onClick={() => add(p)}
                className="flex flex-col items-start rounded-2xl border border-slate-200 bg-white p-4 text-left shadow-sm transition hover:-translate-y-0.5 hover:border-emerald-300 hover:shadow-md active:scale-95"
              >
                <span className="text-3xl">{p.emoji}</span>
                <span className="mt-2 line-clamp-2 text-sm font-semibold text-slate-800">{p.name}</span>
                <span className="mt-1 font-mono text-xs text-slate-400">{p.sku}</span>
                <span className="mt-2 text-sm font-bold text-emerald-600">{formatIDR(p.priceRetail)}</span>
                <span className="text-xs text-slate-400">Stok {p.stock} {p.unit}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Cart */}
        <div className="lg:col-span-1">
          <Card className="sticky top-4 rounded-2xl border-slate-200 shadow-sm">
            <CardContent className="p-5">
              <div className="flex items-center gap-2">
                <ShoppingCart className="h-5 w-5 text-emerald-600" />
                <h3 className="font-semibold text-slate-800">Keranjang</h3>
                <Badge variant="outline" className="ml-auto border-slate-200 text-slate-600">
                  {cart.reduce((s, l) => s + l.qty, 0)} item
                </Badge>
              </div>

              <div className="mt-4 space-y-3">
                {cart.length === 0 ? (
                  <p className="py-8 text-center text-sm text-slate-400">
                    Keranjang kosong. Klik produk untuk menambah.
                  </p>
                ) : (
                  cart.map((l) => (
                    <div key={l.product.id} className="flex items-center gap-2">
                      <span className="text-lg">{l.product.emoji}</span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium text-slate-800">{l.product.name}</p>
                        <p className="text-xs text-slate-400">{formatIDR(l.product.priceRetail)}</p>
                      </div>
                      <div className="flex items-center gap-1">
                        <button onClick={() => changeQty(l.product.id, -1)} className="flex h-6 w-6 items-center justify-center rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50">
                          <Minus className="h-3 w-3" />
                        </button>
                        <span className="w-6 text-center text-sm font-semibold text-slate-800">{l.qty}</span>
                        <button onClick={() => changeQty(l.product.id, 1)} className="flex h-6 w-6 items-center justify-center rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50">
                          <Plus className="h-3 w-3" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {cart.length > 0 && (
                <button
                  onClick={() => setCart([])}
                  className="mt-3 flex items-center gap-1 text-xs font-medium text-rose-500 hover:text-rose-600"
                >
                  <Trash2 className="h-3 w-3" /> Kosongkan
                </button>
              )}

              <div className="mt-4 border-t border-slate-100 pt-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Metode Bayar</p>
                <div className="mt-2 grid grid-cols-3 gap-2">
                  {(["Tunai", "Transfer", "Utang"] as PayMethod[]).map((m) => (
                    <button
                      key={m}
                      onClick={() => setMethod(m)}
                      className={cn(
                        "rounded-lg border px-2 py-2 text-xs font-semibold transition",
                        method === m
                          ? "border-emerald-500 bg-emerald-50 text-emerald-700"
                          : "border-slate-200 text-slate-600 hover:bg-slate-50"
                      )}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>

              <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-4">
                <span className="text-sm text-slate-500">Total</span>
                <span className="font-serif text-2xl font-bold text-slate-900">{formatIDR(total)}</span>
              </div>

              <Button
                onClick={checkout}
                disabled={cart.length === 0}
                className="mt-4 w-full rounded-xl bg-emerald-600 py-6 text-base hover:bg-emerald-700"
              >
                Bayar & Cetak Struk
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}