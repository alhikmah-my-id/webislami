import { useState } from "react";
import {
  Server,
  Ban,
  Gift,
  TrendingUp,
  Wallet,
  Activity,
  Terminal,
  CheckCircle2,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  TENANTS,
  SERVERS,
  DEPLOY_LOG,
  MRR_TREND,
  PAYMENT_CHANNELS,
} from "@/lib/roles-data";

const rupiah = (n: number) => "Rp " + n.toLocaleString("id-ID");

const planTone: Record<string, string> = {
  active: "bg-emerald-100 text-emerald-700 hover:bg-emerald-100",
  free_trial: "bg-sky-100 text-sky-700 hover:bg-sky-100",
  expired: "bg-rose-100 text-rose-700 hover:bg-rose-100",
};

const serverTone: Record<string, string> = {
  normal: "bg-emerald-100 text-emerald-700",
  padat: "bg-amber-100 text-amber-700",
  kritis: "bg-rose-100 text-rose-700",
};

const barTone: Record<string, string> = {
  normal: "bg-emerald-500",
  padat: "bg-amber-500",
  kritis: "bg-rose-500",
};

export default function SuperAdminPage() {
  const [tenants, setTenants] = useState(TENANTS);
  const totalMrr = tenants.reduce((s, t) => s + t.mrr, 0);
  const maxMrr = Math.max(...MRR_TREND.map((m) => m.mrr), 1);

  const toggleBlock = (id: string) =>
    setTenants((prev) =>
      prev.map((t) =>
        t.id === id
          ? { ...t, status: t.status === "aktif" ? "diblokir" : "aktif" }
          : t
      )
    );

  const grantTrial = (id: string) =>
    setTenants((prev) =>
      prev.map((t) =>
        t.id === id ? { ...t, plan: "free_trial", status: "aktif" } : t
      )
    );

  return (
    <div className="space-y-6">
      <div className="rounded-2xl bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-900 p-6 shadow-md">
        <span className="inline-block rounded-full bg-rose-500/20 px-3 py-1 text-xs font-semibold text-rose-200">
          Panel SuperSaaS Admin · Akses Terbatas
        </span>
        <h2 className="mt-3 font-serif text-2xl font-bold text-white">
          Kontrol Penuh WarungOS
        </h2>
        <p className="mt-1 text-sm text-slate-300">
          Pantau MRR, kelola tenant, dan monitor kesehatan server produksi.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-2 text-emerald-700">
              <TrendingUp className="h-4 w-4" />
              <p className="text-xs font-medium text-slate-500">MRR Bulan Ini</p>
            </div>
            <p className="mt-2 font-serif text-xl font-bold text-slate-900">
              {rupiah(totalMrr)}
            </p>
            <p className="text-xs font-semibold text-emerald-700">+22,9% vs bulan lalu</p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-medium text-slate-500">Total Tenant</p>
            <p className="mt-2 font-serif text-xl font-bold text-slate-900">
              {tenants.length}
            </p>
            <p className="text-xs text-slate-500">
              {tenants.filter((t) => t.status === "aktif").length} aktif ·{" "}
              {tenants.filter((t) => t.status === "diblokir").length} diblokir
            </p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-medium text-slate-500">Server Kritis</p>
            <p className="mt-2 font-serif text-xl font-bold text-rose-700">
              {SERVERS.filter((s) => s.status === "kritis").length}
            </p>
            <p className="text-xs text-slate-500">dari {SERVERS.length} node</p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-2">
              <Wallet className="h-4 w-4 text-emerald-700" />
              <p className="text-xs font-medium text-slate-500">DANA + QRIS</p>
            </div>
            <p className="mt-2 font-serif text-xl font-bold text-slate-900">
              {rupiah(PAYMENT_CHANNELS[0].amount + PAYMENT_CHANNELS[1].amount)}
            </p>
            <p className="text-xs text-slate-500">82% dari total pembayaran</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="rounded-2xl border-slate-200 shadow-sm lg:col-span-2">
          <CardHeader className="border-b border-slate-100 pb-4">
            <CardTitle className="text-base text-slate-900">Tren MRR 6 Bulan</CardTitle>
          </CardHeader>
          <CardContent className="pt-5">
            <div className="flex h-48 items-end gap-3">
              {MRR_TREND.map((m) => (
                <div key={m.month} className="flex flex-1 flex-col items-center gap-2">
                  <span className="text-xs font-semibold text-slate-600">
                    {(m.mrr / 1000000).toFixed(1)}jt
                  </span>
                  <div
                    className="w-full rounded-t-lg bg-gradient-to-t from-emerald-600 to-emerald-400"
                    style={{ height: `${(m.mrr / maxMrr) * 100}%` }}
                  />
                  <span className="text-xs text-slate-500">{m.month}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardHeader className="border-b border-slate-100 pb-4">
            <CardTitle className="text-base text-slate-900">Metode Pembayaran</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 pt-5">
            {PAYMENT_CHANNELS.map((p) => (
              <div key={p.name}>
                <div className="mb-1 flex items-center justify-between text-xs">
                  <span className="font-medium text-slate-700">{p.name}</span>
                  <span className="font-semibold text-slate-800">{rupiah(p.amount)}</span>
                </div>
                <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-100">
                  <div
                    className="h-full rounded-full bg-emerald-500"
                    style={{ width: `${p.share}%` }}
                  />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardHeader className="border-b border-slate-100 pb-4">
          <CardTitle className="text-base text-slate-900">Manajemen Tenant</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 pt-4">
          {tenants.map((t) => (
            <div
              key={t.id}
              className="flex flex-col gap-3 rounded-xl border border-slate-100 bg-slate-50/60 p-4 lg:flex-row lg:items-center lg:justify-between"
            >
              <div className="lg:w-1/3">
                <p className="text-sm font-semibold text-slate-800">{t.business}</p>
                <p className="text-xs text-slate-500">
                  {t.owner} · hingga {t.until}
                </p>
              </div>
              <div className="flex items-center gap-3 lg:w-1/4">
                <Badge className={`rounded-full ${planTone[t.plan]}`}>{t.plan}</Badge>
                <span className="text-sm font-semibold text-slate-800">
                  {t.mrr > 0 ? rupiah(t.mrr) : "-"}
                </span>
              </div>
              <div className="flex gap-2 lg:justify-end">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => grantTrial(t.id)}
                  className="rounded-lg border-sky-200 text-sky-700 hover:bg-sky-50"
                >
                  <Gift className="mr-1.5 h-3.5 w-3.5" />
                  Trial
                </Button>
                <Button
                  size="sm"
                  onClick={() => toggleBlock(t.id)}
                  className={`rounded-lg ${
                    t.status === "aktif"
                      ? "bg-rose-600 text-white hover:bg-rose-700"
                      : "bg-emerald-600 text-white hover:bg-emerald-700"
                  }`}
                >
                  <Ban className="mr-1.5 h-3.5 w-3.5" />
                  {t.status === "aktif" ? "Blokir" : "Aktifkan"}
                </Button>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardHeader className="border-b border-slate-100 pb-4">
            <CardTitle className="flex items-center gap-2 text-base text-slate-900">
              <Server className="h-4 w-4 text-emerald-700" />
              Server Monitor
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 pt-4">
            {SERVERS.map((s) => (
              <div key={s.id} className="rounded-xl border border-slate-100 bg-slate-50/60 p-3">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-mono text-sm font-semibold text-slate-800">{s.name}</p>
                    <p className="text-xs text-slate-500">{s.region}</p>
                  </div>
                  <Badge className={`rounded-full ${serverTone[s.status]}`}>{s.status}</Badge>
                </div>
                <div className="mt-3 space-y-2">
                  {[
                    { label: "CPU", value: s.cpu },
                    { label: "RAM", value: s.ram },
                    { label: "Disk", value: s.disk },
                  ].map((m) => (
                    <div key={m.label} className="flex items-center gap-2">
                      <span className="w-8 text-xs text-slate-500">{m.label}</span>
                      <div className="h-2 flex-1 overflow-hidden rounded-full bg-slate-200">
                        <div
                          className={`h-full rounded-full ${barTone[s.status]}`}
                          style={{ width: `${m.value}%` }}
                        />
                      </div>
                      <span className="w-9 text-right text-xs font-semibold text-slate-600">
                        {m.value}%
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardHeader className="border-b border-slate-100 pb-4">
            <CardTitle className="flex items-center gap-2 text-base text-slate-900">
              <Terminal className="h-4 w-4 text-emerald-700" />
              Cloud Shell Deploy
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 pt-4">
            <div className="rounded-xl bg-slate-900 p-4 font-mono text-xs leading-relaxed text-emerald-300">
              <p className="text-slate-500"># update WarungOS</p>
              <p>cd warungos-app/</p>
              <p>git pull origin main</p>
              <p className="text-slate-500"># deploy otomatis</p>
              <p>./.cloudshell/deploy-backend.sh</p>
            </div>
            <div className="space-y-2">
              {DEPLOY_LOG.map((d) => (
                <div key={d.id} className="flex items-start gap-2 text-xs">
                  <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-600" />
                  <span className="font-mono text-slate-400">{d.time}</span>
                  <span className="text-slate-600">{d.text}</span>
                </div>
              ))}
            </div>
            <Button className="w-full rounded-xl bg-emerald-600 font-semibold text-white hover:bg-emerald-700">
              <Activity className="mr-2 h-4 w-4" />
              Jalankan Deploy Sekarang
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}