import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FlaskConical, CheckCircle2, XCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { runPayoutControllerTests, type TestResult } from "@/lib/__tests__/payout-controller.test";

export function UnitTestPanel() {
  const [results, setResults] = useState<TestResult[]>([]);
  const [ran, setRan] = useState(false);

  function run() {
    setResults(runPayoutControllerTests());
    setRan(true);
  }

  const passed = results.filter((r) => r.passed).length;

  return (
    <Card className="rounded-2xl border-slate-200 shadow-sm">
      <CardHeader className="flex flex-row items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-violet-50 text-violet-600 ring-1 ring-violet-100">
            <FlaskConical className="h-5 w-5" />
          </div>
          <div>
            <CardTitle className="text-lg font-bold text-slate-900">Unit Tests</CardTitle>
            <p className="text-xs text-slate-500">payout-controller</p>
          </div>
        </div>
        <Button onClick={run} className="rounded-xl bg-violet-600 hover:bg-violet-700">
          Run Tests
        </Button>
      </CardHeader>
      <CardContent className="p-0">
        {!ran ? (
          <p className="px-5 py-10 text-center text-sm text-slate-400">
            Tekan "Run Tests" untuk menjalankan suite.
          </p>
        ) : (
          <>
            <div className="flex items-center gap-2 border-b border-slate-100 bg-slate-50/60 px-5 py-3">
              <Badge
                variant="outline"
                className={cn(
                  passed === results.length
                    ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                    : "border-amber-200 bg-amber-50 text-amber-700"
                )}
              >
                {passed} / {results.length} passed
              </Badge>
            </div>
            <div className="divide-y divide-slate-100">
              {results.map((r) => (
                <div key={r.name} className="flex items-center gap-3 px-5 py-3">
                  {r.passed ? (
                    <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-500" />
                  ) : (
                    <XCircle className="h-4 w-4 shrink-0 text-rose-500" />
                  )}
                  <span className="min-w-0 flex-1 truncate text-sm text-slate-700">{r.name}</span>
                  <span className="shrink-0 text-xs text-slate-400">{r.detail}</span>
                </div>
              ))}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}