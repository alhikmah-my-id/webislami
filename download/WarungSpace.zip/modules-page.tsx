import { useState } from "react";
import {
  Layers,
  ClipboardList,
  FlaskConical,
  Briefcase,
  Truck,
  CheckCircle2,
  AlertTriangle,
  Clock,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useVertical } from "@/lib/vertical-context";
import type { VerticalId } from "@/lib/verticals";

interface Row {
  id: string;
  title: string;
  meta: string;
  status: string;
  tone: "ok" | "warn" | "info";
}

const DATA: Record<VerticalId, { heading: string; icon: typeof Layers; rows: Row[] }> = {
  retail: {
    heading: "Operasional Toko",
    icon: Layers,
    rows: [
      { id: "r1", title: "Restok Beras Premium", meta: "Supplier: CV Sumber Rejeki", status: "Dipesan", tone: "info" },
      { id: "r2", title: "Opname Harian", meta: "Selisih 0 item", status: "Selesai", tone: "ok" },
      { id: "r3", title: "Minyak Goreng 2L", meta: "Sisa 3 unit", status: "Stok Rendah", tone: "warn" },
    ],
  },
  konveksi: {
    heading: "Lini Produksi",
    icon: ClipboardList,
    rows: [
      { id: "k1", title: "Seragam Sekolah 120 pcs", meta: "Klien: SMAN 3 · Deadline 12 hari", status: "Cutting", tone: "info" },
      { id: "k2", title: "Kaos Komunitas 60 pcs", meta: "Klien: Komunitas Lari", status: "Sewing", tone: "info" },
      { id: "k3", title: "Jaket Varsity 40 pcs", meta: "Klien: BEM Univ", status: "QC", tone: "warn" },
      { id: "k4", title: "Kemeja PDH 200 pcs", meta: "Klien: PT Nusantara", status: "Selesai", tone: "ok" },
    ],
  },
  fnb: {
    heading: "Resep & Food Cost",
    icon: FlaskConical,
    rows: [
      { id: "f1", title: "Nasi Goreng Spesial", meta: "HPP Rp 9.400 · Jual Rp 22.000", status: "Margin 57%", tone: "ok" },
      { id: "f2", title: "Es Kopi Susu", meta: "HPP Rp 7.100 · Jual Rp 18.000", status: "Margin 61%", tone: "ok" },
      { id: "f3", title: "Ayam Geprek", meta: "HPP Rp 11.200 · Jual Rp 20.000", status: "Margin 44%", tone: "warn" },
    ],
  },
  farmasi: {
    heading: "Batch & Kadaluarsa",
    icon: FlaskConical,
    rows: [
      { id: "p1", title: "Paracetamol 500mg", meta: "Batch B2401 · Exp 2026-03", status: "Aman", tone: "ok" },
      { id: "p2", title: "Amoxicillin 500mg", meta: "Batch A2312 · Exp 2025-11", status: "Segera Exp", tone: "warn" },
      { id: "p3", title: "Vitamin C 1000mg", meta: "Batch V2405 · Exp 2027-01", status: "Aman", tone: "ok" },
    ],
  },
  jasa: {
    heading: "Proyek & Timesheet",
    icon: Briefcase,
    rows: [
      { id: "j1", title: "Redesign Website Klien A", meta: "42 jam · 68% selesai", status: "Berjalan", tone: "info" },
      { id: "j2", title: "Audit Keuangan Klien B", meta: "18 jam · 100% selesai", status: "Selesai", tone: "ok" },
      { id: "j3", title: "Kampanye Sosial Klien C", meta: "6 jam · 22% selesai", status: "Berjalan", tone: "info" },
    ],
  },
  logistik: {
    heading: "Shipment & Rute",
    icon: Truck,
    rows: [
      { id: "l1", title: "SHP-1042 · Jakarta → Bandung", meta: "Armada B 1234 XY · 3 koli", status: "Dalam Perjalanan", tone: "info" },
      { id: "l2", title: "SHP-1041 · Surabaya → Malang", meta: "Armada B 8899 ZZ · 1 koli", status: "Terkirim", tone: "ok" },
      { id: "l3", title: "SHP-1040 · Medan → Banda Aceh", meta: "Armada BK 5522 AA · 5 koli", status: "Tertunda", tone: "warn" },
    ],
  },
};

const toneStyle: Record<Row["tone"], string> = {
  ok: "bg-emerald-100 text-emerald-700 hover:bg-emerald-100",
  warn: "bg-amber-100 text-amber-700 hover:bg-amber-100",
  info: "bg-sky-100 text-sky-700 hover:bg-sky-100",
};

const toneIcon: Record<Row["tone"], typeof CheckCircle2> = {
  ok: CheckCircle2,
  warn: AlertTriangle,
  info: Clock,
};

export default function ModulesPage() {
  const { vertical } = useVertical();
  const data = DATA[vertical.id];
  const Icon = data.icon;
  const [done, setDone] = useState<Record<string, boolean>>({});

  return (
    <div className="space-y-6">
      <header
        className={`rounded-2xl bg-gradient-to-br ${vertical.accent} p-6 text-white shadow-md md:p-8`}
      >
        <div className="flex items-center gap-2 text-white/70">
          <Icon className="h-4 w-4" />
          <span className="text-xs font-semibold uppercase tracking-widest">
            {vertical.name}
          </span>
        </div>
        <h1 className="mt-2 font-serif text-2xl font-bold md:text-3xl">{data.heading}</h1>
        <p className="mt-1 text-sm text-white/80">
          Modul khusus industri: {vertical.modules.join(" · ")}
        </p>
      </header>

      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardHeader className="border-b border-slate-100 pb-4">
          <CardTitle className="text-base text-slate-900">Daftar Kerja</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 pt-4">
          {data.rows.map((row) => {
            const StatusIcon = toneIcon[row.tone];
            const isDone = done[row.id];
            return (
              <div
                key={row.id}
                className="flex flex-col gap-3 rounded-xl border border-slate-100 bg-slate-50/60 p-4 sm:flex-row sm:items-center"
              >
                <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-white text-slate-600 shadow-sm">
                  <StatusIcon className="h-5 w-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold text-slate-800">{row.title}</p>
                  <p className="truncate text-xs text-slate-500">{row.meta}</p>
                </div>
                <Badge className={`w-fit rounded-full ${toneStyle[row.tone]}`}>{row.status}</Badge>
                <Button
                  size="sm"
                  variant={isDone ? "outline" : "default"}
                  className={`rounded-lg ${isDone ? "" : "bg-emerald-600 hover:bg-emerald-700"}`}
                  onClick={() => setDone((p) => ({ ...p, [row.id]: !p[row.id] }))}
                >
                  {isDone ? "Dibuka" : "Tandai Selesai"}
                </Button>
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}