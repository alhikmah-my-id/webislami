import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { FEATURES, FAQS, STATS, type Feature } from "@/lib/features-data";
import {
  ChevronDown,
  Check,
  Sparkles,
  Store,
  ArrowRight,
} from "lucide-react";

const badgeStyles: Record<string, string> = {
  Gratis: "border-emerald-200 bg-emerald-50 text-emerald-700",
  Langganan: "border-indigo-200 bg-indigo-50 text-indigo-700",
  "Add-on": "border-amber-200 bg-amber-50 text-amber-700",
};

function FeatureCard({ feature }: { feature: Feature }) {
  return (
    <div className="group flex flex-col rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:border-emerald-200 hover:shadow-md">
      <div className="flex items-start justify-between gap-3">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-50 text-xl ring-1 ring-emerald-100">
          {feature.icon}
        </div>
        {feature.badge && (
          <Badge variant="outline" className={cn("shrink-0 text-xs", badgeStyles[feature.badge])}>
            {feature.badge}
          </Badge>
        )}
      </div>
      <h3 className="mt-4 text-base font-bold text-slate-900">{feature.title}</h3>
      <p className="mt-1 text-sm text-slate-500">{feature.description}</p>
      <ul className="mt-4 space-y-2">
        {feature.items.map((item) => (
          <li key={item} className="flex gap-2 text-sm text-slate-600">
            <Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" />
            <span>{item}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function FaqItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left transition hover:bg-slate-50"
      >
        <span className="text-sm font-semibold text-slate-800">{q}</span>
        <ChevronDown
          className={cn(
            "h-4 w-4 shrink-0 text-slate-400 transition-transform",
            open && "rotate-180"
          )}
        />
      </button>
      {open && (
        <p className="border-t border-slate-100 px-5 py-4 text-sm text-slate-600">{a}</p>
      )}
    </div>
  );
}

export function LandingPage() {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Nav */}
      <nav className="sticky top-0 z-20 border-b border-slate-200 bg-white/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-3.5 sm:px-8">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-600 text-white shadow-sm">
              <Store className="h-5 w-5" />
            </div>
            <span className="font-serif text-lg font-bold text-slate-900">WarungSpace</span>
          </div>
          <div className="hidden items-center gap-6 sm:flex">
            <a href="#fitur" className="text-sm font-medium text-slate-600 transition hover:text-emerald-600">
              Fitur
            </a>
            <a href="#faq" className="text-sm font-medium text-slate-600 transition hover:text-emerald-600">
              FAQ
            </a>
          </div>
          <Button className="rounded-xl bg-emerald-600 hover:bg-emerald-700">
            Coba Gratis
          </Button>
        </div>
      </nav>

      {/* Hero */}
      <header className="relative overflow-hidden bg-gradient-to-br from-emerald-700 via-emerald-600 to-teal-600">
        <div className="absolute -right-20 -top-20 h-64 w-64 rounded-full bg-white/10 blur-2xl" />
        <div className="absolute -bottom-24 -left-16 h-72 w-72 rounded-full bg-teal-400/20 blur-3xl" />
        <div className="relative mx-auto max-w-6xl px-5 py-16 sm:px-8 sm:py-24">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-2 rounded-full bg-white/15 px-3.5 py-1.5 text-xs font-semibold text-white ring-1 ring-white/25 backdrop-blur">
              <Sparkles className="h-3.5 w-3.5" />
              ERP UMKM All-in-One
            </span>
            <h1 className="mt-5 font-serif text-4xl font-bold leading-tight text-white sm:text-5xl">
              Kelola warung Anda dengan lebih mudah & profesional
            </h1>
            <p className="mt-5 max-w-xl text-base text-emerald-50 sm:text-lg">
              Semua yang dibutuhkan UMKM untuk mengelola toko — kasir, stok, piutang,
              laporan, sampai katalog online. Mobile-first, siap pakai.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button size="lg" className="rounded-xl bg-white text-emerald-700 shadow-sm hover:bg-emerald-50">
                Coba Gratis
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="rounded-xl border-white/40 bg-white/10 text-white hover:bg-white/20 hover:text-white"
              >
                Lihat FAQ
              </Button>
            </div>
          </div>

          <div className="mt-14 grid grid-cols-2 gap-4 sm:grid-cols-4">
            {STATS.map((s) => (
              <div
                key={s.label}
                className="rounded-2xl border border-white/20 bg-white/10 p-4 backdrop-blur"
              >
                <p className="font-serif text-2xl font-bold text-white sm:text-3xl">{s.value}</p>
                <p className="mt-1 text-xs text-emerald-100">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </header>

      {/* Features */}
      <section id="fitur" className="mx-auto max-w-6xl px-5 py-16 sm:px-8 sm:py-20">
        <div className="max-w-2xl">
          <p className="text-sm font-semibold uppercase tracking-wide text-emerald-600">
            Fitur Lengkap
          </p>
          <h2 className="mt-2 font-serif text-3xl font-bold text-slate-900 sm:text-4xl">
            Daftar fitur WarungSpace
          </h2>
          <p className="mt-3 text-base text-slate-500">
            Semua yang dibutuhkan UMKM untuk mengelola toko dengan lebih mudah dan profesional.
          </p>
        </div>

        <div className="mt-10 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <FeatureCard key={f.title} feature={f} />
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="border-t border-slate-200 bg-white">
        <div className="mx-auto max-w-3xl px-5 py-16 sm:px-8 sm:py-20">
          <div className="text-center">
            <p className="text-sm font-semibold uppercase tracking-wide text-emerald-600">
              Pertanyaan Umum
            </p>
            <h2 className="mt-2 font-serif text-3xl font-bold text-slate-900 sm:text-4xl">
              Ada yang ingin ditanyakan?
            </h2>
          </div>
          <div className="mt-10 space-y-3">
            {FAQS.map((f) => (
              <FaqItem key={f.q} q={f.q} a={f.a} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-6xl px-5 py-16 sm:px-8">
        <div className="overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-700 to-teal-600 p-8 text-center sm:p-12">
          <h2 className="font-serif text-2xl font-bold text-white sm:text-3xl">
            Siap memulai dengan WarungSpace?
          </h2>
          <p className="mx-auto mt-3 max-w-lg text-sm text-emerald-50 sm:text-base">
            Daftar sekarang dan rasakan kemudahan mengelola warung Anda — gratis untuk memulai.
          </p>
          <Button size="lg" className="mt-7 rounded-xl bg-white text-emerald-700 hover:bg-emerald-50">
            Coba Gratis Sekarang
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-slate-900">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-5 py-8 sm:flex-row sm:px-8">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-600 text-white">
              <Store className="h-4 w-4" />
            </div>
            <span className="font-serif text-base font-bold text-white">WarungSpace</span>
          </div>
          <p className="text-sm text-slate-400">
            Develop by{" "}
            <a
              href="https://awdev.my.id"
              target="_blank"
              rel="noreferrer"
              className="font-semibold text-emerald-400 transition hover:text-emerald-300"
            >
              AWD
            </a>
          </p>
        </div>
      </footer>
    </div>
  );
}