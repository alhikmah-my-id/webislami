import { ChevronDown } from "lucide-react";
import { VERTICALS } from "@/lib/verticals";
import { useVertical } from "@/lib/vertical-context";

export default function VerticalSwitcher() {
  const { vertical, setVerticalId } = useVertical();

  return (
    <div className="relative">
      <div className="flex items-center gap-2 rounded-xl bg-emerald-800/60 px-3 py-2">
        <span className="text-lg leading-none">{vertical.emoji}</span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-xs font-semibold text-white">{vertical.name}</p>
          <p className="truncate text-xs text-emerald-300">{vertical.tagline}</p>
        </div>
        <ChevronDown className="h-4 w-4 shrink-0 text-emerald-300" />
      </div>
      <select
        aria-label="Pilih industri"
        value={vertical.id}
        onChange={(e) => setVerticalId(e.target.value as typeof vertical.id)}
        className="absolute inset-0 cursor-pointer opacity-0"
      >
        {VERTICALS.map((v) => (
          <option key={v.id} value={v.id}>
            {v.emoji} {v.name}
          </option>
        ))}
      </select>
    </div>
  );
}