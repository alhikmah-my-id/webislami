import { useState } from "react";
import { Search, Package, AlertTriangle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

interface Item {
  id: string;
  name: string;
  sku: string;
  stock: number;
  unit: string;
  price: number;
}

const ITEMS: Item[] = [
  { id: "i1", name: "Beras Premium 5kg", sku: "BRS-5K", stock: 42, unit: "sak", price: 68000 },
  { id: "i2", name: "Minyak Goreng 2L", sku: "MYK-2L", stock: 3, unit: "pouch", price: 36000 },
  { id: "i3", name: "Gula Pasir 1kg", sku: "GLA-1K", stock: 58, unit: "kg", price: 15000 },
  { id: "i4", name: "Telur Ayam 1kg", sku: "TLR-1K", stock: 12, unit: "kg", price: 28000 },
  { id: "i5", name: "Kopi Sachet (10pcs)", sku: "KPI-10", stock: 96, unit: "pack", price: 12000 },
  { id: "i6", name: "Sabun Mandi", sku: "SBN-01", stock: 7, unit: "pcs", price: 4500 },
];

const rupiah = (n: number) => "Rp " + n.toLocaleString("id-ID");

export default function InventoryPage() {
  const [q, setQ] = useState("");
  const filtered = ITEMS.filter(
    (i) =>
      i.name.toLowerCase().includes(q.toLowerCase()) ||
      i.sku.toLowerCase().includes(q.toLowerCase())
  );

  const lowStock = ITEMS.filter((i) => i.stock <= 10).length;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="flex items-center gap-4 p-5">
            <div className="grid h-11 w-11 place-items-center rounded-xl bg-emerald-50 text-emerald-700">
              <Package className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500">Total SKU</p>
              <p className="font-serif text-xl font-bold text-slate-900">{ITEMS.length}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="flex items-center gap-4 p-5">
            <div className="grid h-11 w-11 place-items-center rounded-xl bg-amber-50 text-amber-700">
              <AlertTriangle className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500">Stok Rendah</p>
              <p className="font-serif text-xl font-bold text-slate-900">{lowStock} item</p>
            </div>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="flex items-center gap-4 p-5">
            <div className="grid h-11 w-11 place-items-center rounded-xl bg-sky-50 text-sky-700">
              <Package className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500">Nilai Persediaan</p>
              <p className="font-serif text-xl font-bold text-slate-900">Rp 8,4 jt</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardHeader className="flex flex-col gap-3 border-b border-slate-100 pb-4 sm:flex-row sm:items-center sm:justify-between">
          <CardTitle className="text-base text-slate-900">Daftar Produk</CardTitle>
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Cari nama atau SKU..."
              className="rounded-xl pl-9"
            />
          </div>
        </CardHeader>
        <CardContent className="space-y-3 pt-4">
          {filtered.length === 0 ? (
            <p className="py-10 text-center text-sm text-slate-500">
              Tidak ada produk yang cocok.
            </p>
          ) : (
            filtered.map((i) => {
              const low = i.stock <= 10;
              return (
                <div
                  key={i.id}
                  className="flex flex-col gap-3 rounded-xl border border-slate-100 bg-slate-50/60 p-4 sm:flex-row sm:items-center sm:justify-between"
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold text-slate-800">{i.name}</p>
                    <p className="text-xs text-slate-500">
                      {i.sku} · {rupiah(i.price)} / {i.unit}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-semibold text-slate-800">
                      {i.stock} {i.unit}
                    </span>
                    <Badge
                      className={`rounded-full ${
                        low
                          ? "bg-amber-100 text-amber-700 hover:bg-amber-100"
                          : "bg-emerald-100 text-emerald-700 hover:bg-emerald-100"
                      }`}
                    >
                      {low ? "Stok Rendah" : "Tersedia"}
                    </Badge>
                  </div>
                </div>
              );
            })
          )}
        </CardContent>
      </Card>
    </div>
  );
}