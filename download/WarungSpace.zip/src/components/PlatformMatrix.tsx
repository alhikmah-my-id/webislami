import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";
import { PLATFORM_SUPPORT, DEPLOYMENT_OPTIONS } from "@/lib/tappx-service";

const accentMap: Record<string, { chip: string; dot: string }> = {
  sky: { chip: "bg-sky-50 text-sky-600 ring-sky-100", dot: "text-sky-500" },
  emerald: { chip: "bg-emerald-50 text-emerald-600 ring-emerald-100", dot: "text-emerald-500" },
  rose: { chip: "bg-rose-50 text-rose-600 ring-rose-100", dot: "text-rose-500" },
};

export function PlatformMatrix() {
  return (
    <div className="space-y-6">
      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg font-bold text-slate-900">Platform Support</CardTitle>
          <p className="text-xs text-slate-500">Web · Android · iOS ready</p>
        </CardHeader>
        <CardContent className="space-y-3">
          {PLATFORM_SUPPORT.map((p) => {
            const accent = accentMap[p.accent] ?? accentMap.sky;
            return (
              <div key={p.platform} className="rounded-xl border border-slate-100 bg-slate-50/50 p-4">
                <div className="mb-3 flex items-center gap-3">
                  <span className={cn("flex h-9 w-9 items-center justify-center rounded-lg text-lg ring-1", accent.chip)}>
                    {p.icon}
                  </span>
                  <span className="font-semibold text-slate-800">{p.platform}</span>
                </div>
                <ul className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
                  {p.requirements.map((r) => (
                    <li key={r} className="flex items-center gap-2 text-xs text-slate-600">
                      <Check className={cn("h-3.5 w-3.5 shrink-0", accent.dot)} />
                      {r}
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </CardContent>
      </Card>

      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg font-bold text-slate-900">Deployment</CardTitle>
          <p className="text-xs text-slate-500">Lihat DEPLOY.md untuk panduan lengkap</p>
        </CardHeader>
        <CardContent className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          {DEPLOYMENT_OPTIONS.map((d) => (
            <div
              key={d.name}
              className="flex items-center gap-3 rounded-xl border border-slate-100 bg-white p-3.5 shadow-sm transition hover:border-indigo-200 hover:shadow-md"
            >
              <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-slate-100 text-base">
                {d.icon}
              </span>
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold text-slate-800">{d.name}</p>
                <p className="truncate text-xs text-slate-500">{d.detail}</p>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}