import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Wallet, ArrowUpRight, ArrowDownRight } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  checkWalletBalance,
  getWalletHistory,
  type WalletBalance,
  type WalletHistoryEntry,
} from "@/lib/wallet-api";

export function WalletBalanceCard() {
  const [balance, setBalance] = useState<WalletBalance | null>(null);
  const [history, setHistory] = useState<WalletHistoryEntry[]>([]);

  useEffect(() => {
    setBalance(checkWalletBalance());
    setHistory(getWalletHistory());
  }, []);

  if (!balance) {
    return (
      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardContent className="p-6 text-sm text-slate-400">Memuat saldo…</CardContent>
      </Card>
    );
  }

  return (
    <Card className="rounded-2xl border-slate-200 shadow-sm">
      <CardHeader className="flex flex-row items-center gap-3 border-b border-slate-100 pb-4">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600 ring-1 ring-emerald-100">
          <Wallet className="h-5 w-5" />
        </div>
        <div>
          <CardTitle className="text-lg font-bold text-slate-900">Saldo Dompet</CardTitle>
          <p className="text-xs text-slate-500">Xendit balance</p>
        </div>
      </CardHeader>
      <CardContent className="p-5">
        <p className="text-3xl font-bold text-slate-900">
          Rp {balance.available.toLocaleString("id-ID")}
        </p>
        <p className="mt-1 text-xs text-slate-400">
          Pending: Rp {balance.pending.toLocaleString("id-ID")}
        </p>

        <div className="mt-5 space-y-2">
          {history.slice(0, 4).map((h) => (
            <div key={h.id} className="flex items-center gap-3">
              <span
                className={cn(
                  "flex h-8 w-8 items-center justify-center rounded-lg",
                  h.type === "credit"
                    ? "bg-emerald-50 text-emerald-600"
                    : "bg-rose-50 text-rose-600"
                )}
              >
                {h.type === "credit" ? (
                  <ArrowDownRight className="h-4 w-4" />
                ) : (
                  <ArrowUpRight className="h-4 w-4" />
                )}
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm text-slate-700">{h.description}</p>
                <p className="text-xs text-slate-400">
                  {new Date(h.at).toLocaleDateString("id-ID", { day: "numeric", month: "short" })}
                </p>
              </div>
              <span
                className={cn(
                  "text-sm font-semibold",
                  h.type === "credit" ? "text-emerald-600" : "text-rose-600"
                )}
              >
                {h.type === "credit" ? "+" : "-"}Rp {h.amount.toLocaleString("id-ID")}
              </span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}