import { useState } from "react";
import {
  ShieldCheck,
  ShieldAlert,
  ShieldX,
  Play,
  Loader2,
  CheckCircle2,
  AlertTriangle,
  XCircle,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  validatePayoutPayload,
  validateWebhookPayload,
  validateBalanceSufficiency,
  validateTenantConfig,
  type ValidationReport,
  type ValidationIssue,
} from "@/lib/validation";
import { XENDIT_WEBHOOK_TOKEN } from "@/lib/xendit-service";

interface Suite {
  name: string;
  report: ValidationReport;
}

const ICON: Record<ValidationIssue["severity"], typeof CheckCircle2> = {
  ok: CheckCircle2,
  warning: AlertTriangle,
  error: XCircle,
};

const COLOR: Record<ValidationIssue["severity"], string> = {
  ok: "text-emerald-600",
  warning: "text-amber-600",
  error: "text-rose-600",
};

export default function ValidationPanel() {
  const [suites, setSuites] = useState<Suite[]>([]);
  const [running, setRunning] = useState(false);

  async function run() {
    setRunning(true);
    setSuites([]);
    await new Promise((r) => setTimeout(r, 500));

    const results: Suite[] = [
      {
        name: "Payout Payload — valid case",
        report: validatePayoutPayload({
          externalID: `TOPUP-DANA-${Date.now()}`,
          amount: 50000,
          channelCode: "DANA",
          accountNumber: "083842170430",
          description: "Topup ERP Otomatis",
        }),
      },
      {
        name: "Payout Payload — invalid amount & phone",
        report: validatePayoutPayload({
          externalID: "X",
          amount: 5000,
          channelCode: "DANA",
          accountNumber: "12345",
          description: "",
        }),
      },
      {
        name: "Webhook — valid token",
        report: validateWebhookPayload(XENDIT_WEBHOOK_TOKEN, {
          external_id: "TOPUP-DANA-1",
          status: "COMPLETED",
          id: "po_abc",
        }),
      },
      {
        name: "Webhook — invalid token",
        report: validateWebhookPayload("wrong-token", {
          external_id: "TOPUP-DANA-1",
          status: "COMPLETED",
          id: "po_abc",
        }),
      },
      {
        name: "Balance Sufficiency — cukup",
        report: validateBalanceSufficiency(12450000, 50000),
      },
      {
        name: "Balance Sufficiency — tidak cukup",
        report: validateBalanceSufficiency(20000, 50000),
      },
      {
        name: "Tenant Config — valid",
        report: validateTenantConfig({
          businessName: "Warung Space",
          email: "owner@warungspace.id",
          phone: "08123456789",
          subdomain: "warung-space",
        }),
      },
      {
        name: "Tenant Config — invalid",
        report: validateTenantConfig({
          businessName: "W",
          email: "bukan-email",
          phone: "123",
          subdomain: "AB",
        }),
      },
    ];

    setSuites(results);
    setRunning(false);
  }

  const totalIssues = suites.reduce((s, x) => s + x.report.issues.length, 0);
  const totalErrors = suites.reduce(
    (s, x) => s + x.report.issues.filter((i) => i.severity === "error").length,
    0
  );
  const allValid = suites.length > 0 && suites.every((s) => s.report.valid);

  return (
    <Card className="rounded-2xl border-slate-200 shadow-sm">
      <CardContent className="p-5">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="grid h-9 w-9 place-items-center rounded-lg bg-sky-600 text-white">
              <ShieldCheck className="h-4 w-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Validasi Skrip & Payload</h3>
              <p className="text-xs text-slate-500">
                Schema, range, token, saldo & tenant config
              </p>
            </div>
          </div>
          {suites.length > 0 && (
            <Badge
              className={`rounded-full ${
                allValid
                  ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100"
                  : "bg-amber-100 text-amber-700 hover:bg-amber-100"
              }`}
            >
              {totalIssues} issue · {totalErrors} error
            </Badge>
          )}
        </div>

        <Button
          onClick={run}
          disabled={running}
          className="w-full rounded-xl bg-sky-600 py-3 font-bold text-white hover:bg-sky-700 disabled:opacity-60"
        >
          {running ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Memvalidasi...
            </>
          ) : (
            <>
              <Play className="mr-2 h-4 w-4" />
              Jalankan Validasi Lengkap
            </>
          )}
        </Button>

        {suites.length > 0 && (
          <div className="mt-4 space-y-3">
            {suites.map((s, i) => {
              const Header = s.report.valid ? ShieldCheck : ShieldAlert;
              return (
                <div
                  key={i}
                  className={`rounded-xl border p-3 ${
                    s.report.valid
                      ? "border-emerald-100 bg-emerald-50/40"
                      : "border-amber-200 bg-amber-50/40"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Header
                      className={`h-4 w-4 ${
                        s.report.valid ? "text-emerald-600" : "text-amber-600"
                      }`}
                    />
                    <p className="text-xs font-bold text-slate-800">{s.name}</p>
                  </div>
                  <div className="mt-2 space-y-1">
                    {s.report.issues.map((issue, j) => {
                      const Icon = ICON[issue.severity];
                      return (
                        <div key={j} className="flex items-start gap-2 text-xs">
                          <Icon className={`mt-0.5 h-3 w-3 shrink-0 ${COLOR[issue.severity]}`} />
                          <span className="text-slate-600">
                            <span className="font-mono font-semibold text-slate-700">
                              {issue.field}
                            </span>
                            {" — "}
                            {issue.message}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {allValid && (
          <div className="mt-3 flex items-center gap-2 rounded-xl border border-emerald-200 bg-white p-3 text-xs font-medium text-emerald-700">
            <ShieldX className="h-4 w-4 rotate-180" />
            Semua skrip tervalidasi — tidak ada error blocking.
          </div>
        )}
      </CardContent>
    </Card>
  );
}