import { Heart, ExternalLink, Star } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export default function SponsorCard() {
  return (
    <Card className="overflow-hidden rounded-2xl border-emerald-200 bg-gradient-to-br from-emerald-50 to-teal-50 shadow-sm">
      <CardContent className="p-6">
        <div className="flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-xl bg-emerald-600 text-white">
            <Heart className="h-5 w-5" />
          </div>
          <div>
            <h3 className="font-serif text-lg font-bold text-slate-900">
              Dukung Proyek Ini
            </h3>
            <p className="text-xs text-slate-600">
              Bantu kami terus mengembangkan WarungSpace untuk UMKM.
            </p>
          </div>
        </div>

        <div className="mt-5 flex flex-col gap-3 sm:flex-row">
          <a
            href="https://github.com/sponsors/alhikmah-my-id"
            target="_blank"
            rel="noreferrer"
            className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-emerald-600 px-4 py-3 text-sm font-semibold text-white transition hover:bg-emerald-700"
          >
            <Star className="h-4 w-4" />
            Sponsor di GitHub
          </a>
          <a
            href="https://paypal.me/wahyudi9kdl"
            target="_blank"
            rel="noreferrer"
            className="flex flex-1 items-center justify-center gap-2 rounded-xl border border-emerald-300 bg-white px-4 py-3 text-sm font-semibold text-emerald-700 transition hover:bg-emerald-50"
          >
            <ExternalLink className="h-4 w-4" />
            Support via PayPal
          </a>
        </div>

        <p className="mt-4 text-center text-xs text-slate-500">
          Setiap dukungan sangat berarti. Terima kasih! 🙏
        </p>
      </CardContent>
    </Card>
  );
}