import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { HandCoins, MessageCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { DEBTS, CUSTOMERS, formatIDR } from "@/lib/erp-data";

export function DebtsModule() {
  const rows = DEBTS.map((d) => ({
    ...d,
    customer: CUSTOMERS.find((c) => c.id === d.customerId),
  }));

  return (
    <Card className="rounded-2xl border-slate-200 shadow-sm">
      <CardHeader className="flex flex-row items-center gap-3 border-b border-slate-100 pb-4">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-rose-50 text-rose-600 ring-1 ring-rose-100">
          <HandCoins className="h-5 w-5" />
        </div>
        <div>
          <CardTitle className="text-lg font-bold text-slate-900">Buku Utang</CardTitle>
          <p className="text-xs text-slate-500">{rows.length} tagihan aktif</p>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="divide-y divide-slate-100">
          {rows.map((d) => (
            <div key={d.id} className="flex flex-wrap items-center gap-3 px-5 py-4 transition hover:bg-slate-50">
              <div className="min-w-0 flex-1">
                <p className="truncate font-medium text-slate-800">{d.customer?.name}</p>
                <p className="text-xs text-slate-400">
                  {d.customer?.phone} · jatuh tempo{" "}
                  {new Date(d.dueDate).toLocaleDateString("id-ID", { day: "numeric", month: "short" })}
                </p>
              </div>
              <div className="text-right">
                <p className="font-bold text-slate-900">{formatIDR(d.amount)}</p>
                <Badge
                  variant="outline"
                  className={cn(
                    "mt-0.5",
                    d.status === "overdue"
                      ? "border-rose-200 bg-rose-50 text-rose-600"
                      : "border-amber-200 bg-amber-50 text-amber-700"
                  )}
                >
                  {d.status === "overdue" ? "Terlambat" : "Belum bayar"}
                </Badge>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="rounded-xl border-emerald-200 text-emerald-700 hover:bg-emerald-50"
              >
                <MessageCircle className="mr-1.5 h-3.5 w-3.5" />
                WA
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}