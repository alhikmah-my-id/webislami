import { useVertical, VERTICALS } from "@/lib/vertical-context";

export default function VerticalSwitcher() {
  const { vertical, setVerticalId } = useVertical();

  return (
    <div className="rounded-xl bg-emerald-900/60 p-3">
      <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-emerald-300">
        Jenis Usaha
      </p>
      <div className="flex gap-2 md:flex-col">
        {VERTICALS.map((v) => {
          const active = v.id === vertical.id;
          return (
            <button
              key={v.id}
              onClick={() => setVerticalId(v.id)}
              className={`flex flex-1 items-center gap-2 rounded-lg px-3 py-2 text-xs font-medium transition md:flex-none ${
                active
                  ? "bg-emerald-500 text-white shadow-sm"
                  : "bg-emerald-800/40 text-emerald-100 hover:bg-emerald-700/60"
              }`}
            >
              <span>{v.emoji}</span>
              <span className="truncate">{v.name}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}