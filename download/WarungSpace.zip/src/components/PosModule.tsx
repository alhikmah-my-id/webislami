import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Minus, Plus, ShoppingCart, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { PRODUCTS, formatIDR, type Product } from "@/lib/erp-data";

interface CartLine {
  product: Product;
  qty: number;
}

export function PosModule() {
  const [cart, setCart] = useState<CartLine[]>([]);
  const [query, setQuery] = useState("");

  const filtered = PRODUCTS.filter((p) =>
    p.name.toLowerCase().includes(query.toLowerCase())
  );

  function addToCart(p: Product) {
    setCart((prev) => {
      const found = prev.find((l) => l.product.id === p.id);
      if (found) return prev.map((l) => (l.product.id === p.id ? { ...l, qty: l.qty + 1 } : l));
      return [...prev, { product: p, qty: 1 }];
    });
  }

  function changeQty(id: string, delta: number) {
    setCart((prev) =>
      prev
        .map((l) => (l.product.id === id ? { ...l, qty: l.qty + delta } : l))
        .filter((l) => l.qty > 0)
    );
  }

  const total = cart.reduce((sum, l) => sum + l.product.priceRetail * l.qty, 0);

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-5">
      {/* Product picker */}
      <div className="lg:col-span-3">
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg font-bold text-slate-900">Pilih Produk</CardTitle>
            <Input
              placeholder="Cari produk…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="mt-2 rounded-xl"
            />
          </CardHeader>
          <CardContent className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {filtered.map((p) => (
              <button
                key={p.id}
                onClick={() => addToCart(p)}
                disabled={p.stock === 0}
                className={cn(
                  "flex flex-col items-start rounded-xl border border-slate-100 bg-white p-3.5 text-left shadow-sm transition",
                  p.stock === 0
                    ? "cursor-not-allowed opacity-50"
                    : "hover:border-indigo-300 hover:shadow-md active:scale-95"
                )}
              >
                <span className="text-sm font-semibold text-slate-800">{p.name}</span>
                <span className="mt-0.5 text-xs text-slate-400">{p.sku}</span>
                <div className="mt-2 flex w-full items-center justify-between">
                  <span className="font-bold text-indigo-600">{formatIDR(p.priceRetail)}</span>
                  <Badge
                    variant="outline"
                    className={cn(
                      "text-xs",
                      p.stock === 0
                        ? "border-rose-200 bg-rose-50 text-rose-600"
                        : p.stock <= 10
                        ? "border-amber-200 bg-amber-50 text-amber-700"
                        : "border-slate-200 bg-slate-50 text-slate-500"
                    )}
                  >
                    stok {p.stock}
                  </Badge>
                </div>
              </button>
            ))}
            {filtered.length === 0 && (
              <p className="col-span-full py-8 text-center text-sm text-slate-400">
                Produk tidak ditemukan.
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Cart */}
      <div className="lg:col-span-2">
        <Card className="sticky top-6 rounded-2xl border-slate-200 shadow-sm">
          <CardHeader className="flex flex-row items-center gap-3 border-b border-slate-100 pb-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600 ring-1 ring-indigo-100">
              <ShoppingCart className="h-5 w-5" />
            </div>
            <CardTitle className="text-lg font-bold text-slate-900">Keranjang</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {cart.length === 0 ? (
              <div className="px-5 py-12 text-center">
                <p className="text-sm text-slate-400">Keranjang masih kosong.</p>
                <p className="mt-1 text-xs text-slate-300">Tap produk untuk menambahkan.</p>
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {cart.map((l) => (
                  <div key={l.product.id} className="flex items-center gap-3 px-5 py-3">
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-slate-800">{l.product.name}</p>
                      <p className="text-xs text-slate-400">
                        {formatIDR(l.product.priceRetail)} × {l.qty}
                      </p>
                    </div>
                    <div className="flex items-center gap-1">
                      <Button
                        size="icon"
                        variant="outline"
                        className="h-7 w-7 rounded-lg"
                        onClick={() => changeQty(l.product.id, -1)}
                      >
                        <Minus className="h-3 w-3" />
                      </Button>
                      <span className="w-6 text-center text-sm font-semibold">{l.qty}</span>
                      <Button
                        size="icon"
                        variant="outline"
                        className="h-7 w-7 rounded-lg"
                        onClick={() => changeQty(l.product.id, 1)}
                      >
                        <Plus className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {cart.length > 0 && (
              <div className="border-t border-slate-100 bg-slate-50/60 p-5">
                <div className="mb-4 flex items-center justify-between">
                  <span className="text-sm font-medium text-slate-600">Total</span>
                  <span className="text-xl font-bold text-slate-900">{formatIDR(total)}</span>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    className="rounded-xl"
                    onClick={() => setCart([])}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                  <Button className="flex-1 rounded-xl bg-indigo-600 hover:bg-indigo-700">
                    Bayar
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}