import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Package, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";
import { PRODUCTS, formatIDR } from "@/lib/erp-data";

export function InventoryModule() {
  const lowStock = PRODUCTS.filter((p) => p.stock <= 10);

  return (
    <div className="space-y-6">
      {lowStock.length > 0 && (
        <div className="flex items-start gap-3 rounded-2xl border border-amber-200 bg-amber-50 p-4">
          <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-amber-600" />
          <div>
            <p className="text-sm font-semibold text-amber-800">
              {lowStock.length} produk perlu restock
            </p>
            <p className="text-xs text-amber-700">
              {lowStock.map((p) => p.name).join(", ")}
            </p>
          </div>
        </div>
      )}

      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardHeader className="flex flex-row items-center gap-3 border-b border-slate-100 pb-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600 ring-1 ring-emerald-100">
            <Package className="h-5 w-5" />
          </div>
          <div>
            <CardTitle className="text-lg font-bold text-slate-900">Stok Barang</CardTitle>
            <p className="text-xs text-slate-500">{PRODUCTS.length} produk terdaftar</p>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y divide-slate-100">
            {PRODUCTS.map((p) => (
              <div key={p.id} className="flex items-center gap-4 px-5 py-4 transition hover:bg-slate-50">
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium text-slate-800">{p.name}</p>
                  <p className="text-xs text-slate-400">
                    {p.sku} · {p.unit}
                  </p>
                </div>
                <div className="hidden text-right sm:block">
                  <p className="text-sm font-semibold text-slate-700">{formatIDR(p.priceRetail)}</p>
                  <p className="text-xs text-slate-400">
                    grosir {formatIDR(p.priceWholesale)} / min {p.wholesaleMinQty}
                  </p>
                </div>
                <Badge
                  variant="outline"
                  className={cn(
                    "shrink-0",
                    p.stock === 0
                      ? "border-rose-200 bg-rose-50 text-rose-600"
                      : p.stock <= 10
                      ? "border-amber-200 bg-amber-50 text-amber-700"
                      : "border-emerald-200 bg-emerald-50 text-emerald-700"
                  )}
                >
                  {p.stock} {p.unit}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}