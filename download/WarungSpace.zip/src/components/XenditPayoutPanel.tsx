import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Send, Webhook, ScrollText } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  simulateWebhook,
  subscribeXendit,
  getSnapshot,
  createDisbursement,
  type XenditSnapshot,
} from "@/lib/xendit-service";

const statusStyles: Record<string, string> = {
  COMPLETED: "border-emerald-200 bg-emerald-50 text-emerald-700",
  PENDING: "border-amber-200 bg-amber-50 text-amber-700",
  FAILED: "border-rose-200 bg-rose-50 text-rose-600",
};

export function XenditPayoutPanel() {
  const [snapshot, setSnapshot] = useState<XenditSnapshot>(() => getSnapshot());
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const unsub = subscribeXendit(setSnapshot);
    return unsub;
  }, []);

  function handleSimulate() {
    setBusy(true);
    setTimeout(() => {
      simulateWebhook("PAID");
      setBusy(false);
    }, 500);
  }

  function handlePayout() {
    setBusy(true);
    setTimeout(() => {
      createDisbursement(1500000, "BCA", "1234567890", "Toko Makmur Jaya");
      setBusy(false);
    }, 500);
  }

  return (
    <div className="space-y-6">
      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600 ring-1 ring-indigo-100">
              <Send className="h-5 w-5" />
            </div>
            <div>
              <CardTitle className="text-lg font-bold text-slate-900">Xendit Payout</CardTitle>
              <p className="text-xs text-slate-500">{snapshot.disbursements.length} disbursement</p>
            </div>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={handleSimulate}
              disabled={busy}
              className="rounded-xl"
            >
              <Webhook className="mr-2 h-4 w-4" />
              Simulate
            </Button>
            <Button
              onClick={handlePayout}
              disabled={busy}
              className="rounded-xl bg-indigo-600 hover:bg-indigo-700"
            >
              <Send className="mr-2 h-4 w-4" />
              Payout
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y divide-slate-100">
            {snapshot.disbursements.map((d) => (
              <div key={d.id} className="flex items-center gap-3 px-5 py-3.5 transition hover:bg-slate-50">
                <div className="min-w-0 flex-1">
                  <p className="truncate font-mono text-sm font-medium text-slate-800">{d.id}</p>
                  <p className="text-xs text-slate-400">
                    {d.bankCode} · {d.accountNumber} · {d.accountName}
                  </p>
                </div>
                <span className="text-sm font-semibold text-slate-700">
                  Rp {d.amount.toLocaleString("id-ID")}
                </span>
                <Badge variant="outline" className={cn("shrink-0", statusStyles[d.status])}>
                  {d.status}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardHeader className="flex flex-row items-center gap-3 border-b border-slate-100 pb-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100 text-slate-600 ring-1 ring-slate-200">
            <ScrollText className="h-5 w-5" />
          </div>
          <div>
            <CardTitle className="text-lg font-bold text-slate-900">Audit Log</CardTitle>
            <p className="text-xs text-slate-500">
              {snapshot.lastWebhookAt
                ? `Webhook terakhir ${new Date(snapshot.lastWebhookAt).toLocaleTimeString("id-ID")}`
                : "Belum ada webhook"}
            </p>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y divide-slate-100">
            {snapshot.auditLogs.slice(0, 6).map((l) => (
              <div key={l.id} className="flex items-center gap-3 px-5 py-3">
                <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-indigo-400" />
                <span className="font-mono text-xs font-medium text-slate-700">{l.action}</span>
                <span className="min-w-0 flex-1 truncate text-xs text-slate-400">{l.detail}</span>
                <span className="shrink-0 text-xs text-slate-400">
                  {new Date(l.at).toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" })}
                </span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}