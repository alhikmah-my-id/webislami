import { useState } from "react";
import {
  Zap,
  Loader2,
  CheckCircle2,
  AlertCircle,
  ArrowDownToLine,
  Smartphone,
  Wallet,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { formatRupiah } from "@/lib/disbursement-data";
import {
  Payout,
  DEFAULT_TOPUPS,
  PAYOUT_MIN,
  PAYOUT_FEE,
  isValidPayoutAccount,
  type TopUpPreset,
} from "@/lib/payout";

interface Props {
  onSuccess: (amount: number, label: string) => void;
  onLog: (action: string, detail: string) => void;
}

export default function DefaultTopUpPanel({ onSuccess, onLog }: Props) {
  const [selected, setSelected] = useState<TopUpPreset>(DEFAULT_TOPUPS[0]);
  const [amount, setAmount] = useState(String(DEFAULT_TOPUPS[0].amount));
  const [account, setAccount] = useState(DEFAULT_TOPUPS[0].accountNumber);
  const [channel, setChannel] = useState(DEFAULT_TOPUPS[0].channelCode);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ ok: boolean; msg: string } | null>(null);

  const numeric = Number(amount.replace(/\D/g, "")) || 0;
  const accountValid = isValidPayoutAccount(channel, account);
  const amountValid = numeric >= PAYOUT_MIN;
  const canSubmit = accountValid && amountValid && !loading;

  function pick(p: TopUpPreset) {
    setSelected(p);
    setAmount(String(p.amount));
    setAccount(p.accountNumber);
    setChannel(p.channelCode);
    setResult(null);
  }

  async function run() {
    setLoading(true);
    setResult(null);
    try {
      const res = await Payout.createPayout({
        externalID: `DISB-TOPUP-${Date.now()}`,
        amount: numeric,
        channelCode: channel,
        accountNumber: account,
        description: "Top up otomatis dari saldo kasir ERP",
      });
      onSuccess(res.amount, `${selected.member} · ${res.channelCode}`);
      onLog(
        "PAYOUT_TOPUP",
        `Top up ${formatRupiah(res.amount)} ke ${res.channelCode} ${res.accountNumber}`
      );
      setResult({
        ok: true,
        msg: `Top up ${formatRupiah(res.amount)} ke ${res.channelCode} berhasil (${res.id}).`,
      });
    } catch (e) {
      setResult({ ok: false, msg: e instanceof Error ? e.message : "Payout gagal." });
    } finally {
      setLoading(false);
    }
  }

  return (
    <Card className="rounded-2xl border-emerald-200 bg-emerald-50/40 shadow-sm">
      <CardContent className="p-5">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="grid h-9 w-9 place-items-center rounded-lg bg-emerald-600 text-white">
              <Zap className="h-4 w-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Top Up Otomatis</h3>
              <p className="text-xs text-slate-500">Payout instan ke e-wallet member</p>
            </div>
          </div>
          <Badge className="rounded-full bg-emerald-100 text-emerald-700 hover:bg-emerald-100">
            Default
          </Badge>
        </div>

        <div className="mb-4 grid grid-cols-1 gap-2 sm:grid-cols-3">
          {DEFAULT_TOPUPS.map((p) => (
            <button
              key={p.id}
              onClick={() => pick(p)}
              className={`rounded-xl border p-3 text-left transition ${
                selected.id === p.id
                  ? "border-emerald-500 bg-white shadow-sm"
                  : "border-slate-200 bg-white/60 hover:bg-white"
              }`}
            >
              <p className="text-xs font-semibold text-slate-800">{p.label}</p>
              <p className="font-mono text-sm font-bold text-emerald-700">
                {formatRupiah(p.amount)}
              </p>
              <p className="mt-1 text-xs text-slate-500">
                {p.member} · {p.channelCode}
              </p>
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label htmlFor="topup-account">Nomor Tujuan</Label>
            <div className="relative">
              <Smartphone className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <Input
                id="topup-account"
                value={account}
                onChange={(e) => setAccount(e.target.value)}
                className={`rounded-xl pl-9 ${
                  account && !accountValid ? "border-rose-400" : ""
                }`}
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="topup-amount">Nominal</Label>
            <div className="relative">
              <Wallet className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <Input
                id="topup-amount"
                inputMode="numeric"
                value={amount ? Number(amount).toLocaleString("id-ID") : ""}
                onChange={(e) => setAmount(e.target.value.replace(/\D/g, ""))}
                className={`rounded-xl pl-9 font-mono ${
                  amount && !amountValid ? "border-rose-400" : ""
                }`}
              />
            </div>
          </div>
        </div>

        <div className="mt-3 flex items-center justify-between text-xs text-slate-500">
          <span>Channel: {channel}</span>
          <span>Biaya admin {formatRupiah(PAYOUT_FEE)}</span>
        </div>

        <Button
          onClick={run}
          disabled={!canSubmit}
          className="mt-4 w-full rounded-xl bg-emerald-600 py-3 font-bold text-white hover:bg-emerald-700 disabled:opacity-60"
        >
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Memproses Payout...
            </>
          ) : (
            <>
              <ArrowDownToLine className="mr-2 h-4 w-4" />
              Top Up {formatRupiah(numeric)}
            </>
          )}
        </Button>

        {result && (
          <div
            className={`mt-3 flex items-start gap-2 rounded-xl border p-3 text-xs ${
              result.ok
                ? "border-emerald-200 bg-white text-emerald-700"
                : "border-rose-200 bg-white text-rose-700"
            }`}
          >
            {result.ok ? (
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
            ) : (
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
            )}
            <span className="font-medium">{result.msg}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}