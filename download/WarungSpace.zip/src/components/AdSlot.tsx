import { useEffect, useRef, useState } from "react";
import { Megaphone, Info } from "lucide-react";

interface AdSlotProps {
  slot: string;
  client?: string;
  format?: "auto" | "horizontal" | "rectangle";
  label?: string;
  className?: string;
}

const DEFAULT_CLIENT = "ca-pub-6718454554209533";

declare global {
  interface Window {
    adsbygoogle?: unknown[];
  }
}

export default function AdSlot({
  slot,
  client = DEFAULT_CLIENT,
  format = "auto",
  label = "Iklan",
  className = "",
}: AdSlotProps) {
  const ref = useRef<HTMLModElement>(null);
  const [pushed, setPushed] = useState(false);

  useEffect(() => {
    try {
      if (typeof window !== "undefined") {
        window.adsbygoogle = window.adsbygoogle || [];
        window.adsbygoogle.push({});
        setPushed(true);
      }
    } catch {
      setPushed(false);
    }
  }, []);

  return (
    <div
      className={`relative overflow-hidden rounded-2xl border border-dashed border-amber-300 bg-amber-50/60 p-4 ${className}`}
    >
      <div className="mb-2 flex items-center justify-between">
        <span className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wide text-amber-700">
          <Megaphone className="h-3.5 w-3.5" />
          {label}
        </span>
        <span className="font-mono text-xs text-amber-600">slot {slot}</span>
      </div>

      <ins
        ref={ref}
        className="adsbygoogle block"
        style={{ display: "block", minHeight: 90 }}
        data-ad-client={client}
        data-ad-slot={slot}
        data-ad-format={format}
        data-full-width-responsive="true"
      />

      {!pushed && (
        <div className="flex items-center gap-2 rounded-xl bg-white/70 p-3 text-xs text-amber-700">
          <Info className="h-3.5 w-3.5" />
          Slot iklan siap — menunggu script AdSense dimuat.
        </div>
      )}
    </div>
  );
}