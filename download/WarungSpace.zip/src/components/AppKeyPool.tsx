import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { RefreshCw, KeyRound, Zap } from "lucide-react";
import { cn } from "@/lib/utils";
import { APP_KEYS, rotateKeys, type AppKey, type RotationEvent } from "@/lib/tappx-service";

const statusStyles: Record<AppKey["status"], string> = {
  active: "bg-emerald-100 text-emerald-700 border-emerald-200",
  standby: "bg-slate-100 text-slate-600 border-slate-200",
  cooldown: "bg-amber-100 text-amber-700 border-amber-200",
};

export function AppKeyPool() {
  const [keys, setKeys] = useState<AppKey[]>(APP_KEYS);
  const [events, setEvents] = useState<RotationEvent[]>([]);
  const [rotating, setRotating] = useState(false);

  function handleRotate() {
    setRotating(true);
    setTimeout(() => {
      const { keys: next, event } = rotateKeys(keys, "Manual rotation");
      setKeys(next);
      setEvents((prev) => [event, ...prev].slice(0, 5));
      setRotating(false);
    }, 600);
  }

  return (
    <Card className="rounded-2xl border-slate-200 shadow-sm">
      <CardHeader className="flex flex-row items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600 ring-1 ring-indigo-100">
            <KeyRound className="h-5 w-5" />
          </div>
          <div>
            <CardTitle className="text-lg font-bold text-slate-900">App Key Pool</CardTitle>
            <p className="text-xs text-slate-500">6 keys · rotasi otomatis</p>
          </div>
        </div>
        <Button
          onClick={handleRotate}
          disabled={rotating}
          className="rounded-xl bg-indigo-600 hover:bg-indigo-700"
        >
          <RefreshCw className={cn("mr-2 h-4 w-4", rotating && "animate-spin")} />
          {rotating ? "Rotating…" : "Rotate"}
        </Button>
      </CardHeader>

      <CardContent className="p-0">
        <div className="divide-y divide-slate-100">
          {keys.map((k) => (
            <div key={k.id} className="flex items-center gap-3 px-5 py-3.5 transition hover:bg-slate-50">
              <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-xs font-bold text-slate-500">
                {k.id}
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate font-mono text-sm font-medium text-slate-800">{k.key}</p>
                <p className="text-xs text-slate-400">
                  {k.impressions.toLocaleString("en-US")} imp · ${k.revenue.toFixed(2)} · {k.fillRate}% fill
                </p>
              </div>
              <Badge variant="outline" className={cn("shrink-0 capitalize", statusStyles[k.status])}>
                {k.status === "active" && <Zap className="mr-1 h-3 w-3" />}
                {k.status}
              </Badge>
            </div>
          ))}
        </div>

        {events.length > 0 && (
          <div className="border-t border-slate-100 bg-slate-50/60 px-5 py-4">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">Rotation Log</p>
            <ul className="space-y-1.5">
              {events.map((e) => (
                <li key={e.id} className="flex items-center gap-2 text-xs text-slate-600">
                  <span className="h-1.5 w-1.5 rounded-full bg-indigo-400" />
                  <span className="font-mono">{e.fromKey.split("-").slice(-2).join("-")}</span>
                  <span className="text-slate-400">→</span>
                  <span className="font-mono">{e.toKey.split("-").slice(-2).join("-")}</span>
                  <span className="ml-auto text-slate-400">
                    {new Date(e.at).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  );
}