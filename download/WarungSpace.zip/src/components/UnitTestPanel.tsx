import { useState } from "react";
import {
  FlaskConical,
  Play,
  Loader2,
  CheckCircle2,
  XCircle,
  ShieldCheck,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { runPayoutControllerTests } from "@/lib/__tests__/payout-controller.test";

interface Result {
  name: string;
  passed: boolean;
  detail: string;
}

export default function UnitTestPanel() {
  const [results, setResults] = useState<Result[]>([]);
  const [running, setRunning] = useState(false);

  async function run() {
    setRunning(true);
    setResults([]);
    const res = await runPayoutControllerTests();
    setResults(res);
    setRunning(false);
  }

  const passed = results.filter((r) => r.passed).length;
  const total = results.length;

  return (
    <Card className="rounded-2xl border-slate-200 shadow-sm">
      <CardContent className="p-5">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="grid h-9 w-9 place-items-center rounded-lg bg-slate-800 text-white">
              <FlaskConical className="h-4 w-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Unit Test — Payout Controller</h3>
              <p className="text-xs text-slate-500">
                Validasi routing, idempotency & webhook
              </p>
            </div>
          </div>
          {total > 0 && (
            <Badge
              className={`rounded-full ${
                passed === total
                  ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100"
                  : "bg-amber-100 text-amber-700 hover:bg-amber-100"
              }`}
            >
              {passed}/{total} passed
            </Badge>
          )}
        </div>

        <Button
          onClick={run}
          disabled={running}
          className="w-full rounded-xl bg-slate-800 py-3 font-bold text-white hover:bg-slate-900 disabled:opacity-60"
        >
          {running ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Menjalankan test suite...
            </>
          ) : (
            <>
              <Play className="mr-2 h-4 w-4" />
              Jalankan Semua Test
            </>
          )}
        </Button>

        {results.length > 0 && (
          <div className="mt-4 space-y-2">
            {results.map((r, i) => (
              <div
                key={i}
                className={`flex items-start gap-2 rounded-xl border p-3 text-xs ${
                  r.passed
                    ? "border-emerald-100 bg-emerald-50/50"
                    : "border-rose-200 bg-rose-50"
                }`}
              >
                {r.passed ? (
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
                ) : (
                  <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-rose-600" />
                )}
                <div>
                  <p
                    className={`font-semibold ${
                      r.passed ? "text-emerald-800" : "text-rose-800"
                    }`}
                  >
                    {r.name}
                  </p>
                  {!r.passed && <p className="text-rose-600">{r.detail}</p>}
                </div>
              </div>
            ))}
          </div>
        )}

        {total > 0 && passed === total && (
          <div className="mt-3 flex items-center gap-2 rounded-xl border border-emerald-200 bg-white p-3 text-xs font-medium text-emerald-700">
            <ShieldCheck className="h-4 w-4" />
            Semua test lulus — controller siap produksi.
          </div>
        )}
      </CardContent>
    </Card>
  );
}