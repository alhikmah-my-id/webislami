import { useEffect, useState } from "react";
import {
  Wallet,
  Lock,
  RefreshCw,
  Zap,
  CheckCircle2,
  XCircle,
  Loader2,
  ShieldCheck,
  TrendingDown,
  Bell,
  Phone,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAudit } from "@/lib/audit-context";
import {
  LOCKED_PHONE,
  DEFAULT_TOPUP_AMOUNT,
  INITIAL_BALANCE,
  INITIAL_TOPUPS,
  INITIAL_WALLET_LOGS,
  formatRupiah,
  type TopUpRecord,
  type WalletAuditLog,
} from "@/lib/wallet-data";
import { walletEngine, playTopUpChime } from "@/lib/wallet-engine";

const STATUS_STYLE: Record<TopUpRecord["status"], string> = {
  PENDING: "bg-amber-100 text-amber-700",
  SUCCESS: "bg-emerald-100 text-emerald-700",
  FAILED: "bg-rose-100 text-rose-700",
};

function StatusPill({ status }: { status: TopUpRecord["status"] }) {
  const icon =
    status === "SUCCESS" ? (
      <CheckCircle2 className="h-3 w-3" />
    ) : status === "FAILED" ? (
      <XCircle className="h-3 w-3" />
    ) : (
      <Loader2 className="h-3 w-3 animate-spin" />
    );
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold ${STATUS_STYLE[status]}`}
    >
      {icon}
      {status}
    </span>
  );
}

export default function WalletTopUpPanel() {
  const { log } = useAudit();
  const [balance, setBalance] = useState(INITIAL_BALANCE.balance);
  const [loadingBalance, setLoadingBalance] = useState(false);
  const [topUps, setTopUps] = useState<TopUpRecord[]>(INITIAL_TOPUPS);
  const [walletLogs, setWalletLogs] = useState<WalletAuditLog[]>(INITIAL_WALLET_LOGS);
  const [amount, setAmount] = useState(DEFAULT_TOPUP_AMOUNT);
  const [toast, setToast] = useState<{ amount: number } | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const offTopUp = walletEngine.onTopUp((record) => {
      setTopUps((prev) => {
        const exists = prev.some((t) => t.refId === record.refId);
        if (exists) {
          return prev.map((t) => (t.refId === record.refId ? record : t));
        }
        return [record, ...prev];
      });

      if (record.status === "SUCCESS") {
        setBalance((b) => Math.max(0, b - record.amount));
        playTopUpChime();
        setToast({ amount: record.amount });
        setTimeout(() => setToast(null), 4200);
        log(
          "AUTO_TOPUP_SUCCESS",
          `Top-up ${formatRupiah(record.amount)} ke ${LOCKED_PHONE} sukses (${record.refId})`,
          "system"
        );
      }
      if (record.status === "FAILED") {
        log(
          "AUTO_TOPUP_FAILED",
          `Top-up ${record.refId} GAGAL — ${record.failureCode ?? "unknown"}`,
          "system"
        );
      }
    });

    const offLog = walletEngine.onLog((entry) => {
      setWalletLogs((prev) => [entry, ...prev]);
    });

    return () => {
      offTopUp();
      offLog();
    };
  }, [log]);

  function refreshBalance() {
    setLoadingBalance(true);
    setTimeout(() => {
      setBalance((b) => b + Math.floor(Math.random() * 50000));
      setLoadingBalance(false);
      log("WALLET_BALANCE_CHECK", "Cek saldo kas perusahaan via Xendit Balance API");
    }, 700);
  }

  function executeTopUp() {
    setError(null);
    if (amount < 10000) {
      setError("Nominal minimal top-up adalah Rp 10.000.");
      return;
    }
    if (amount > balance) {
      setError(
        `Saldo kas perusahaan tidak mencukupi. Sisa saldo: ${formatRupiah(balance)}`
      );
      return;
    }

    const ok = window.confirm(
      `Kirim ${formatRupiah(amount)} ke nomor terkunci ${LOCKED_PHONE}?`
    );
    if (!ok) return;

    walletEngine.initiateTopUp(amount);
    log(
      "AUTO_TOPUP_INITIATED",
      `Top-up ${formatRupiah(amount)} diantrekan ke nomor terkunci ${LOCKED_PHONE}`,
      "owner@warungspace.id"
    );
  }

  const pendingCount = topUps.filter((t) => t.status === "PENDING").length;

  return (
    <div className="space-y-6">
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-3 rounded-2xl border border-emerald-200 bg-white px-4 py-3 shadow-xl">
          <div className="grid h-10 w-10 place-items-center rounded-xl bg-emerald-100">
            <Bell className="h-5 w-5 text-emerald-600" />
          </div>
          <div>
            <p className="text-sm font-bold text-slate-900">Top-up Berhasil! 🎉</p>
            <p className="text-xs text-slate-500">
              {formatRupiah(toast.amount)} terkirim ke {LOCKED_PHONE}
            </p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="rounded-2xl border-emerald-200 bg-gradient-to-br from-emerald-600 to-teal-700 shadow-md lg:col-span-2">
          <CardContent className="p-6">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 text-emerald-100">
                  <Wallet className="h-4 w-4" />
                  <p className="text-xs font-semibold uppercase tracking-widest">
                    Saldo Kas Perusahaan
                  </p>
                </div>
                <p className="mt-3 font-serif text-3xl font-bold text-white md:text-4xl">
                  {formatRupiah(balance)}
                </p>
                <p className="mt-1 text-xs text-emerald-100">
                  Xendit Balance API · account_type: CASH · IDR
                </p>
              </div>
              <Button
                onClick={refreshBalance}
                disabled={loadingBalance}
                className="rounded-xl bg-white/15 font-semibold text-white backdrop-blur transition hover:bg-white/25 disabled:opacity-60"
              >
                <RefreshCw
                  className={`mr-2 h-4 w-4 ${loadingBalance ? "animate-spin" : ""}`}
                />
                {loadingBalance ? "Memuat…" : "Refresh Saldo"}
              </Button>
            </div>

            <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-3">
              <div className="rounded-xl border border-emerald-400/30 bg-emerald-900/30 p-3">
                <p className="text-xs text-emerald-100">Total Top-up Sukses</p>
                <p className="mt-1 font-serif text-lg font-bold text-white">
                  {formatRupiah(
                    topUps
                      .filter((t) => t.status === "SUCCESS")
                      .reduce((s, t) => s + t.amount, 0)
                  )}
                </p>
              </div>
              <div className="rounded-xl border border-emerald-400/30 bg-emerald-900/30 p-3">
                <p className="text-xs text-emerald-100">Transaksi Pending</p>
                <p className="mt-1 font-serif text-lg font-bold text-white">
                  {pendingCount}
                </p>
              </div>
              <div className="rounded-xl border border-emerald-400/30 bg-emerald-900/30 p-3">
                <p className="text-xs text-emerald-100">Nomor Terkunci</p>
                <p className="mt-1 font-mono text-sm font-bold text-white">
                  {LOCKED_PHONE}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardHeader className="border-b border-slate-100 pb-4">
            <CardTitle className="flex items-center gap-2 text-base text-slate-900">
              <Zap className="h-4 w-4 text-emerald-700" />
              Instant Top Up DANA
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 pt-4">
            <div className="flex items-center gap-3 rounded-xl border border-slate-200 bg-slate-50 p-3">
              <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-slate-900 text-white">
                <Lock className="h-4 w-4" />
              </div>
              <div className="min-w-0">
                <p className="text-xs text-slate-500">Nomor tujuan (terkunci)</p>
                <p className="font-mono text-sm font-bold text-slate-800">
                  {LOCKED_PHONE}
                </p>
              </div>
              <Badge className="ml-auto shrink-0 rounded-full bg-slate-200 text-slate-600 hover:bg-slate-200">
                LOCKED
              </Badge>
            </div>

            <div>
              <p className="text-xs font-medium text-slate-500">Nominal Top-up</p>
              <div className="mt-2 flex flex-wrap gap-2">
                {[50000, 100000, 250000, 500000].map((v) => (
                  <button
                    key={v}
                    onClick={() => setAmount(v)}
                    className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
                      amount === v
                        ? "bg-emerald-600 text-white"
                        : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                    }`}
                  >
                    {formatRupiah(v)}
                  </button>
                ))}
              </div>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="mt-3 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm font-semibold text-slate-800 outline-none transition focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100"
              />
            </div>

            {error && (
              <div className="flex items-start gap-2 rounded-xl border border-rose-200 bg-rose-50 px-3 py-2">
                <TrendingDown className="mt-0.5 h-4 w-4 shrink-0 text-rose-600" />
                <p className="text-xs font-medium text-rose-700">{error}</p>
              </div>
            )}

            <Button
              onClick={executeTopUp}
              className="w-full rounded-xl bg-emerald-600 py-5 font-semibold text-white hover:bg-emerald-700"
            >
              <Zap className="mr-2 h-4 w-4" />
              Instant Top Up DANA
            </Button>

            <div className="flex items-center gap-2 rounded-xl bg-slate-50 px-3 py-2 text-xs text-slate-500">
              <ShieldCheck className="h-4 w-4 text-emerald-600" />
              Idempotency-key otomatis · webhook signature diverifikasi
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="rounded-2xl border-slate-200 shadow-sm lg:col-span-2">
          <CardHeader className="border-b border-slate-100 pb-4">
            <CardTitle className="flex items-center gap-2 text-base text-slate-900">
              <Phone className="h-4 w-4 text-emerald-700" />
              Riwayat Top-up
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full min-w-3xl border-collapse text-left text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-xs uppercase tracking-wider text-slate-400">
                    <th className="px-5 py-3 font-semibold">Ref ID</th>
                    <th className="px-5 py-3 font-semibold">Nomor</th>
                    <th className="px-5 py-3 font-semibold">Nominal</th>
                    <th className="px-5 py-3 font-semibold">Status</th>
                    <th className="px-5 py-3 font-semibold">Gateway</th>
                  </tr>
                </thead>
                <tbody>
                  {topUps.map((t) => (
                    <tr
                      key={t.refId}
                      className="border-b border-slate-100 transition hover:bg-slate-50"
                    >
                      <td className="px-5 py-3">
                        <p className="font-mono text-xs text-slate-600">{t.refId}</p>
                        <p className="text-xs text-slate-400">{t.createdAt}</p>
                      </td>
                      <td className="px-5 py-3 font-mono text-xs text-slate-700">
                        {t.phoneNumber}
                      </td>
                      <td className="px-5 py-3 font-mono font-bold text-emerald-700">
                        {formatRupiah(t.amount)}
                      </td>
                      <td className="px-5 py-3">
                        <StatusPill status={t.status} />
                        {t.failureCode && (
                          <p className="mt-1 text-xs text-rose-600">{t.failureCode}</p>
                        )}
                      </td>
                      <td className="px-5 py-3 font-mono text-xs text-slate-500">
                        {t.gatewayId}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardHeader className="border-b border-slate-100 pb-4">
            <CardTitle className="text-base text-slate-900">Audit Trail Wallet</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 pt-4">
            {walletLogs.slice(0, 8).map((l) => (
              <div
                key={l.id}
                className="rounded-xl border border-slate-100 bg-slate-50/60 p-3"
              >
                <div className="flex items-center justify-between gap-2">
                  <Badge className="rounded-full bg-slate-200 text-slate-700 hover:bg-slate-200">
                    {l.action}
                  </Badge>
                  <span className="font-mono text-xs text-slate-400">
                    {l.timestamp.slice(11)}
                  </span>
                </div>
                <p className="mt-1.5 font-mono text-xs text-slate-600">{l.refId}</p>
                {l.target && (
                  <p className="text-xs text-slate-500">target: {l.target}</p>
                )}
                {l.gatewayId && (
                  <p className="text-xs text-slate-500">gateway: {l.gatewayId}</p>
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}