import { ShieldCheck, Store, Smartphone } from "lucide-react";
import { useRole, type RoleId } from "@/lib/role-context";

const ROLES: { id: RoleId; label: string; icon: typeof ShieldCheck }[] = [
  { id: "admin", label: "SuperSaaS Admin", icon: ShieldCheck },
  { id: "member", label: "Member Dashboard", icon: Store },
  { id: "staff", label: "Staff / Kasir", icon: Smartphone },
];

export default function RoleSwitcher() {
  const { role, setRole } = useRole();

  return (
    <div className="rounded-xl bg-emerald-900/60 p-1.5">
      <p className="px-2 pb-1.5 pt-1 text-xs font-semibold uppercase tracking-wider text-emerald-300">
        Mode Akses
      </p>
      <div className="flex gap-1 md:flex-col">
        {ROLES.map(({ id, label, icon: Icon }) => {
          const active = role === id;
          return (
            <button
              key={id}
              onClick={() => setRole(id)}
              className={`flex flex-1 items-center gap-2 rounded-lg px-2.5 py-2 text-xs font-medium transition md:w-full ${
                active
                  ? "bg-emerald-500 text-white shadow-sm"
                  : "text-emerald-200 hover:bg-emerald-800/60"
              }`}
            >
              <Icon className="h-3.5 w-3.5 shrink-0" />
              <span className="truncate">{label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}