import { useEffect, useRef, useState } from "react";
import {
  CheckCircle2,
  Loader2,
  X,
  ShieldCheck,
  Copy,
  Wifi,
  WifiOff,
  XCircle,
  Radio,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatRupiah } from "@/lib/payment-data";
import { realtime, playSuccessChime } from "@/lib/realtime";

interface PaymentModalProps {
  open: boolean;
  invoice: string;
  total: number;
  qrisPayload: string;
  onClose: () => void;
  onPaid: () => void;
}

type Status = "PENDING" | "PAID" | "FAILED";

function QrMatrix({ seed }: { seed: string }) {
  const size = 25;
  const cells: boolean[] = [];
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  for (let i = 0; i < size * size; i++) {
    h = (h * 1103515245 + 12345) >>> 0;
    cells.push((h >>> 16) % 100 < 48);
  }
  const isFinder = (r: number, c: number) => {
    const inBox = (r0: number, c0: number) =>
      r >= r0 && r < r0 + 7 && c >= c0 && c < c0 + 7;
    return inBox(0, 0) || inBox(0, size - 7) || inBox(size - 7, 0);
  };
  const finderOn = (r: number, c: number) => {
    const local = (r0: number, c0: number) => {
      const rr = r - r0;
      const cc = c - c0;
      if (rr === 0 || rr === 6 || cc === 0 || cc === 6) return true;
      if (rr >= 2 && rr <= 4 && cc >= 2 && cc <= 4) return true;
      return false;
    };
    if (r < 7 && c < 7) return local(0, 0);
    if (r < 7 && c >= size - 7) return local(0, size - 7);
    if (r >= size - 7 && c < 7) return local(size - 7, 0);
    return false;
  };

  return (
    <div
      className="grid gap-0 rounded-xl bg-white p-3"
      style={{ gridTemplateColumns: `repeat(${size}, minmax(0, 1fr))` }}
    >
      {cells.map((on, i) => {
        const r = Math.floor(i / size);
        const c = i % size;
        const dark = isFinder(r, c) ? finderOn(r, c) : on;
        return (
          <div
            key={i}
            className={dark ? "aspect-square bg-slate-900" : "aspect-square bg-white"}
          />
        );
      })}
    </div>
  );
}

export default function PaymentModal({
  open,
  invoice,
  total,
  qrisPayload,
  onClose,
  onPaid,
}: PaymentModalProps) {
  const [status, setStatus] = useState<Status>("PENDING");
  const [seconds, setSeconds] = useState(0);
  const [copied, setCopied] = useState(false);
  const [connected, setConnected] = useState(realtime.isConnected());
  const [mode, setMode] = useState<"socket" | "polling">("socket");
  const [pollCount, setPollCount] = useState(0);
  const paidRef = useRef(false);

  useEffect(() => {
    if (!open) return;
    setStatus("PENDING");
    setSeconds(0);
    setPollCount(0);
    paidRef.current = false;
  }, [open, invoice]);

  useEffect(() => {
    if (!open || status !== "PENDING") return;
    const tick = setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => clearInterval(tick);
  }, [open, status]);

  useEffect(() => {
    if (!open || !invoice) return;
    realtime.join(invoice);
    realtime.simulateWebhook(invoice);

    const offMessage = realtime.on((payload) => {
      if (payload.invoice !== invoice) return;
      if (paidRef.current) return;
      paidRef.current = true;
      setStatus(payload.status);
      if (payload.status === "PAID") {
        playSuccessChime();
        onPaid();
      }
    });

    const offConn = realtime.onConnectionChange(setConnected);

    return () => {
      offMessage();
      offConn();
      realtime.leave(invoice);
    };
  }, [open, invoice, onPaid]);

  useEffect(() => {
    if (!open || status !== "PENDING" || mode !== "polling") return;
    const poll = setInterval(() => {
      setPollCount((c) => c + 1);
      if (paidRef.current) return;
      if (Math.random() < 0.3) {
        paidRef.current = true;
        setStatus("PAID");
        playSuccessChime();
        onPaid();
      }
    }, 3000);
    return () => clearInterval(poll);
  }, [open, status, mode, onPaid]);

  if (!open) return null;

  const mm = String(Math.floor(seconds / 60)).padStart(2, "0");
  const ss = String(seconds % 60).padStart(2, "0");

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-slate-900/60 p-0 backdrop-blur-sm sm:items-center sm:p-4">
      <div className="w-full max-w-md overflow-hidden rounded-t-3xl bg-white shadow-2xl sm:rounded-3xl">
        <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-widest text-emerald-700">
              Pembayaran QRIS
            </p>
            <p className="font-serif text-lg font-bold text-slate-900">{invoice}</p>
          </div>
          <div className="flex items-center gap-2">
            <span
              className={`flex items-center gap-1 rounded-full px-2 py-1 text-xs font-semibold ${
                connected
                  ? "bg-emerald-100 text-emerald-700"
                  : "bg-rose-100 text-rose-700"
              }`}
            >
              {connected ? (
                <Wifi className="h-3 w-3" />
              ) : (
                <WifiOff className="h-3 w-3" />
              )}
              {connected ? "Live" : "Offline"}
            </span>
            <button
              onClick={onClose}
              className="grid h-9 w-9 place-items-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-slate-700"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        <div className="px-5 py-5">
          <div className="rounded-2xl bg-slate-50 p-4 text-center">
            <p className="text-xs text-slate-500">Total Tagihan</p>
            <p className="font-serif text-3xl font-bold text-slate-900">
              {formatRupiah(total)}
            </p>
          </div>

          {status === "PENDING" && (
            <>
              <div className="mx-auto mt-5 w-56">
                <QrMatrix seed={qrisPayload} />
              </div>
              <p className="mt-4 text-center text-xs text-slate-500">
                Scan dengan aplikasi apa pun berlogo QRIS — DANA, GoPay, OVO,
                ShopeePay, BCA Mobile, Livin', Jago, dan 50+ lainnya.
              </p>

              <div className="mt-4 flex items-center justify-center gap-2 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3">
                <span className="relative flex h-3 w-3">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-amber-500 opacity-75" />
                  <span className="relative inline-flex h-3 w-3 rounded-full bg-amber-500" />
                </span>
                <span className="text-sm font-semibold text-amber-700">
                  Menunggu Pembayaran
                </span>
                <span className="text-xs text-amber-600">
                  {mm}:{ss}
                </span>
              </div>

              <div className="mt-3 flex items-center justify-between rounded-xl border border-slate-200 px-3 py-2">
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <Radio className="h-3.5 w-3.5 text-emerald-600" />
                  {mode === "socket" ? (
                    <span>
                      Socket channel · room <span className="font-mono">{invoice}</span>
                    </span>
                  ) : (
                    <span>Polling tiap 3s · {pollCount}x cek</span>
                  )}
                </div>
                <button
                  onClick={() => setMode((m) => (m === "socket" ? "polling" : "socket"))}
                  className="rounded-lg bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-600 transition hover:bg-slate-200"
                >
                  {mode === "socket" ? "Pakai Polling" : "Pakai Socket"}
                </button>
              </div>

              <button
                onClick={() => {
                  navigator.clipboard?.writeText(qrisPayload).catch(() => {});
                  setCopied(true);
                  setTimeout(() => setCopied(false), 1500);
                }}
                className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl border border-slate-200 px-4 py-2.5 text-xs font-medium text-slate-600 transition hover:bg-slate-50"
              >
                <Copy className="h-3.5 w-3.5" />
                {copied ? "Payload tersalin!" : "Salin payload QRIS"}
              </button>
            </>
          )}

          {status === "PAID" && (
            <div className="mt-6 flex flex-col items-center py-4">
              <div className="grid h-20 w-20 animate-bounce place-items-center rounded-full bg-emerald-100">
                <CheckCircle2 className="h-11 w-11 text-emerald-600" />
              </div>
              <p className="mt-4 font-serif text-xl font-bold text-slate-900">
                Pembayaran Sukses
              </p>
              <p className="mt-1 text-center text-sm text-slate-500">
                Sinyal real-time diterima dari webhook. Transaksi ditandai PAID.
              </p>
              <div className="mt-4 flex items-center gap-2 rounded-xl bg-emerald-50 px-4 py-2 text-xs font-medium text-emerald-700">
                <ShieldCheck className="h-4 w-4" />
                Signature valid · broadcast ke room {invoice}
              </div>
            </div>
          )}

          {status === "FAILED" && (
            <div className="mt-6 flex flex-col items-center py-4">
              <div className="grid h-20 w-20 place-items-center rounded-full bg-rose-100">
                <XCircle className="h-11 w-11 text-rose-600" />
              </div>
              <p className="mt-4 font-serif text-xl font-bold text-slate-900">
                QRIS Kedaluwarsa
              </p>
              <p className="mt-1 text-center text-sm text-slate-500">
                Pembayaran gagal atau melewati batas waktu. Silakan buat QRIS
                baru.
              </p>
            </div>
          )}
        </div>

        <div className="border-t border-slate-100 px-5 py-4">
          {status === "PENDING" ? (
            <Button
              variant="outline"
              onClick={onClose}
              className="w-full rounded-xl font-semibold"
            >
              Batalkan
            </Button>
          ) : (
            <Button
              onClick={onClose}
              className={`w-full rounded-xl font-semibold text-white ${
                status === "PAID"
                  ? "bg-emerald-600 hover:bg-emerald-700"
                  : "bg-rose-600 hover:bg-rose-700"
              }`}
            >
              {status === "PAID" ? "Selesai" : "Tutup"}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}