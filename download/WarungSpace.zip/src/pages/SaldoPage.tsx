import { useMemo, useState } from "react";
import {
  Wallet,
  ArrowDownToLine,
  ArrowUpRight,
  QrCode,
  Plus,
  Minus,
  CheckCircle2,
  Building2,
  Smartphone,
  ScanLine,
  X,
  TrendingUp,
  History,
  AlertCircle,
  Loader2,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { formatRupiah } from "@/lib/disbursement-data";
import { useAudit } from "@/lib/audit-context";
import DefaultTopUpPanel from "@/components/DefaultTopUpPanel";
import XenditPayoutPanel from "@/components/XenditPayoutPanel";
import WalletBalanceCard from "@/components/WalletBalanceCard";
import UnitTestPanel from "@/components/UnitTestPanel";
import ValidationPanel from "@/components/ValidationPanel";

type Action = "deposit" | "transfer" | "scan" | null;

interface Tx {
  id: number;
  type: "DEPOSIT" | "TRANSFER" | "SCAN" | "TOPUP";
  label: string;
  amount: number;
  direction: "in" | "out";
  time: string;
  status: "SUCCESS" | "PENDING";
}

const CHANNELS = [
  { code: "BCA", label: "BCA Virtual Account", emoji: "🏦" },
  { code: "DANA", label: "DANA", emoji: "💙" },
  { code: "OVO", label: "OVO", emoji: "💜" },
  { code: "GOPAY", label: "GoPay", emoji: "💚" },
];

const INITIAL_TX: Tx[] = [
  {
    id: 1,
    type: "DEPOSIT",
    label: "Top-up via BCA VA",
    amount: 5000000,
    direction: "in",
    time: "2025-01-31 09:12",
    status: "SUCCESS",
  },
  {
    id: 2,
    type: "TRANSFER",
    label: "Transfer ke Andi Pratama (DANA)",
    amount: 1850000,
    direction: "out",
    time: "2025-01-31 08:20",
    status: "SUCCESS",
  },
  {
    id: 3,
    type: "SCAN",
    label: "Bayar QRIS — Supplier Kopi Nusantara",
    amount: 720000,
    direction: "out",
    time: "2025-01-30 15:45",
    status: "SUCCESS",
  },
];

const MIN_DEPOSIT = 10000;
const MAX_DEPOSIT = 50000000;
const MIN_TRANSFER = 10000;
const MAX_TRANSFER = 25000000;
const DAILY_LIMIT = 10000000;

function nowStamp() {
  const d = new Date();
  const p = (v: number) => String(v).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(
    d.getHours()
  )}:${p(d.getMinutes())}`;
}

function isValidPhone(v: string) {
  return /^(\+62|62|0)8[1-9][0-9]{6,11}$/.test(v.replace(/[\s-]/g, ""));
}

function isValidAccount(v: string) {
  return /^[0-9]{8,20}$/.test(v.replace(/[\s-]/g, ""));
}

export default function SaldoPage() {
  const { log } = useAudit();
  const [balance, setBalance] = useState(12450000);
  const [txs, setTxs] = useState<Tx[]>(INITIAL_TX);
  const [action, setAction] = useState<Action>(null);
  const [amount, setAmount] = useState("");
  const [channel, setChannel] = useState("BCA");
  const [recipient, setRecipient] = useState("");
  const [recipientType, setRecipientType] = useState<"phone" | "account">("phone");
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [submitting, setSubmitting] = useState(false);
  const [toast, setToast] = useState<{ msg: string; ok: boolean } | null>(null);

  const numericAmount = Number(amount.replace(/\D/g, "")) || 0;

  const spentToday = useMemo(
    () =>
      txs
        .filter(
          (t) =>
            t.direction === "out" &&
            t.status === "SUCCESS" &&
            t.time.startsWith(nowStamp().slice(0, 10))
        )
        .reduce((s, t) => s + t.amount, 0),
    [txs]
  );

  const errors = useMemo(() => {
    const e: Record<string, string> = {};
    if (!action) return e;

    if (action === "deposit") {
      if (!numericAmount) e.amount = "Nominal deposit wajib diisi.";
      else if (numericAmount < MIN_DEPOSIT)
        e.amount = `Minimal deposit ${formatRupiah(MIN_DEPOSIT)}.`;
      else if (numericAmount > MAX_DEPOSIT)
        e.amount = `Maksimal deposit ${formatRupiah(MAX_DEPOSIT)} per transaksi.`;
      if (!channel) e.channel = "Pilih metode deposit.";
    }

    if (action === "transfer") {
      if (!recipient.trim()) e.recipient = "Tujuan transfer wajib diisi.";
      else if (recipientType === "phone" && !isValidPhone(recipient))
        e.recipient = "Format nomor HP tidak valid (contoh: 08123456789).";
      else if (recipientType === "account" && !isValidAccount(recipient))
        e.recipient = "Nomor rekening harus 8–20 digit angka.";

      if (!numericAmount) e.amount = "Nominal transfer wajib diisi.";
      else if (numericAmount < MIN_TRANSFER)
        e.amount = `Minimal transfer ${formatRupiah(MIN_TRANSFER)}.`;
      else if (numericAmount > MAX_TRANSFER)
        e.amount = `Maksimal transfer ${formatRupiah(MAX_TRANSFER)} per transaksi.`;
      else if (numericAmount > balance) e.amount = "Saldo tidak mencukupi.";
      else if (spentToday + numericAmount > DAILY_LIMIT)
        e.amount = `Melebihi limit harian ${formatRupiah(DAILY_LIMIT)}.`;
    }

    if (action === "scan") {
      if (!numericAmount) e.amount = "Nominal pembayaran wajib diisi.";
      else if (numericAmount < 1000) e.amount = "Minimal pembayaran Rp 1.000.";
      else if (numericAmount > balance) e.amount = "Saldo tidak mencukupi.";
      else if (spentToday + numericAmount > DAILY_LIMIT)
        e.amount = `Melebihi limit harian ${formatRupiah(DAILY_LIMIT)}.`;
    }

    return e;
  }, [action, numericAmount, recipient, recipientType, balance, spentToday, channel]);

  const isValid = Object.keys(errors).length === 0;

  function flash(msg: string, ok = true) {
    setToast({ msg, ok });
    setTimeout(() => setToast(null), 3200);
  }

  function close() {
    setAction(null);
    setAmount("");
    setRecipient("");
    setTouched({});
    setSubmitting(false);
  }

  function submit() {
    setTouched({ amount: true, recipient: true, channel: true });
    if (!isValid) {
      flash("Periksa kembali data yang belum valid.", false);
      return;
    }
    setSubmitting(true);

    setTimeout(() => {
      const val = numericAmount;

      if (action === "deposit") {
        setBalance((b) => b + val);
        setTxs((t) => [
          {
            id: Date.now(),
            type: "DEPOSIT",
            label: `Top-up via ${channel}`,
            amount: val,
            direction: "in",
            time: nowStamp(),
            status: "SUCCESS",
          },
          ...t,
        ]);
        log("SALDO_DEPOSIT", `Deposit ${formatRupiah(val)} via ${channel}`, "owner@warungspace.id");
        flash(`Deposit ${formatRupiah(val)} berhasil!`);
      } else if (action === "transfer") {
        setBalance((b) => b - val);
        setTxs((t) => [
          {
            id: Date.now(),
            type: "TRANSFER",
            label: `Transfer ke ${recipient}`,
            amount: val,
            direction: "out",
            time: nowStamp(),
            status: "SUCCESS",
          },
          ...t,
        ]);
        log("SALDO_TRANSFER", `Transfer ${formatRupiah(val)} ke ${recipient}`, "owner@warungspace.id");
        flash(`Transfer ${formatRupiah(val)} terkirim!`);
      } else if (action === "scan") {
        setBalance((b) => b - val);
        setTxs((t) => [
          {
            id: Date.now(),
            type: "SCAN",
            label: "Bayar QRIS — Merchant",
            amount: val,
            direction: "out",
            time: nowStamp(),
            status: "SUCCESS",
          },
          ...t,
        ]);
        log("SALDO_SCAN", `Bayar QRIS ${formatRupiah(val)}`, "owner@warungspace.id");
        flash(`Pembayaran QRIS ${formatRupiah(val)} berhasil!`);
      }
      close();
    }, 700);
  }

  function handleTopUp(amt: number, label: string) {
    setBalance((b) => b - amt);
    setTxs((t) => [
      {
        id: Date.now(),
        type: "TOPUP",
        label: `Top up otomatis — ${label}`,
        amount: amt,
        direction: "out",
        time: nowStamp(),
        status: "SUCCESS",
      },
      ...t,
    ]);
    flash(`Top up ${formatRupiah(amt)} ke ${label} berhasil!`);
  }

  const showErr = (key: string) => touched[key] && errors[key];

  return (
    <div className="space-y-6">
      {toast && (
        <div
          className={`fixed bottom-6 right-6 z-50 flex items-center gap-3 rounded-2xl border bg-white px-4 py-3 shadow-xl ${
            toast.ok ? "border-emerald-200" : "border-rose-200"
          }`}
        >
          {toast.ok ? (
            <CheckCircle2 className="h-5 w-5 text-emerald-600" />
          ) : (
            <AlertCircle className="h-5 w-5 text-rose-600" />
          )}
          <p className="text-sm font-semibold text-slate-800">{toast.msg}</p>
        </div>
      )}

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-xl bg-emerald-600 text-white">
            <Wallet className="h-5 w-5" />
          </div>
          <div>
            <h2 className="font-serif text-xl font-bold text-slate-900">
              Saldo & Dompet Bisnis
            </h2>
            <p className="text-xs text-slate-500">
              Deposit, transfer, top up otomatis, dan bayar QRIS.
            </p>
          </div>
        </div>
        <Badge className="rounded-full bg-emerald-100 text-emerald-700 hover:bg-emerald-100">
          <TrendingUp className="mr-1 h-3 w-3" />
          Limit harian {formatRupiah(DAILY_LIMIT)}
        </Badge>
      </div>

      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-700 via-emerald-800 to-slate-900 p-6 text-white shadow-lg md:p-8">
        <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-emerald-500/20 blur-2xl" />
        <p className="text-xs font-semibold uppercase tracking-widest text-emerald-300">
          Saldo Tersedia
        </p>
        <p className="mt-2 font-serif text-3xl font-bold md:text-4xl">
          {formatRupiah(balance)}
        </p>
        <p className="mt-1 text-xs text-emerald-200">
          Terpakai hari ini: {formatRupiah(spentToday)} / {formatRupiah(DAILY_LIMIT)}
        </p>

        <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-3">
          <button
            onClick={() => setAction("deposit")}
            className="flex items-center justify-center gap-2 rounded-xl bg-white/95 py-3 text-sm font-bold text-emerald-800 transition hover:bg-white"
          >
            <ArrowDownToLine className="h-4 w-4" />
            Deposit
          </button>
          <button
            onClick={() => setAction("transfer")}
            className="flex items-center justify-center gap-2 rounded-xl bg-emerald-500 py-3 text-sm font-bold text-white transition hover:bg-emerald-400"
          >
            <ArrowUpRight className="h-4 w-4" />
            Kirim Transfer
          </button>
          <button
            onClick={() => setAction("scan")}
            className="flex items-center justify-center gap-2 rounded-xl bg-white/15 py-3 text-sm font-bold text-white ring-1 ring-white/30 transition hover:bg-white/25"
          >
            <QrCode className="h-4 w-4" />
            Scan QRIS
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <DefaultTopUpPanel onSuccess={handleTopUp} onLog={log} />
          <XenditPayoutPanel onDebit={handleTopUp} onLog={log} />
        </div>

        <div className="space-y-6">
          <WalletBalanceCard plannedTopUp={50000} />
          <ValidationPanel />
          <UnitTestPanel />
        </div>
      </div>

      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardContent className="p-5">
          <div className="mb-4 flex items-center gap-2">
            <History className="h-4 w-4 text-slate-500" />
            <h3 className="text-sm font-bold text-slate-900">Riwayat Transaksi</h3>
          </div>
          <div className="space-y-2">
            {txs.map((t) => (
              <div
                key={t.id}
                className="flex items-center justify-between rounded-xl border border-slate-100 p-3 transition hover:bg-slate-50"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`grid h-9 w-9 place-items-center rounded-lg ${
                      t.direction === "in"
                        ? "bg-emerald-100 text-emerald-700"
                        : "bg-rose-100 text-rose-700"
                    }`}
                  >
                    {t.direction === "in" ? (
                      <Plus className="h-4 w-4" />
                    ) : (
                      <Minus className="h-4 w-4" />
                    )}
                  </div>
                  <div>
                    <p className="text-sm font-medium text-slate-800">{t.label}</p>
                    <p className="text-xs text-slate-400">{t.time}</p>
                  </div>
                </div>
                <p
                  className={`font-mono text-sm font-bold ${
                    t.direction === "in" ? "text-emerald-700" : "text-rose-700"
                  }`}
                >
                  {t.direction === "in" ? "+" : "-"}
                  {formatRupiah(t.amount)}
                </p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {action && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-slate-900/50 p-0 sm:items-center sm:p-4">
          <div className="w-full max-w-md rounded-t-3xl bg-white p-6 shadow-2xl sm:rounded-3xl">
            <div className="mb-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                {action === "deposit" && <ArrowDownToLine className="h-5 w-5 text-emerald-600" />}
                {action === "transfer" && <ArrowUpRight className="h-5 w-5 text-emerald-600" />}
                {action === "scan" && <ScanLine className="h-5 w-5 text-emerald-600" />}
                <h3 className="font-serif text-lg font-bold text-slate-900">
                  {action === "deposit"
                    ? "Deposit Saldo"
                    : action === "transfer"
                    ? "Kirim Transfer"
                    : "Scan & Bayar QRIS"}
                </h3>
              </div>
              <button
                onClick={close}
                className="grid h-8 w-8 place-items-center rounded-lg text-slate-400 transition hover:bg-slate-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {action === "scan" && (
              <div className="mb-4 grid place-items-center rounded-2xl border-2 border-dashed border-emerald-300 bg-emerald-50 py-10">
                <QrCode className="h-16 w-16 text-emerald-500" />
                <p className="mt-2 text-xs font-medium text-emerald-700">
                  Arahkan kamera ke kode QRIS merchant
                </p>
              </div>
            )}

            {action === "deposit" && (
              <div className="mb-4 space-y-2">
                <Label>Metode Deposit</Label>
                <div className="grid grid-cols-2 gap-2">
                  {CHANNELS.map((c) => (
                    <button
                      key={c.code}
                      onClick={() => setChannel(c.code)}
                      className={`flex items-center gap-2 rounded-xl border p-3 text-sm font-medium transition ${
                        channel === c.code
                          ? "border-emerald-500 bg-emerald-50 text-emerald-800"
                          : "border-slate-200 text-slate-600 hover:bg-slate-50"
                      }`}
                    >
                      <span>{c.emoji}</span>
                      {c.code}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {action === "transfer" && (
              <div className="mb-4 space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="recipient">Tujuan Transfer</Label>
                  <div className="flex gap-1 rounded-lg bg-slate-100 p-0.5">
                    {(["phone", "account"] as const).map((t) => (
                      <button
                        key={t}
                        onClick={() => {
                          setRecipientType(t);
                          setRecipient("");
                        }}
                        className={`rounded-md px-2 py-1 text-xs font-semibold transition ${
                          recipientType === t
                            ? "bg-white text-emerald-700 shadow-sm"
                            : "text-slate-500"
                        }`}
                      >
                        {t === "phone" ? "No. HP" : "Rekening"}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="relative">
                  <Smartphone className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                  <Input
                    id="recipient"
                    value={recipient}
                    onChange={(e) => setRecipient(e.target.value)}
                    onBlur={() => setTouched((s) => ({ ...s, recipient: true }))}
                    placeholder={
                      recipientType === "phone" ? "08123456789" : "1234567890"
                    }
                    className={`rounded-xl pl-9 ${
                      showErr("recipient") ? "border-rose-400 focus-visible:ring-rose-300" : ""
                    }`}
                  />
                </div>
                {showErr("recipient") && (
                  <p className="flex items-center gap-1 text-xs text-rose-600">
                    <AlertCircle className="h-3 w-3" />
                    {errors.recipient}
                  </p>
                )}
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="amount">Nominal</Label>
              <div className="relative">
                <Building2 className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                <Input
                  id="amount"
                  inputMode="numeric"
                  value={amount ? Number(amount).toLocaleString("id-ID") : ""}
                  onChange={(e) => setAmount(e.target.value.replace(/\D/g, ""))}
                  onBlur={() => setTouched((s) => ({ ...s, amount: true }))}
                  placeholder="0"
                  className={`rounded-xl pl-9 font-mono text-lg ${
                    showErr("amount") ? "border-rose-400 focus-visible:ring-rose-300" : ""
                  }`}
                />
              </div>
              {showErr("amount") && (
                <p className="flex items-center gap-1 text-xs text-rose-600">
                  <AlertCircle className="h-3 w-3" />
                  {errors.amount}
                </p>
              )}
              <div className="flex flex-wrap gap-2">
                {[50000, 100000, 500000, 1000000].map((v) => (
                  <button
                    key={v}
                    onClick={() => {
                      setAmount(String(v));
                      setTouched((s) => ({ ...s, amount: true }));
                    }}
                    className="rounded-lg bg-slate-100 px-3 py-1.5 text-xs font-semibold text-slate-600 transition hover:bg-slate-200"
                  >
                    {formatRupiah(v)}
                  </button>
                ))}
              </div>
              {action !== "deposit" && (
                <p className="text-xs text-slate-500">
                  Saldo tersedia: <b>{formatRupiah(balance)}</b>
                </p>
              )}
            </div>

            <Button
              onClick={submit}
              disabled={submitting}
              className="mt-5 w-full rounded-xl bg-emerald-600 py-3 font-bold text-white hover:bg-emerald-700 disabled:opacity-60"
            >
              {submitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Memproses...
                </>
              ) : action === "deposit" ? (
                "Konfirmasi Deposit"
              ) : action === "transfer" ? (
                "Kirim Sekarang"
              ) : (
                "Bayar Sekarang"
              )}
            </Button>
            {!isValid && Object.keys(touched).length > 0 && (
              <p className="mt-2 text-center text-xs text-slate-400">
                Lengkapi data yang valid untuk melanjutkan.
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}