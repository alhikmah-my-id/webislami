import { useState } from "react";
import {
  User,
  ShieldCheck,
  Link2,
  Unlink,
  Star,
  Wallet,
  Landmark,
  ScrollText,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Save,
  KeyRound,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  PROVIDERS,
  INITIAL_PROFILES,
  INITIAL_FINTECH_LOGS,
  nowStamp,
  maskPhone,
  type FintechProfile,
  type FintechAuditLog,
} from "@/lib/profile-data";

const STATUS_STYLES: Record<FintechProfile["bindingStatus"], string> = {
  LINKED: "bg-emerald-100 text-emerald-700",
  PENDING: "bg-amber-100 text-amber-700",
  UNLINKED: "bg-slate-100 text-slate-600",
  EXPIRED: "bg-rose-100 text-rose-700",
};

export default function ProfileSettingsPage() {
  const [name, setName] = useState("Wahyudi");
  const [email, setEmail] = useState("owner@warungspace.id");
  const [phone, setPhone] = useState("081234567890");
  const [saved, setSaved] = useState(false);

  const [profiles, setProfiles] = useState<FintechProfile[]>(INITIAL_PROFILES);
  const [logs, setLogs] = useState<FintechAuditLog[]>(INITIAL_FINTECH_LOGS);
  const [busyId, setBusyId] = useState<number | null>(null);

  function pushLog(
    action: string,
    providerCode: string,
    status: "SUCCESS" | "FAILED",
    detail: string
  ) {
    setLogs((prev) => [
      {
        id: Date.now() + Math.floor(Math.random() * 1000),
        timestamp: nowStamp(),
        action,
        providerCode,
        status,
        ip: "103.28.14.9",
        detail,
      },
      ...prev,
    ]);
  }

  function handleSaveProfile(e: React.FormEvent) {
    e.preventDefault();
    setSaved(true);
    setTimeout(() => setSaved(false), 1800);
  }

  function bindProvider(providerId: number) {
    const provider = PROVIDERS.find((p) => p.id === providerId);
    if (!provider) return;
    setBusyId(providerId);

    setTimeout(() => {
      const existing = profiles.find((p) => p.providerId === providerId);
      if (existing) {
        setProfiles((prev) =>
          prev.map((p) =>
            p.providerId === providerId
              ? { ...p, bindingStatus: "LINKED", linkedAt: nowStamp() }
              : p
          )
        );
      } else {
        setProfiles((prev) => [
          ...prev,
          {
            id: Date.now(),
            providerId,
            externalCustomerId: `${provider.code}-CUST-${Math.floor(
              10000 + Math.random() * 90000
            )}`,
            maskedPhone: maskPhone(phone),
            accountStatus: "BASIC",
            isPrimary: prev.length === 0,
            bindingStatus: "LINKED",
            linkedAt: nowStamp(),
          },
        ]);
      }
      pushLog(
        "ACCOUNT_BINDING",
        provider.code,
        "SUCCESS",
        `Binding token diterima dari ${provider.name}, refresh_token tersimpan (encrypted)`
      );
      setBusyId(null);
    }, 900);
  }

  function unbindProvider(providerId: number) {
    const provider = PROVIDERS.find((p) => p.id === providerId);
    if (!provider) return;
    setBusyId(providerId);

    setTimeout(() => {
      setProfiles((prev) =>
        prev.map((p) =>
          p.providerId === providerId
            ? { ...p, bindingStatus: "UNLINKED", isPrimary: false }
            : p
        )
      );
      pushLog(
        "ACCOUNT_UNBINDING",
        provider.code,
        "SUCCESS",
        `Token akses ${provider.name} dicabut, auto-disburse dinonaktifkan`
      );
      setBusyId(null);
    }, 700);
  }

  function setPrimary(providerId: number) {
    const provider = PROVIDERS.find((p) => p.id === providerId);
    setProfiles((prev) =>
      prev.map((p) => ({ ...p, isPrimary: p.providerId === providerId }))
    );
    if (provider) {
      pushLog(
        "SET_PRIMARY_WALLET",
        provider.code,
        "SUCCESS",
        `${provider.name} dijadikan dompet utama untuk reimbursement & gaji`
      );
    }
  }

  const linkedCount = profiles.filter((p) => p.bindingStatus === "LINKED").length;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-xl bg-emerald-600 text-white">
            <User className="h-5 w-5" />
          </div>
          <div>
            <h2 className="font-serif text-xl font-bold text-slate-900">
              Pengaturan Profil
            </h2>
            <p className="text-xs text-slate-500">
              Kelola identitas akun dan integrasi dompet digital / bank.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs font-semibold text-emerald-700">
          <ShieldCheck className="h-4 w-4" />
          {linkedCount} akun fintech terhubung
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Card className="rounded-2xl border-slate-200 shadow-sm">
            <CardContent className="p-6">
              <h3 className="text-sm font-bold text-slate-900">Data Akun</h3>
              <form onSubmit={handleSaveProfile} className="mt-4 grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="name">Nama Lengkap</Label>
                  <Input
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="rounded-xl"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="rounded-xl"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="phone">Nomor HP</Label>
                  <Input
                    id="phone"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="rounded-xl"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label>Role</Label>
                  <div className="flex h-10 items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3">
                    <Badge className="rounded-full bg-emerald-100 text-emerald-700 hover:bg-emerald-100">
                      ADMIN
                    </Badge>
                    <span className="text-xs text-slate-500">Akses penuh</span>
                  </div>
                </div>
                <div className="sm:col-span-2">
                  <Button
                    type="submit"
                    className="rounded-xl bg-emerald-600 font-semibold text-white hover:bg-emerald-700"
                  >
                    <Save className="mr-2 h-4 w-4" />
                    {saved ? "Tersimpan!" : "Simpan Perubahan"}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          <Card className="rounded-2xl border-slate-200 shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center gap-2">
                <KeyRound className="h-4 w-4 text-slate-500" />
                <h3 className="text-sm font-bold text-slate-900">
                  Keamanan Akun
                </h3>
              </div>
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="pw">Password Baru</Label>
                  <Input id="pw" type="password" placeholder="••••••••" className="rounded-xl" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="pin">PIN Kasir (6 digit)</Label>
                  <Input id="pin" type="password" placeholder="••••••" className="rounded-xl" />
                </div>
              </div>
              <p className="mt-3 text-xs text-slate-500">
                PIN digunakan karyawan untuk clock-in absensi GPS.
              </p>
            </CardContent>
          </Card>

          <Card className="rounded-2xl border-slate-200 shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center gap-2">
                <ScrollText className="h-4 w-4 text-slate-500" />
                <h3 className="text-sm font-bold text-slate-900">
                  Log Audit Fintech
                </h3>
              </div>
              <div className="mt-4 overflow-x-auto">
                <table className="w-full min-w-3xl border-collapse text-left text-sm">
                  <thead>
                    <tr className="border-b border-slate-200 text-xs uppercase tracking-wider text-slate-400">
                      <th className="py-3 pr-4 font-semibold">Waktu</th>
                      <th className="py-3 pr-4 font-semibold">Aksi</th>
                      <th className="py-3 pr-4 font-semibold">Provider</th>
                      <th className="py-3 pr-4 font-semibold">Status</th>
                      <th className="py-3 font-semibold">Detail</th>
                    </tr>
                  </thead>
                  <tbody>
                    {logs.map((l) => (
                      <tr
                        key={l.id}
                        className="border-b border-slate-100 transition hover:bg-slate-50"
                      >
                        <td className="whitespace-nowrap py-3 pr-4 font-mono text-xs text-slate-500">
                          {l.timestamp}
                        </td>
                        <td className="whitespace-nowrap py-3 pr-4 font-medium text-slate-700">
                          {l.action}
                        </td>
                        <td className="py-3 pr-4">
                          <Badge className="rounded-full bg-slate-100 text-slate-700 hover:bg-slate-100">
                            {l.providerCode}
                          </Badge>
                        </td>
                        <td className="py-3 pr-4">
                          <span
                            className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold ${
                              l.status === "SUCCESS"
                                ? "bg-emerald-100 text-emerald-700"
                                : "bg-rose-100 text-rose-700"
                            }`}
                          >
                            {l.status === "SUCCESS" ? (
                              <CheckCircle2 className="h-3 w-3" />
                            ) : (
                              <XCircle className="h-3 w-3" />
                            )}
                            {l.status}
                          </span>
                        </td>
                        <td className="py-3 text-slate-600">{l.detail}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="rounded-2xl border-slate-200 shadow-sm">
            <CardContent className="p-6">
              <h3 className="text-sm font-bold text-slate-900">
                Dompet & Bank Terhubung
              </h3>
              <p className="mt-1 text-xs text-slate-500">
                Binding akun untuk auto-disburse gaji & reimbursement.
              </p>

              <div className="mt-4 space-y-3">
                {PROVIDERS.map((provider) => {
                  const profile = profiles.find((p) => p.providerId === provider.id);
                  const linked = profile?.bindingStatus === "LINKED";
                  const busy = busyId === provider.id;

                  return (
                    <div
                      key={provider.id}
                      className={`rounded-xl border p-3 transition ${
                        linked ? "border-emerald-200 bg-emerald-50/50" : "border-slate-200 bg-white"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`grid h-9 w-9 shrink-0 place-items-center rounded-lg border text-base ${provider.color}`}
                        >
                          {provider.emoji}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5">
                            <p className="truncate text-sm font-semibold text-slate-800">
                              {provider.name}
                            </p>
                            {profile?.isPrimary && (
                              <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                            )}
                          </div>
                          <p className="flex items-center gap-1 text-xs text-slate-500">
                            {provider.category === "E-WALLET" ? (
                              <Wallet className="h-3 w-3" />
                            ) : (
                              <Landmark className="h-3 w-3" />
                            )}
                            {provider.category.replace("_", " ")}
                          </p>
                        </div>
                        {profile && (
                          <Badge
                            className={`rounded-full ${STATUS_STYLES[profile.bindingStatus]} hover:bg-inherit`}
                          >
                            {profile.bindingStatus}
                          </Badge>
                        )}
                      </div>

                      {profile && profile.bindingStatus === "LINKED" && (
                        <div className="mt-2 space-y-0.5 rounded-lg bg-white/70 px-2.5 py-2 text-xs text-slate-500">
                          <p>
                            ID: <span className="font-mono text-slate-700">{profile.externalCustomerId}</span>
                          </p>
                          <p>
                            HP: <span className="font-mono text-slate-700">{profile.maskedPhone}</span> ·{" "}
                            {profile.accountStatus}
                          </p>
                        </div>
                      )}

                      <div className="mt-2 flex gap-2">
                        {linked ? (
                          <>
                            <button
                              onClick={() => unbindProvider(provider.id)}
                              disabled={busy}
                              className="flex flex-1 items-center justify-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2 py-1.5 text-xs font-semibold text-slate-600 transition hover:bg-slate-50 disabled:opacity-50"
                            >
                              <Unlink className="h-3.5 w-3.5" />
                              {busy ? "Memproses…" : "Lepas"}
                            </button>
                            {!profile?.isPrimary && (
                              <button
                                onClick={() => setPrimary(provider.id)}
                                className="flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-emerald-600 px-2 py-1.5 text-xs font-semibold text-white transition hover:bg-emerald-700"
                              >
                                <Star className="h-3.5 w-3.5" />
                                Jadikan Utama
                              </button>
                            )}
                          </>
                        ) : (
                          <button
                            onClick={() => bindProvider(provider.id)}
                            disabled={busy}
                            className="flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-emerald-600 px-2 py-1.5 text-xs font-semibold text-white transition hover:bg-emerald-700 disabled:opacity-50"
                          >
                            <Link2 className="h-3.5 w-3.5" />
                            {busy ? "Menghubungkan…" : "Hubungkan Akun"}
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-2xl border-amber-200 bg-amber-50 shadow-sm">
            <CardContent className="p-5">
              <div className="flex items-start gap-2">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" />
                <div>
                  <p className="text-xs font-bold text-amber-800">
                    Token Keamanan Terenkripsi
                  </p>
                  <p className="mt-1 text-xs text-amber-700">
                    access_token & refresh_token disimpan terenkripsi. Token
                    kedaluwarsa otomatis di-refresh tanpa OTP berulang.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}