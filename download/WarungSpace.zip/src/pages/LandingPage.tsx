import { useState } from "react";
import {
  Store,
  Check,
  ChevronDown,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  WifiOff,
  BarChart3,
  Receipt,
  Info,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { FEATURE_GROUPS, FAQS } from "@/lib/features-data";

interface LandingPageProps {
  onEnterApp: () => void;
  onViewAllFeatures: () => void;
  onViewSegments: () => void;
  onViewAbout: () => void;
}

const HIGHLIGHTS = [
  { icon: WifiOff, title: "Kasir Offline", desc: "Keranjang aman saat internet putus" },
  { icon: Receipt, title: "Kasbon & Piutang", desc: "Invoice ter-update tiap cicilan" },
  { icon: BarChart3, title: "Profit Intelligence", desc: "Harga jual dari HPP + margin" },
  { icon: ShieldCheck, title: "Multi-Peran", desc: "Pemilik, Manajer, Kasir, Mitra" },
];

export default function LandingPage({
  onEnterApp,
  onViewAllFeatures,
  onViewSegments,
  onViewAbout,
}: LandingPageProps) {
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <header className="sticky top-0 z-20 border-b border-emerald-900/20 bg-emerald-950/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3 md:px-8">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-emerald-500/20 text-emerald-300">
              <Store className="h-5 w-5" />
            </div>
            <div className="leading-tight">
              <p className="font-serif text-lg font-bold text-white">WarungSpace</p>
              <p className="text-xs text-emerald-300">SaaS ERP UMKM</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onViewSegments}
              className="hidden rounded-lg px-3 py-2 text-sm font-medium text-emerald-100 transition hover:bg-emerald-800/60 md:block"
            >
              Kebutuhan
            </button>
            <button
              onClick={onViewAllFeatures}
              className="hidden rounded-lg px-3 py-2 text-sm font-medium text-emerald-100 transition hover:bg-emerald-800/60 sm:block"
            >
              Semua Fitur
            </button>
            <button
              onClick={onViewAbout}
              className="hidden rounded-lg px-3 py-2 text-sm font-medium text-emerald-100 transition hover:bg-emerald-800/60 md:block"
            >
              Tentang
            </button>
            <a
              href="#faq"
              className="hidden rounded-lg px-3 py-2 text-sm font-medium text-emerald-100 transition hover:bg-emerald-800/60 sm:block"
            >
              Lihat FAQ
            </a>
            <Button
              onClick={onEnterApp}
              className="rounded-xl bg-emerald-500 font-semibold text-white hover:bg-emerald-400"
            >
              Coba Gratis
            </Button>
          </div>
        </div>
      </header>

      <section className="relative overflow-hidden bg-gradient-to-br from-emerald-950 via-emerald-900 to-teal-900">
        <div className="mx-auto grid max-w-6xl gap-10 px-4 py-14 md:grid-cols-2 md:items-center md:px-8 md:py-20">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full bg-emerald-500/15 px-3 py-1 text-xs font-semibold text-emerald-200">
              <Sparkles className="h-3.5 w-3.5" />
              All-in-One untuk Warung & Toko
            </span>
            <h1 className="mt-4 font-serif text-3xl font-bold leading-tight text-white md:text-5xl">
              Kelola warung lebih mudah & profesional
            </h1>
            <p className="mt-4 max-w-lg text-sm text-emerald-100/90 md:text-base">
              Kasir cepat, stok rapi, kasbon terkelola, dan laporan bisnis otomatis —
              semua dalam satu aplikasi yang ramah pemula.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button
                onClick={onEnterApp}
                className="rounded-xl bg-emerald-500 px-6 py-5 font-semibold text-white hover:bg-emerald-400"
              >
                Coba Gratis
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              <button
                onClick={onViewSegments}
                className="rounded-xl border border-emerald-400/40 px-6 py-5 text-sm font-semibold text-emerald-100 transition hover:bg-emerald-800/40"
              >
                Pilih berdasarkan kebutuhan
              </button>
            </div>
            <p className="mt-4 text-xs text-emerald-300">
              Gratis 7 hari · Tanpa kartu kredit · Bisa dipakai offline
            </p>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {HIGHLIGHTS.map(({ icon: Icon, title, desc }) => (
              <div
                key={title}
                className="rounded-2xl border border-emerald-400/20 bg-emerald-900/40 p-4 backdrop-blur"
              >
                <div className="grid h-10 w-10 place-items-center rounded-xl bg-emerald-500/20 text-emerald-300">
                  <Icon className="h-5 w-5" />
                </div>
                <p className="mt-3 text-sm font-semibold text-white">{title}</p>
                <p className="text-xs text-emerald-200/80">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="fitur" className="mx-auto max-w-6xl px-4 py-14 md:px-8">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div className="max-w-2xl">
            <p className="text-xs font-semibold uppercase tracking-widest text-emerald-700">
              Fitur Lengkap
            </p>
            <h2 className="mt-2 font-serif text-2xl font-bold text-slate-900 md:text-3xl">
              Fitur Lengkap WarungSpace
            </h2>
            <p className="mt-2 text-sm text-slate-600">
              Semua yang dibutuhkan UMKM untuk mengelola toko dengan lebih mudah dan
              profesional.
            </p>
          </div>
          <button
            onClick={onViewAllFeatures}
            className="flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-emerald-700"
          >
            Jelajahi Semua Fitur
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>

        <div className="mt-8 grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
          {FEATURE_GROUPS.map((g) => (
            <Card
              key={g.id}
              className="rounded-2xl border-slate-200 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
            >
              <CardContent className="p-5">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-3">
                    <div className="grid h-10 w-10 place-items-center rounded-xl bg-emerald-50 text-lg">
                      {g.emoji}
                    </div>
                    <h3 className="text-sm font-bold text-slate-900">{g.title}</h3>
                  </div>
                  {g.tag && (
                    <Badge className="shrink-0 rounded-full bg-amber-100 text-amber-700 hover:bg-amber-100">
                      {g.tag}
                    </Badge>
                  )}
                </div>
                <ul className="mt-4 space-y-2">
                  {g.items.map((item) => (
                    <li key={item} className="flex gap-2 text-xs text-slate-600">
                      <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-600" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="bg-white py-14">
        <div className="mx-auto max-w-6xl px-4 md:px-8">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div className="max-w-2xl">
              <p className="text-xs font-semibold uppercase tracking-widest text-emerald-700">
                Pilih berdasarkan kebutuhan
              </p>
              <h2 className="mt-2 font-serif text-2xl font-bold text-slate-900 md:text-3xl">
                Belum yakin masuk kategori mana?
              </h2>
              <p className="mt-2 text-sm text-slate-600">
                Ini panduan singkatnya. Temukan jenis usaha Anda dan lihat bagaimana
                WarungSpace membantu.
              </p>
            </div>
            <button
              onClick={onViewSegments}
              className="flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-emerald-700"
            >
              Lihat Panduan
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>

          <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { emoji: "🍽️", title: "Makanan & Minuman", desc: "Kafe, coffee shop, rumah makan, dan warteg." },
              { emoji: "🛍️", title: "Retail", desc: "Toko retail, fashion, dan minimarket." },
              { emoji: "🧺", title: "Jasa", desc: "Usaha jasa seperti laundry." },
              { emoji: "🏪", title: "Toko Harian", desc: "Warung dan toko kelontong." },
            ].map((c) => (
              <button
                key={c.title}
                onClick={onViewSegments}
                className="rounded-2xl border border-slate-200 bg-slate-50/60 p-5 text-left shadow-sm transition hover:-translate-y-0.5 hover:border-emerald-300 hover:shadow-md"
              >
                <div className="grid h-11 w-11 place-items-center rounded-xl bg-emerald-50 text-xl">
                  {c.emoji}
                </div>
                <h3 className="mt-3 text-sm font-bold text-slate-900">{c.title}</h3>
                <p className="mt-1 text-xs text-slate-600">{c.desc}</p>
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-slate-50 py-14">
        <div className="mx-auto max-w-6xl px-4 md:px-8">
          <div className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm md:p-8">
            <div className="flex items-start gap-4">
              <div className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-emerald-50 text-emerald-700">
                <Info className="h-6 w-6" />
              </div>
              <div>
                <h2 className="font-serif text-xl font-bold text-slate-900">
                  Tentang Proyek
                </h2>
                <p className="mt-1 max-w-xl text-sm text-slate-600">
                  Dokumentasi lengkap: fitur utama, arsitektur sistem, teknologi,
                  instalasi, API, deployment, lisensi, dan cara berkontribusi.
                </p>
              </div>
            </div>
            <button
              onClick={onViewAbout}
              className="flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-emerald-700"
            >
              Baca Selengkapnya
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </section>

      <section id="faq" className="bg-white py-14">
        <div className="mx-auto max-w-3xl px-4 md:px-8">
          <p className="text-xs font-semibold uppercase tracking-widest text-emerald-700">
            FAQ
          </p>
          <h2 className="mt-2 font-serif text-2xl font-bold text-slate-900 md:text-3xl">
            Pertanyaan yang sering diajukan
          </h2>
          <div className="mt-6 space-y-3">
            {FAQS.map((f, i) => {
              const open = openFaq === i;
              return (
                <div
                  key={f.q}
                  className="overflow-hidden rounded-2xl border border-slate-200 bg-slate-50/60"
                >
                  <button
                    onClick={() => setOpenFaq(open ? null : i)}
                    className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left"
                  >
                    <span className="text-sm font-semibold text-slate-800">{f.q}</span>
                    <ChevronDown
                      className={`h-4 w-4 shrink-0 text-emerald-700 transition-transform ${
                        open ? "rotate-180" : ""
                      }`}
                    />
                  </button>
                  {open && (
                    <p className="border-t border-slate-200 px-5 py-4 text-sm text-slate-600">
                      {f.a}
                    </p>
                  )}
                </div>
              );
            })}
          </div>

          <div className="mt-10 rounded-2xl bg-gradient-to-r from-emerald-700 to-teal-700 p-6 text-center shadow-md">
            <h3 className="font-serif text-xl font-bold text-white">
              Siap mulai kelola warung Anda?
            </h3>
            <p className="mt-1 text-sm text-emerald-100">
              Coba gratis 7 hari, tanpa kartu kredit.
            </p>
            <Button
              onClick={onEnterApp}
              className="mt-4 rounded-xl bg-white font-semibold text-emerald-800 hover:bg-emerald-50"
            >
              Coba Gratis Sekarang
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </section>

      <footer className="border-t border-slate-200 bg-slate-900 py-8">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-4 md:flex-row md:px-8">
          <div className="flex items-center gap-2 text-slate-300">
            <Store className="h-4 w-4 text-emerald-400" />
            <span className="font-serif text-sm font-bold text-white">WarungSpace</span>
          </div>
          <p className="text-xs text-slate-400">
            Devolope by{" "}
            <a
              href="https://awdev.my.id"
              target="_blank"
              rel="noreferrer"
              className="font-semibold text-emerald-400 transition hover:text-emerald-300"
            >
              AWD
            </a>
            {" · "}
            <a
              href="https://paypal.me/wahyudi9kdl"
              target="_blank"
              rel="noreferrer"
              className="font-semibold text-emerald-400 transition hover:text-emerald-300"
            >
              Support
            </a>
          </p>
        </div>
      </footer>
    </div>
  );
}