import { Users, Clock, CalendarClock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TABLES } from "@/lib/restaurant-data";

const statusStyle: Record<string, { card: string; badge: string }> = {
  Kosong: {
    card: "border-emerald-200 bg-emerald-50",
    badge: "bg-emerald-100 text-emerald-700 hover:bg-emerald-100",
  },
  Terisi: {
    card: "border-amber-200 bg-amber-50",
    badge: "bg-amber-100 text-amber-700 hover:bg-amber-100",
  },
  Reservasi: {
    card: "border-sky-200 bg-sky-50",
    badge: "bg-sky-100 text-sky-700 hover:bg-sky-100",
  },
  "Perlu Dibersihkan": {
    card: "border-rose-200 bg-rose-50",
    badge: "bg-rose-100 text-rose-700 hover:bg-rose-100",
  },
};

export default function TablesPage() {
  const counts = TABLES.reduce<Record<string, number>>((acc, t) => {
    acc[t.status] = (acc[t.status] ?? 0) + 1;
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        {Object.entries(statusStyle).map(([status, style]) => (
          <Card key={status} className={`rounded-2xl border shadow-sm ${style.card}`}>
            <CardContent className="p-4">
              <p className="text-xs font-medium text-slate-600">{status}</p>
              <p className="mt-1 font-serif text-2xl font-bold text-slate-900">
                {counts[status] ?? 0}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardHeader className="border-b border-slate-100 pb-4">
          <CardTitle className="text-base text-slate-900">Denah Meja</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-2 gap-4 pt-4 sm:grid-cols-3 lg:grid-cols-4">
          {TABLES.map((t) => {
            const style = statusStyle[t.status];
            return (
              <div
                key={t.id}
                className={`rounded-2xl border p-4 shadow-sm transition hover:shadow-md ${style.card}`}
              >
                <div className="flex items-start justify-between">
                  <p className="font-serif text-xl font-bold text-slate-900">{t.label}</p>
                  <Badge className={`rounded-full text-xs ${style.badge}`}>{t.status}</Badge>
                </div>
                <div className="mt-3 flex items-center gap-1.5 text-xs text-slate-600">
                  <Users className="h-3.5 w-3.5" />
                  {t.seats} kursi
                </div>
                {t.guest && (
                  <div className="mt-1.5 flex items-center gap-1.5 text-xs text-slate-600">
                    <CalendarClock className="h-3.5 w-3.5" />
                    {t.guest}
                  </div>
                )}
                {t.time && (
                  <div className="mt-1.5 flex items-center gap-1.5 text-xs text-slate-600">
                    <Clock className="h-3.5 w-3.5" />
                    {t.time}
                  </div>
                )}
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}