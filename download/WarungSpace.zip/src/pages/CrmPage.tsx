import { Users2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LEADS, CRM_STAGES } from "@/lib/erp-data";

const rupiah = (n: number) => "Rp " + n.toLocaleString("id-ID");

const stageAccent: Record<string, string> = {
  Lead: "border-slate-300",
  Qualified: "border-sky-400",
  Proposal: "border-indigo-400",
  Negotiation: "border-amber-400",
  Won: "border-emerald-500",
};

export default function CrmPage() {
  const pipeline = LEADS.reduce((s, l) => s + l.value, 0);

  return (
    <div className="space-y-6">
      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardContent className="flex flex-wrap items-center justify-between gap-3 p-5">
          <div>
            <p className="text-xs font-medium text-slate-500">Nilai Pipeline</p>
            <p className="mt-1 font-serif text-2xl font-bold text-slate-900">{rupiah(pipeline)}</p>
          </div>
          <p className="max-w-md text-xs text-slate-500">
            Lead, opportunity, dan pipeline penjualan dalam satu dasbor.
          </p>
        </CardContent>
      </Card>

      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardHeader className="border-b border-slate-100 pb-4">
          <CardTitle className="flex items-center gap-2 text-base text-slate-900">
            <Users2 className="h-4 w-4 text-emerald-700" />
            Pipeline Penjualan
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-4">
          <div className="grid grid-cols-1 gap-4 md:grid-cols-5">
            {CRM_STAGES.map((stage) => {
              const items = LEADS.filter((l) => l.stage === stage);
              const value = items.reduce((s, l) => s + l.value, 0);
              return (
                <div key={stage} className="space-y-3">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-semibold text-slate-700">{stage}</p>
                    <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs font-medium text-slate-600">
                      {items.length}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">{rupiah(value)}</p>
                  <div className="space-y-2">
                    {items.map((l) => (
                      <div
                        key={l.id}
                        className={`rounded-xl border-l-4 bg-slate-50 p-3 shadow-sm ${stageAccent[stage]}`}
                      >
                        <p className="truncate text-sm font-semibold text-slate-800">{l.company}</p>
                        <p className="text-xs text-slate-500">{l.name}</p>
                        <p className="mt-1 text-xs font-semibold text-emerald-700">
                          {rupiah(l.value)}
                        </p>
                      </div>
                    ))}
                    {items.length === 0 && (
                      <div className="rounded-xl border border-dashed border-slate-200 p-3 text-center text-xs text-slate-400">
                        Kosong
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}