import { BookOpen } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { LEDGER } from "@/lib/erp-data";

const rupiah = (n: number) => "Rp " + n.toLocaleString("id-ID");

const typeTone: Record<string, string> = {
  Aset: "bg-emerald-100 text-emerald-700 hover:bg-emerald-100",
  Kewajiban: "bg-rose-100 text-rose-700 hover:bg-rose-100",
  Ekuitas: "bg-sky-100 text-sky-700 hover:bg-sky-100",
  Pendapatan: "bg-emerald-100 text-emerald-700 hover:bg-emerald-100",
  Beban: "bg-amber-100 text-amber-700 hover:bg-amber-100",
};

export default function AccountingPage() {
  const assets = LEDGER.filter((a) => a.type === "Aset").reduce((s, a) => s + a.balance, 0);
  const liabilities = LEDGER.filter((a) => a.type === "Kewajiban").reduce((s, a) => s + a.balance, 0);
  const revenue = LEDGER.filter((a) => a.type === "Pendapatan").reduce((s, a) => s + a.balance, 0);
  const expense = LEDGER.filter((a) => a.type === "Beban").reduce((s, a) => s + a.balance, 0);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-medium text-slate-500">Total Aset</p>
            <p className="mt-1 font-serif text-xl font-bold text-slate-900">{rupiah(assets)}</p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-medium text-slate-500">Total Kewajiban</p>
            <p className="mt-1 font-serif text-xl font-bold text-rose-700">{rupiah(liabilities)}</p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-medium text-slate-500">Pendapatan</p>
            <p className="mt-1 font-serif text-xl font-bold text-emerald-700">{rupiah(revenue)}</p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-medium text-slate-500">Laba Bersih</p>
            <p className="mt-1 font-serif text-xl font-bold text-slate-900">
              {rupiah(revenue - expense)}
            </p>
          </CardContent>
        </Card>
      </div>

      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardHeader className="border-b border-slate-100 pb-4">
          <CardTitle className="flex items-center gap-2 text-base text-slate-900">
            <BookOpen className="h-4 w-4 text-emerald-700" />
            Bagan Akun
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 pt-4">
          {LEDGER.map((a) => (
            <div
              key={a.code}
              className="flex flex-col gap-3 rounded-xl border border-slate-100 bg-slate-50/60 p-4 sm:flex-row sm:items-center sm:justify-between"
            >
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold text-slate-800">{a.name}</p>
                <p className="text-xs text-slate-500">{a.code}</p>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-sm font-semibold text-slate-800">{rupiah(a.balance)}</span>
                <Badge className={`rounded-full ${typeTone[a.type]}`}>{a.type}</Badge>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}