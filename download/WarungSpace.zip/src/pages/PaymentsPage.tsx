import { CreditCard, CheckCircle2, Circle, Wallet } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PAYMENT_PROVIDERS } from "@/lib/marketplace-data";

const rupiah = (n: number) => "Rp " + n.toLocaleString("id-ID");

export default function PaymentsPage() {
  const totalVolume = PAYMENT_PROVIDERS.reduce((s, p) => s + p.volume, 0);
  const totalSettled = PAYMENT_PROVIDERS.reduce((s, p) => s + p.settled, 0);
  const totalFee = totalVolume - totalSettled;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-medium text-slate-500">Volume Transaksi</p>
            <p className="mt-1 font-serif text-xl font-bold text-slate-900">
              {rupiah(totalVolume)}
            </p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-medium text-slate-500">Dana Tersettle</p>
            <p className="mt-1 font-serif text-xl font-bold text-emerald-700">
              {rupiah(totalSettled)}
            </p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-medium text-slate-500">Total Biaya Gateway</p>
            <p className="mt-1 font-serif text-xl font-bold text-amber-700">{rupiah(totalFee)}</p>
          </CardContent>
        </Card>
      </div>

      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardHeader className="border-b border-slate-100 pb-4">
          <CardTitle className="flex items-center gap-2 text-base text-slate-900">
            <CreditCard className="h-4 w-4 text-emerald-700" />
            Payment Gateway & Rekonsiliasi
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 pt-4">
          {PAYMENT_PROVIDERS.map((p) => (
            <div
              key={p.id}
              className="flex flex-col gap-3 rounded-xl border border-slate-100 bg-slate-50/60 p-4 lg:flex-row lg:items-center lg:justify-between"
            >
              <div className="flex items-center gap-3 lg:w-1/4">
                <div className="grid h-10 w-10 place-items-center rounded-xl bg-emerald-100 text-emerald-700">
                  <Wallet className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-slate-800">{p.name}</p>
                  <p className="text-xs text-slate-500">Fee {p.fee}%</p>
                </div>
              </div>

              <div className="flex flex-wrap gap-1.5 lg:w-1/3">
                {p.methods.map((m) => (
                  <span
                    key={m}
                    className="rounded-lg bg-white px-2 py-1 text-xs font-medium text-slate-600 shadow-sm"
                  >
                    {m}
                  </span>
                ))}
              </div>

              <div className="flex items-center gap-4 lg:w-1/4 lg:justify-end">
                <div className="text-right">
                  <p className="text-xs text-slate-500">Volume</p>
                  <p className="text-sm font-semibold text-slate-800">
                    {p.volume > 0 ? rupiah(p.volume) : "-"}
                  </p>
                </div>
                <Badge
                  className={`rounded-full ${
                    p.connected
                      ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100"
                      : "bg-slate-200 text-slate-600 hover:bg-slate-200"
                  }`}
                >
                  {p.connected ? "Terhubung" : "Hubungkan"}
                </Badge>
                {p.connected ? (
                  <CheckCircle2 className="h-5 w-5 text-emerald-600" />
                ) : (
                  <Circle className="h-5 w-5 text-slate-300" />
                )}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}