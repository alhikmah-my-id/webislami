import { Factory, Boxes } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { WORK_ORDERS } from "@/lib/erp-data";

const statusTone: Record<string, string> = {
  Direncanakan: "bg-slate-100 text-slate-700 hover:bg-slate-100",
  Produksi: "bg-amber-100 text-amber-700 hover:bg-amber-100",
  Selesai: "bg-emerald-100 text-emerald-700 hover:bg-emerald-100",
};

const BOM = [
  { material: "Beras Premium", qty: "5 kg", cost: 34000 },
  { material: "Kemasan Plastik", qty: "1 pcs", cost: 1500 },
  { material: "Label & Segel", qty: "1 set", cost: 800 },
];

export default function ManufacturingPage() {
  return (
    <div className="space-y-6">
      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardContent className="p-5">
          <p className="text-xs text-slate-500">
            Bill of materials, work order, dan perencanaan produksi.
          </p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-5">
        <Card className="rounded-2xl border-slate-200 shadow-sm lg:col-span-3">
          <CardHeader className="border-b border-slate-100 pb-4">
            <CardTitle className="flex items-center gap-2 text-base text-slate-900">
              <Factory className="h-4 w-4 text-emerald-700" />
              Work Order
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 pt-4">
            {WORK_ORDERS.map((w) => (
              <div
                key={w.id}
                className="rounded-xl border border-slate-100 bg-slate-50/60 p-4"
              >
                <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold text-slate-800">{w.product}</p>
                    <p className="text-xs text-slate-500">
                      {w.id} · {w.qty} unit
                    </p>
                  </div>
                  <Badge className={`w-fit rounded-full ${statusTone[w.status]}`}>
                    {w.status}
                  </Badge>
                </div>
                <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-slate-200">
                  <div
                    className="h-full rounded-full bg-emerald-500"
                    style={{ width: `${w.progress}%` }}
                  />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="rounded-2xl border-slate-200 shadow-sm lg:col-span-2">
          <CardHeader className="border-b border-slate-100 pb-4">
            <CardTitle className="flex items-center gap-2 text-base text-slate-900">
              <Boxes className="h-4 w-4 text-emerald-700" />
              Bill of Materials
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 pt-4">
            <p className="text-xs text-slate-500">Paket Sembako Hemat (per unit)</p>
            {BOM.map((b) => (
              <div
                key={b.material}
                className="flex items-center justify-between rounded-xl border border-slate-100 bg-slate-50/60 p-3"
              >
                <div>
                  <p className="text-sm font-semibold text-slate-800">{b.material}</p>
                  <p className="text-xs text-slate-500">{b.qty}</p>
                </div>
                <span className="text-sm font-semibold text-slate-800">
                  Rp {b.cost.toLocaleString("id-ID")}
                </span>
              </div>
            ))}
            <div className="flex items-center justify-between rounded-xl bg-emerald-50 p-3">
              <span className="text-xs font-medium text-emerald-700">Total Biaya Bahan</span>
              <span className="text-sm font-bold text-emerald-700">
                Rp {BOM.reduce((s, b) => s + b.cost, 0).toLocaleString("id-ID")}
              </span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}