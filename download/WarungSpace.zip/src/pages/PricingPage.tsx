import { useState } from "react";
import { Check, Sparkles, Loader2, QrCode, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";

interface Plan {
  id: string;
  name: string;
  price: number;
  description: string;
  features: string[];
  isPopular?: boolean;
}

const plans: Plan[] = [
  {
    id: "starter",
    name: "Paket Starter",
    price: 49000,
    description: "Cocok untuk pedagang kaki lima atau online shop rumahan baru.",
    features: [
      "Modul Katalog WA Instan",
      "Modul Pencatatan Buku Utang",
      "Maksimal 50 Transaksi/Bulan",
      "Dukungan Chat Admin",
    ],
  },
  {
    id: "pro",
    name: "Paket Professional",
    price: 99000,
    description: "Solusi lengkap bagi warung makan, laundry, kedai kopi, dan salon.",
    features: [
      "Semua Fitur Paket Starter",
      "Sistem Kasir (POS) & Inventori",
      "Maksimal 3 Karyawan Toko",
      "Notifikasi Pengingat Utang WA",
      "Transaksi Tanpa Batas",
    ],
    isPopular: true,
  },
  {
    id: "enterprise",
    name: "Paket Enterprise",
    price: 199000,
    description: "Terbaik untuk toko bangunan, grosir besar, dan bisnis multi-cabang.",
    features: [
      "Semua Fitur Paket Professional",
      "Absensi Berbasis GPS & Swafoto",
      "Kalkulasi Gaji + Komisi Otomatis",
      "Karyawan Tanpa Batas",
      "Laporan Keuangan Eksekutif (Excel/PDF)",
    ],
  },
];

const rupiah = (n: number) => "Rp " + n.toLocaleString("id-ID");

type Stage = "idle" | "creating" | "paying" | "success";

export default function PricingPage() {
  const [selected, setSelected] = useState<Plan | null>(null);
  const [stage, setStage] = useState<Stage>("idle");
  const [paidPlan, setPaidPlan] = useState<string | null>(null);

  const openCheckout = (plan: Plan) => {
    setSelected(plan);
    setStage("creating");
    // Simulasi pembuatan tagihan di payment gateway
    setTimeout(() => setStage("paying"), 1100);
  };

  const confirmPayment = () => {
    setStage("success");
    setTimeout(() => {
      setPaidPlan(selected?.name ?? null);
      setSelected(null);
      setStage("idle");
    }, 1400);
  };

  const closeDialog = () => {
    if (stage === "creating" || stage === "success") return;
    setSelected(null);
    setStage("idle");
  };

  return (
    <div className="space-y-6">
      <header className="rounded-2xl bg-gradient-to-br from-emerald-700 to-emerald-900 p-6 text-emerald-50 shadow-md md:p-8">
        <div className="flex items-center gap-2 text-emerald-300">
          <Sparkles className="h-4 w-4" />
          <span className="text-xs font-semibold uppercase tracking-widest">Langganan</span>
        </div>
        <h1 className="mt-2 font-serif text-2xl font-bold md:text-3xl">
          Kembangkan Bisnis UMKM Anda
        </h1>
        <p className="mt-1 max-w-2xl text-sm text-emerald-200">
          Satu harga langganan murah untuk kelola kasir, stok, absensi, hingga tagihan otomatis.
        </p>
      </header>

      {paidPlan && (
        <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-medium text-emerald-800">
          ✅ Pembayaran {paidPlan} berhasil. Langganan Anda kini aktif selama 30 hari.
        </div>
      )}

      <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
        {plans.map((plan) => (
          <div
            key={plan.id}
            className={cn(
              "relative flex flex-col justify-between rounded-2xl border bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-md",
              plan.isPopular ? "border-emerald-500 ring-2 ring-emerald-200" : "border-slate-200"
            )}
          >
            {plan.isPopular && (
              <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-emerald-600 px-4 py-1 text-xs font-semibold uppercase tracking-wide text-white hover:bg-emerald-600">
                Paling Diminati
              </Badge>
            )}

            <div>
              <h3 className="text-xl font-bold text-slate-900">{plan.name}</h3>
              <p className="mt-2 min-h-10 text-sm text-slate-500">{plan.description}</p>
              <div className="mt-4 flex items-baseline">
                <span className="text-3xl font-extrabold text-slate-900">{rupiah(plan.price)}</span>
                <span className="ml-2 text-sm text-slate-500">/bulan</span>
              </div>

              <ul className="mt-6 space-y-3">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-start text-sm text-slate-600">
                    <Check className="mr-2 h-5 w-5 shrink-0 text-emerald-500" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>

            <Button
              onClick={() => openCheckout(plan)}
              className={cn(
                "mt-8 w-full rounded-xl py-6 text-base font-semibold",
                plan.isPopular
                  ? "bg-emerald-600 hover:bg-emerald-700"
                  : "bg-slate-800 hover:bg-slate-900"
              )}
            >
              Pilih {plan.name}
            </Button>
          </div>
        ))}
      </div>

      <p className="text-center text-xs text-slate-400">
        * Mendukung pembayaran otomatis aman via QRIS, DANA, OVO, ShopeePay, dan Transfer Bank Lokal.
      </p>

      <Dialog open={selected !== null} onOpenChange={(o) => !o && closeDialog()}>
        <DialogContent className="rounded-2xl sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-serif text-lg">
              {stage === "success" ? "Pembayaran Berhasil" : "Pembayaran Langganan"}
            </DialogTitle>
            <DialogDescription>
              {selected?.name} · {selected ? rupiah(selected.price) : ""} / bulan
            </DialogDescription>
          </DialogHeader>

          <div className="py-2">
            {stage === "creating" && (
              <div className="flex flex-col items-center gap-3 py-8 text-center">
                <Loader2 className="h-8 w-8 animate-spin text-emerald-600" />
                <p className="text-sm font-medium text-slate-600">
                  Membuat tagihan di payment gateway...
                </p>
              </div>
            )}

            {stage === "paying" && (
              <div className="flex flex-col items-center gap-4 py-4 text-center">
                <div className="grid h-40 w-40 place-items-center rounded-2xl border-2 border-dashed border-emerald-300 bg-emerald-50">
                  <QrCode className="h-24 w-24 text-emerald-700" />
                </div>
                <p className="text-sm font-medium text-slate-700">
                  Pindai QRIS atau bayar via DANA / OVO
                </p>
                <p className="text-xs text-slate-500">
                  Total tagihan: <span className="font-bold text-slate-800">{selected ? rupiah(selected.price) : ""}</span>
                </p>
                <div className="flex items-center gap-1 text-xs text-emerald-700">
                  <ShieldCheck className="h-4 w-4" /> Transaksi terenkripsi & aman
                </div>
              </div>
            )}

            {stage === "success" && (
              <div className="flex flex-col items-center gap-3 py-8 text-center">
                <div className="grid h-14 w-14 place-items-center rounded-full bg-emerald-100">
                  <Check className="h-8 w-8 text-emerald-600" />
                </div>
                <p className="text-sm font-medium text-slate-700">
                  Langganan Anda sedang diaktifkan...
                </p>
              </div>
            )}
          </div>

          <DialogFooter>
            {stage === "paying" && (
              <Button
                className="w-full rounded-xl bg-emerald-600 hover:bg-emerald-700"
                onClick={confirmPayment}
              >
                Saya Sudah Bayar
              </Button>
            )}
            {stage === "creating" && (
              <Button disabled className="w-full rounded-xl">
                <Loader2 className="h-4 w-4 animate-spin" /> Memproses...
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}