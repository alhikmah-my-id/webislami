import { useMemo, useState } from "react";
import {
  Megaphone,
  Copy,
  Check,
  FileText,
  ShieldCheck,
  Globe,
  DollarSign,
  AlertTriangle,
  Code2,
  ListChecks,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import AdSlot from "@/components/AdSlot";

const PUBLISHERS = [
  { id: "ca-pub-6718454554209533", label: "Publisher Utama", primary: true },
  { id: "ca-pub-5407249785989200", label: "Publisher Sekunder", primary: false },
];

const AD_UNITS = [
  {
    slot: "7205994686",
    name: "Display Ads — Bawah Artikel",
    format: "auto" as const,
    placement: "Setelah konten utama",
  },
  {
    slot: "1234567890",
    name: "In-Article — Tengah Konten",
    format: "rectangle" as const,
    placement: "Antar paragraf",
  },
  {
    slot: "0987654321",
    name: "Leaderboard — Header",
    format: "horizontal" as const,
    placement: "Atas halaman",
  },
];

const ADS_TXT_LINES = [
  "google.com, pub-6718454554209533, DIRECT, f08c47fec0942fa0",
  "google.com, pub-5407249785989200, DIRECT, f08c47fec0942fa0",
  "tappx.com, 36063, DIRECT, 9f375a07da0318ec",
  "inventorypartnerdomain=tappx.com",
  "pubmatic.com, 158111, RESELLER, 5d62403b186f2ace",
  "smartadserver.com, 1692, RESELLER, 060d053dcf45cbf3",
  "rubiconproject.com, 13856, RESELLER, 0bfd66d529a55807",
  "sharethrough.com, 1692, RESELLER, d53b998a7bd4ecd2",
  "mediaverse.ai, 3021109348, RESELLER",
  "pubmatic.com, 167377, RESELLER, 5d62403b186f2ace",
  "loopme.com, 11227, RESELLER, 6c8d5f95897a5a3b",
  "pubnative.net, 1018206, RESELLER, d641df8625486a7b",
  "videoheroes.tv, 212473, RESELLER, 064bc410192443d8",
  "video.unrulymedia.com, 3341072718, RESELLER",
  "lijit.com, 396126, RESELLER, fafdf38b16bf6b2b",
  "onlinemediasolutions.com, 20937, RESELLER",
  "thebrave.io, 1234661, RESELLER, c25b2154543746ac",
  "triplelift.com, 11617, RESELLER, 6c33edb13117fd86",
  "chartboost.com, 5da62a1035b91e0aff190bf7, RESELLER",
  "33across.com, 0010b00001siQHqAAM, RESELLER, bbea06d9c4d2853c",
  "improvedigital.com, 1934, RESELLER",
  "smaato.com, 1100058016, RESELLER, 07bcf65f187117b4",
  "smaato.com, 1100004890, RESELLER, 07bcf65f187117b4",
  "playdigo.com, 1970, RESELLER, 92011346d63d3c30",
  "visiblemeasures.com, 1004, RESELLER",
  "admanmedia.com, 2002, RESELLER",
  "sharethrough.com, iHIgeRWP, RESELLER, d53b998a7bd4ecd2",
  "33across.com, 0013300001kQj2HAAS, RESELLER, bbea06d9c4d2853c",
  "disqus.com, 4728052, DIRECT",
  "zetaglobal.net, 100, DIRECT",
  "aps.amazon.com, 31d3a4c9-a8a6-4ae0-a5ae-d3b0de43284c, RESELLER",
  "google.com, pub-6650322601660058, RESELLER, f08c47fec0942fa0",
  "minutemedia.com, 01gcrv9grwe9, RESELLER",
  "rubiconproject.com, 17598, RESELLER, 0bfd66d529a55807",
  "media.net, 8CUWNDO6S, RESELLER",
  "yieldmo.com, 2954622693783052507, RESELLER",
  "themediagrid.com, T49HZW, RESELLER, 9fac4a4a87c2a44f",
  "sharethrough.com, 00PriK0o, RESELLER, d53b998a7bd4ecd2",
  "sharethrough.com, UvcAx8IL, RESELLER, d53b998a7bd4ecd2",
  "amxrtb.com, 105199574, RESELLER",
  "pubmatic.com, 158355, RESELLER",
  "rubiconproject.com, 23844, RESELLER",
  "pubmatic.com, 158685, RESELLER, 5d62403b186f2ace",
  "pubmatic.com, 162418, RESELLER, 5d62403b186f2ace",
  "pubmatic.com, 167175, RESELLER, 5d62403b186f2ace",
  "appnexus.com, 2797, RESELLER",
  "smartadserver.com, 4899, RESELLER, 060d053dcf45cbf3",
  "sharethrough.com, 4899, RESELLER, d53b998a7bd4ecd2",
  "rubiconproject.com, 13380, RESELLER, 0bfd66d529a55807",
  "mediafuse.com, 604, RESELLER",
  "appnexus.com, 9538, RESELLER",
  "inmobi.com, 7cd970b6ef494a05b3a4d538650c5e47, RESELLER, 83e75a7ae333ca9d",
  "onetag.com, 5cd7fb62fac7ec9, RESELLER",
  "openx.com, 537133236, RESELLER, 6a698e2ec38604c6",
  "openx.com, 564020929, RESELLER, 6a698e2ec38604c6",
  "openx.com, 540717801, RESELLER, 6a698e2ec38604c6",
  "video.unrulymedia.com, 919139201, RESELLER",
  "lijit.com, 279534, RESELLER, fafdf38b16bf6b2b",
  "openx.com, 538959099, RESELLER, 6a698e2ec38604c6",
  "pubmatic.com, 137711, RESELLER, 5d62403b186f2ace",
  "loopme.com, 14872, RESELLER, 6c8d5f95897a5a3b",
  "admanmedia.com, 1069, RESELLER",
  "ogury.com, ad6deacb-e82d-4900-9c01-012cf70c70c1, RESELLER",
  "indexexchange.com, 216162, RESELLER, 50b1c356f2c5c8fc",
  "media.net, 8CAH6D2Q2, DIRECT",
  "media.net, 8CAVPDT3Y, DIRECT",
  "media.net, 8CA1N5JCF, DIRECT",
  "seedtag.com, 6a4bcbea649b090007e84f3a, DIRECT",
  "xandr.com, 4009, RESELLER, f5ab79cb980f11d1",
  "rubiconproject.com, 17280, RESELLER, 0bfd66d529a55807",
  "lijit.com, 612248, DIRECT, fafdf38b16bf6b2b",
];

const APP_ADS_TXT = [
  "# app-ads.txt — wajib di root domain developer",
  "google.com, pub-6718454554209533, DIRECT, f08c47fec0942fa0",
  "google.com, pub-5407249785989200, DIRECT, f08c47fec0942fa0",
  "tappx.com, 36063, DIRECT, 9f375a07da0318ec",
  "inventorypartnerdomain=tappx.com",
];

const META_TAGS = [
  { name: "google-site-verification", content: "e1adJE3Uadivc1NAhHfSiG1YcUSbTFCJ0gQ9T4nDj_U" },
  { name: "google-site-verification", content: "QT96Rd0InOuqkb4s1Wu5BlgGD_pCNOy8CsCtveF1zEA" },
  { name: "msvalidate.01", content: "A6BC1DD96D711E50BC95B39A1FA4C33E" },
  { name: "google-adsense-account", content: "ca-pub-6718454554209533" },
];

const GTM_SNIPPET = `(function(w,i,g){w[g]=w[g]||[];if(typeof w[g].push=='function')w[g].push(i)})
(window,'GTM-5SKT7TJ','google_tags_first_party');`;

function CopyButton({ text, label = "Copy" }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <Button
      variant="outline"
      size="sm"
      onClick={() => {
        navigator.clipboard?.writeText(text);
        setCopied(true);
        setTimeout(() => setCopied(false), 1800);
      }}
      className="rounded-lg border-slate-200 text-xs font-semibold"
    >
      {copied ? (
        <>
          <Check className="mr-1 h-3 w-3 text-emerald-600" />
          Tersalin
        </>
      ) : (
        <>
          <Copy className="mr-1 h-3 w-3" />
          {label}
        </>
      )}
    </Button>
  );
}

export default function AdsPage() {
  const [tab, setTab] = useState<"ads" | "app-ads" | "meta" | "gtm">("ads");

  const adsTxt = useMemo(() => ADS_TXT_LINES.join("\n"), []);
  const appAdsTxt = useMemo(() => APP_ADS_TXT.join("\n"), []);

  const stats = [
    { label: "Publisher ID", value: "2", icon: DollarSign, tone: "bg-emerald-100 text-emerald-700" },
    { label: "Ad Units", value: String(AD_UNITS.length), icon: Megaphone, tone: "bg-amber-100 text-amber-700" },
    { label: "ads.txt Records", value: String(ADS_TXT_LINES.length), icon: FileText, tone: "bg-sky-100 text-sky-700" },
    { label: "Meta Tags", value: String(META_TAGS.length), icon: ShieldCheck, tone: "bg-violet-100 text-violet-700" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-xl bg-amber-500 text-white">
            <Megaphone className="h-5 w-5" />
          </div>
          <div>
            <h2 className="font-serif text-xl font-bold text-slate-900">
              Monetisasi & AdSense
            </h2>
            <p className="text-xs text-slate-500">
              Publisher, ad units, ads.txt, app-ads.txt & meta verifikasi.
            </p>
          </div>
        </div>
        <Badge className="rounded-full bg-amber-100 text-amber-700 hover:bg-amber-100">
          <Globe className="mr-1 h-3 w-3" />
          alhikmah.my.id
        </Badge>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <Card key={s.label} className="rounded-2xl border-slate-200 shadow-sm">
              <CardContent className="p-4">
                <div className={`mb-2 grid h-9 w-9 place-items-center rounded-lg ${s.tone}`}>
                  <Icon className="h-4 w-4" />
                </div>
                <p className="font-serif text-2xl font-bold text-slate-900">{s.value}</p>
                <p className="text-xs text-slate-500">{s.label}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Card className="rounded-2xl border-slate-200 shadow-sm">
            <CardContent className="p-5">
              <div className="mb-4 flex items-center gap-2">
                <ListChecks className="h-4 w-4 text-slate-500" />
                <h3 className="text-sm font-bold text-slate-900">Ad Units Terdaftar</h3>
              </div>
              <div className="space-y-4">
                {AD_UNITS.map((u) => (
                  <div key={u.slot} className="rounded-xl border border-slate-100 p-4">
                    <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <p className="text-sm font-semibold text-slate-800">{u.name}</p>
                        <p className="text-xs text-slate-400">{u.placement}</p>
                      </div>
                      <Badge className="rounded-full bg-slate-100 font-mono text-xs text-slate-600 hover:bg-slate-100">
                        {u.slot}
                      </Badge>
                    </div>
                    <AdSlot slot={u.slot} format={u.format} label={u.name} />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-2xl border-slate-200 shadow-sm">
            <CardContent className="p-5">
              <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <FileText className="h-4 w-4 text-slate-500" />
                  <h3 className="text-sm font-bold text-slate-900">File Konfigurasi</h3>
                </div>
                <div className="flex gap-1 rounded-lg bg-slate-100 p-0.5">
                  {(
                    [
                      ["ads", "ads.txt"],
                      ["app-ads", "app-ads.txt"],
                      ["meta", "Meta Tags"],
                      ["gtm", "GTM"],
                    ] as const
                  ).map(([key, label]) => (
                    <button
                      key={key}
                      onClick={() => setTab(key)}
                      className={`rounded-md px-2.5 py-1 text-xs font-semibold transition ${
                        tab === key ? "bg-white text-amber-700 shadow-sm" : "text-slate-500"
                      }`}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>

              {tab === "ads" && (
                <>
                  <div className="mb-3 flex items-center justify-between">
                    <p className="text-xs text-slate-500">
                      Letakkan di <span className="font-mono">/ads.txt</span> root domain.
                    </p>
                    <CopyButton text={adsTxt} label="Copy ads.txt" />
                  </div>
                  <pre className="max-h-96 overflow-auto rounded-xl bg-slate-900 p-4 font-mono text-xs leading-relaxed text-emerald-300">
                    {adsTxt}
                  </pre>
                </>
              )}

              {tab === "app-ads" && (
                <>
                  <div className="mb-3 flex items-center justify-between">
                    <p className="text-xs text-slate-500">
                      Letakkan di <span className="font-mono">/app-ads.txt</span> root domain developer.
                    </p>
                    <CopyButton text={appAdsTxt} label="Copy app-ads.txt" />
                  </div>
                  <pre className="overflow-auto rounded-xl bg-slate-900 p-4 font-mono text-xs leading-relaxed text-sky-300">
                    {appAdsTxt}
                  </pre>
                  <div className="mt-3 flex items-start gap-2 rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs text-amber-700">
                    <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                    app-ads.txt hanya berlaku untuk aplikasi mobile. Pastikan URL developer
                    di Play Store / App Store menunjuk ke domain yang sama.
                  </div>
                </>
              )}

              {tab === "meta" && (
                <div className="space-y-2">
                  {META_TAGS.map((m, i) => (
                    <div
                      key={i}
                      className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-100 p-3"
                    >
                      <div className="min-w-0">
                        <p className="font-mono text-xs font-semibold text-slate-700">
                          {m.name}
                        </p>
                        <p className="truncate font-mono text-xs text-slate-400">
                          {m.content}
                        </p>
                      </div>
                      <CopyButton
                        text={`<meta name="${m.name}" content="${m.content}" />`}
                        label="Copy"
                      />
                    </div>
                  ))}
                </div>
              )}

              {tab === "gtm" && (
                <>
                  <div className="mb-3 flex items-center justify-between">
                    <p className="text-xs text-slate-500">
                      Google Tag Manager — container <span className="font-mono">GTM-5SKT7TJ</span>
                    </p>
                    <CopyButton text={GTM_SNIPPET} label="Copy snippet" />
                  </div>
                  <pre className="overflow-auto rounded-xl bg-slate-900 p-4 font-mono text-xs leading-relaxed text-violet-300">
                    {GTM_SNIPPET}
                  </pre>
                </>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="rounded-2xl border-slate-200 shadow-sm">
            <CardContent className="p-5">
              <div className="mb-4 flex items-center gap-2">
                <DollarSign className="h-4 w-4 text-slate-500" />
                <h3 className="text-sm font-bold text-slate-900">Publisher Accounts</h3>
              </div>
              <div className="space-y-2">
                {PUBLISHERS.map((p) => (
                  <div
                    key={p.id}
                    className={`flex items-center justify-between rounded-xl border p-3 ${
                      p.primary ? "border-emerald-200 bg-emerald-50/50" : "border-slate-100"
                    }`}
                  >
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-slate-800">{p.label}</p>
                      <p className="truncate font-mono text-xs text-slate-500">{p.id}</p>
                    </div>
                    {p.primary && (
                      <Badge className="rounded-full bg-emerald-100 text-emerald-700 hover:bg-emerald-100">
                        Aktif
                      </Badge>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-2xl border-slate-200 shadow-sm">
            <CardContent className="p-5">
              <div className="mb-3 flex items-center gap-2">
                <Code2 className="h-4 w-4 text-slate-500" />
                <h3 className="text-sm font-bold text-slate-900">Checklist Integrasi</h3>
              </div>
              <ul className="space-y-2 text-xs text-slate-600">
                {[
                  "Script AdSense dimuat di <head> dengan client pub-6718454554209533",
                  "ads.txt tersedia di root domain (200 OK, text/plain)",
                  "Meta verifikasi Google & Bing terpasang",
                  "GTM container GTM-5SKT7TJ aktif",
                  "Ad unit responsif dengan data-full-width-responsive",
                ].map((c, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-600" />
                    {c}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          <AdSlot slot="0987654321" format="rectangle" label="Sidebar Ads" />
        </div>
      </div>
    </div>
  );
}