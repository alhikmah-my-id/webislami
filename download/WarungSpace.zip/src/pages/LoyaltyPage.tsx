import { Crown, Gift, Users2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CUSTOMERS } from "@/lib/marketplace-data";

const rupiah = (n: number) => "Rp " + n.toLocaleString("id-ID");

const tierTone: Record<string, string> = {
  Platinum: "bg-indigo-100 text-indigo-700 hover:bg-indigo-100",
  Gold: "bg-amber-100 text-amber-700 hover:bg-amber-100",
  Silver: "bg-slate-200 text-slate-700 hover:bg-slate-200",
  Bronze: "bg-orange-100 text-orange-700 hover:bg-orange-100",
};

const REWARDS = [
  { name: "Voucher Rp 25.000", points: 1000, claimed: 42 },
  { name: "Gratis Ongkir", points: 500, claimed: 128 },
  { name: "Produk Sample", points: 750, claimed: 67 },
];

export default function LoyaltyPage() {
  const totalSpent = CUSTOMERS.reduce((s, c) => s + c.spent, 0);
  const totalPoints = CUSTOMERS.reduce((s, c) => s + c.points, 0);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-medium text-slate-500">Total Pelanggan</p>
            <p className="mt-1 font-serif text-xl font-bold text-slate-900">
              {CUSTOMERS.length}
            </p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-medium text-slate-500">Poin Beredar</p>
            <p className="mt-1 font-serif text-xl font-bold text-slate-900">
              {totalPoints.toLocaleString("id-ID")}
            </p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-medium text-slate-500">Total Belanja</p>
            <p className="mt-1 font-serif text-xl font-bold text-emerald-700">
              {rupiah(totalSpent)}
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-5">
        <Card className="rounded-2xl border-slate-200 shadow-sm lg:col-span-3">
          <CardHeader className="border-b border-slate-100 pb-4">
            <CardTitle className="flex items-center gap-2 text-base text-slate-900">
              <Users2 className="h-4 w-4 text-emerald-700" />
              Database Pelanggan
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 pt-4">
            {CUSTOMERS.map((c) => (
              <div
                key={c.id}
                className="flex flex-col gap-2 rounded-xl border border-slate-100 bg-slate-50/60 p-3 sm:flex-row sm:items-center sm:justify-between"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="truncate text-sm font-semibold text-slate-800">{c.name}</p>
                    <Badge className={`rounded-full text-xs ${tierTone[c.tier]}`}>
                      {c.tier}
                    </Badge>
                  </div>
                  <p className="mt-0.5 text-xs text-slate-500">
                    {c.orders} pesanan · terakhir {c.lastOrder}
                  </p>
                </div>
                <div className="flex items-center gap-4 text-right">
                  <div>
                    <p className="text-xs text-slate-500">Poin</p>
                    <p className="text-sm font-semibold text-slate-800">
                      {c.points.toLocaleString("id-ID")}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">Belanja</p>
                    <p className="text-sm font-semibold text-slate-800">{rupiah(c.spent)}</p>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="rounded-2xl border-slate-200 shadow-sm lg:col-span-2">
          <CardHeader className="border-b border-slate-100 pb-4">
            <CardTitle className="flex items-center gap-2 text-base text-slate-900">
              <Gift className="h-4 w-4 text-emerald-700" />
              Program Reward
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 pt-4">
            {REWARDS.map((r) => (
              <div
                key={r.name}
                className="rounded-xl border border-slate-100 bg-slate-50/60 p-3"
              >
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold text-slate-800">{r.name}</p>
                  <span className="flex items-center gap-1 text-xs font-semibold text-amber-700">
                    <Crown className="h-3.5 w-3.5" />
                    {r.points} poin
                  </span>
                </div>
                <p className="mt-1 text-xs text-slate-500">{r.claimed}x ditukar</p>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}