import { BarChart3, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CHANNELS, TOP_PRODUCTS } from "@/lib/marketplace-data";

const rupiah = (n: number) => "Rp " + n.toLocaleString("id-ID");
const short = (n: number) => "Rp " + (n / 1000000).toFixed(1) + " jt";

export default function AnalyticsPage() {
  const totalRevenue = CHANNELS.reduce((s, c) => s + c.revenue, 0);
  const maxRevenue = Math.max(...CHANNELS.map((c) => c.revenue), 1);
  const maxSold = Math.max(...TOP_PRODUCTS.map((p) => p.sold), 1);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-medium text-slate-500">Total Omzet</p>
            <p className="mt-1 font-serif text-xl font-bold text-slate-900">
              {rupiah(totalRevenue)}
            </p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-medium text-slate-500">Rata-rata Margin</p>
            <p className="mt-1 font-serif text-xl font-bold text-emerald-700">
              {Math.round(TOP_PRODUCTS.reduce((s, p) => s + p.margin, 0) / TOP_PRODUCTS.length)}%
            </p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-medium text-slate-500">Produk Terjual</p>
            <p className="mt-1 font-serif text-xl font-bold text-slate-900">
              {TOP_PRODUCTS.reduce((s, p) => s + p.sold, 0).toLocaleString("id-ID")} unit
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardHeader className="border-b border-slate-100 pb-4">
            <CardTitle className="flex items-center gap-2 text-base text-slate-900">
              <BarChart3 className="h-4 w-4 text-emerald-700" />
              Performa per Channel
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 pt-4">
            {CHANNELS.filter((c) => c.connected).map((c) => (
              <div key={c.id}>
                <div className="mb-1 flex items-center justify-between text-xs">
                  <span className="font-medium text-slate-700">{c.name}</span>
                  <span className="font-semibold text-slate-800">{short(c.revenue)}</span>
                </div>
                <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-100">
                  <div
                    className="h-full rounded-full bg-emerald-500"
                    style={{ width: `${(c.revenue / maxRevenue) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardHeader className="border-b border-slate-100 pb-4">
            <CardTitle className="flex items-center gap-2 text-base text-slate-900">
              <TrendingUp className="h-4 w-4 text-emerald-700" />
              Produk Terlaris
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 pt-4">
            {TOP_PRODUCTS.map((p) => (
              <div
                key={p.name}
                className="rounded-xl border border-slate-100 bg-slate-50/60 p-3"
              >
                <div className="flex items-center justify-between gap-2">
                  <p className="truncate text-sm font-semibold text-slate-800">{p.name}</p>
                  <Badge className="shrink-0 rounded-full bg-emerald-100 text-emerald-700 hover:bg-emerald-100">
                    Margin {p.margin}%
                  </Badge>
                </div>
                <div className="mt-1 flex items-center justify-between text-xs text-slate-500">
                  <span>{p.channel}</span>
                  <span>
                    {p.sold} unit · {rupiah(p.revenue)}
                  </span>
                </div>
                <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-slate-200">
                  <div
                    className="h-full rounded-full bg-emerald-500"
                    style={{ width: `${(p.sold / maxSold) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}