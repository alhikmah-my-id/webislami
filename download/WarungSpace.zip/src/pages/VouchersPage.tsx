import { Ticket, Plus } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { VOUCHERS } from "@/lib/restaurant-data";

export default function VouchersPage() {
  const active = VOUCHERS.filter((v) => v.active).length;
  const totalUsage = VOUCHERS.reduce((s, v) => s + v.usage, 0);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-medium text-slate-500">Voucher Aktif</p>
            <p className="mt-1 font-serif text-xl font-bold text-slate-900">{active}</p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-medium text-slate-500">Total Pemakaian</p>
            <p className="mt-1 font-serif text-xl font-bold text-slate-900">{totalUsage}x</p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="flex h-full items-center justify-between p-5">
            <div>
              <p className="text-xs font-medium text-slate-500">Buat Promo Baru</p>
              <p className="mt-1 text-xs text-slate-500">Tingkatkan kunjungan pelanggan</p>
            </div>
            <Button className="rounded-xl bg-emerald-600 hover:bg-emerald-700">
              <Plus className="mr-1 h-4 w-4" />
              Voucher
            </Button>
          </CardContent>
        </Card>
      </div>

      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardHeader className="border-b border-slate-100 pb-4">
          <CardTitle className="flex items-center gap-2 text-base text-slate-900">
            <Ticket className="h-4 w-4 text-emerald-700" />
            Daftar Voucher & Promosi
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 pt-4">
          {VOUCHERS.map((v) => {
            const pct = Math.round((v.usage / v.quota) * 100);
            return (
              <div
                key={v.id}
                className="flex flex-col gap-3 rounded-xl border border-slate-100 bg-slate-50/60 p-4 lg:flex-row lg:items-center lg:justify-between"
              >
                <div className="min-w-0 lg:w-1/3">
                  <div className="flex items-center gap-2">
                    <p className="truncate text-sm font-semibold text-slate-800">{v.name}</p>
                    <Badge
                      className={`rounded-full text-xs ${
                        v.active
                          ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100"
                          : "bg-slate-200 text-slate-600 hover:bg-slate-200"
                      }`}
                    >
                      {v.active ? "Aktif" : "Berakhir"}
                    </Badge>
                  </div>
                  <p className="mt-1 text-xs text-slate-500">
                    <span className="font-mono font-semibold text-emerald-700">{v.code}</span> ·{" "}
                    {v.type} · {v.value}
                  </p>
                </div>

                <div className="text-xs text-slate-500 lg:w-1/4">{v.period}</div>

                <div className="lg:w-1/3">
                  <div className="mb-1 flex justify-between text-xs text-slate-500">
                    <span>Pemakaian</span>
                    <span className="font-semibold text-slate-700">
                      {v.usage}/{v.quota}
                    </span>
                  </div>
                  <div className="h-2 w-full overflow-hidden rounded-full bg-slate-200">
                    <div
                      className={`h-full rounded-full ${
                        pct >= 100 ? "bg-rose-500" : "bg-emerald-500"
                      }`}
                      style={{ width: `${Math.min(100, pct)}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}