import {
  Zap,
  BarChart3,
  Globe,
  Truck,
  Crown,
  Layers,
  ArrowRight,
  CheckCircle2,
  Clock,
  Circle,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { BENEFITS, FLOW_STEPS, KPIS } from "@/lib/ecommerce-data";

const ICONS: Record<string, typeof Zap> = {
  zap: Zap,
  chart: BarChart3,
  globe: Globe,
  truck: Truck,
  crown: Crown,
  layers: Layers,
};

const statusTone: Record<string, string> = {
  Selesai: "bg-emerald-100 text-emerald-700 hover:bg-emerald-100",
  Berjalan: "bg-amber-100 text-amber-700 hover:bg-amber-100",
  Menunggu: "bg-slate-200 text-slate-600 hover:bg-slate-200",
};

const statusIcon: Record<string, typeof CheckCircle2> = {
  Selesai: CheckCircle2,
  Berjalan: Clock,
  Menunggu: Circle,
};

export default function EcommerceOverviewPage() {
  return (
    <div className="space-y-6">
      <div className="overflow-hidden rounded-2xl bg-gradient-to-br from-emerald-700 via-emerald-800 to-teal-900 p-6 shadow-md md:p-8">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
          <div className="max-w-xl">
            <span className="inline-block rounded-full bg-emerald-500/20 px-3 py-1 text-xs font-semibold text-emerald-200">
              ERP untuk E-Commerce
            </span>
            <h2 className="mt-3 font-serif text-2xl font-bold leading-tight text-white md:text-3xl">
              Tingkatkan efisiensi operasional dan pertumbuhan bisnis e-commerce Anda
            </h2>
            <p className="mt-3 text-sm text-emerald-100">
              Satu sistem untuk mengelola pesanan, stok, fulfillment, pelanggan, dan keuangan
              dari semua channel penjualan Anda.
            </p>
            <div className="mt-5 flex flex-wrap gap-3">
              <Button className="rounded-xl bg-white font-semibold text-emerald-800 hover:bg-emerald-50">
                Mulai Integrasi
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                className="rounded-xl border-emerald-400/40 bg-transparent font-semibold text-emerald-100 hover:bg-emerald-700/40 hover:text-white"
              >
                Lihat Demo
              </Button>
            </div>
          </div>

          <div className="grid w-full grid-cols-2 gap-3 lg:w-96">
            {KPIS.map((k) => (
              <div
                key={k.label}
                className="rounded-xl border border-emerald-500/20 bg-emerald-900/40 p-3 backdrop-blur"
              >
                <p className="text-xs text-emerald-200">{k.label}</p>
                <p className="mt-1 font-serif text-lg font-bold text-white">{k.value}</p>
                <p className="text-xs font-semibold text-emerald-300">{k.delta}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
        {BENEFITS.map((b) => {
          const Icon = ICONS[b.icon] ?? Zap;
          return (
            <Card
              key={b.id}
              className="rounded-2xl border-slate-200 shadow-sm transition hover:shadow-md"
            >
              <CardContent className="p-5">
                <div className="flex items-start justify-between">
                  <div className={`grid h-11 w-11 place-items-center rounded-xl ${b.accent}`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <div className="text-right">
                    <p className="font-serif text-xl font-bold text-slate-900">{b.metric}</p>
                    <p className="text-xs text-slate-500">{b.metricLabel}</p>
                  </div>
                </div>
                <p className="mt-4 text-sm font-semibold text-slate-800">{b.title}</p>
                <p className="mt-1 text-xs leading-relaxed text-slate-500">{b.description}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardHeader className="border-b border-slate-100 pb-4">
          <CardTitle className="text-base text-slate-900">
            Alur Fulfillment Otomatis
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-4">
          <div className="space-y-3">
            {FLOW_STEPS.map((s, i) => {
              const Icon = statusIcon[s.status];
              return (
                <div key={s.id} className="flex items-center gap-4">
                  <div className="flex flex-col items-center">
                    <div
                      className={`grid h-9 w-9 place-items-center rounded-full ${
                        s.status === "Selesai"
                          ? "bg-emerald-100 text-emerald-700"
                          : s.status === "Berjalan"
                          ? "bg-amber-100 text-amber-700"
                          : "bg-slate-100 text-slate-400"
                      }`}
                    >
                      <Icon className="h-4 w-4" />
                    </div>
                    {i < FLOW_STEPS.length - 1 && (
                      <div className="my-1 h-6 w-px bg-slate-200" />
                    )}
                  </div>
                  <div className="flex flex-1 flex-col gap-1 rounded-xl border border-slate-100 bg-slate-50/60 p-3 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <p className="text-sm font-semibold text-slate-800">{s.label}</p>
                      <p className="text-xs text-slate-500">{s.detail}</p>
                    </div>
                    <Badge className={`rounded-full ${statusTone[s.status]}`}>
                      {s.status}
                    </Badge>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}