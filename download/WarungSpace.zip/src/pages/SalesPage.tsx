import { FileText, ArrowRight } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { SALES_ORDERS } from "@/lib/erp-data";

const rupiah = (n: number) => "Rp " + n.toLocaleString("id-ID");

const stageTone: Record<string, string> = {
  Quotation: "bg-slate-100 text-slate-700 hover:bg-slate-100",
  "Sales Order": "bg-sky-100 text-sky-700 hover:bg-sky-100",
  Invoice: "bg-amber-100 text-amber-700 hover:bg-amber-100",
  Paid: "bg-emerald-100 text-emerald-700 hover:bg-emerald-100",
};

const FLOW = ["Quotation", "Sales Order", "Invoice", "Paid"];

export default function SalesPage() {
  const total = SALES_ORDERS.reduce((s, o) => s + o.amount, 0);

  return (
    <div className="space-y-6">
      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardContent className="p-5">
          <div className="flex flex-wrap items-center gap-2">
            {FLOW.map((s, i) => (
              <div key={s} className="flex items-center gap-2">
                <span className="rounded-lg bg-emerald-50 px-3 py-1.5 text-xs font-semibold text-emerald-700">
                  {s}
                </span>
                {i < FLOW.length - 1 && <ArrowRight className="h-4 w-4 text-slate-300" />}
              </div>
            ))}
          </div>
          <p className="mt-3 text-xs text-slate-500">
            Quotation, sales order, sampai invoice penjualan dalam satu alur.
          </p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-medium text-slate-500">Total Nilai Order</p>
            <p className="mt-1 font-serif text-xl font-bold text-slate-900">{rupiah(total)}</p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-medium text-slate-500">Menunggu Invoice</p>
            <p className="mt-1 font-serif text-xl font-bold text-slate-900">
              {SALES_ORDERS.filter((o) => o.stage === "Sales Order").length} order
            </p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-medium text-slate-500">Sudah Dibayar</p>
            <p className="mt-1 font-serif text-xl font-bold text-emerald-700">
              {SALES_ORDERS.filter((o) => o.stage === "Paid").length} order
            </p>
          </CardContent>
        </Card>
      </div>

      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardHeader className="border-b border-slate-100 pb-4">
          <CardTitle className="flex items-center gap-2 text-base text-slate-900">
            <FileText className="h-4 w-4 text-emerald-700" />
            Daftar Penjualan
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 pt-4">
          {SALES_ORDERS.map((o) => (
            <div
              key={o.id}
              className="flex flex-col gap-3 rounded-xl border border-slate-100 bg-slate-50/60 p-4 sm:flex-row sm:items-center sm:justify-between"
            >
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold text-slate-800">{o.customer}</p>
                <p className="text-xs text-slate-500">
                  {o.id} · {o.date}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-sm font-semibold text-slate-800">{rupiah(o.amount)}</span>
                <Badge className={`rounded-full ${stageTone[o.stage]}`}>{o.stage}</Badge>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}