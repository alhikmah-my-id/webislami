import { Plug, RefreshCw, CheckCircle2, Circle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CHANNELS } from "@/lib/marketplace-data";

const rupiah = (n: number) => "Rp " + n.toLocaleString("id-ID");

export default function MarketplacePage() {
  const connected = CHANNELS.filter((c) => c.connected).length;
  const totalRevenue = CHANNELS.reduce((s, c) => s + c.revenue, 0);
  const totalOrders = CHANNELS.reduce((s, c) => s + c.ordersToday, 0);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-medium text-slate-500">Channel Terhubung</p>
            <p className="mt-1 font-serif text-xl font-bold text-slate-900">
              {connected}/{CHANNELS.length}
            </p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-medium text-slate-500">Pesanan Hari Ini</p>
            <p className="mt-1 font-serif text-xl font-bold text-slate-900">{totalOrders}</p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-medium text-slate-500">Omzet Semua Channel</p>
            <p className="mt-1 font-serif text-xl font-bold text-emerald-700">
              {rupiah(totalRevenue)}
            </p>
          </CardContent>
        </Card>
      </div>

      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardHeader className="border-b border-slate-100 pb-4">
          <CardTitle className="flex items-center gap-2 text-base text-slate-900">
            <Plug className="h-4 w-4 text-emerald-700" />
            Integrasi Marketplace & Website
          </CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 gap-4 pt-4 md:grid-cols-2 xl:grid-cols-3">
          {CHANNELS.map((c) => (
            <div
              key={c.id}
              className="rounded-2xl border border-slate-100 bg-slate-50/60 p-4 shadow-sm transition hover:shadow-md"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div
                    className={`grid h-10 w-10 place-items-center rounded-xl font-serif text-lg font-bold ${c.accent}`}
                  >
                    {c.logo}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-800">{c.name}</p>
                    <p className="text-xs text-slate-500">{c.products} produk tersinkron</p>
                  </div>
                </div>
                {c.connected ? (
                  <CheckCircle2 className="h-5 w-5 text-emerald-600" />
                ) : (
                  <Circle className="h-5 w-5 text-slate-300" />
                )}
              </div>

              <div className="mt-4 grid grid-cols-2 gap-2">
                <div className="rounded-lg bg-white p-2.5">
                  <p className="text-xs text-slate-500">Order</p>
                  <p className="text-sm font-semibold text-slate-800">{c.ordersToday}</p>
                </div>
                <div className="rounded-lg bg-white p-2.5">
                  <p className="text-xs text-slate-500">Omzet</p>
                  <p className="text-sm font-semibold text-slate-800">
                    {c.revenue > 0 ? rupiah(c.revenue) : "-"}
                  </p>
                </div>
              </div>

              <div className="mt-3 flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-xs text-slate-500">
                  <RefreshCw className="h-3.5 w-3.5" />
                  {c.lastSync}
                </span>
                <Badge
                  className={`rounded-full text-xs ${
                    c.connected
                      ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100"
                      : "bg-slate-200 text-slate-600 hover:bg-slate-200"
                  }`}
                >
                  {c.connected ? "Aktif" : "Hubungkan"}
                </Badge>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}