import { useState } from "react";
import { Plus, Minus, Trash2, Receipt, Split, Percent } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MENU_ITEMS } from "@/lib/restaurant-data";

const rupiah = (n: number) => "Rp " + n.toLocaleString("id-ID");

type OrderType = "Dine-in" | "Takeaway" | "Delivery";

export default function RestaurantPosPage() {
  const [lines, setLines] = useState<{ id: string; qty: number }[]>([
    { id: "m1", qty: 2 },
    { id: "m3", qty: 2 },
  ]);
  const [orderType, setOrderType] = useState<OrderType>("Dine-in");
  const [discount, setDiscount] = useState(0);
  const [splitCount, setSplitCount] = useState(1);

  const items = lines.map((l) => {
    const m = MENU_ITEMS.find((x) => x.id === l.id)!;
    return { ...m, qty: l.qty, subtotal: m.price * l.qty };
  });
  const subtotal = items.reduce((s, i) => s + i.subtotal, 0);
  const tax = Math.round(subtotal * 0.1);
  const total = subtotal + tax - discount;

  const add = (id: string) =>
    setLines((l) => {
      const e = l.find((x) => x.id === id);
      return e ? l.map((x) => (x.id === id ? { ...x, qty: x.qty + 1 } : x)) : [...l, { id, qty: 1 }];
    });
  const dec = (id: string) =>
    setLines((l) =>
      l.map((x) => (x.id === id ? { ...x, qty: x.qty - 1 } : x)).filter((x) => x.qty > 0)
    );
  const remove = (id: string) => setLines((l) => l.filter((x) => x.id !== id));

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-5">
      <Card className="rounded-2xl border-slate-200 shadow-sm lg:col-span-3">
        <CardHeader className="flex flex-col gap-3 border-b border-slate-100 pb-4 sm:flex-row sm:items-center sm:justify-between">
          <CardTitle className="text-base text-slate-900">Menu Restoran</CardTitle>
          <div className="flex gap-2">
            {(["Dine-in", "Takeaway", "Delivery"] as const).map((t) => (
              <button
                key={t}
                onClick={() => setOrderType(t)}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
                  orderType === t
                    ? "bg-emerald-600 text-white"
                    : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </CardHeader>
        <CardContent className="grid grid-cols-1 gap-3 pt-4 sm:grid-cols-2">
          {MENU_ITEMS.map((m) => (
            <button
              key={m.id}
              onClick={() => add(m.id)}
              disabled={!m.available}
              className="flex items-center justify-between rounded-xl border border-slate-100 bg-slate-50/60 p-4 text-left transition hover:border-emerald-300 hover:bg-emerald-50 disabled:cursor-not-allowed disabled:opacity-40"
            >
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold text-slate-800">{m.name}</p>
                <p className="text-xs text-slate-500">
                  {rupiah(m.price)} · {m.category}
                </p>
              </div>
              <div className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-emerald-600 text-white">
                <Plus className="h-4 w-4" />
              </div>
            </button>
          ))}
        </CardContent>
      </Card>

      <Card className="rounded-2xl border-slate-200 shadow-sm lg:col-span-2">
        <CardHeader className="flex flex-row items-center justify-between border-b border-slate-100 pb-4">
          <CardTitle className="flex items-center gap-2 text-base text-slate-900">
            <Receipt className="h-4 w-4 text-emerald-700" />
            Pesanan
          </CardTitle>
          <Badge className="rounded-full bg-emerald-100 text-emerald-700 hover:bg-emerald-100">
            {orderType}
          </Badge>
        </CardHeader>
        <CardContent className="space-y-3 pt-4">
          {items.length === 0 ? (
            <p className="py-10 text-center text-sm text-slate-500">Belum ada item dipilih.</p>
          ) : (
            items.map((i) => (
              <div
                key={i.id}
                className="flex items-center gap-3 rounded-xl border border-slate-100 bg-slate-50/60 p-3"
              >
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold text-slate-800">{i.name}</p>
                  <p className="text-xs text-slate-500">{rupiah(i.subtotal)}</p>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => dec(i.id)}
                    className="grid h-7 w-7 place-items-center rounded-lg bg-white text-slate-600 shadow-sm transition hover:bg-slate-100"
                  >
                    <Minus className="h-3.5 w-3.5" />
                  </button>
                  <span className="w-6 text-center text-sm font-semibold text-slate-800">
                    {i.qty}
                  </span>
                  <button
                    onClick={() => add(i.id)}
                    className="grid h-7 w-7 place-items-center rounded-lg bg-white text-slate-600 shadow-sm transition hover:bg-slate-100"
                  >
                    <Plus className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={() => remove(i.id)}
                    className="grid h-7 w-7 place-items-center rounded-lg bg-rose-50 text-rose-600 transition hover:bg-rose-100"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}

          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => setDiscount((d) => (d === 0 ? 10000 : 0))}
              className={`flex items-center justify-center gap-2 rounded-xl py-2.5 text-xs font-semibold transition ${
                discount > 0
                  ? "bg-emerald-600 text-white"
                  : "bg-slate-100 text-slate-600 hover:bg-slate-200"
              }`}
            >
              <Percent className="h-3.5 w-3.5" />
              Diskon 10rb
            </button>
            <button
              onClick={() => setSplitCount((s) => (s >= 4 ? 1 : s + 1))}
              className="flex items-center justify-center gap-2 rounded-xl bg-slate-100 py-2.5 text-xs font-semibold text-slate-600 transition hover:bg-slate-200"
            >
              <Split className="h-3.5 w-3.5" />
              Split {splitCount}x
            </button>
          </div>

          <div className="space-y-1.5 rounded-xl bg-slate-50 p-4 text-sm">
            <div className="flex justify-between text-slate-600">
              <span>Subtotal</span>
              <span>{rupiah(subtotal)}</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>Pajak (10%)</span>
              <span>{rupiah(tax)}</span>
            </div>
            {discount > 0 && (
              <div className="flex justify-between text-emerald-700">
                <span>Diskon</span>
                <span>-{rupiah(discount)}</span>
              </div>
            )}
            <div className="flex justify-between border-t border-slate-200 pt-2 font-serif text-lg font-bold text-slate-900">
              <span>Total</span>
              <span>{rupiah(total)}</span>
            </div>
            {splitCount > 1 && (
              <p className="text-xs text-slate-500">
                Per orang: {rupiah(Math.round(total / splitCount))}
              </p>
            )}
          </div>

          <Button
            disabled={items.length === 0}
            className="w-full rounded-xl bg-emerald-600 py-5 font-semibold text-white hover:bg-emerald-700 disabled:opacity-40"
          >
            Kirim ke Dapur
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}