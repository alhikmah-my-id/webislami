import { useState } from "react";
import { QrCode, Plus, Minus, ShoppingBag, CheckCircle2, Utensils } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useStore } from "@/lib/store";

const rupiah = (n: number) => "Rp " + n.toLocaleString("id-ID");

export default function OrderPage() {
  const { products } = useStore();
  const [cart, setCart] = useState<Record<string, number>>({});
  const [paid, setPaid] = useState(false);

  const change = (id: string, delta: number) =>
    setCart((prev) => {
      const next = { ...prev, [id]: Math.max(0, (prev[id] ?? 0) + delta) };
      if (next[id] === 0) delete next[id];
      return next;
    });

  const total = Object.entries(cart).reduce((a, [id, qty]) => {
    const p = products.find((x) => x.id === id);
    return a + (p ? p.priceRetail * qty : 0);
  }, 0);

  const itemCount = Object.values(cart).reduce((a, b) => a + b, 0);

  if (paid) {
    return (
      <div className="mx-auto max-w-md space-y-6">
        <Card className="rounded-2xl border-emerald-200 bg-emerald-50 shadow-sm">
          <CardContent className="flex flex-col items-center gap-3 p-8 text-center">
            <div className="grid h-16 w-16 place-items-center rounded-full bg-emerald-500 text-white">
              <CheckCircle2 className="h-8 w-8" />
            </div>
            <h2 className="font-serif text-xl font-bold text-emerald-900">Pesanan Terkirim!</h2>
            <p className="text-sm text-emerald-700">
              Pembayaran QRIS berhasil. Pesanan Anda masuk ke dapur.
            </p>
            <Button
              variant="outline"
              className="mt-2 rounded-xl"
              onClick={() => {
                setPaid(false);
                setCart({});
              }}
            >
              Pesan Lagi
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <header className="rounded-2xl bg-gradient-to-br from-emerald-700 to-emerald-900 p-6 text-emerald-50 shadow-md md:p-8">
        <div className="flex items-center gap-2 text-emerald-300">
          <QrCode className="h-4 w-4" />
          <span className="text-xs font-semibold uppercase tracking-widest">Scan QR · Meja 04</span>
        </div>
        <h1 className="mt-2 font-serif text-2xl font-bold md:text-3xl">Menu Digital</h1>
        <p className="mt-1 text-sm text-emerald-200">
          Pilih menu, pesan, dan bayar langsung dari HP Anda.
        </p>
      </header>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:col-span-2">
          {products.map((p) => (
            <div
              key={p.id}
              className="flex flex-col rounded-2xl border border-slate-200 bg-white p-4 shadow-sm"
            >
              <div className="grid h-10 w-10 place-items-center rounded-xl bg-emerald-100 text-emerald-700">
                <Utensils className="h-5 w-5" />
              </div>
              <p className="mt-3 line-clamp-2 text-sm font-semibold text-slate-800">{p.name}</p>
              <p className="mt-1 text-sm font-bold text-emerald-700">{rupiah(p.priceRetail)}</p>
              <Badge
                className={`mt-2 w-fit rounded-full ${
                  p.stock > 0
                    ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100"
                    : "bg-rose-100 text-rose-700 hover:bg-rose-100"
                }`}
              >
                {p.stock > 0 ? "Ready" : "Habis"}
              </Badge>
              <div className="mt-3 flex items-center justify-between">
                <Button
                  size="icon"
                  variant="outline"
                  className="h-8 w-8 rounded-lg"
                  disabled={!cart[p.id]}
                  onClick={() => change(p.id, -1)}
                >
                  <Minus className="h-3 w-3" />
                </Button>
                <span className="text-sm font-bold text-slate-800">{cart[p.id] ?? 0}</span>
                <Button
                  size="icon"
                  className="h-8 w-8 rounded-lg bg-emerald-600 hover:bg-emerald-700"
                  disabled={p.stock <= 0}
                  onClick={() => change(p.id, 1)}
                >
                  <Plus className="h-3 w-3" />
                </Button>
              </div>
            </div>
          ))}
        </div>

        <Card className="h-fit rounded-2xl border-slate-200 shadow-sm lg:sticky lg:top-6">
          <CardHeader className="border-b border-slate-100 pb-4">
            <CardTitle className="flex items-center gap-2 text-base text-slate-900">
              <ShoppingBag className="h-4 w-4" /> Pesanan Anda
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 pt-4">
            {itemCount === 0 ? (
              <p className="py-6 text-center text-sm text-slate-400">Belum ada item dipilih.</p>
            ) : (
              <div className="space-y-2">
                {Object.entries(cart).map(([id, qty]) => {
                  const p = products.find((x) => x.id === id);
                  if (!p) return null;
                  return (
                    <div key={id} className="flex items-center justify-between text-sm">
                      <span className="truncate text-slate-700">
                        {p.name} × {qty}
                      </span>
                      <span className="font-semibold text-slate-900">
                        {rupiah(p.priceRetail * qty)}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}

            <div className="flex items-center justify-between border-t border-slate-100 pt-4">
              <span className="text-sm text-slate-500">Total</span>
              <span className="text-xl font-bold text-slate-900">{rupiah(total)}</span>
            </div>

            <Button
              disabled={itemCount === 0}
              onClick={() => setPaid(true)}
              className="w-full rounded-xl bg-emerald-600 py-6 text-base font-semibold hover:bg-emerald-700"
            >
              <QrCode className="h-4 w-4" /> Bayar QRIS
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}