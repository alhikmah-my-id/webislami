import { Wallet, MessageCircle, CheckCircle2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useStore } from "@/lib/store";

const rupiah = (n: number) => "Rp " + n.toLocaleString("id-ID");

export default function DebtsPage() {
  const { debts, markDebtPaid } = useStore();

  const outstanding = debts
    .filter((d) => d.status === "unpaid")
    .reduce((s, d) => s + d.amount, 0);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card className="rounded-2xl border-slate-200 shadow-sm sm:col-span-1">
          <CardContent className="p-5">
            <div className="grid h-11 w-11 place-items-center rounded-xl bg-amber-50 text-amber-700">
              <Wallet className="h-5 w-5" />
            </div>
            <p className="mt-4 text-xs font-medium text-slate-500">Total Piutang</p>
            <p className="mt-1 font-serif text-2xl font-bold text-slate-900">
              {rupiah(outstanding)}
            </p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm sm:col-span-2">
          <CardContent className="p-5">
            <p className="text-xs font-medium text-slate-500">Pengingat WhatsApp</p>
            <p className="mt-1 text-sm text-slate-600">
              Kirim pengingat tagihan otomatis ke pelanggan yang belum melunasi utang.
              Terintegrasi dengan WhatsApp Gateway.
            </p>
            <Button className="mt-4 rounded-xl bg-emerald-600 hover:bg-emerald-700">
              <MessageCircle className="mr-2 h-4 w-4" />
              Kirim Semua Pengingat
            </Button>
          </CardContent>
        </Card>
      </div>

      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardHeader className="border-b border-slate-100 pb-4">
          <CardTitle className="text-base text-slate-900">Buku Utang Pelanggan</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 pt-4">
          {debts.length === 0 ? (
            <p className="py-10 text-center text-sm text-slate-500">
              Belum ada catatan utang.
            </p>
          ) : (
            debts.map((d) => (
              <div
                key={d.id}
                className="flex flex-col gap-3 rounded-xl border border-slate-100 bg-slate-50/60 p-4 sm:flex-row sm:items-center sm:justify-between"
              >
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-slate-800">{d.customer}</p>
                  <p className="text-xs text-slate-500">
                    {d.phone} · Jatuh tempo {d.dueDate}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-semibold text-slate-800">{rupiah(d.amount)}</span>
                  <Badge
                    className={`rounded-full ${
                      d.status === "paid"
                        ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100"
                        : "bg-amber-100 text-amber-700 hover:bg-amber-100"
                    }`}
                  >
                    {d.status === "paid" ? "Lunas" : "Belum Bayar"}
                  </Badge>
                  {d.status === "unpaid" && (
                    <Button
                      size="sm"
                      onClick={() => markDebtPaid(d.id)}
                      className="rounded-lg bg-emerald-600 hover:bg-emerald-700"
                    >
                      <CheckCircle2 className="mr-1 h-3.5 w-3.5" />
                      Lunas
                    </Button>
                  )}
                </div>
              </div>
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
}