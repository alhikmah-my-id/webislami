import { Building2, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { OUTLETS } from "@/lib/restaurant-data";

const rupiah = (n: number) => "Rp " + n.toLocaleString("id-ID");
const short = (n: number) => "Rp " + (n / 1000000).toFixed(1) + " jt";

export default function OutletsPage() {
  const totalRevenue = OUTLETS.reduce((s, o) => s + o.revenue, 0);
  const totalFoodCost = OUTLETS.reduce((s, o) => s + o.foodCost, 0);
  const totalOpex = OUTLETS.reduce((s, o) => s + o.opex, 0);
  const totalProfit = totalRevenue - totalFoodCost - totalOpex;
  const maxRevenue = Math.max(...OUTLETS.map((o) => o.revenue));

  const summary = [
    { label: "Total Pendapatan", value: rupiah(totalRevenue), tone: "bg-emerald-50 text-emerald-700" },
    { label: "Food Cost", value: rupiah(totalFoodCost), tone: "bg-amber-50 text-amber-700" },
    { label: "Biaya Operasional", value: rupiah(totalOpex), tone: "bg-sky-50 text-sky-700" },
    { label: "Laba Bersih", value: rupiah(totalProfit), tone: "bg-emerald-50 text-emerald-700" },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {summary.map((s) => (
          <Card key={s.label} className="rounded-2xl border-slate-200 shadow-sm">
            <CardContent className="p-5">
              <span className={`inline-block rounded-lg px-2 py-0.5 text-xs font-semibold ${s.tone}`}>
                {s.label}
              </span>
              <p className="mt-3 font-serif text-xl font-bold text-slate-900">{s.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardHeader className="border-b border-slate-100 pb-4">
          <CardTitle className="flex items-center gap-2 text-base text-slate-900">
            <Building2 className="h-4 w-4 text-emerald-700" />
            Performa Antar Outlet
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 pt-4">
          {OUTLETS.map((o) => {
            const profit = o.revenue - o.foodCost - o.opex;
            const foodCostPct = Math.round((o.foodCost / o.revenue) * 100);
            const margin = Math.round((profit / o.revenue) * 100);
            return (
              <div
                key={o.id}
                className="rounded-xl border border-slate-100 bg-slate-50/60 p-4"
              >
                <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <p className="text-sm font-semibold text-slate-800">{o.name}</p>
                    <p className="text-xs text-slate-500">
                      {o.city} · {o.transactions.toLocaleString("id-ID")} transaksi
                    </p>
                  </div>
                  <div className="flex items-center gap-4 text-right">
                    <div>
                      <p className="text-xs text-slate-500">Pendapatan</p>
                      <p className="text-sm font-semibold text-slate-800">{short(o.revenue)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500">Food Cost</p>
                      <p className="text-sm font-semibold text-amber-700">{foodCostPct}%</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500">Margin</p>
                      <p className="flex items-center gap-1 text-sm font-semibold text-emerald-700">
                        <TrendingUp className="h-3.5 w-3.5" />
                        {margin}%
                      </p>
                    </div>
                  </div>
                </div>
                <div className="mt-3 h-2.5 w-full overflow-hidden rounded-full bg-slate-200">
                  <div
                    className="h-full rounded-full bg-emerald-500"
                    style={{ width: `${(o.revenue / maxRevenue) * 100}%` }}
                  />
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}