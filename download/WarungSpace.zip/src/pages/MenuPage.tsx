import { useState } from "react";
import { UtensilsCrossed, ChevronDown } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MENU_ITEMS } from "@/lib/restaurant-data";

const rupiah = (n: number) => "Rp " + n.toLocaleString("id-ID");

const catTone: Record<string, string> = {
  Makanan: "bg-emerald-100 text-emerald-700 hover:bg-emerald-100",
  Minuman: "bg-sky-100 text-sky-700 hover:bg-sky-100",
  Snack: "bg-amber-100 text-amber-700 hover:bg-amber-100",
};

export default function MenuPage() {
  const [open, setOpen] = useState<string | null>("m1");

  return (
    <div className="space-y-6">
      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardContent className="p-5">
          <p className="text-xs text-slate-500">
            Susun menu, varian, harga, modifier, dan resep bahan baku. Setiap penjualan
            mengurangi stok sesuai komposisi resep.
          </p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {MENU_ITEMS.map((m) => {
          const isOpen = open === m.id;
          return (
            <Card key={m.id} className="rounded-2xl border-slate-200 shadow-sm">
              <CardHeader className="border-b border-slate-100 pb-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <CardTitle className="flex items-center gap-2 text-base text-slate-900">
                      <UtensilsCrossed className="h-4 w-4 text-emerald-700" />
                      {m.name}
                    </CardTitle>
                    <p className="mt-1 text-xs text-slate-500">{rupiah(m.price)}</p>
                  </div>
                  <div className="flex shrink-0 flex-col items-end gap-2">
                    <Badge className={`rounded-full ${catTone[m.category]}`}>{m.category}</Badge>
                    <Badge
                      className={`rounded-full ${
                        m.available
                          ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100"
                          : "bg-rose-100 text-rose-700 hover:bg-rose-100"
                      }`}
                    >
                      {m.available ? "Tersedia" : "Habis"}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3 pt-4">
                <div className="flex flex-wrap gap-2">
                  {m.variants.map((v) => (
                    <span
                      key={v}
                      className="rounded-lg bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-600"
                    >
                      {v}
                    </span>
                  ))}
                </div>

                <button
                  onClick={() => setOpen(isOpen ? null : m.id)}
                  className="flex w-full items-center justify-between rounded-xl bg-slate-50 px-3 py-2 text-xs font-semibold text-slate-700 transition hover:bg-slate-100"
                >
                  Resep Bahan Baku ({m.recipe.length})
                  <ChevronDown
                    className={`h-4 w-4 transition-transform ${isOpen ? "rotate-180" : ""}`}
                  />
                </button>

                {isOpen && (
                  <div className="space-y-2">
                    {m.recipe.map((r) => (
                      <div
                        key={r.material}
                        className="flex items-center justify-between rounded-lg border border-slate-100 bg-white px-3 py-2"
                      >
                        <span className="text-xs font-medium text-slate-700">{r.material}</span>
                        <span className="text-xs text-slate-500">
                          {r.qty} {r.unit}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}