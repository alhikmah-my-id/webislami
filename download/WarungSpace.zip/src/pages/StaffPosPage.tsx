import { useState } from "react";
import { ScanBarcode, Camera, CheckCircle2, ShoppingCart, Trash2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface StaffProduct {
  id: string;
  name: string;
  price: number;
  emoji: string;
  stock: number;
}

const PRODUCTS: StaffProduct[] = [
  { id: "p1", name: "Beras 5kg", price: 68000, emoji: "🍚", stock: 24 },
  { id: "p2", name: "Minyak 2L", price: 34000, emoji: "🛢️", stock: 18 },
  { id: "p3", name: "Gula 1kg", price: 16000, emoji: "🍬", stock: 40 },
  { id: "p4", name: "Telur 1kg", price: 29000, emoji: "🥚", stock: 12 },
  { id: "p5", name: "Kopi Sachet", price: 2500, emoji: "☕", stock: 120 },
  { id: "p6", name: "Sabun Mandi", price: 5500, emoji: "🧼", stock: 60 },
];

const rupiah = (n: number) => "Rp " + n.toLocaleString("id-ID");

export default function StaffPosPage() {
  const [cart, setCart] = useState<{ id: string; qty: number }[]>([]);
  const [method, setMethod] = useState<"Tunai" | "Transfer" | "Utang">("Tunai");
  const [clockedIn, setClockedIn] = useState(false);

  const add = (id: string) =>
    setCart((prev) => {
      const found = prev.find((c) => c.id === id);
      if (found) return prev.map((c) => (c.id === id ? { ...c, qty: c.qty + 1 } : c));
      return [...prev, { id, qty: 1 }];
    });

  const remove = (id: string) => setCart((prev) => prev.filter((c) => c.id !== id));

  const total = cart.reduce((s, c) => {
    const p = PRODUCTS.find((x) => x.id === c.id);
    return s + (p ? p.price * c.qty : 0);
  }, 0);

  return (
    <div className="space-y-6">
      <Card
        className={`rounded-2xl border-0 shadow-sm ${
          clockedIn
            ? "bg-gradient-to-r from-emerald-600 to-teal-700"
            : "bg-gradient-to-r from-amber-500 to-orange-600"
        }`}
      >
        <CardContent className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-xl bg-white/20 text-white">
              <Camera className="h-6 w-6" />
            </div>
            <div>
              <p className="font-serif text-lg font-bold text-white">
                {clockedIn ? "Sudah Absen Masuk" : "Belum Absen Masuk"}
              </p>
              <p className="text-xs text-white/80">
                {clockedIn
                  ? "Clock in 08:02 · GPS & selfie terekam"
                  : "Ambil selfie untuk mulai shift"}
              </p>
            </div>
          </div>
          <Button
            onClick={() => setClockedIn((v) => !v)}
            className="rounded-xl bg-white font-semibold text-slate-800 hover:bg-slate-100"
          >
            {clockedIn ? (
              <>
                <CheckCircle2 className="mr-2 h-4 w-4 text-emerald-600" />
                Clock Out
              </>
            ) : (
              <>
                <Camera className="mr-2 h-4 w-4" />
                Absen Sekarang
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <div className="mb-4 flex items-center gap-2 rounded-xl border border-slate-200 bg-white p-3 shadow-sm">
            <ScanBarcode className="h-5 w-5 text-emerald-700" />
            <span className="text-sm text-slate-500">Scan barcode atau pilih produk</span>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {PRODUCTS.map((p) => (
              <button
                key={p.id}
                onClick={() => add(p.id)}
                className="rounded-2xl border border-slate-200 bg-white p-4 text-left shadow-sm transition hover:-translate-y-0.5 hover:border-emerald-300 hover:shadow-md active:scale-95"
              >
                <div className="text-3xl">{p.emoji}</div>
                <p className="mt-2 text-sm font-semibold text-slate-800">{p.name}</p>
                <p className="text-xs text-slate-500">Stok {p.stock}</p>
                <p className="mt-1 text-sm font-bold text-emerald-700">{rupiah(p.price)}</p>
              </button>
            ))}
          </div>
        </div>

        <Card className="h-fit rounded-2xl border-slate-200 shadow-sm lg:sticky lg:top-6">
          <CardHeader className="border-b border-slate-100 pb-4">
            <CardTitle className="flex items-center gap-2 text-base text-slate-900">
              <ShoppingCart className="h-4 w-4 text-emerald-700" />
              Keranjang
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 pt-4">
            {cart.length === 0 ? (
              <p className="py-8 text-center text-sm text-slate-400">
                Belum ada produk dipilih
              </p>
            ) : (
              cart.map((c) => {
                const p = PRODUCTS.find((x) => x.id === c.id)!;
                return (
                  <div
                    key={c.id}
                    className="flex items-center justify-between rounded-xl border border-slate-100 bg-slate-50/60 p-3"
                  >
                    <div>
                      <p className="text-sm font-medium text-slate-800">{p.name}</p>
                      <p className="text-xs text-slate-500">
                        {c.qty} × {rupiah(p.price)}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-slate-800">
                        {rupiah(p.price * c.qty)}
                      </span>
                      <button
                        onClick={() => remove(c.id)}
                        className="rounded-lg p-1 text-rose-500 transition hover:bg-rose-50"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                );
              })
            )}

            <div className="flex gap-2 pt-2">
              {(["Tunai", "Transfer", "Utang"] as const).map((m) => (
                <button
                  key={m}
                  onClick={() => setMethod(m)}
                  className={`flex-1 rounded-lg py-2 text-xs font-semibold transition ${
                    method === m
                      ? "bg-emerald-600 text-white"
                      : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>

            <div className="flex items-center justify-between border-t border-slate-100 pt-3">
              <span className="text-sm text-slate-500">Total</span>
              <span className="font-serif text-xl font-bold text-slate-900">
                {rupiah(total)}
              </span>
            </div>

            <Button
              disabled={cart.length === 0}
              className="w-full rounded-xl bg-emerald-600 py-5 font-semibold text-white hover:bg-emerald-700 disabled:opacity-40"
            >
              Bayar & Cetak Struk
            </Button>
            {method === "Utang" && (
              <Badge className="w-full justify-center rounded-lg bg-amber-100 py-1.5 text-amber-700 hover:bg-amber-100">
                Akan dicatat ke buku utang pelanggan
              </Badge>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}