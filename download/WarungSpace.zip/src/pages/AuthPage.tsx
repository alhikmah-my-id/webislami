import { useState } from "react";
import {
  Store,
  Mail,
  Lock,
  User,
  Phone,
  ArrowLeft,
  CheckCircle2,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";

type Mode = "login" | "register" | "reset";

const FEATURES = [
  "Kasir POS + QRIS real-time",
  "Manajemen stok & multi-outlet",
  "Buku utang + reminder WhatsApp",
  "Absensi GPS & payroll otomatis",
  "Auto-disbursement ke e-wallet",
  "Cetak struk thermal 80mm",
];

export default function AuthPage({
  onBack,
  onSuccess,
}: {
  onBack: () => void;
  onSuccess: () => void;
}) {
  const [mode, setMode] = useState<Mode>("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [businessName, setBusinessName] = useState("");
  const [phone, setPhone] = useState("");
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");

    if (mode === "reset") {
      if (!email) {
        setError("Masukkan email terdaftar.");
        return;
      }
      setSent(true);
      return;
    }

    if (!email || !password) {
      setError("Email dan kata sandi wajib diisi.");
      return;
    }
    if (mode === "register" && (!fullName || !businessName)) {
      setError("Nama lengkap dan nama usaha wajib diisi.");
      return;
    }
    onSuccess();
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-900 via-emerald-800 to-slate-900">
      <div className="mx-auto grid min-h-screen max-w-6xl grid-cols-1 gap-8 p-6 lg:grid-cols-2 lg:items-center lg:p-10">
        {/* Left: brand + features */}
        <div className="text-white">
          <button
            onClick={onBack}
            className="mb-8 flex items-center gap-2 text-xs font-medium text-emerald-200 transition hover:text-white"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Kembali ke Beranda
          </button>

          <div className="flex items-center gap-3">
            <div className="grid h-12 w-12 place-items-center rounded-2xl bg-emerald-500/20 text-emerald-300">
              <Store className="h-6 w-6" />
            </div>
            <div>
              <p className="font-serif text-2xl font-bold leading-none">
                WarungSpace
              </p>
              <p className="text-sm text-emerald-300">All-in-One SaaS ERP UMKM</p>
            </div>
          </div>

          <h1 className="mt-8 font-serif text-3xl font-bold leading-tight md:text-4xl">
            Kelola seluruh bisnis Anda dari satu dashboard.
          </h1>
          <p className="mt-3 max-w-md text-sm text-emerald-100/80">
            Multi-tenant, aman dengan Row Level Security, dan siap pakai untuk
            retail, restoran, hingga marketplace.
          </p>

          <ul className="mt-8 grid grid-cols-1 gap-3 sm:grid-cols-2">
            {FEATURES.map((f) => (
              <li key={f} className="flex items-center gap-2 text-sm text-emerald-50">
                <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
                {f}
              </li>
            ))}
          </ul>

          <div className="mt-8 flex items-center gap-2 rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-4 py-3 text-xs text-emerald-100">
            <ShieldCheck className="h-4 w-4 text-emerald-400" />
            Data terisolasi per tenant · Free trial 7 hari tanpa kartu kredit
          </div>
        </div>

        {/* Right: auth card */}
        <Card className="rounded-3xl border-0 shadow-2xl">
          <CardContent className="p-6 md:p-8">
            <div className="mb-6 flex gap-1 rounded-xl bg-slate-100 p-1">
              {(["login", "register"] as const).map((m) => (
                <button
                  key={m}
                  onClick={() => {
                    setMode(m);
                    setError("");
                    setSent(false);
                  }}
                  className={`flex-1 rounded-lg py-2 text-sm font-semibold transition ${
                    mode === m
                      ? "bg-white text-emerald-700 shadow-sm"
                      : "text-slate-500 hover:text-slate-700"
                  }`}
                >
                  {m === "login" ? "Masuk" : "Daftar"}
                </button>
              ))}
            </div>

            {mode === "reset" ? (
              <div>
                <div className="mb-4 flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-emerald-600" />
                  <h2 className="font-serif text-xl font-bold text-slate-900">
                    Reset Kata Sandi
                  </h2>
                </div>
                {sent ? (
                  <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4">
                    <div className="flex items-center gap-2 text-emerald-700">
                      <CheckCircle2 className="h-5 w-5" />
                      <p className="text-sm font-bold">Tautan terkirim!</p>
                    </div>
                    <p className="mt-1 text-xs text-slate-600">
                      Kami mengirim instruksi reset ke <b>{email}</b>. Periksa
                      kotak masuk dan folder spam Anda.
                    </p>
                    <Button
                      onClick={() => {
                        setMode("login");
                        setSent(false);
                      }}
                      className="mt-4 w-full rounded-xl bg-emerald-600 font-semibold text-white hover:bg-emerald-700"
                    >
                      Kembali ke Login
                    </Button>
                  </div>
                ) : (
                  <form onSubmit={submit} className="space-y-4">
                    <p className="text-sm text-slate-500">
                      Masukkan email terdaftar untuk menerima tautan reset.
                    </p>
                    <div className="space-y-2">
                      <Label htmlFor="reset-email">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                        <Input
                          id="reset-email"
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="nama@usaha.id"
                          className="rounded-xl pl-9"
                        />
                      </div>
                    </div>
                    {error && <p className="text-xs text-rose-600">{error}</p>}
                    <Button
                      type="submit"
                      className="w-full rounded-xl bg-emerald-600 font-semibold text-white hover:bg-emerald-700"
                    >
                      Kirim Tautan Reset
                    </Button>
                    <button
                      type="button"
                      onClick={() => setMode("login")}
                      className="w-full text-center text-xs font-medium text-slate-500 hover:text-slate-700"
                    >
                      Batal
                    </button>
                  </form>
                )}
              </div>
            ) : (
              <form onSubmit={submit} className="space-y-4">
                <h2 className="font-serif text-xl font-bold text-slate-900">
                  {mode === "login" ? "Masuk ke Dashboard" : "Daftarkan Usaha Anda"}
                </h2>

                {mode === "register" && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="fullName">Nama Lengkap</Label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                        <Input
                          id="fullName"
                          value={fullName}
                          onChange={(e) => setFullName(e.target.value)}
                          placeholder="Budi Santoso"
                          className="rounded-xl pl-9"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="businessName">Nama Usaha</Label>
                      <div className="relative">
                        <Store className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                        <Input
                          id="businessName"
                          value={businessName}
                          onChange={(e) => setBusinessName(e.target.value)}
                          placeholder="Toko Berkah Jaya"
                          className="rounded-xl pl-9"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Nomor WhatsApp</Label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                        <Input
                          id="phone"
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          placeholder="0812xxxxxxx"
                          className="rounded-xl pl-9"
                        />
                      </div>
                    </div>
                  </>
                )}

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                    <Input
                      id="email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="nama@usaha.id"
                      className="rounded-xl pl-9"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="password">Kata Sandi</Label>
                    {mode === "login" && (
                      <button
                        type="button"
                        onClick={() => setMode("reset")}
                        className="text-xs font-medium text-emerald-700 hover:text-emerald-900"
                      >
                        Lupa sandi?
                      </button>
                    )}
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                    <Input
                      id="password"
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="rounded-xl pl-9"
                    />
                  </div>
                </div>

                {error && <p className="text-xs text-rose-600">{error}</p>}

                <Button
                  type="submit"
                  className="w-full rounded-xl bg-emerald-600 py-3 font-semibold text-white hover:bg-emerald-700"
                >
                  {mode === "login" ? "Masuk" : "Mulai Free Trial 7 Hari"}
                </Button>

                <p className="text-center text-xs text-slate-400">
                  Dengan melanjutkan, Anda menyetujui Syarat & Kebijakan Privasi
                  WarungSpace.
                </p>
              </form>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}