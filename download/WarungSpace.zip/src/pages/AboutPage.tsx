import { ArrowLeft, ArrowRight, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import SponsorCard from "@/components/SponsorCard";
import { ABOUT_SECTIONS } from "@/lib/about-data";

interface AboutPageProps {
  onBack: () => void;
  onEnterApp: () => void;
}

export default function AboutPage({ onBack, onEnterApp }: AboutPageProps) {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <header className="sticky top-0 z-20 border-b border-emerald-900/20 bg-emerald-950/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3 md:px-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-emerald-100 transition hover:bg-emerald-800/60"
          >
            <ArrowLeft className="h-4 w-4" />
            Beranda
          </button>
          <Button
            onClick={onEnterApp}
            className="rounded-xl bg-emerald-500 font-semibold text-white hover:bg-emerald-400"
          >
            Coba Gratis
          </Button>
        </div>
      </header>

      <section className="bg-gradient-to-br from-emerald-950 via-emerald-900 to-teal-900">
        <div className="mx-auto max-w-6xl px-4 py-12 md:px-8 md:py-16">
          <span className="inline-flex items-center gap-2 rounded-full bg-emerald-500/15 px-3 py-1 text-xs font-semibold text-emerald-200">
            <Info className="h-3.5 w-3.5" />
            Tentang Proyek
          </span>
          <h1 className="mt-4 font-serif text-3xl font-bold text-white md:text-4xl">
            Tentang WarungSpace
          </h1>
          <p className="mt-3 max-w-2xl text-sm text-emerald-100/90 md:text-base">
            Dokumentasi lengkap proyek: fitur, arsitektur, teknologi, instalasi,
            API, hingga cara berkontribusi dan mendukung pengembangan.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-10 md:px-8 md:py-14">
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <div className="space-y-6 lg:col-span-2">
            {ABOUT_SECTIONS.map((s) => (
              <Card
                key={s.id}
                id={s.id}
                className="rounded-2xl border-slate-200 shadow-sm"
              >
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <div className="grid h-10 w-10 place-items-center rounded-xl bg-emerald-50 text-lg">
                      {s.emoji}
                    </div>
                    <h2 className="font-serif text-lg font-bold text-slate-900">
                      {s.title}
                    </h2>
                  </div>

                  {s.body.map((p) => (
                    <p key={p} className="mt-3 text-sm text-slate-600">
                      {p}
                    </p>
                  ))}

                  {s.list && (
                    <ul className="mt-4 space-y-2">
                      {s.list.map((item) => (
                        <li key={item} className="flex gap-2 text-sm text-slate-600">
                          <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-emerald-500" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  )}

                  {s.code && (
                    <pre className="mt-4 overflow-x-auto rounded-xl bg-slate-900 p-4 text-xs leading-relaxed text-emerald-200">
                      <code>{s.code}</code>
                    </pre>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>

          <aside className="space-y-6 lg:sticky lg:top-24 lg:self-start">
            <Card className="rounded-2xl border-slate-200 shadow-sm">
              <CardContent className="p-5">
                <h3 className="text-xs font-semibold uppercase tracking-widest text-emerald-700">
                  Daftar Isi
                </h3>
                <nav className="mt-3 flex flex-col gap-1">
                  {ABOUT_SECTIONS.map((s) => (
                    <a
                      key={s.id}
                      href={`#${s.id}`}
                      className="rounded-lg px-3 py-2 text-sm text-slate-600 transition hover:bg-emerald-50 hover:text-emerald-700"
                    >
                      {s.emoji} {s.title}
                    </a>
                  ))}
                </nav>
              </CardContent>
            </Card>

            <SponsorCard />

            <Card className="rounded-2xl border-slate-200 bg-slate-900 shadow-sm">
              <CardContent className="p-5">
                <h3 className="font-serif text-base font-bold text-white">
                  Siap mulai?
                </h3>
                <p className="mt-1 text-xs text-slate-400">
                  Coba gratis 7 hari, tanpa kartu kredit.
                </p>
                <Button
                  onClick={onEnterApp}
                  className="mt-4 w-full rounded-xl bg-emerald-500 font-semibold text-white hover:bg-emerald-400"
                >
                  Coba Gratis
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          </aside>
        </div>
      </section>

      <footer className="border-t border-slate-200 bg-slate-900 py-8">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-4 md:flex-row md:px-8">
          <p className="font-serif text-sm font-bold text-white">WarungSpace</p>
          <p className="text-xs text-slate-400">
            Devolope by{" "}
            <a
              href="https://awdev.my.id"
              target="_blank"
              rel="noreferrer"
              className="font-semibold text-emerald-400 transition hover:text-emerald-300"
            >
              AWD
            </a>
            {" · "}
            <a
              href="https://paypal.me/wahyudi9kdl"
              target="_blank"
              rel="noreferrer"
              className="font-semibold text-emerald-400 transition hover:text-emerald-300"
            >
              Support
            </a>
          </p>
        </div>
      </footer>
    </div>
  );
}