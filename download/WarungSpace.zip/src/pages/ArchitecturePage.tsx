import { Folder, FileCode, Server, Bot, Palette, Cloud } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface Node {
  name: string;
  desc?: string;
  children?: Node[];
}

const tree: Node[] = [
  {
    name: ".cloudshell/",
    desc: "Cloud Shell & deployment scripts",
    children: [
      { name: "deploy-backend.sh", desc: "Push PHP ke server" },
      { name: "deploy-bot.sh", desc: "Push Python bot ke cloud" },
      { name: "nginx.conf", desc: "Subdomain tenant (toko member)" },
    ],
  },
  {
    name: "warungos-frontend/",
    desc: "Next.js + Sass",
    children: [
      { name: "app/page.tsx", desc: "Landing page WarungOS.com" },
      { name: "app/login/", desc: "Masuk member / karyawan" },
      { name: "app/pricing/", desc: "Pilih paket (DANA/QRIS)" },
      { name: "styles/dashboard.scss", desc: "UI kasir & admin" },
    ],
  },
  {
    name: "warungos-backend-php/",
    desc: "Laravel multi-tenant",
    children: [
      { name: "AdminSaaSController.php", desc: "Kontroler pemilik WarungOS" },
      { name: "POSController.php", desc: "Kasir toko member" },
      { name: "ProductController.php", desc: "Stok & produk grosir/ececer" },
      { name: "WebhookController.php", desc: "Deteksi bayar sukses DANA/QRIS" },
      { name: "Models: Tenant, User, Product" },
      { name: "routes/api.php, web.php" },
    ],
  },
  {
    name: "warungos-bot-python/",
    desc: "Automation & WhatsApp bot",
    children: [
      { name: "main.py", desc: "Bot penagih utang otomatis" },
      { name: "requirements.txt", desc: "requests, fastapi, twilio/wapi" },
      { name: "cron_scheduler.py", desc: "Jalan 9 pagi cek utang tempo" },
    ],
  },
];

const stack = [
  { icon: Palette, label: "Frontend", value: "Next.js + Sass" },
  { icon: Server, label: "Backend", value: "PHP / Laravel" },
  { icon: Bot, label: "Automation", value: "Python Bot" },
  { icon: Cloud, label: "Deploy", value: "Cloud Shell + Nginx" },
];

export default function ArchitecturePage() {
  return (
    <div className="space-y-6">
      <header className="rounded-2xl bg-gradient-to-br from-emerald-700 to-emerald-900 p-6 text-emerald-50 shadow-md md:p-8">
        <div className="flex items-center gap-2 text-emerald-300">
          <Folder className="h-4 w-4" />
          <span className="text-xs font-semibold uppercase tracking-widest">Blueprint</span>
        </div>
        <h1 className="mt-2 font-serif text-2xl font-bold md:text-3xl">Struktur Proyek WarungOS</h1>
        <p className="mt-1 max-w-2xl text-sm text-emerald-200">
          Cetak biru arsitektur multi-tenant: frontend, backend, bot WhatsApp, dan skrip deployment.
        </p>
      </header>

      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        {stack.map((s) => {
          const Icon = s.icon;
          return (
            <Card key={s.label} className="rounded-2xl border-slate-200 shadow-sm">
              <CardContent className="flex items-center gap-3 p-4">
                <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-emerald-100 text-emerald-700">
                  <Icon className="h-5 w-5" />
                </div>
                <div className="min-w-0">
                  <p className="text-xs uppercase tracking-wide text-slate-400">{s.label}</p>
                  <p className="truncate text-sm font-semibold text-slate-800">{s.value}</p>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {tree.map((root) => (
          <Card key={root.name} className="rounded-2xl border-slate-200 shadow-sm">
            <CardHeader className="border-b border-slate-100 pb-4">
              <CardTitle className="flex items-center gap-2 font-mono text-base text-slate-900">
                <Folder className="h-4 w-4 text-emerald-600" />
                {root.name}
              </CardTitle>
              {root.desc && <p className="text-xs text-slate-500">{root.desc}</p>}
            </CardHeader>
            <CardContent className="space-y-2 pt-4">
              {root.children?.map((child) => (
                <div
                  key={child.name}
                  className="flex items-start gap-3 rounded-xl bg-slate-50 px-3 py-2 transition hover:bg-emerald-50"
                >
                  <FileCode className="mt-0.5 h-4 w-4 shrink-0 text-slate-400" />
                  <div className="min-w-0">
                    <p className="truncate font-mono text-xs font-medium text-slate-800">
                      {child.name}
                    </p>
                    {child.desc && <p className="text-xs text-slate-500">{child.desc}</p>}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="rounded-2xl border border-amber-200 bg-amber-50 p-5">
        <div className="flex items-center gap-2">
          <Badge className="rounded-full bg-amber-500 text-white hover:bg-amber-500">Catatan</Badge>
          <span className="text-sm font-semibold text-amber-900">Preview ini berjalan di browser</span>
        </div>
        <p className="mt-2 text-sm text-amber-800">
          Aplikasi ini adalah MVP front-end yang mensimulasikan modul Kasir, Stok, Utang, dan
          Langganan. Backend PHP/Laravel, bot Python, dan webhook pembayaran pada blueprint di atas
          memerlukan server sungguhan dan tidak dapat dijalankan di preview statis ini.
        </p>
      </div>
    </div>
  );
}