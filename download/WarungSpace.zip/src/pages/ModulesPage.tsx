import { Layers, Store, MessageCircle, CreditCard, ShieldCheck, MapPin } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const MODULES = [
  { icon: Store, name: "Katalog E-Commerce WA", desc: "Toko online publik via subdomain + order WhatsApp.", status: "Aktif" },
  { icon: MessageCircle, name: "WhatsApp Gateway", desc: "Pengingat utang & notifikasi otomatis ke pelanggan.", status: "Aktif" },
  { icon: MapPin, name: "Absensi GPS Karyawan", desc: "Clock-in dengan foto & koordinat lokasi.", status: "Aktif" },
  { icon: CreditCard, name: "Payment Gateway", desc: "Xendit / Midtrans dengan webhook otomatis.", status: "Trial" },
  { icon: ShieldCheck, name: "Multi-Tenant RLS", desc: "Isolasi data per toko dengan Row Level Security.", status: "Aktif" },
];

export default function ModulesPage() {
  return (
    <div className="space-y-6">
      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardHeader className="border-b border-slate-100 pb-4">
          <CardTitle className="flex items-center gap-2 text-base text-slate-900">
            <Layers className="h-4 w-4 text-emerald-700" />
            Modul ERP All-in-One
          </CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 gap-4 pt-4 md:grid-cols-2">
          {MODULES.map((m) => {
            const Icon = m.icon;
            const active = m.status === "Aktif";
            return (
              <div
                key={m.name}
                className="flex items-start gap-4 rounded-xl border border-slate-100 bg-slate-50/60 p-4 transition hover:border-emerald-300 hover:bg-emerald-50"
              >
                <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-emerald-100 text-emerald-700">
                  <Icon className="h-5 w-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <p className="truncate text-sm font-semibold text-slate-800">{m.name}</p>
                    <Badge
                      className={`rounded-full ${
                        active
                          ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100"
                          : "bg-amber-100 text-amber-700 hover:bg-amber-100"
                      }`}
                    >
                      {m.status}
                    </Badge>
                  </div>
                  <p className="mt-1 text-xs text-slate-500">{m.desc}</p>
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}