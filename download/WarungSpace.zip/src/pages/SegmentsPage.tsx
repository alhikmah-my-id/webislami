import { useState } from "react";
import { ArrowLeft, ArrowRight, Sparkles, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { SEGMENT_CATEGORIES, SEGMENTS } from "@/lib/segments-data";

interface SegmentsPageProps {
  onBack: () => void;
  onEnterApp: () => void;
}

export default function SegmentsPage({ onBack, onEnterApp }: SegmentsPageProps) {
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  const visibleSegments = activeCategory
    ? SEGMENTS.filter((s) => s.category === activeCategory)
    : SEGMENTS;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <header className="sticky top-0 z-20 border-b border-emerald-900/20 bg-emerald-950/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3 md:px-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-emerald-100 transition hover:bg-emerald-800/60"
          >
            <ArrowLeft className="h-4 w-4" />
            Beranda
          </button>
          <Button
            onClick={onEnterApp}
            className="rounded-xl bg-emerald-500 font-semibold text-white hover:bg-emerald-400"
          >
            Coba Gratis
          </Button>
        </div>
      </header>

      <section className="bg-gradient-to-br from-emerald-950 via-emerald-900 to-teal-900">
        <div className="mx-auto max-w-6xl px-4 py-12 md:px-8 md:py-16">
          <span className="inline-flex items-center gap-2 rounded-full bg-emerald-500/15 px-3 py-1 text-xs font-semibold text-emerald-200">
            <Sparkles className="h-3.5 w-3.5" />
            Pilih berdasarkan kebutuhan
          </span>
          <h1 className="mt-4 font-serif text-3xl font-bold text-white md:text-4xl">
            Belum yakin masuk kategori mana?
          </h1>
          <p className="mt-3 max-w-2xl text-sm text-emerald-100/90 md:text-base">
            Ini panduan singkatnya. Temukan jenis usaha Anda dan lihat bagaimana
            WarungSpace membantu operasional sehari-hari.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-10 md:px-8 md:py-14">
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {SEGMENT_CATEGORIES.map((cat) => {
            const active = activeCategory === cat.title;
            return (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(active ? null : cat.title)}
                className={`rounded-2xl border p-5 text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-md ${
                  active
                    ? "border-emerald-500 bg-emerald-50 ring-2 ring-emerald-200"
                    : "border-slate-200 bg-white"
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="grid h-11 w-11 place-items-center rounded-xl bg-emerald-50 text-xl">
                    {cat.emoji}
                  </div>
                  {active && (
                    <span className="grid h-6 w-6 place-items-center rounded-full bg-emerald-600 text-white">
                      <Check className="h-3.5 w-3.5" />
                    </span>
                  )}
                </div>
                <h3 className="mt-3 text-sm font-bold text-slate-900">{cat.title}</h3>
                <p className="mt-1 text-xs text-slate-600">{cat.desc}</p>
                <ul className="mt-3 space-y-1">
                  {cat.examples.map((ex) => (
                    <li key={ex} className="text-xs font-medium text-emerald-700">
                      {ex}
                    </li>
                  ))}
                </ul>
              </button>
            );
          })}
        </div>

        <div className="mt-10 flex flex-wrap items-center justify-between gap-3">
          <h2 className="font-serif text-xl font-bold text-slate-900 md:text-2xl">
            {activeCategory ? `Cocok untuk: ${activeCategory}` : "Semua jenis usaha"}
          </h2>
          {activeCategory && (
            <button
              onClick={() => setActiveCategory(null)}
              className="text-xs font-semibold text-emerald-700 transition hover:text-emerald-900"
            >
              Tampilkan semua
            </button>
          )}
        </div>

        <div className="mt-5 grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
          {visibleSegments.map((s) => (
            <Card
              key={s.id}
              className="rounded-2xl border-slate-200 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
            >
              <CardContent className="flex h-full flex-col p-5">
                <div className="grid h-12 w-12 place-items-center rounded-xl bg-emerald-50 text-2xl">
                  {s.emoji}
                </div>
                <p className="mt-3 text-xs font-semibold uppercase tracking-wider text-emerald-700">
                  {s.category}
                </p>
                <h3 className="mt-1 text-sm font-bold text-slate-900">{s.title}</h3>
                <p className="mt-2 flex-1 text-xs text-slate-600">{s.desc}</p>
                <button
                  onClick={onEnterApp}
                  className="mt-4 flex items-center gap-1.5 text-xs font-semibold text-emerald-700 transition hover:text-emerald-900"
                >
                  Pelajari lebih lanjut
                  <ArrowRight className="h-3.5 w-3.5" />
                </button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-12 rounded-2xl bg-gradient-to-r from-emerald-700 to-teal-700 p-6 text-center shadow-md md:p-8">
          <h3 className="font-serif text-xl font-bold text-white md:text-2xl">
            Tidak menemukan jenis usaha Anda?
          </h3>
          <p className="mt-1 text-sm text-emerald-100">
            WarungSpace fleksibel untuk hampir semua jenis UMKM. Coba gratis dan
            sesuaikan sendiri.
          </p>
          <Button
            onClick={onEnterApp}
            className="mt-4 rounded-xl bg-white font-semibold text-emerald-800 hover:bg-emerald-50"
          >
            Coba Gratis Sekarang
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </section>

      <footer className="border-t border-slate-200 bg-slate-900 py-8">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-4 md:flex-row md:px-8">
          <p className="font-serif text-sm font-bold text-white">WarungSpace</p>
          <p className="text-xs text-slate-400">
            Devolope by{" "}
            <a
              href="https://awdev.my.id"
              target="_blank"
              rel="noreferrer"
              className="font-semibold text-emerald-400 transition hover:text-emerald-300"
            >
              AWD
            </a>
          </p>
        </div>
      </footer>
    </div>
  );
}