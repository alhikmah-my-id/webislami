import { useEffect, useMemo, useState } from "react";
import {
  Zap,
  Wallet,
  Clock,
  CheckCircle2,
  XCircle,
  Loader2,
  ShieldCheck,
  TrendingUp,
  AlertTriangle,
  Banknote,
  Bell,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAudit } from "@/lib/audit-context";
import {
  INITIAL_CLAIMS,
  CHANNEL_META,
  formatRupiah,
  type Claim,
  type DisbursementStatus,
} from "@/lib/disbursement-data";
import { disbursementEngine, playMoneyInChime } from "@/lib/disbursement-engine";

const STATUS_STYLE: Record<DisbursementStatus, string> = {
  PENDING: "bg-amber-100 text-amber-700",
  QUEUED: "bg-sky-100 text-sky-700",
  SUCCESS: "bg-emerald-100 text-emerald-700",
  FAILED: "bg-rose-100 text-rose-700",
};

function StatusPill({ status }: { status: DisbursementStatus }) {
  const icon =
    status === "SUCCESS" ? (
      <CheckCircle2 className="h-3 w-3" />
    ) : status === "FAILED" ? (
      <XCircle className="h-3 w-3" />
    ) : status === "QUEUED" ? (
      <Loader2 className="h-3 w-3 animate-spin" />
    ) : (
      <Clock className="h-3 w-3" />
    );
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold ${STATUS_STYLE[status]}`}
    >
      {icon}
      {status}
    </span>
  );
}

export default function DisbursementPage() {
  const { log } = useAudit();
  const [claims, setClaims] = useState<Claim[]>(INITIAL_CLAIMS);
  const [toast, setToast] = useState<{ name: string; amount: number } | null>(null);
  const [filter, setFilter] = useState<"ALL" | "PENDING" | "DONE">("ALL");

  useEffect(() => {
    const off = disbursementEngine.on((updated) => {
      setClaims((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));

      if (updated.status === "SUCCESS") {
        playMoneyInChime();
        setToast({ name: updated.memberName, amount: updated.amount });
        setTimeout(() => setToast(null), 4200);
        log(
          "AUTO_DISBURSEMENT",
          `Payout ${formatRupiah(updated.amount)} ke ${updated.channelCode} ${updated.accountNumber} sukses (${updated.ref})`,
          "system"
        );
      }
      if (updated.status === "FAILED") {
        log(
          "AUTO_DISBURSEMENT",
          `Payout ${updated.ref} GAGAL — ${updated.errorMessage}`,
          "system"
        );
      }
    });
    return off;
  }, [log]);

  const pending = claims.filter((c) => c.status === "PENDING");
  const queued = claims.filter((c) => c.status === "QUEUED");
  const done = claims.filter(
    (c) => c.status === "SUCCESS" || c.status === "FAILED"
  );

  const totalPending = pending.reduce((s, c) => s + c.amount, 0);
  const totalPaid = claims
    .filter((c) => c.status === "SUCCESS")
    .reduce((s, c) => s + c.amount, 0);

  const visible = useMemo(() => {
    if (filter === "PENDING")
      return claims.filter((c) => c.status === "PENDING" || c.status === "QUEUED");
    if (filter === "DONE") return done;
    return claims;
  }, [claims, filter, done]);

  function approve(claim: Claim) {
    const ok = window.confirm(
      `Setujui & cairkan ${formatRupiah(claim.amount)} ke ${claim.channelCode} (${claim.accountNumber}) atas nama ${claim.memberName}?`
    );
    if (!ok) return;

    const queuedClaim = disbursementEngine.initiate(claim);
    setClaims((prev) => prev.map((c) => (c.id === claim.id ? queuedClaim : c)));
    log(
      "DISBURSEMENT_INITIATED",
      `Payout ${claim.type} ${formatRupiah(claim.amount)} diantrekan ke ${claim.channelCode} (${claim.ref})`,
      "owner@warungspace.id"
    );
  }

  return (
    <div className="space-y-6">
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-3 rounded-2xl border border-emerald-200 bg-white px-4 py-3 shadow-xl">
          <div className="grid h-10 w-10 place-items-center rounded-xl bg-emerald-100">
            <Bell className="h-5 w-5 text-emerald-600" />
          </div>
          <div>
            <p className="text-sm font-bold text-slate-900">Uang Masuk! 🎉</p>
            <p className="text-xs text-slate-500">
              {formatRupiah(toast.amount)} terkirim ke {toast.name}
            </p>
          </div>
        </div>
      )}

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-xl bg-emerald-600 text-white">
            <Zap className="h-5 w-5" />
          </div>
          <div>
            <h2 className="font-serif text-xl font-bold text-slate-900">
              Auto-Disbursement Center
            </h2>
            <p className="text-xs text-slate-500">
              Pencairan gaji & reimbursement langsung ke e-wallet member.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs font-semibold text-emerald-700">
          <ShieldCheck className="h-4 w-4" />
          Gateway: Xendit Payouts · Balance cukup
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card className="rounded-2xl border-amber-200 bg-amber-50 shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-2 text-amber-700">
              <Clock className="h-4 w-4" />
              <p className="text-xs font-semibold uppercase tracking-wider">
                Menunggu Approval
              </p>
            </div>
            <p className="mt-2 font-serif text-2xl font-bold text-slate-900">
              {formatRupiah(totalPending)}
            </p>
            <p className="text-xs text-slate-500">{pending.length} klaim tertunda</p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-sky-200 bg-sky-50 shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-2 text-sky-700">
              <Loader2 className="h-4 w-4" />
              <p className="text-xs font-semibold uppercase tracking-wider">
                Diantrekan Gateway
              </p>
            </div>
            <p className="mt-2 font-serif text-2xl font-bold text-slate-900">
              {queued.length}
            </p>
            <p className="text-xs text-slate-500">Menunggu webhook konfirmasi</p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-emerald-200 bg-emerald-50 shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-2 text-emerald-700">
              <TrendingUp className="h-4 w-4" />
              <p className="text-xs font-semibold uppercase tracking-wider">
                Total Tercairkan
              </p>
            </div>
            <p className="mt-2 font-serif text-2xl font-bold text-slate-900">
              {formatRupiah(totalPaid)}
            </p>
            <p className="text-xs text-slate-500">
              {done.filter((c) => c.status === "SUCCESS").length} payout sukses
            </p>
          </CardContent>
        </Card>
      </div>

      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardContent className="p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Banknote className="h-4 w-4 text-slate-500" />
              <h3 className="text-sm font-bold text-slate-900">Approval Center</h3>
            </div>
            <div className="flex gap-1 rounded-xl bg-slate-100 p-1">
              {(["ALL", "PENDING", "DONE"] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
                    filter === f
                      ? "bg-white text-emerald-700 shadow-sm"
                      : "text-slate-500 hover:text-slate-700"
                  }`}
                >
                  {f === "ALL" ? "Semua" : f === "PENDING" ? "Tertunda" : "Selesai"}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-4 overflow-x-auto">
            <table className="w-full min-w-3xl border-collapse text-left text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-xs uppercase tracking-wider text-slate-400">
                  <th className="py-3 pr-4 font-semibold">Ref</th>
                  <th className="py-3 pr-4 font-semibold">Member</th>
                  <th className="py-3 pr-4 font-semibold">Nominal</th>
                  <th className="py-3 pr-4 font-semibold">Tujuan</th>
                  <th className="py-3 pr-4 font-semibold">Status</th>
                  <th className="py-3 font-semibold">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {visible.map((c) => {
                  const meta = CHANNEL_META[c.channelCode];
                  return (
                    <tr
                      key={c.id}
                      className="border-b border-slate-100 transition hover:bg-slate-50"
                    >
                      <td className="py-3 pr-4">
                        <p className="font-mono text-xs text-slate-500">#{c.id}</p>
                        <Badge className="mt-1 rounded-full bg-slate-100 text-slate-600 hover:bg-slate-100">
                          {c.type}
                        </Badge>
                      </td>
                      <td className="py-3 pr-4">
                        <p className="font-medium text-slate-800">{c.memberName}</p>
                        <p className="text-xs text-slate-400">{c.memberEmail}</p>
                      </td>
                      <td className="py-3 pr-4 font-mono font-bold text-emerald-700">
                        {formatRupiah(c.amount)}
                      </td>
                      <td className="py-3 pr-4">
                        <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-slate-50 px-2.5 py-0.5 text-xs font-semibold text-slate-700">
                          {meta?.emoji ?? c.channelEmoji} {c.channelCode}
                        </span>
                        <p className="mt-0.5 font-mono text-xs text-slate-500">
                          {c.accountNumber}
                        </p>
                      </td>
                      <td className="py-3 pr-4">
                        <StatusPill status={c.status} />
                        {c.status === "FAILED" && c.errorMessage && (
                          <p className="mt-1 flex items-center gap-1 text-xs text-rose-600">
                            <AlertTriangle className="h-3 w-3" />
                            {c.errorMessage}
                          </p>
                        )}
                      </td>
                      <td className="py-3">
                        {c.status === "PENDING" ? (
                          <Button
                            onClick={() => approve(c)}
                            className="rounded-lg bg-emerald-600 text-xs font-bold text-white hover:bg-emerald-700"
                          >
                            <Zap className="mr-1.5 h-3.5 w-3.5" />
                            Approve & Cairkan
                          </Button>
                        ) : c.status === "QUEUED" ? (
                          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-sky-600">
                            <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            Memproses…
                          </span>
                        ) : (
                          <span className="text-xs text-slate-400">
                            {c.gatewayRefId ?? "—"}
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {visible.length === 0 && (
            <div className="mt-4 flex flex-col items-center rounded-xl border border-dashed border-slate-200 py-10">
              <Wallet className="h-8 w-8 text-slate-300" />
              <p className="mt-2 text-sm font-medium text-slate-500">
                Tidak ada klaim pada filter ini
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="rounded-2xl border-slate-200 bg-slate-50 shadow-sm">
        <CardContent className="p-5">
          <div className="flex items-start gap-2">
            <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
            <div>
              <p className="text-xs font-bold text-slate-800">
                Prosedur Keamanan Payout
              </p>
              <ul className="mt-1 list-inside list-disc space-y-0.5 text-xs text-slate-500">
                <li>Approval ganda (maker-checker) untuk nominal &gt; Rp 5.000.000</li>
                <li>Validasi nama pemilik akun via API sebelum instruksi dikirim</li>
                <li>Webhook signature diverifikasi; status hanya berubah dari callback resmi</li>
                <li>Semua aksi tercatat di fintech_audit_logs dengan IP & payload</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}