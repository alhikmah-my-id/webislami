import { FolderKanban, CheckSquare } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { PROJECTS } from "@/lib/erp-data";

const rupiah = (n: number) => "Rp " + n.toLocaleString("id-ID");

export default function ProjectsPage() {
  return (
    <div className="space-y-6">
      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardContent className="p-5">
          <p className="text-xs text-slate-500">
            Task, timesheet, dan anggaran projek dengan profitabilitas terukur.
          </p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {PROJECTS.map((p) => {
          const profit = p.budget - p.spent;
          const margin = Math.round((profit / p.budget) * 100);
          return (
            <Card key={p.id} className="rounded-2xl border-slate-200 shadow-sm">
              <CardHeader className="border-b border-slate-100 pb-4">
                <CardTitle className="flex items-center gap-2 text-base text-slate-900">
                  <FolderKanban className="h-4 w-4 text-emerald-700" />
                  {p.name}
                </CardTitle>
                <p className="text-xs text-slate-500">
                  {p.id} · Klien: {p.client}
                </p>
              </CardHeader>
              <CardContent className="space-y-4 pt-4">
                <div>
                  <div className="mb-1 flex items-center justify-between text-xs">
                    <span className="font-medium text-slate-600">Progres</span>
                    <span className="font-semibold text-slate-800">{p.progress}%</span>
                  </div>
                  <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-100">
                    <div
                      className="h-full rounded-full bg-emerald-500"
                      style={{ width: `${p.progress}%` }}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="rounded-xl bg-slate-50 p-3">
                    <p className="text-xs text-slate-500">Anggaran</p>
                    <p className="text-sm font-semibold text-slate-800">{rupiah(p.budget)}</p>
                  </div>
                  <div className="rounded-xl bg-slate-50 p-3">
                    <p className="text-xs text-slate-500">Terpakai</p>
                    <p className="text-sm font-semibold text-slate-800">{rupiah(p.spent)}</p>
                  </div>
                </div>

                <div className="flex items-center justify-between rounded-xl bg-emerald-50 p-3">
                  <div className="flex items-center gap-2 text-emerald-700">
                    <CheckSquare className="h-4 w-4" />
                    <span className="text-xs font-medium">
                      {p.tasksDone}/{p.tasksTotal} task selesai
                    </span>
                  </div>
                  <span className="text-sm font-bold text-emerald-700">
                    Margin {margin}%
                  </span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}