import { useEffect, useRef, useState } from "react";
import { Printer, CheckCircle2, Receipt, Store, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { formatRupiah } from "@/lib/disbursement-data";

export interface ReceiptItem {
  name: string;
  quantity: number;
  price: number;
}

export interface ReceiptData {
  invoice_number: string;
  created_at: string;
  cashier_name: string;
  payment_method_type: string;
  total_amount: number;
}

const SAMPLE_ITEMS: ReceiptItem[] = [
  { name: "Kopi Arabika 250g", quantity: 2, price: 45000 },
  { name: "Gula Aren Cair", quantity: 1, price: 28000 },
  { name: "Susu UHT 1L", quantity: 3, price: 21000 },
  { name: "Cup Plastik 50pcs", quantity: 1, price: 35000 },
];

const SAMPLE_DATA: ReceiptData = {
  invoice_number: "INV-2025-0131-0042",
  created_at: new Date().toISOString(),
  cashier_name: "Andi Pratama",
  payment_method_type: "QRIS",
  total_amount: SAMPLE_ITEMS.reduce((s, i) => s + i.price * i.quantity, 0),
};

function ThermalReceipt({
  data,
  items,
}: {
  data: ReceiptData;
  items: ReceiptItem[];
}) {
  const totalQty = items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div
      id="thermal-receipt-area"
      className="mx-auto w-full max-w-xs bg-white p-3 font-mono text-xs text-black"
    >
      <div className="mb-3 text-center">
        <h2 className="text-sm font-bold uppercase tracking-wider">
          WARUNGSPACE MART
        </h2>
        <p className="text-xs">Jl. Pemuda No. 123, Semarang</p>
        <p className="text-xs">Telp: 024-1234567</p>
        <p className="my-2 border-b border-dashed border-gray-400" />
      </div>

      <div className="mb-2 space-y-0.5 text-xs">
        <p>No. Nota : {data.invoice_number}</p>
        <p>
          Tanggal&nbsp;&nbsp;:{" "}
          {new Date(data.created_at).toLocaleString("id-ID")}
        </p>
        <p>Kasir&nbsp;&nbsp;&nbsp;&nbsp;: {data.cashier_name || "Sistem ERP"}</p>
        <p>Metode&nbsp;&nbsp;&nbsp;: {data.payment_method_type} (MIDTRANS)</p>
        <p>
          Status&nbsp;&nbsp;&nbsp;: <span className="font-bold">LUNAS</span>
        </p>
        <p className="my-2 border-b border-dashed border-gray-400" />
      </div>

      <div className="space-y-2 text-xs">
        {items.map((item, index) => (
          <div key={index}>
            <div className="flex justify-between">
              <span className="uppercase">{item.name}</span>
            </div>
            <div className="flex justify-between text-gray-700">
              <span>
                {item.quantity} x {formatRupiah(item.price)}
              </span>
              <span>{formatRupiah(item.price * item.quantity)}</span>
            </div>
          </div>
        ))}
        <p className="my-2 border-b border-dashed border-gray-400" />
      </div>

      <div className="space-y-1 text-xs">
        <div className="flex justify-between">
          <span>TOTAL ITEM:</span>
          <span>{totalQty}</span>
        </div>
        <div className="flex justify-between text-sm font-bold">
          <span>GRAND TOTAL:</span>
          <span>{formatRupiah(data.total_amount)}</span>
        </div>
        <div className="flex justify-between">
          <span>BAYAR (QRIS):</span>
          <span>{formatRupiah(data.total_amount)}</span>
        </div>
        <div className="flex justify-between">
          <span>KEMBALI:</span>
          <span>Rp 0</span>
        </div>
        <p className="my-2 border-b border-dashed border-gray-400" />
      </div>

      <div className="mt-4 space-y-0.5 text-center text-xs">
        <p className="font-bold">TERIMA KASIH</p>
        <p>Barang yang sudah dibeli</p>
        <p>tidak dapat ditukar/dikembalikan</p>
        <p className="mt-2 text-xs text-gray-400">
          Powered by WarungSpace ERP
        </p>
      </div>
    </div>
  );
}

export default function ThermalReceiptPage({ onBack }: { onBack?: () => void }) {
  const [paid, setPaid] = useState(false);
  const [autoPrint, setAutoPrint] = useState(true);
  const [printedAt, setPrintedAt] = useState<string | null>(null);
  const receiptRef = useRef<HTMLDivElement>(null);

  // Simulate the QRIS websocket "PAID" event -> auto print
  useEffect(() => {
    if (!paid || !autoPrint) return;
    const t = setTimeout(() => {
      window.print();
      setPrintedAt(new Date().toLocaleTimeString("id-ID"));
    }, 500);
    return () => clearTimeout(t);
  }, [paid, autoPrint]);

  function handlePrint() {
    window.print();
    setPrintedAt(new Date().toLocaleTimeString("id-ID"));
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-xl bg-emerald-600 text-white">
            <Receipt className="h-5 w-5" />
          </div>
          <div>
            <h2 className="font-serif text-xl font-bold text-slate-900">
              Cetak Struk Thermal
            </h2>
            <p className="text-xs text-slate-500">
              Layout 80mm · auto-print setelah pembayaran QRIS sukses.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {onBack && (
            <Button
              variant="outline"
              onClick={onBack}
              className="rounded-xl border-slate-200 text-xs font-semibold"
            >
              <ArrowLeft className="mr-1.5 h-3.5 w-3.5" />
              Kembali
            </Button>
          )}
          <Badge className="rounded-full bg-emerald-100 text-emerald-700 hover:bg-emerald-100">
            <Store className="mr-1 h-3 w-3" />
            Kasir Aktif
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="rounded-2xl border-slate-200 shadow-sm lg:col-span-2">
          <CardContent className="flex flex-col items-center p-6">
            <p className="mb-3 text-sm font-medium text-slate-500">
              Pratinjau Struk Belanja
            </p>
            <div
              ref={receiptRef}
              className="w-full max-w-xs rounded-xl border border-slate-200 bg-white p-2 shadow-sm"
            >
              <ThermalReceipt data={SAMPLE_DATA} items={SAMPLE_ITEMS} />
            </div>

            <div className="no-print mt-5 flex w-full max-w-xs flex-col gap-3">
              <Button
                onClick={handlePrint}
                className="w-full rounded-xl bg-emerald-600 py-3 font-bold text-white hover:bg-emerald-700"
              >
                <Printer className="mr-2 h-4 w-4" />
                Cetak Struk Fisik
              </Button>
              <Button
                onClick={() => setPaid(true)}
                variant="outline"
                className="w-full rounded-xl border-emerald-200 font-semibold text-emerald-700 hover:bg-emerald-50"
              >
                <CheckCircle2 className="mr-2 h-4 w-4" />
                Simulasikan Pembayaran QRIS Sukses
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="no-print space-y-4">
          <Card className="rounded-2xl border-emerald-200 bg-emerald-50 shadow-sm">
            <CardContent className="p-5">
              <p className="text-xs font-semibold uppercase tracking-wider text-emerald-700">
                Status Pembayaran
              </p>
              <div className="mt-2 flex items-center gap-2">
                {paid ? (
                  <>
                    <CheckCircle2 className="h-5 w-5 text-emerald-600" />
                    <span className="font-bold text-emerald-800">PAID</span>
                  </>
                ) : (
                  <>
                    <span className="h-3 w-3 animate-ping rounded-full bg-amber-500" />
                    <span className="font-bold text-amber-700">PENDING</span>
                  </>
                )}
              </div>
              <p className="mt-2 text-xs text-slate-600">
                {paid
                  ? "Webhook Midtrans diterima. Struk siap dicetak."
                  : "Menunggu notifikasi webhook dari payment gateway."}
              </p>
            </CardContent>
          </Card>

          <Card className="rounded-2xl border-slate-200 shadow-sm">
            <CardContent className="p-5">
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Pengaturan Cetak
              </p>
              <label className="mt-3 flex cursor-pointer items-center justify-between gap-3">
                <span className="text-sm font-medium text-slate-700">
                  Auto-print saat PAID
                </span>
                <input
                  type="checkbox"
                  checked={autoPrint}
                  onChange={(e) => setAutoPrint(e.target.checked)}
                  className="h-4 w-4 accent-emerald-600"
                />
              </label>
              <div className="mt-3 rounded-xl bg-slate-50 p-3 text-xs text-slate-500">
                <p>Ukuran kertas: 80mm</p>
                <p>Font: monospace 12px</p>
                {printedAt && (
                  <p className="mt-1 font-semibold text-emerald-700">
                    Terakhir dicetak: {printedAt}
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}