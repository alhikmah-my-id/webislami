import { ArrowLeft, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import FeatureCatalog from "@/components/FeatureCatalog";

interface FeaturesPageProps {
  onBack: () => void;
  onEnterApp: () => void;
}

export default function FeaturesPage({ onBack, onEnterApp }: FeaturesPageProps) {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <header className="sticky top-0 z-20 border-b border-emerald-900/20 bg-emerald-950/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3 md:px-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-emerald-100 transition hover:bg-emerald-800/60"
          >
            <ArrowLeft className="h-4 w-4" />
            Beranda
          </button>
          <Button
            onClick={onEnterApp}
            className="rounded-xl bg-emerald-500 font-semibold text-white hover:bg-emerald-400"
          >
            Coba Gratis
          </Button>
        </div>
      </header>

      <section className="bg-gradient-to-br from-emerald-950 via-emerald-900 to-teal-900">
        <div className="mx-auto max-w-6xl px-4 py-12 md:px-8 md:py-16">
          <span className="inline-flex items-center gap-2 rounded-full bg-emerald-500/15 px-3 py-1 text-xs font-semibold text-emerald-200">
            <Sparkles className="h-3.5 w-3.5" />
            Katalog Fitur Lengkap
          </span>
          <h1 className="mt-4 font-serif text-3xl font-bold text-white md:text-4xl">
            Semua fitur WarungSpace
          </h1>
          <p className="mt-3 max-w-2xl text-sm text-emerald-100/90 md:text-base">
            Dari kasir cepat, stok rapi, kasbon terkelola, sampai restoran, marketplace,
            dan sistem mitra — jelajahi seluruh modul dalam satu tempat.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-10 md:px-8 md:py-14">
        <FeatureCatalog />
      </section>

      <footer className="border-t border-slate-200 bg-slate-900 py-8">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-4 md:flex-row md:px-8">
          <p className="font-serif text-sm font-bold text-white">WarungSpace</p>
          <p className="text-xs text-slate-400">
            Devolope by{" "}
            <a
              href="https://awdev.my.id"
              target="_blank"
              rel="noreferrer"
              className="font-semibold text-emerald-400 transition hover:text-emerald-300"
            >
              AWD
            </a>
          </p>
        </div>
      </footer>
    </div>
  );
}