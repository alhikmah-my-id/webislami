import { useState } from "react";
import { Plus, Minus, Trash2, ShoppingCart } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { useStore } from "@/lib/store";

const rupiah = (n: number) => "Rp " + n.toLocaleString("id-ID");

export default function PosPage() {
  const { products, cart, addToCart, decrementCart, removeFromCart, checkout } = useStore();
  const [customer, setCustomer] = useState("");
  const [method, setMethod] = useState<"Tunai" | "Transfer" | "Utang">("Tunai");

  const items = cart.map((line) => {
    const p = products.find((x) => x.id === line.productId)!;
    return { ...p, qty: line.qty, subtotal: p.price * line.qty };
  });
  const total = items.reduce((s, i) => s + i.subtotal, 0);

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-5">
      <Card className="rounded-2xl border-slate-200 shadow-sm lg:col-span-3">
        <CardHeader className="border-b border-slate-100 pb-4">
          <CardTitle className="text-base text-slate-900">Pilih Produk</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 gap-3 pt-4 sm:grid-cols-2">
          {products.map((p) => (
            <button
              key={p.id}
              onClick={() => addToCart(p.id)}
              disabled={p.stock <= 0}
              className="flex items-center justify-between rounded-xl border border-slate-100 bg-slate-50/60 p-4 text-left transition hover:border-emerald-300 hover:bg-emerald-50 disabled:cursor-not-allowed disabled:opacity-40"
            >
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold text-slate-800">{p.name}</p>
                <p className="text-xs text-slate-500">
                  {rupiah(p.price)} / {p.unit} · stok {p.stock}
                </p>
              </div>
              <div className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-emerald-600 text-white">
                <Plus className="h-4 w-4" />
              </div>
            </button>
          ))}
        </CardContent>
      </Card>

      <Card className="rounded-2xl border-slate-200 shadow-sm lg:col-span-2">
        <CardHeader className="flex flex-row items-center justify-between border-b border-slate-100 pb-4">
          <CardTitle className="text-base text-slate-900">Keranjang</CardTitle>
          <Badge className="rounded-full bg-emerald-100 text-emerald-700 hover:bg-emerald-100">
            {items.length} item
          </Badge>
        </CardHeader>
        <CardContent className="space-y-3 pt-4">
          {items.length === 0 ? (
            <div className="flex flex-col items-center gap-2 py-10 text-center">
              <div className="grid h-12 w-12 place-items-center rounded-2xl bg-slate-100 text-slate-400">
                <ShoppingCart className="h-6 w-6" />
              </div>
              <p className="text-sm font-medium text-slate-600">Keranjang masih kosong</p>
              <p className="text-xs text-slate-400">Pilih produk di sebelah kiri</p>
            </div>
          ) : (
            items.map((i) => (
              <div
                key={i.id}
                className="flex items-center gap-3 rounded-xl border border-slate-100 bg-slate-50/60 p-3"
              >
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold text-slate-800">{i.name}</p>
                  <p className="text-xs text-slate-500">{rupiah(i.subtotal)}</p>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => decrementCart(i.id)}
                    className="grid h-7 w-7 place-items-center rounded-lg bg-white text-slate-600 shadow-sm transition hover:bg-slate-100"
                  >
                    <Minus className="h-3.5 w-3.5" />
                  </button>
                  <span className="w-6 text-center text-sm font-semibold text-slate-800">{i.qty}</span>
                  <button
                    onClick={() => addToCart(i.id)}
                    className="grid h-7 w-7 place-items-center rounded-lg bg-white text-slate-600 shadow-sm transition hover:bg-slate-100"
                  >
                    <Plus className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={() => removeFromCart(i.id)}
                    className="grid h-7 w-7 place-items-center rounded-lg bg-rose-50 text-rose-600 transition hover:bg-rose-100"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}

          <div className="space-y-3">
            <Input
              value={customer}
              onChange={(e) => setCustomer(e.target.value)}
              placeholder="Nama pelanggan (opsional)"
              className="rounded-xl"
            />
            <div className="flex gap-2">
              {(["Tunai", "Transfer", "Utang"] as const).map((m) => (
                <button
                  key={m}
                  onClick={() => setMethod(m)}
                  className={`flex-1 rounded-lg py-2 text-xs font-semibold transition ${
                    method === m
                      ? "bg-emerald-600 text-white"
                      : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-2 rounded-xl bg-emerald-900 p-4 text-white">
            <div className="flex items-center justify-between">
              <span className="text-sm text-emerald-200">Total Bayar</span>
              <span className="font-serif text-2xl font-bold">{rupiah(total)}</span>
            </div>
            <Button
              disabled={items.length === 0}
              onClick={() => {
                checkout(method, customer);
                setCustomer("");
              }}
              className="mt-4 w-full rounded-xl bg-emerald-500 py-5 font-semibold text-white hover:bg-emerald-400 disabled:opacity-40"
            >
              Proses Pembayaran
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}