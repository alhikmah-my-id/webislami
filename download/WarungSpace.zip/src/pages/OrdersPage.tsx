import { PackageCheck, Truck, Search } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ORDERS } from "@/lib/marketplace-data";
import { useState } from "react";

const rupiah = (n: number) => "Rp " + n.toLocaleString("id-ID");

const statusTone: Record<string, string> = {
  Baru: "bg-sky-100 text-sky-700 hover:bg-sky-100",
  Diproses: "bg-amber-100 text-amber-700 hover:bg-amber-100",
  Dikirim: "bg-indigo-100 text-indigo-700 hover:bg-indigo-100",
  Selesai: "bg-emerald-100 text-emerald-700 hover:bg-emerald-100",
  Batal: "bg-rose-100 text-rose-700 hover:bg-rose-100",
};

const CHANNEL_TONE: Record<string, string> = {
  Shopee: "bg-orange-100 text-orange-700",
  Tokopedia: "bg-emerald-100 text-emerald-700",
  Lazada: "bg-sky-100 text-sky-700",
  WooCommerce: "bg-indigo-100 text-indigo-700",
};

export default function OrdersPage() {
  const [q, setQ] = useState("");
  const filtered = ORDERS.filter(
    (o) =>
      o.id.toLowerCase().includes(q.toLowerCase()) ||
      o.customer.toLowerCase().includes(q.toLowerCase()) ||
      o.channel.toLowerCase().includes(q.toLowerCase())
  );

  const counts = ORDERS.reduce<Record<string, number>>((acc, o) => {
    acc[o.status] = (acc[o.status] ?? 0) + 1;
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-5">
        {(["Baru", "Diproses", "Dikirim", "Selesai", "Batal"] as const).map((s) => (
          <Card key={s} className="rounded-2xl border-slate-200 shadow-sm">
            <CardContent className="p-4">
              <p className="text-xs font-medium text-slate-500">{s}</p>
              <p className="mt-1 font-serif text-xl font-bold text-slate-900">
                {counts[s] ?? 0}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardHeader className="flex flex-col gap-3 border-b border-slate-100 pb-4 sm:flex-row sm:items-center sm:justify-between">
          <CardTitle className="flex items-center gap-2 text-base text-slate-900">
            <PackageCheck className="h-4 w-4 text-emerald-700" />
            Pesanan Semua Channel
          </CardTitle>
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Cari invoice / pelanggan"
              className="rounded-xl pl-9"
            />
          </div>
        </CardHeader>
        <CardContent className="space-y-3 pt-4">
          {filtered.length === 0 ? (
            <p className="py-10 text-center text-sm text-slate-500">
              Tidak ada pesanan yang cocok.
            </p>
          ) : (
            filtered.map((o) => (
              <div
                key={o.id}
                className="flex flex-col gap-3 rounded-xl border border-slate-100 bg-slate-50/60 p-4 lg:flex-row lg:items-center lg:justify-between"
              >
                <div className="min-w-0 lg:w-1/4">
                  <div className="flex items-center gap-2">
                    <p className="truncate text-sm font-semibold text-slate-800">{o.id}</p>
                    <span
                      className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                        CHANNEL_TONE[o.channel] ?? "bg-slate-100 text-slate-600"
                      }`}
                    >
                      {o.channel}
                    </span>
                  </div>
                  <p className="mt-1 text-xs text-slate-500">
                    {o.customer} · {o.items} item
                  </p>
                </div>

                <div className="flex items-center gap-2 text-xs text-slate-600 lg:w-1/4">
                  <Truck className="h-3.5 w-3.5 text-slate-400" />
                  <span>{o.courier}</span>
                  {o.tracking !== "-" && (
                    <span className="font-mono text-slate-500">({o.tracking})</span>
                  )}
                </div>

                <div className="flex items-center gap-3 lg:w-1/4 lg:justify-end">
                  <span className="text-sm font-semibold text-slate-800">{rupiah(o.total)}</span>
                  <Badge className={`rounded-full ${statusTone[o.status]}`}>{o.status}</Badge>
                </div>
              </div>
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
}