import { ChefHat, Flame, Wine, Snowflake } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { KITCHEN_TICKETS } from "@/lib/restaurant-data";

const STATIONS = [
  { id: "Hot Kitchen", icon: Flame, accent: "text-rose-600 bg-rose-50" },
  { id: "Cold Kitchen", icon: Snowflake, accent: "text-sky-600 bg-sky-50" },
  { id: "Bar", icon: Wine, accent: "text-amber-600 bg-amber-50" },
] as const;

const statusTone: Record<string, string> = {
  Antrian: "bg-slate-100 text-slate-700 hover:bg-slate-100",
  Dimasak: "bg-amber-100 text-amber-700 hover:bg-amber-100",
  Siap: "bg-emerald-100 text-emerald-700 hover:bg-emerald-100",
};

export default function KitchenPage() {
  return (
    <div className="space-y-6">
      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardContent className="flex items-center gap-3 p-5">
          <div className="grid h-11 w-11 place-items-center rounded-xl bg-emerald-50 text-emerald-700">
            <ChefHat className="h-5 w-5" />
          </div>
          <p className="text-xs text-slate-500">
            Pesanan dikelompokkan per station. Pantau status agar koordinasi kasir, pelayan,
            dan dapur lebih rapi.
          </p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {STATIONS.map((s) => {
          const Icon = s.icon;
          const tickets = KITCHEN_TICKETS.filter((t) => t.station === s.id);
          return (
            <Card key={s.id} className="rounded-2xl border-slate-200 shadow-sm">
              <CardHeader className="border-b border-slate-100 pb-4">
                <CardTitle className="flex items-center gap-2 text-base text-slate-900">
                  <span className={`grid h-8 w-8 place-items-center rounded-lg ${s.accent}`}>
                    <Icon className="h-4 w-4" />
                  </span>
                  {s.id}
                  <span className="ml-auto rounded-full bg-slate-100 px-2 py-0.5 text-xs font-medium text-slate-600">
                    {tickets.length}
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 pt-4">
                {tickets.length === 0 ? (
                  <p className="py-8 text-center text-xs text-slate-400">Tidak ada pesanan.</p>
                ) : (
                  tickets.map((t) => (
                    <div
                      key={t.id}
                      className="rounded-xl border border-slate-100 bg-slate-50/60 p-3"
                    >
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-semibold text-slate-800">
                          Meja {t.table}
                        </p>
                        <Badge className={`rounded-full text-xs ${statusTone[t.status]}`}>
                          {t.status}
                        </Badge>
                      </div>
                      <p className="mt-1 text-xs text-slate-500">
                        {t.id} · {t.minutes} menit lalu
                      </p>
                      <ul className="mt-2 space-y-1">
                        {t.items.map((it) => (
                          <li key={it} className="text-xs text-slate-700">
                            • {it}
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}