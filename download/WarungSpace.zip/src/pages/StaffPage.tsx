import { useState } from "react";
import { Camera, MapPin, Clock, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";

export default function StaffPage() {
  const [pin, setPin] = useState("");
  const [clockedIn, setClockedIn] = useState(false);
  const [time, setTime] = useState<string | null>(null);

  const handleClock = () => {
    if (pin.length !== 6) return;
    setClockedIn(true);
    setTime(new Date().toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" }));
  };

  return (
    <div className="space-y-6">
      <header className="rounded-2xl bg-gradient-to-br from-amber-600 to-amber-800 p-6 text-amber-50 shadow-md md:p-8">
        <div className="flex items-center gap-2 text-amber-200">
          <Clock className="h-4 w-4" />
          <span className="text-xs font-semibold uppercase tracking-widest">Staff / Kasir</span>
        </div>
        <h1 className="mt-2 font-serif text-2xl font-bold md:text-3xl">Absensi Karyawan</h1>
        <p className="mt-1 text-sm text-amber-100">
          Clock in dengan PIN + verifikasi GPS & swafoto.
        </p>
      </header>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardHeader className="border-b border-slate-100 pb-4">
            <CardTitle className="text-base text-slate-900">Clock In</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 pt-4">
            <div>
              <label className="text-xs font-medium text-slate-500">PIN Karyawan (6 digit)</label>
              <Input
                value={pin}
                onChange={(e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 6))}
                placeholder="••••••"
                inputMode="numeric"
                className="mt-1 rounded-xl text-center text-lg tracking-widest"
              />
            </div>

            <div className="flex items-center gap-3 rounded-xl bg-slate-50 px-3 py-3">
              <div className="grid h-9 w-9 place-items-center rounded-lg bg-sky-100 text-sky-700">
                <MapPin className="h-4 w-4" />
              </div>
              <div>
                <p className="text-xs text-slate-500">Lokasi terdeteksi</p>
                <p className="text-sm font-medium text-slate-800">-6.2000, 106.8166 · Toko</p>
              </div>
            </div>

            <div className="flex items-center gap-3 rounded-xl bg-slate-50 px-3 py-3">
              <div className="grid h-9 w-9 place-items-center rounded-lg bg-emerald-100 text-emerald-700">
                <Camera className="h-4 w-4" />
              </div>
              <div>
                <p className="text-xs text-slate-500">Swafoto</p>
                <p className="text-sm font-medium text-slate-800">Kamera siap</p>
              </div>
            </div>

            <Button
              onClick={handleClock}
              disabled={pin.length !== 6 || clockedIn}
              className="w-full rounded-xl bg-amber-600 py-6 text-base font-semibold hover:bg-amber-700"
            >
              {clockedIn ? "Sudah Clock In" : "Clock In Sekarang"}
            </Button>
          </CardContent>
        </Card>

        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardHeader className="border-b border-slate-100 pb-4">
            <CardTitle className="text-base text-slate-900">Status Hari Ini</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 pt-4">
            {clockedIn ? (
              <div className="flex items-center gap-3 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-4">
                <CheckCircle2 className="h-5 w-5 text-emerald-600" />
                <div>
                  <p className="text-sm font-semibold text-emerald-800">Hadir</p>
                  <p className="text-xs text-emerald-700">Clock in pukul {time}</p>
                </div>
              </div>
            ) : (
              <div className="rounded-xl border border-dashed border-slate-200 px-4 py-8 text-center">
                <p className="text-sm text-slate-400">Belum ada absensi hari ini.</p>
              </div>
            )}

            <div className="space-y-2">
              <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">
                Riwayat Minggu Ini
              </p>
              {[
                { d: "Senin", s: "Hadir" },
                { d: "Selasa", s: "Hadir" },
                { d: "Rabu", s: "Hadir" },
                { d: "Kamis", s: "Terlambat" },
              ].map((r) => (
                <div
                  key={r.d}
                  className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2"
                >
                  <span className="text-sm text-slate-700">{r.d}</span>
                  <Badge
                    className={`rounded-full ${
                      r.s === "Hadir"
                        ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100"
                        : "bg-amber-100 text-amber-700 hover:bg-amber-100"
                    }`}
                  >
                    {r.s}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}