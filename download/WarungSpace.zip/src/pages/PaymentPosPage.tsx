import { useMemo, useRef, useState } from "react";
import {
  ScanLine,
  Trash2,
  Plus,
  Minus,
  Printer,
  QrCode,
  Wallet,
  Landmark,
  ShieldCheck,
  Search,
  Wifi,
  WifiOff,
  Radio,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import PaymentModal from "@/components/PaymentModal";
import { useAudit } from "@/lib/audit-context";
import { realtime } from "@/lib/realtime";
import {
  PRODUCTS,
  EWALLETS,
  BANKS,
  formatRupiah,
  generateInvoice,
  generateQrisPayload,
  type CartItem,
} from "@/lib/payment-data";

export default function PaymentPosPage() {
  const { log } = useAudit();
  const [barcode, setBarcode] = useState("");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [notFound, setNotFound] = useState(false);
  const [invoice, setInvoice] = useState("");
  const [qrisPayload, setQrisPayload] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [paid, setPaid] = useState(false);
  const [lastPaidTotal, setLastPaidTotal] = useState(0);
  const [connected, setConnected] = useState(realtime.isConnected());
  const inputRef = useRef<HTMLInputElement>(null);

  useMemo(() => {
    realtime.onConnectionChange(setConnected);
    return null;
  }, []);

  const subtotal = useMemo(
    () => cart.reduce((s, i) => s + i.price * i.qty, 0),
    [cart]
  );
  const tax = Math.round(subtotal * 0.11);
  const total = subtotal + tax;

  function addProduct(barcodeValue: string) {
    const found = PRODUCTS.find((p) => p.barcode === barcodeValue.trim());
    if (!found) {
      setNotFound(true);
      setTimeout(() => setNotFound(false), 1800);
      return;
    }
    setCart((prev) => {
      const existing = prev.find((i) => i.id === found.id);
      if (existing) {
        return prev.map((i) => (i.id === found.id ? { ...i, qty: i.qty + 1 } : i));
      }
      return [...prev, { ...found, qty: 1 }];
    });
    log("SCAN_PRODUCT", `Scan barcode ${found.barcode} — ${found.name}`, "andi@warungspace.id");
    setBarcode("");
    inputRef.current?.focus();
  }

  function changeQty(id: string, delta: number) {
    setCart((prev) =>
      prev
        .map((i) => (i.id === id ? { ...i, qty: i.qty + delta } : i))
        .filter((i) => i.qty > 0)
    );
  }

  function startPayment() {
    if (cart.length === 0) return;
    const inv = generateInvoice();
    setInvoice(inv);
    setQrisPayload(generateQrisPayload(inv, total));
    setPaid(false);
    setModalOpen(true);
    log("GENERATE_PAYMENT", `QRIS ${formatRupiah(total)} dibuat via MIDTRANS (${inv})`);
  }

  function handlePaid() {
    setPaid(true);
    setLastPaidTotal(total);
    log("PAYMENT_WEBHOOK", `Callback PAID diterima, signature valid (${invoice})`, "system");
  }

  function closeModal() {
    setModalOpen(false);
    if (paid) {
      setCart([]);
      setInvoice("");
      setQrisPayload("");
    }
  }

  function printReceipt() {
    log("PRINT_INVOICE", `Cetak struk ${invoice || "INV-TERAKHIR"} (thermal 58mm)`);
    window.print();
  }

  return (
    <div className="space-y-6">
      <style>{`
        @media print {
          body * { visibility: hidden !important; }
          #thermal-receipt, #thermal-receipt * { visibility: visible !important; }
          #thermal-receipt {
            position: absolute; left: 0; top: 0;
            width: 58mm; padding: 4mm; margin: 0;
            font-family: 'Courier New', monospace; font-size: 11px; color: #000;
          }
          @page { size: 58mm auto; margin: 0; }
        }
      `}</style>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 shadow-sm">
          {connected ? (
            <Wifi className="h-4 w-4 text-emerald-600" />
          ) : (
            <WifiOff className="h-4 w-4 text-rose-600" />
          )}
          <span className="text-xs font-semibold text-slate-700">
            {connected ? "Socket terhubung" : "Socket terputus"}
          </span>
          <button
            onClick={() => (connected ? realtime.simulateDisconnect() : realtime.simulateReconnect())}
            className="rounded-lg bg-slate-100 px-2 py-1 text-xs font-semibold text-slate-600 transition hover:bg-slate-200"
          >
            {connected ? "Simulasi Putus" : "Sambungkan"}
          </button>
        </div>
        <div className="flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs font-semibold text-emerald-700">
          <Radio className="h-4 w-4" />
          Real-time payment listener aktif
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Card className="rounded-2xl border-slate-200 shadow-sm">
            <CardContent className="p-5">
              <div className="flex items-center gap-2">
                <div className="grid h-9 w-9 place-items-center rounded-xl bg-emerald-50 text-emerald-700">
                  <ScanLine className="h-5 w-5" />
                </div>
                <div>
                  <h2 className="text-sm font-bold text-slate-900">
                    Panel Scanner & POS
                  </h2>
                  <p className="text-xs text-slate-500">
                    Arahkan barcode ke scanner, atau ketik kode lalu Enter.
                  </p>
                </div>
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  addProduct(barcode);
                }}
                className="mt-4 flex gap-2"
              >
                <div className="relative flex-1">
                  <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                  <Input
                    ref={inputRef}
                    value={barcode}
                    onChange={(e) => setBarcode(e.target.value)}
                    placeholder="Scan / ketik barcode…"
                    autoFocus
                    className={`pl-9 rounded-xl ${
                      notFound ? "border-rose-400 ring-2 ring-rose-100" : ""
                    }`}
                  />
                </div>
                <Button
                  type="submit"
                  className="rounded-xl bg-emerald-600 font-semibold text-white hover:bg-emerald-700"
                >
                  Tambah
                </Button>
              </form>

              {notFound && (
                <p className="mt-2 text-xs font-medium text-rose-600">
                  Barcode tidak ditemukan. Coba contoh: 8991002101234
                </p>
              )}

              <div className="mt-3 flex flex-wrap gap-2">
                {PRODUCTS.slice(0, 4).map((p) => (
                  <button
                    key={p.id}
                    onClick={() => addProduct(p.barcode)}
                    className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-medium text-slate-600 transition hover:border-emerald-300 hover:bg-emerald-50 hover:text-emerald-700"
                  >
                    {p.barcode}
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-2xl border-slate-200 shadow-sm">
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-bold text-slate-900">Daftar Belanjaan</h2>
                <Badge className="rounded-full bg-emerald-100 text-emerald-700 hover:bg-emerald-100">
                  {cart.reduce((s, i) => s + i.qty, 0)} item
                </Badge>
              </div>

              {cart.length === 0 ? (
                <div className="mt-6 flex flex-col items-center rounded-xl border border-dashed border-slate-200 py-10">
                  <ScanLine className="h-8 w-8 text-slate-300" />
                  <p className="mt-2 text-sm font-medium text-slate-500">
                    Belum ada produk
                  </p>
                  <p className="text-xs text-slate-400">
                    Scan barcode untuk mulai transaksi
                  </p>
                </div>
              ) : (
                <ul className="mt-4 divide-y divide-slate-100">
                  {cart.map((item) => (
                    <li key={item.id} className="flex items-center gap-3 py-3">
                      <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-emerald-50 text-sm font-bold text-emerald-700">
                        {item.name.charAt(0)}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-semibold text-slate-800">
                          {item.name}
                        </p>
                        <p className="text-xs text-slate-500">
                          {item.barcode} · {formatRupiah(item.price)}
                        </p>
                      </div>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => changeQty(item.id, -1)}
                          className="grid h-7 w-7 place-items-center rounded-lg border border-slate-200 text-slate-600 transition hover:bg-slate-50"
                        >
                          <Minus className="h-3.5 w-3.5" />
                        </button>
                        <span className="w-7 text-center text-sm font-semibold text-slate-800">
                          {item.qty}
                        </span>
                        <button
                          onClick={() => changeQty(item.id, 1)}
                          className="grid h-7 w-7 place-items-center rounded-lg border border-slate-200 text-slate-600 transition hover:bg-slate-50"
                        >
                          <Plus className="h-3.5 w-3.5" />
                        </button>
                      </div>
                      <p className="w-24 text-right text-sm font-bold text-slate-900">
                        {formatRupiah(item.price * item.qty)}
                      </p>
                      <button
                        onClick={() => setCart((p) => p.filter((i) => i.id !== item.id))}
                        className="grid h-7 w-7 place-items-center rounded-lg text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="rounded-2xl border-slate-200 shadow-sm">
            <CardContent className="p-5">
              <h2 className="text-sm font-bold text-slate-900">Ringkasan</h2>
              <div className="mt-4 space-y-2 text-sm">
                <div className="flex justify-between text-slate-600">
                  <span>Subtotal</span>
                  <span className="font-medium text-slate-800">
                    {formatRupiah(subtotal)}
                  </span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>PPN 11%</span>
                  <span className="font-medium text-slate-800">{formatRupiah(tax)}</span>
                </div>
                <div className="mt-2 flex justify-between border-t border-slate-100 pt-3">
                  <span className="font-semibold text-slate-900">Total</span>
                  <span className="font-serif text-xl font-bold text-emerald-700">
                    {formatRupiah(total)}
                  </span>
                </div>
              </div>

              <Button
                onClick={startPayment}
                disabled={cart.length === 0}
                className="mt-5 w-full rounded-xl bg-emerald-600 py-5 font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
              >
                <QrCode className="mr-2 h-4 w-4" />
                Bayar via QRIS / Transfer
              </Button>
              <p className="mt-2 text-center text-xs text-slate-400">
                DANA · GoPay · OVO · ShopeePay · BCA · Mandiri · Jago · 50+ lainnya
              </p>
            </CardContent>
          </Card>

          <Card className="rounded-2xl border-slate-200 shadow-sm">
            <CardContent className="p-5">
              <h2 className="text-sm font-bold text-slate-900">
                Metode Pembayaran Didukung
              </h2>

              <p className="mt-3 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-slate-400">
                <Wallet className="h-3.5 w-3.5" /> E-Wallet
              </p>
              <div className="mt-2 grid grid-cols-2 gap-2">
                {EWALLETS.map((w) => (
                  <div
                    key={w.id}
                    className={`flex items-center gap-2 rounded-xl border px-3 py-2 text-xs font-semibold ${w.color}`}
                  >
                    <span>{w.emoji}</span>
                    {w.name}
                  </div>
                ))}
              </div>

              <p className="mt-4 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-slate-400">
                <Landmark className="h-3.5 w-3.5" /> Bank Digital
              </p>
              <div className="mt-2 grid grid-cols-2 gap-2">
                {BANKS.map((b) => (
                  <div
                    key={b.id}
                    className={`flex items-center gap-2 rounded-xl border px-3 py-2 text-xs font-semibold ${b.color}`}
                  >
                    <span>{b.emoji}</span>
                    {b.name}
                  </div>
                ))}
              </div>

              <div className="mt-4 flex items-center gap-2 rounded-xl bg-slate-50 px-3 py-2 text-xs text-slate-500">
                <ShieldCheck className="h-4 w-4 text-emerald-600" />
                Webhook signature diverifikasi otomatis
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-2xl border-slate-200 shadow-sm">
            <CardContent className="p-5">
              <h2 className="text-sm font-bold text-slate-900">Struk Terakhir</h2>
              {paid ? (
                <>
                  <div
                    id="thermal-receipt"
                    className="mt-3 rounded-xl border border-dashed border-slate-300 bg-white p-4 font-mono text-xs text-slate-800"
                  >
                    <div className="text-center">
                      <p className="font-bold">WARUNGSPACE</p>
                      <p>Toko Berkah · Jakarta</p>
                      <p>--------------------------------</p>
                    </div>
                    <p>No : {invoice}</p>
                    <p>Kasir: Andi</p>
                    <p>--------------------------------</p>
                    {cart.length > 0 ? (
                      cart.map((i) => (
                        <div key={i.id} className="flex justify-between">
                          <span>
                            {i.qty}x {i.name.slice(0, 14)}
                          </span>
                          <span>{i.price * i.qty}</span>
                        </div>
                      ))
                    ) : (
                      <p>Transaksi selesai</p>
                    )}
                    <p>--------------------------------</p>
                    <div className="flex justify-between font-bold">
                      <span>TOTAL</span>
                      <span>{lastPaidTotal}</span>
                    </div>
                    <p>Bayar: QRIS (PAID)</p>
                    <p className="mt-2 text-center">Terima kasih 🙏</p>
                  </div>
                  <Button
                    onClick={printReceipt}
                    className="mt-3 w-full rounded-xl bg-slate-900 font-semibold text-white hover:bg-slate-800"
                  >
                    <Printer className="mr-2 h-4 w-4" />
                    Cetak Struk Resmi
                  </Button>
                </>
              ) : (
                <p className="mt-3 rounded-xl border border-dashed border-slate-200 py-6 text-center text-xs text-slate-400">
                  Belum ada transaksi sukses
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      <PaymentModal
        open={modalOpen}
        invoice={invoice}
        total={total}
        qrisPayload={qrisPayload}
        onClose={closeModal}
        onPaid={handlePaid}
      />
    </div>
  );
}