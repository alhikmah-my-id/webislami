import { useState } from "react";
import { ScrollText, Search, ShieldCheck, Printer } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useAudit } from "@/lib/audit-context";

const ACTION_STYLES: Record<string, string> = {
  GENERATE_PAYMENT: "bg-amber-100 text-amber-700",
  PAYMENT_WEBHOOK: "bg-emerald-100 text-emerald-700",
  PRINT_INVOICE: "bg-blue-100 text-blue-700",
  SCAN_PRODUCT: "bg-slate-100 text-slate-700",
};

export default function AuditTrailPage() {
  const { logs, log } = useAudit();
  const [query, setQuery] = useState("");

  const filtered = logs.filter(
    (l) =>
      l.action.toLowerCase().includes(query.toLowerCase()) ||
      l.operator.toLowerCase().includes(query.toLowerCase()) ||
      l.description.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <style>{`
        @media print {
          body * { visibility: hidden !important; }
          #audit-print, #audit-print * { visibility: visible !important; }
          #audit-print { position: absolute; left: 0; top: 0; width: 100%; padding: 12mm; }
          @page { size: A4; margin: 0; }
        }
      `}</style>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-xl bg-slate-900 text-white">
            <ScrollText className="h-5 w-5" />
          </div>
          <div>
            <h2 className="font-serif text-xl font-bold text-slate-900">
              Audit Trail
            </h2>
            <p className="text-xs text-slate-500">
              Log aktivitas sistem untuk kebutuhan audit internal.
            </p>
          </div>
        </div>
        <Button
          onClick={() => {
            log("PRINT_REPORT", "Cetak laporan audit trail (A4)");
            window.print();
          }}
          className="rounded-xl bg-slate-900 font-semibold text-white hover:bg-slate-800"
        >
          <Printer className="mr-2 h-4 w-4" />
          Cetak Laporan
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Total Log
            </p>
            <p className="mt-1 font-serif text-2xl font-bold text-slate-900">
              {logs.length}
            </p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Webhook PAID
            </p>
            <p className="mt-1 font-serif text-2xl font-bold text-emerald-700">
              {logs.filter((l) => l.action === "PAYMENT_WEBHOOK").length}
            </p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Cetak Dokumen
            </p>
            <p className="mt-1 font-serif text-2xl font-bold text-blue-700">
              {logs.filter((l) => l.action.startsWith("PRINT")).length}
            </p>
          </CardContent>
        </Card>
      </div>

      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardContent className="p-5">
          <div className="relative max-w-sm">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Cari aksi, operator, atau detail…"
              className="pl-9 rounded-xl"
            />
          </div>

          <div id="audit-print" className="mt-4 overflow-x-auto">
            <table className="w-full min-w-3xl border-collapse text-left text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-xs uppercase tracking-wider text-slate-400">
                  <th className="py-3 pr-4 font-semibold">Waktu</th>
                  <th className="py-3 pr-4 font-semibold">Operator</th>
                  <th className="py-3 pr-4 font-semibold">Aksi</th>
                  <th className="py-3 pr-4 font-semibold">Detail Perubahan</th>
                  <th className="py-3 font-semibold">IP</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((l) => (
                  <tr
                    key={l.id}
                    className="border-b border-slate-100 transition hover:bg-slate-50"
                  >
                    <td className="whitespace-nowrap py-3 pr-4 font-mono text-xs text-slate-500">
                      {l.timestamp}
                    </td>
                    <td className="whitespace-nowrap py-3 pr-4 text-slate-700">
                      {l.operator}
                    </td>
                    <td className="py-3 pr-4">
                      <Badge
                        className={`rounded-full ${
                          ACTION_STYLES[l.action] ?? "bg-slate-100 text-slate-700"
                        } hover:bg-inherit`}
                      >
                        {l.action}
                      </Badge>
                    </td>
                    <td className="py-3 pr-4 text-slate-600">{l.description}</td>
                    <td className="whitespace-nowrap py-3 font-mono text-xs text-slate-400">
                      {l.ip}
                    </td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={5} className="py-10 text-center text-sm text-slate-400">
                      Tidak ada log yang cocok.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="mt-4 flex items-center gap-2 rounded-xl bg-emerald-50 px-3 py-2 text-xs text-emerald-700">
            <ShieldCheck className="h-4 w-4" />
            Middleware audit otomatis mencatat aksi krusial (generate payment,
            webhook, cetak, scan).
          </div>
        </CardContent>
      </Card>
    </div>
  );
}