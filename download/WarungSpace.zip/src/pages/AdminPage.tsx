import { TrendingUp, Store, Server, Ban, Gift, Activity } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";

const rupiah = (n: number) => "Rp " + n.toLocaleString("id-ID");

interface TenantRow {
  id: string;
  name: string;
  plan: string;
  status: "active" | "expired" | "free_trial";
  until: string;
}

const seed: TenantRow[] = [
  { id: "t1", name: "Toko Berkah Jaya", plan: "Professional", status: "active", until: "2025-07-11" },
  { id: "t2", name: "Warung Bu Siti", plan: "Starter", status: "free_trial", until: "2025-06-18" },
  { id: "t3", name: "Grosir Jaya Abadi", plan: "Enterprise", status: "active", until: "2025-08-02" },
  { id: "t4", name: "Laundry Kilat", plan: "Starter", status: "expired", until: "2025-05-30" },
];

export default function AdminPage() {
  const [tenants, setTenants] = useState<TenantRow[]>(seed);

  const mrr = tenants
    .filter((t) => t.status === "active")
    .reduce((a, t) => a + (t.plan === "Enterprise" ? 199000 : t.plan === "Professional" ? 99000 : 49000), 0);

  const toggleBlock = (id: string) =>
    setTenants((prev) =>
      prev.map((t) =>
        t.id === id
          ? { ...t, status: t.status === "expired" ? "active" : "expired" }
          : t
      )
    );

  const grantTrial = (id: string) =>
    setTenants((prev) =>
      prev.map((t) => (t.id === id ? { ...t, status: "free_trial" } : t))
    );

  const statusStyle: Record<TenantRow["status"], string> = {
    active: "bg-emerald-100 text-emerald-700 hover:bg-emerald-100",
    expired: "bg-rose-100 text-rose-700 hover:bg-rose-100",
    free_trial: "bg-amber-100 text-amber-700 hover:bg-amber-100",
  };

  return (
    <div className="space-y-6">
      <header className="rounded-2xl bg-gradient-to-br from-indigo-700 to-indigo-900 p-6 text-indigo-50 shadow-md md:p-8">
        <div className="flex items-center gap-2 text-indigo-300">
          <Activity className="h-4 w-4" />
          <span className="text-xs font-semibold uppercase tracking-widest">SuperSaaS Admin</span>
        </div>
        <h1 className="mt-2 font-serif text-2xl font-bold md:text-3xl">Panel Pemilik WarungOS</h1>
        <p className="mt-1 text-sm text-indigo-200">
          Pantau MRR, kelola tenant, dan monitor kesehatan server.
        </p>
      </header>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-indigo-100 text-indigo-700">
              <TrendingUp className="h-5 w-5" />
            </div>
            <p className="mt-3 text-xs uppercase tracking-wide text-slate-400">MRR Aktif</p>
            <p className="mt-1 text-lg font-bold text-slate-900">{rupiah(mrr)}</p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-emerald-100 text-emerald-700">
              <Store className="h-5 w-5" />
            </div>
            <p className="mt-3 text-xs uppercase tracking-wide text-slate-400">Total Tenant</p>
            <p className="mt-1 text-lg font-bold text-slate-900">{tenants.length}</p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl border-slate-200 shadow-sm">
          <CardContent className="p-5">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-sky-100 text-sky-700">
              <Server className="h-5 w-5" />
            </div>
            <p className="mt-3 text-xs uppercase tracking-wide text-slate-400">Server Load</p>
            <p className="mt-1 text-lg font-bold text-slate-900">Normal · 34%</p>
          </CardContent>
        </Card>
      </div>

      <Card className="rounded-2xl border-slate-200 shadow-sm">
        <CardHeader className="border-b border-slate-100 pb-4">
          <CardTitle className="text-base text-slate-900">Manajemen Tenant</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y divide-slate-100">
            {tenants.map((t) => (
              <div
                key={t.id}
                className="flex flex-col gap-3 px-6 py-4 sm:flex-row sm:items-center sm:justify-between"
              >
                <div>
                  <p className="text-sm font-semibold text-slate-800">{t.name}</p>
                  <p className="mt-1 text-xs text-slate-500">
                    {t.plan} · s/d {t.until}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className={`rounded-full capitalize ${statusStyle[t.status]}`}>
                    {t.status.replace("_", " ")}
                  </Badge>
                  <Button
                    size="sm"
                    variant="outline"
                    className="rounded-lg"
                    onClick={() => grantTrial(t.id)}
                  >
                    <Gift className="h-3 w-3" /> Trial
                  </Button>
                  <Button
                    size="sm"
                    variant={t.status === "expired" ? "default" : "destructive"}
                    className={`rounded-lg ${t.status === "expired" ? "bg-emerald-600 hover:bg-emerald-700" : ""}`}
                    onClick={() => toggleBlock(t.id)}
                  >
                    <Ban className="h-3 w-3" />
                    {t.status === "expired" ? "Aktifkan" : "Blokir"}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}