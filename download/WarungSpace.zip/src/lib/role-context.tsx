import { createContext, useContext, useState, type ReactNode } from "react";

export type RoleId = "admin" | "member" | "staff";

interface RoleContextValue {
  role: RoleId;
  setRole: (r: RoleId) => void;
}

const RoleContext = createContext<RoleContextValue | null>(null);

export function RoleProvider({ children }: { children: ReactNode }) {
  const [role, setRole] = useState<RoleId>("member");
  return (
    <RoleContext.Provider value={{ role, setRole }}>{children}</RoleContext.Provider>
  );
}

export function useRole() {
  const ctx = useContext(RoleContext);
  if (!ctx) throw new Error("useRole must be used within RoleProvider");
  return ctx;
}