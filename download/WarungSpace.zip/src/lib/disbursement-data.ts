export type DisbursementPurpose = "PAYROLL" | "REIMBURSEMENT";
export type DisbursementStatus = "PENDING" | "SUCCESS" | "FAILED" | "QUEUED";

export interface Claim {
  id: number;
  memberName: string;
  memberEmail: string;
  amount: number;
  type: DisbursementPurpose;
  channelCode: string;
  channelEmoji: string;
  accountNumber: string;
  accountHolder: string;
  note: string;
  status: DisbursementStatus;
  ref: string;
  gatewayRefId?: string;
  errorMessage?: string;
  createdAt: string;
}

export const CHANNEL_META: Record<string, { emoji: string; label: string }> = {
  DANA: { emoji: "💙", label: "DANA Wallet" },
  OVO: { emoji: "💜", label: "OVO Cash" },
  GOPAY: { emoji: "💚", label: "GoPay" },
  SHOPEEPAY: { emoji: "🧡", label: "ShopeePay" },
  LINKAJA: { emoji: "❤️", label: "LinkAja" },
  BCA: { emoji: "🏦", label: "BCA Digital" },
  JAGO: { emoji: "🐱", label: "Bank Jago" },
};

export const INITIAL_CLAIMS: Claim[] = [
  {
    id: 1041,
    memberName: "Andi Pratama",
    memberEmail: "andi@warungspace.id",
    amount: 1850000,
    type: "PAYROLL",
    channelCode: "DANA",
    channelEmoji: "💙",
    accountNumber: "0812****3456",
    accountHolder: "Andi Pratama",
    note: "Gaji Januari + komisi penjualan",
    status: "PENDING",
    ref: "DISB-PAYROLL-1041",
    createdAt: "2025-01-31 08:12:00",
  },
  {
    id: 1042,
    memberName: "Siti Rahayu",
    memberEmail: "siti@warungspace.id",
    amount: 420000,
    type: "REIMBURSEMENT",
    channelCode: "GOPAY",
    channelEmoji: "💚",
    accountNumber: "0857****1122",
    accountHolder: "Siti Rahayu",
    note: "Klaim bensin operasional kurir",
    status: "PENDING",
    ref: "DISB-REIMBURSEMENT-1042",
    createdAt: "2025-01-30 16:40:00",
  },
  {
    id: 1043,
    memberName: "Budi Santoso",
    memberEmail: "budi@warungspace.id",
    amount: 275000,
    type: "REIMBURSEMENT",
    channelCode: "OVO",
    channelEmoji: "💜",
    accountNumber: "0813****7788",
    accountHolder: "Budi Santoso",
    note: "Klaim pembelian ATK gudang",
    status: "PENDING",
    ref: "DISB-REIMBURSEMENT-1043",
    createdAt: "2025-01-30 11:05:00",
  },
  {
    id: 1039,
    memberName: "Dewi Lestari",
    memberEmail: "dewi@warungspace.id",
    amount: 2100000,
    type: "PAYROLL",
    channelCode: "BCA",
    channelEmoji: "🏦",
    accountNumber: "8830****4411",
    accountHolder: "Dewi Lestari",
    note: "Gaji Januari",
    status: "SUCCESS",
    ref: "DISB-PAYROLL-1039",
    gatewayRefId: "xnd_pay_88213",
    createdAt: "2025-01-28 09:00:00",
  },
];

export function formatRupiah(n: number): string {
  return "Rp " + n.toLocaleString("id-ID");
}

export function nowStamp(): string {
  const d = new Date();
  const p = (v: number) => String(v).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(
    d.getHours()
  )}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}