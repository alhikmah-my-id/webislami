export interface SalesOrder {
  id: string;
  customer: string;
  stage: "Quotation" | "Sales Order" | "Invoice" | "Paid";
  amount: number;
  date: string;
}

export interface PurchaseOrder {
  id: string;
  supplier: string;
  stage: "Permintaan" | "PO" | "Diterima" | "Ditagih";
  amount: number;
  date: string;
}

export interface LedgerAccount {
  code: string;
  name: string;
  type: "Aset" | "Kewajiban" | "Ekuitas" | "Pendapatan" | "Beban";
  balance: number;
}

export interface Project {
  id: string;
  name: string;
  client: string;
  progress: number;
  budget: number;
  spent: number;
  tasksDone: number;
  tasksTotal: number;
}

export interface Lead {
  id: string;
  name: string;
  company: string;
  stage: "Lead" | "Qualified" | "Proposal" | "Negotiation" | "Won";
  value: number;
}

export interface WorkOrder {
  id: string;
  product: string;
  qty: number;
  status: "Direncanakan" | "Produksi" | "Selesai";
  progress: number;
}

export const SALES_ORDERS: SalesOrder[] = [
  { id: "SO-2041", customer: "PT Sinar Jaya", stage: "Invoice", amount: 42500000, date: "2025-06-18" },
  { id: "SO-2040", customer: "CV Maju Bersama", stage: "Sales Order", amount: 18750000, date: "2025-06-17" },
  { id: "SO-2039", customer: "Toko Berkah", stage: "Paid", amount: 9200000, date: "2025-06-15" },
  { id: "SO-2038", customer: "UD Karya Mandiri", stage: "Quotation", amount: 31200000, date: "2025-06-14" },
];

export const PURCHASE_ORDERS: PurchaseOrder[] = [
  { id: "PO-1180", supplier: "Distributor Utama", stage: "Diterima", amount: 26400000, date: "2025-06-16" },
  { id: "PO-1179", supplier: "PT Pangan Nusantara", stage: "PO", amount: 14200000, date: "2025-06-15" },
  { id: "PO-1178", supplier: "Supplier Kemasan", stage: "Ditagih", amount: 6800000, date: "2025-06-12" },
  { id: "PO-1177", supplier: "Grosir Sembako", stage: "Permintaan", amount: 9500000, date: "2025-06-11" },
];

export const LEDGER: LedgerAccount[] = [
  { code: "1-1000", name: "Kas & Bank", type: "Aset", balance: 184500000 },
  { code: "1-1200", name: "Piutang Usaha", type: "Aset", balance: 62800000 },
  { code: "1-1400", name: "Persediaan Barang", type: "Aset", balance: 41200000 },
  { code: "2-2000", name: "Hutang Usaha", type: "Kewajiban", balance: 33500000 },
  { code: "3-3000", name: "Modal Pemilik", type: "Ekuitas", balance: 150000000 },
  { code: "4-4000", name: "Pendapatan Penjualan", type: "Pendapatan", balance: 128400000 },
  { code: "5-5000", name: "Beban Operasional", type: "Beban", balance: 47200000 },
];

export const PROJECTS: Project[] = [
  { id: "PRJ-01", name: "Renovasi Gudang", client: "Internal", progress: 72, budget: 85000000, spent: 61200000, tasksDone: 18, tasksTotal: 25 },
  { id: "PRJ-02", name: "Implementasi POS Cabang", client: "Toko Berkah", progress: 45, budget: 42000000, spent: 18900000, tasksDone: 9, tasksTotal: 20 },
  { id: "PRJ-03", name: "Kampanye Ramadan", client: "Marketing", progress: 90, budget: 25000000, spent: 22500000, tasksDone: 27, tasksTotal: 30 },
];

export const LEADS: Lead[] = [
  { id: "L-01", name: "Andi Wijaya", company: "PT Sinar Jaya", stage: "Negotiation", value: 42500000 },
  { id: "L-02", name: "Rina Kusuma", company: "CV Maju Bersama", stage: "Proposal", value: 18750000 },
  { id: "L-03", name: "Budi Hartono", company: "UD Karya Mandiri", stage: "Qualified", value: 31200000 },
  { id: "L-04", name: "Siti Rahma", company: "Toko Berkah", stage: "Lead", value: 9200000 },
  { id: "L-05", name: "Dewi Lestari", company: "Koperasi Sejahtera", stage: "Won", value: 27400000 },
];

export const WORK_ORDERS: WorkOrder[] = [
  { id: "WO-501", product: "Paket Sembako Hemat", qty: 500, status: "Produksi", progress: 65 },
  { id: "WO-502", product: "Kopi Bubuk Premium 200g", qty: 1200, status: "Direncanakan", progress: 0 },
  { id: "WO-503", product: "Snack Kemasan 50pcs", qty: 800, status: "Selesai", progress: 100 },
];

export const CRM_STAGES: Lead["stage"][] = ["Lead", "Qualified", "Proposal", "Negotiation", "Won"];