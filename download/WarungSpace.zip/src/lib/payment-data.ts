export interface Product {
  id: string;
  barcode: string;
  name: string;
  price: number;
  stock: number;
}

export interface CartItem extends Product {
  qty: number;
}

export interface EWallet {
  id: string;
  name: string;
  emoji: string;
  color: string;
}

export interface Bank {
  id: string;
  name: string;
  emoji: string;
  color: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  operator: string;
  action: string;
  description: string;
  ip: string;
}

export const PRODUCTS: Product[] = [
  { id: "p1", barcode: "8991002101234", name: "Kopi Susu Gula Aren 1L", price: 38000, stock: 42 },
  { id: "p2", barcode: "8991002105678", name: "Teh Melati Premium 250g", price: 15500, stock: 88 },
  { id: "p3", barcode: "8991002109012", name: "Gula Pasir 1kg", price: 14000, stock: 120 },
  { id: "p4", barcode: "8991002103456", name: "Susu UHT Full Cream 1L", price: 21000, stock: 35 },
  { id: "p5", barcode: "8991002107890", name: "Air Mineral 600ml (dus)", price: 48000, stock: 24 },
  { id: "p6", barcode: "8991002102345", name: "Roti Tawar Gandum", price: 18500, stock: 16 },
  { id: "p7", barcode: "8991002106789", name: "Minyak Goreng 2L", price: 36000, stock: 51 },
  { id: "p8", barcode: "8991002100123", name: "Beras Pandan Wangi 5kg", price: 72000, stock: 30 },
];

export const EWALLETS: EWallet[] = [
  { id: "dana", name: "DANA", emoji: "💙", color: "bg-blue-50 text-blue-700 border-blue-200" },
  { id: "gopay", name: "GoPay", emoji: "💚", color: "bg-emerald-50 text-emerald-700 border-emerald-200" },
  { id: "ovo", name: "OVO", emoji: "💜", color: "bg-purple-50 text-purple-700 border-purple-200" },
  { id: "shopeepay", name: "ShopeePay", emoji: "🧡", color: "bg-orange-50 text-orange-700 border-orange-200" },
  { id: "linkaja", name: "LinkAja", emoji: "❤️", color: "bg-rose-50 text-rose-700 border-rose-200" },
  { id: "jenius", name: "Jenius", emoji: "💠", color: "bg-cyan-50 text-cyan-700 border-cyan-200" },
];

export const BANKS: Bank[] = [
  { id: "bca", name: "BCA Mobile", emoji: "🏦", color: "bg-blue-50 text-blue-700 border-blue-200" },
  { id: "mandiri", name: "Livin' Mandiri", emoji: "🏛️", color: "bg-amber-50 text-amber-700 border-amber-200" },
  { id: "bni", name: "BNI Mobile", emoji: "🏦", color: "bg-orange-50 text-orange-700 border-orange-200" },
  { id: "bri", name: "BRImo", emoji: "🏦", color: "bg-sky-50 text-sky-700 border-sky-200" },
  { id: "jago", name: "Bank Jago", emoji: "🐱", color: "bg-yellow-50 text-yellow-700 border-yellow-200" },
  { id: "seabank", name: "SeaBank", emoji: "🌊", color: "bg-teal-50 text-teal-700 border-teal-200" },
];

export const INITIAL_AUDIT_LOGS: AuditLog[] = [
  {
    id: "a1",
    timestamp: "2025-01-14 09:12:04",
    operator: "owner@warungspace.id",
    action: "GENERATE_PAYMENT",
    description: "QRIS Rp 76.000 dibuat via MIDTRANS (ref: MID-88213)",
    ip: "103.28.14.9",
  },
  {
    id: "a2",
    timestamp: "2025-01-14 09:13:41",
    operator: "system",
    action: "PAYMENT_WEBHOOK",
    description: "Callback PAID diterima, signature valid (ref: MID-88213)",
    ip: "52.77.10.4",
  },
  {
    id: "a3",
    timestamp: "2025-01-14 09:14:02",
    operator: "owner@warungspace.id",
    action: "PRINT_INVOICE",
    description: "Cetak struk INV-2025-0114-002 (thermal 58mm)",
    ip: "103.28.14.9",
  },
  {
    id: "a4",
    timestamp: "2025-01-14 09:20:17",
    operator: "andi@warungspace.id",
    action: "SCAN_PRODUCT",
    description: "Scan barcode 8991002101234 — Kopi Susu Gula Aren 1L",
    ip: "103.28.14.22",
  },
];

export function formatRupiah(n: number): string {
  return "Rp " + n.toLocaleString("id-ID");
}

export function generateInvoice(): string {
  const d = new Date();
  const ymd = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(
    d.getDate()
  ).padStart(2, "0")}`;
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `INV-${ymd}-${rand}`;
}

export function generateQrisPayload(invoice: string, total: number): string {
  return `00020101021226610014ID.CO.QRIS.WWW0118${invoice}0215ID102002123456780303UMI51440014ID.CO.QRIS.WWW0215ID102002123456780303UMI5204541153033605802ID5910WARUNGSPAC6007JAKARTA61051234062070703A015404${total}6304ABCD`;
}