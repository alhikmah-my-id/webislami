export interface MenuItem {
  id: string;
  name: string;
  category: "Makanan" | "Minuman" | "Snack";
  price: number;
  variants: string[];
  recipe: { material: string; qty: number; unit: string }[];
  available: boolean;
}

export interface Table {
  id: string;
  label: string;
  seats: number;
  status: "Kosong" | "Terisi" | "Reservasi" | "Perlu Dibersihkan";
  guest?: string;
  time?: string;
}

export interface KitchenTicket {
  id: string;
  table: string;
  station: "Hot Kitchen" | "Cold Kitchen" | "Bar";
  items: string[];
  status: "Antrian" | "Dimasak" | "Siap";
  minutes: number;
}

export interface Voucher {
  id: string;
  code: string;
  name: string;
  type: "Persen" | "Nominal" | "Menu Gratis";
  value: string;
  period: string;
  usage: number;
  quota: number;
  active: boolean;
}

export interface Outlet {
  id: string;
  name: string;
  city: string;
  revenue: number;
  foodCost: number;
  opex: number;
  transactions: number;
}

export const MENU_ITEMS: MenuItem[] = [
  {
    id: "m1",
    name: "Nasi Goreng Spesial",
    category: "Makanan",
    price: 32000,
    variants: ["Original", "Pedas", "Extra Telur"],
    recipe: [
      { material: "Beras", qty: 0.2, unit: "kg" },
      { material: "Telur", qty: 1, unit: "butir" },
      { material: "Ayam Fillet", qty: 0.08, unit: "kg" },
      { material: "Minyak Goreng", qty: 0.03, unit: "L" },
    ],
    available: true,
  },
  {
    id: "m2",
    name: "Ayam Bakar Madu",
    category: "Makanan",
    price: 45000,
    variants: ["Dada", "Paha", "Sayap"],
    recipe: [
      { material: "Ayam Potong", qty: 0.25, unit: "kg" },
      { material: "Madu", qty: 0.03, unit: "L" },
      { material: "Bumbu Bakar", qty: 0.05, unit: "kg" },
    ],
    available: true,
  },
  {
    id: "m3",
    name: "Es Teh Manis",
    category: "Minuman",
    price: 8000,
    variants: ["Less Sugar", "Normal", "Extra Manis"],
    recipe: [
      { material: "Teh Celup", qty: 1, unit: "pcs" },
      { material: "Gula", qty: 0.02, unit: "kg" },
      { material: "Es Batu", qty: 0.1, unit: "kg" },
    ],
    available: true,
  },
  {
    id: "m4",
    name: "Kopi Susu Gula Aren",
    category: "Minuman",
    price: 24000,
    variants: ["Hot", "Iced", "Extra Shot"],
    recipe: [
      { material: "Kopi Espresso", qty: 0.018, unit: "kg" },
      { material: "Susu UHT", qty: 0.15, unit: "L" },
      { material: "Gula Aren", qty: 0.02, unit: "kg" },
    ],
    available: true,
  },
  {
    id: "m5",
    name: "Pisang Goreng Keju",
    category: "Snack",
    price: 18000,
    variants: ["Original", "Extra Keju"],
    recipe: [
      { material: "Pisang", qty: 0.15, unit: "kg" },
      { material: "Tepung", qty: 0.05, unit: "kg" },
      { material: "Keju", qty: 0.03, unit: "kg" },
    ],
    available: false,
  },
];

export const TABLES: Table[] = [
  { id: "t1", label: "A1", seats: 2, status: "Terisi", guest: "2 orang", time: "12:15" },
  { id: "t2", label: "A2", seats: 4, status: "Kosong" },
  { id: "t3", label: "A3", seats: 4, status: "Reservasi", guest: "Keluarga Wijaya", time: "19:00" },
  { id: "t4", label: "B1", seats: 6, status: "Terisi", guest: "6 orang", time: "12:40" },
  { id: "t5", label: "B2", seats: 6, status: "Perlu Dibersihkan" },
  { id: "t6", label: "C1", seats: 8, status: "Kosong" },
  { id: "t7", label: "C2", seats: 2, status: "Kosong" },
  { id: "t8", label: "C3", seats: 4, status: "Terisi", guest: "3 orang", time: "13:05" },
];

export const KITCHEN_TICKETS: KitchenTicket[] = [
  { id: "K-201", table: "A1", station: "Hot Kitchen", items: ["Nasi Goreng Spesial x2", "Ayam Bakar Madu x1"], status: "Dimasak", minutes: 6 },
  { id: "K-202", table: "B1", station: "Bar", items: ["Kopi Susu Gula Aren x3", "Es Teh Manis x2"], status: "Siap", minutes: 2 },
  { id: "K-203", table: "C3", station: "Cold Kitchen", items: ["Pisang Goreng Keju x2"], status: "Antrian", minutes: 1 },
  { id: "K-204", table: "A1", station: "Bar", items: ["Es Teh Manis x2"], status: "Antrian", minutes: 1 },
];

export const VOUCHERS: Voucher[] = [
  { id: "v1", code: "RAMADAN25", name: "Promo Ramadan", type: "Persen", value: "25%", period: "1-30 Jun 2025", usage: 142, quota: 500, active: true },
  { id: "v2", code: "HEMAT10K", name: "Diskon Nominal", type: "Nominal", value: "Rp 10.000", period: "Sepanjang Juni", usage: 89, quota: 300, active: true },
  { id: "v3", code: "GRATISESTEH", name: "Free Es Teh", type: "Menu Gratis", value: "Es Teh Manis", period: "Weekend saja", usage: 56, quota: 200, active: true },
  { id: "v4", code: "NEWMEMBER", name: "Voucher Member Baru", type: "Persen", value: "15%", period: "Berakhir 20 Jun", usage: 210, quota: 210, active: false },
];

export const OUTLETS: Outlet[] = [
  { id: "o1", name: "Cabang Pusat", city: "Jakarta", revenue: 428500000, foodCost: 128500000, opex: 96000000, transactions: 8420 },
  { id: "o2", name: "Cabang Bandung", city: "Bandung", revenue: 312400000, foodCost: 98700000, opex: 74500000, transactions: 6180 },
  { id: "o3", name: "Cabang Surabaya", city: "Surabaya", revenue: 268900000, foodCost: 89200000, opex: 68300000, transactions: 5240 },
  { id: "o4", name: "Cabang Bali", city: "Denpasar", revenue: 196300000, foodCost: 68500000, opex: 52000000, transactions: 3910 },
];

export const RESTAURANT_MODULES = [
  "Manajemen Menu & Resep",
  "POS Restoran",
  "Manajemen Meja & Reservasi",
  "Operasional Dapur",
  "Voucher & Promosi",
  "Pembelian & Persediaan",
  "Keuangan Terintegrasi",
  "Dashboard Multi-Outlet",
];