import {
  LOCKED_PHONE,
  makeGatewayId,
  makeRefId,
  nowStamp,
  type TopUpRecord,
  type WalletAuditLog,
} from "@/lib/wallet-data";

type TopUpListener = (record: TopUpRecord) => void;
type LogListener = (log: WalletAuditLog) => void;

class WalletEngine {
  private topUpListeners = new Set<TopUpListener>();
  private logListeners = new Set<LogListener>();
  private timers = new Map<string, ReturnType<typeof setTimeout>>();

  onTopUp(cb: TopUpListener) {
    this.topUpListeners.add(cb);
    return () => {
      this.topUpListeners.delete(cb);
    };
  }

  onLog(cb: LogListener) {
    this.logListeners.add(cb);
    return () => {
      this.logListeners.delete(cb);
    };
  }

  private emitTopUp(record: TopUpRecord) {
    this.topUpListeners.forEach((cb) => cb(record));
  }

  private emitLog(log: WalletAuditLog) {
    this.logListeners.forEach((cb) => cb(log));
  }

  private pushLog(action: string, refId: string, target?: string, gatewayId?: string) {
    this.emitLog({
      id: `w${Date.now()}${Math.random().toString(36).slice(2, 6)}`,
      timestamp: nowStamp(),
      action,
      refId,
      target,
      gatewayId,
    });
  }

  /**
   * Simulates POST /api/v1/payouts/topup-dana
   * The destination phone is permanently locked to LOCKED_PHONE.
   */
  initiateTopUp(amount: number): TopUpRecord {
    const refId = makeRefId();
    const gatewayId = makeGatewayId();

    const pending: TopUpRecord = {
      refId,
      phoneNumber: LOCKED_PHONE,
      amount,
      gatewayId,
      status: "PENDING",
      createdAt: nowStamp(),
    };

    this.emitTopUp(pending);
    this.pushLog("AUTO_TOPUP_INITIATED", refId, LOCKED_PHONE);

    const delay = 3500 + Math.random() * 5000;
    const timer = setTimeout(() => {
      this.timers.delete(refId);
      const failed = Math.random() < 0.12;
      const final: TopUpRecord = {
        ...pending,
        status: failed ? "FAILED" : "SUCCESS",
        failureCode: failed ? "CHANNEL_DOWN" : undefined,
      };
      this.emitTopUp(final);
      this.pushLog(
        failed ? "WEBHOOK_TOPUP_FAILED" : "WEBHOOK_TOPUP_SUCCESS",
        refId,
        undefined,
        gatewayId
      );
    }, delay);
    this.timers.set(refId, timer);

    return pending;
  }

  cancel(refId: string) {
    const t = this.timers.get(refId);
    if (t) {
      clearTimeout(t);
      this.timers.delete(refId);
    }
  }
}

export const walletEngine = new WalletEngine();

export function playTopUpChime() {
  try {
    const Ctx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext })
        .webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    const now = ctx.currentTime;
    [783.99, 1046.5, 1318.51].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = freq;
      const start = now + i * 0.12;
      gain.gain.setValueAtTime(0, start);
      gain.gain.linearRampToValueAtTime(0.15, start + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, start + 0.3);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(start);
      osc.stop(start + 0.32);
    });
    setTimeout(() => ctx.close().catch(() => {}), 1200);
  } catch {
    /* audio unavailable */
  }
}