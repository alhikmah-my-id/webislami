import { createContext, useContext, useState, type ReactNode } from "react";

export interface Product {
  id: string;
  name: string;
  sku: string;
  stock: number;
  unit: string;
  price: number;
}

export interface CartLine {
  productId: string;
  qty: number;
}

export interface Transaction {
  id: string;
  customer: string;
  total: number;
  method: "Tunai" | "Transfer" | "Utang";
  date: string;
}

export interface Debt {
  id: string;
  customer: string;
  phone: string;
  amount: number;
  dueDate: string;
  status: "unpaid" | "paid";
}

interface StoreValue {
  products: Product[];
  cart: CartLine[];
  transactions: Transaction[];
  debts: Debt[];
  addToCart: (productId: string) => void;
  removeFromCart: (productId: string) => void;
  decrementCart: (productId: string) => void;
  clearCart: () => void;
  checkout: (method: Transaction["method"], customer: string) => void;
  markDebtPaid: (id: string) => void;
}

const StoreContext = createContext<StoreValue | null>(null);

const INITIAL_PRODUCTS: Product[] = [
  { id: "p1", name: "Beras Premium 5kg", sku: "BRS-5K", stock: 42, unit: "sak", price: 68000 },
  { id: "p2", name: "Minyak Goreng 2L", sku: "MYK-2L", stock: 3, unit: "pouch", price: 36000 },
  { id: "p3", name: "Gula Pasir 1kg", sku: "GLA-1K", stock: 58, unit: "kg", price: 15000 },
  { id: "p4", name: "Telur Ayam 1kg", sku: "TLR-1K", stock: 12, unit: "kg", price: 28000 },
  { id: "p5", name: "Kopi Sachet (10pcs)", sku: "KPI-10", stock: 96, unit: "pack", price: 12000 },
  { id: "p6", name: "Sabun Mandi", sku: "SBN-01", stock: 7, unit: "pcs", price: 4500 },
];

const INITIAL_DEBTS: Debt[] = [
  { id: "d1", customer: "Pak Budi", phone: "0812-3456-7890", amount: 320000, dueDate: "2025-06-20", status: "unpaid" },
  { id: "d2", customer: "Bu Rina", phone: "0813-9876-5432", amount: 145000, dueDate: "2025-06-15", status: "unpaid" },
  { id: "d3", customer: "Mas Andi", phone: "0857-1122-3344", amount: 78000, dueDate: "2025-06-28", status: "unpaid" },
  { id: "d4", customer: "Bu Siti", phone: "0821-5566-7788", amount: 210000, dueDate: "2025-06-10", status: "paid" },
];

const INITIAL_TRANSACTIONS: Transaction[] = [
  { id: "INV-1042", customer: "Bu Siti", total: 145000, method: "Tunai", date: "Hari ini" },
  { id: "INV-1041", customer: "Pak Budi", total: 320000, method: "Utang", date: "Hari ini" },
  { id: "INV-1040", customer: "Umum", total: 78500, method: "Transfer", date: "Kemarin" },
  { id: "INV-1039", customer: "Bu Rina", total: 210000, method: "Tunai", date: "Kemarin" },
];

export function StoreProvider({ children }: { children: ReactNode }) {
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [cart, setCart] = useState<CartLine[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS);
  const [debts, setDebts] = useState<Debt[]>(INITIAL_DEBTS);

  const addToCart = (productId: string) =>
    setCart((c) => {
      const existing = c.find((l) => l.productId === productId);
      if (existing) {
        return c.map((l) => (l.productId === productId ? { ...l, qty: l.qty + 1 } : l));
      }
      return [...c, { productId, qty: 1 }];
    });

  const decrementCart = (productId: string) =>
    setCart((c) =>
      c
        .map((l) => (l.productId === productId ? { ...l, qty: l.qty - 1 } : l))
        .filter((l) => l.qty > 0)
    );

  const removeFromCart = (productId: string) =>
    setCart((c) => c.filter((l) => l.productId !== productId));

  const clearCart = () => setCart([]);

  const checkout = (method: Transaction["method"], customer: string) => {
    if (cart.length === 0) return;
    const total = cart.reduce((sum, line) => {
      const p = products.find((x) => x.id === line.productId);
      return sum + (p ? p.price * line.qty : 0);
    }, 0);

    const invoice = "INV-" + Math.floor(1000 + Math.random() * 9000);
    setTransactions((t) => [
      { id: invoice, customer: customer || "Umum", total, method, date: "Baru saja" },
      ...t,
    ]);

    setProducts((prev) =>
      prev.map((p) => {
        const line = cart.find((l) => l.productId === p.id);
        return line ? { ...p, stock: Math.max(0, p.stock - line.qty) } : p;
      })
    );

    if (method === "Utang") {
      setDebts((d) => [
        {
          id: "debt-" + invoice,
          customer: customer || "Umum",
          phone: "-",
          amount: total,
          dueDate: new Date(Date.now() + 14 * 86400000).toISOString().slice(0, 10),
          status: "unpaid",
        },
        ...d,
      ]);
    }

    setCart([]);
  };

  const markDebtPaid = (id: string) =>
    setDebts((d) => d.map((x) => (x.id === id ? { ...x, status: "paid" } : x)));

  return (
    <StoreContext.Provider
      value={{
        products,
        cart,
        transactions,
        debts,
        addToCart,
        removeFromCart,
        decrementCart,
        clearCart,
        checkout,
        markDebtPaid,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used within StoreProvider");
  return ctx;
}