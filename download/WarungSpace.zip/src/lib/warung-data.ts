export interface Tenant {
  id: string;
  businessName: string;
  owner: string;
  plan: "free_trial" | "active" | "expired" | "blocked";
  mrr: number;
  joinedAt: string;
  subscriptionUntil: string;
}

export interface Product {
  id: string;
  name: string;
  sku: string;
  stock: number;
  unit: string;
  priceRetail: number;
  priceWholesale: number;
  wholesaleMinQty: number;
  category: string;
  emoji: string;
}

export interface Debt {
  id: string;
  customer: string;
  phone: string;
  amount: number;
  dueDate: string;
  status: "unpaid" | "partial" | "paid";
}

export interface Employee {
  id: string;
  name: string;
  phone: string;
  pin: string;
  baseSalary: number;
  commissionRate: number;
  presentDays: number;
  salesTotal: number;
  lastClockIn: string | null;
  gps: string;
}

export interface RevenuePoint {
  day: string;
  omzet: number;
}

export const TENANTS: Tenant[] = [
  { id: "t1", businessName: "Toko Bangunan Jaya", owner: "Budi Santoso", plan: "active", mrr: 149000, joinedAt: "2024-08-12", subscriptionUntil: "2025-03-15" },
  { id: "t2", businessName: "Warung Bu Siti", owner: "Siti Aminah", plan: "active", mrr: 99000, joinedAt: "2024-09-01", subscriptionUntil: "2025-03-01" },
  { id: "t3", businessName: "Kopi Kita Senja", owner: "Rian Pratama", plan: "free_trial", mrr: 0, joinedAt: "2025-01-28", subscriptionUntil: "2025-02-04" },
  { id: "t4", businessName: "Sembako Makmur", owner: "Hendra Wijaya", plan: "expired", mrr: 0, joinedAt: "2024-06-20", subscriptionUntil: "2025-01-10" },
  { id: "t5", businessName: "Apotek Sehat Selalu", owner: "Dewi Lestari", plan: "blocked", mrr: 0, joinedAt: "2024-05-05", subscriptionUntil: "2024-12-01" },
  { id: "t6", businessName: "Bakso Pak Kumis", owner: "Agus Salim", plan: "active", mrr: 199000, joinedAt: "2024-10-11", subscriptionUntil: "2025-04-02" },
];

export const PRODUCTS: Product[] = [
  { id: "p1", name: "Semen Tiga Roda 40kg", sku: "SMN-3R-40", stock: 120, unit: "sak", priceRetail: 58000, priceWholesale: 54000, wholesaleMinQty: 10, category: "Material", emoji: "🧱" },
  { id: "p2", name: "Cat Tembok Dulux 5kg", sku: "CAT-DLX-5", stock: 34, unit: "pail", priceRetail: 145000, priceWholesale: 132000, wholesaleMinQty: 5, category: "Material", emoji: "🎨" },
  { id: "p3", name: "Paku Beton 5cm", sku: "PKU-BTN-5", stock: 8, unit: "kg", priceRetail: 22000, priceWholesale: 19000, wholesaleMinQty: 20, category: "Hardware", emoji: "🔩" },
  { id: "p4", name: "Pipa PVC 3 inch", sku: "PIP-PVC-3", stock: 56, unit: "batang", priceRetail: 47000, priceWholesale: 42000, wholesaleMinQty: 12, category: "Plumbing", emoji: "🚰" },
  { id: "p5", name: "Keramik 60x60 Putih", sku: "KRM-6060-W", stock: 240, unit: "dus", priceRetail: 78000, priceWholesale: 71000, wholesaleMinQty: 15, category: "Finishing", emoji: "⬜" },
  { id: "p6", name: "Kunci Gembok Yale", sku: "KCI-YAL-01", stock: 3, unit: "pcs", priceRetail: 65000, priceWholesale: 58000, wholesaleMinQty: 6, category: "Hardware", emoji: "🔒" },
];

export const DEBTS: Debt[] = [
  { id: "d1", customer: "Pak RT 04", phone: "6281234567801", amount: 1250000, dueDate: "2025-02-10", status: "unpaid" },
  { id: "d2", customer: "CV Karya Abadi", phone: "6281234567802", amount: 3400000, dueDate: "2025-02-05", status: "partial" },
  { id: "d3", customer: "Bu Ratna", phone: "6281234567803", amount: 480000, dueDate: "2025-01-28", status: "unpaid" },
  { id: "d4", customer: "Toko Sebelah", phone: "6281234567804", amount: 890000, dueDate: "2025-02-15", status: "unpaid" },
];

export const EMPLOYEES: Employee[] = [
  { id: "e1", name: "Andi Saputra", phone: "628129990001", pin: "4821", baseSalary: 2500000, commissionRate: 2, presentDays: 24, salesTotal: 42500000, lastClockIn: "2025-02-01T07:58:00Z", gps: "-6.2088, 106.8456" },
  { id: "e2", name: "Maya Sari", phone: "628129990002", pin: "7390", baseSalary: 2400000, commissionRate: 2.5, presentDays: 22, salesTotal: 38200000, lastClockIn: "2025-02-01T08:05:00Z", gps: "-6.2090, 106.8460" },
  { id: "e3", name: "Rudi Hartono", phone: "628129990003", pin: "1567", baseSalary: 2300000, commissionRate: 1.5, presentDays: 20, salesTotal: 29800000, lastClockIn: null, gps: "-6.2085, 106.8450" },
];

export const REVENUE: RevenuePoint[] = [
  { day: "Sen", omzet: 3200000 },
  { day: "Sel", omzet: 4100000 },
  { day: "Rab", omzet: 2800000 },
  { day: "Kam", omzet: 5200000 },
  { day: "Jum", omzet: 6400000 },
  { day: "Sab", omzet: 7800000 },
  { day: "Min", omzet: 5600000 },
];

export const SERVER_NODES = [
  { name: "app-node-01", cpu: 42, ram: 61, status: "normal" as const },
  { name: "app-node-02", cpu: 88, ram: 79, status: "warning" as const },
  { name: "db-primary", cpu: 34, ram: 52, status: "normal" as const },
  { name: "worker-bot", cpu: 12, ram: 28, status: "normal" as const },
];

export function formatIDR(n: number): string {
  return "Rp " + n.toLocaleString("id-ID");
}

export function calcSalary(e: Employee): { commission: number; total: number } {
  const commission = Math.round((e.salesTotal * e.commissionRate) / 100);
  return { commission, total: e.baseSalary + commission };
}