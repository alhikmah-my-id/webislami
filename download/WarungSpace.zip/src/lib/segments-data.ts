export interface SegmentCategory {
  id: string;
  title: string;
  desc: string;
  emoji: string;
  examples: string[];
}

export interface Segment {
  id: string;
  emoji: string;
  title: string;
  desc: string;
  category: string;
}

export const SEGMENT_CATEGORIES: SegmentCategory[] = [
  {
    id: "fnb",
    title: "Makanan & Minuman",
    emoji: "🍽️",
    desc: "Kafe, coffee shop, rumah makan, dan warteg yang butuh kasir cepat serta menu digital.",
    examples: ["☕ Kafe & Coffee Shop", "🍜 Rumah Makan & Warteg"],
  },
  {
    id: "retail",
    title: "Retail",
    emoji: "🛍️",
    desc: "Toko retail, fashion, dan minimarket yang mengelola banyak produk dan variasi.",
    examples: ["👗 Toko Retail & Fashion", "🛒 Minimarket"],
  },
  {
    id: "service",
    title: "Jasa",
    emoji: "🧺",
    desc: "Usaha jasa seperti laundry yang butuh pencatatan transaksi rapi.",
    examples: ["👕 Bisnis Laundry"],
  },
  {
    id: "daily",
    title: "Toko Harian",
    emoji: "🏪",
    desc: "Warung dan toko kelontong yang ingin lepas dari buku nota manual.",
    examples: ["🏪 Warung & Kelontong"],
  },
];

export const SEGMENTS: Segment[] = [
  {
    id: "kafe",
    emoji: "☕",
    title: "Pemilik kafe, coffee shop, dan kedai minuman",
    desc: "Dari order meja hingga laporan harian, semua bisa dikerjakan dari satu aplikasi.",
    category: "Makanan & Minuman",
  },
  {
    id: "warung",
    emoji: "🏪",
    title: "Pemilik warung, toko kelontong, dan toko sembako",
    desc: "Tidak perlu buku nota — catat semua transaksi otomatis dan lihat untung rugi toko Anda.",
    category: "Toko Harian",
  },
  {
    id: "fashion",
    emoji: "👗",
    title: "Pemilik toko retail, toko fashion, toko pakaian, dan butik",
    desc: "Stok ratusan produk, variasi warna dan ukuran, laporan penjualan — semua dalam satu platform.",
    category: "Retail",
  },
  {
    id: "rumah-makan",
    emoji: "🍜",
    title: "Pemilik rumah makan, warteg, warung makan, dan restoran kecil",
    desc: "Catat setiap pesanan, pantau penjualan per menu, dan lihat laporan harian dengan mudah.",
    category: "Makanan & Minuman",
  },
  {
    id: "laundry",
    emoji: "👕",
    title: "Pemilik usaha laundry kiloan dan satuan",
    desc: "Catat transaksi laundry, pantau pesanan, dan cetak struk dengan cepat.",
    category: "Jasa",
  },
  {
    id: "minimarket",
    emoji: "🛒",
    title: "Pemilik minimarket, swalayan kecil, dan toko serba ada",
    desc: "Kelola ribuan produk, proses transaksi cepat, dan pantau stok — tanpa software mahal.",
    category: "Retail",
  },
];