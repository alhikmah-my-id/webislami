import {
  handleWebhook,
  simulateWebhook,
  getDisbursements,
  getAuditLogs,
  getSnapshot,
} from "@/lib/xendit-service";

export interface TestResult {
  name: string;
  passed: boolean;
  detail: string;
}

export function runPayoutControllerTests(): TestResult[] {
  const results: TestResult[] = [];

  // Test 1: valid webhook marks disbursement completed
  const before = getDisbursements().length;
  const valid = handleWebhook(getSnapshot().webhookToken, {
    external_id: "disb_001",
    status: "PAID",
    amount: 2500000,
  });
  results.push({
    name: "handleWebhook accepts valid token",
    passed: valid.ok === true,
    detail: valid.message,
  });

  // Test 2: invalid token rejected
  const invalid = handleWebhook("wrong-token", {
    external_id: "disb_999",
    status: "PAID",
    amount: 100000,
  });
  results.push({
    name: "handleWebhook rejects invalid token",
    passed: invalid.ok === false,
    detail: invalid.message,
  });

  // Test 3: simulateWebhook creates a new disbursement
  const sim = simulateWebhook("SETTLEMENT");
  const after = getDisbursements().length;
  results.push({
    name: "simulateWebhook creates disbursement",
    passed: sim.ok === true && after > before,
    detail: sim.message,
  });

  // Test 4: audit logs recorded
  const logs = getAuditLogs();
  results.push({
    name: "audit logs recorded",
    passed: logs.length > 0,
    detail: `${logs.length} log entries`,
  });

  return results;
}