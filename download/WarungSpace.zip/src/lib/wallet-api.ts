export interface WalletBalance {
  available: number;
  pending: number;
  currency: string;
  updatedAt: string;
}

export interface WalletHistoryEntry {
  id: string;
  type: "credit" | "debit";
  amount: number;
  description: string;
  at: string;
}

const state: { balance: WalletBalance; history: WalletHistoryEntry[] } = {
  balance: {
    available: 12450000,
    pending: 850000,
    currency: "IDR",
    updatedAt: new Date().toISOString(),
  },
  history: [
    { id: "wh1", type: "credit", amount: 340000, description: "Penjualan INV-2025-0142", at: "2025-02-01T09:12:00Z" },
    { id: "wh2", type: "credit", amount: 620000, description: "Penjualan INV-2025-0139", at: "2025-01-31T15:05:00Z" },
    { id: "wh3", type: "debit", amount: 2500000, description: "Payout ke BCA ****1234", at: "2025-01-30T11:00:00Z" },
    { id: "wh4", type: "credit", amount: 89000, description: "Penjualan INV-2025-0140", at: "2025-01-31T17:22:00Z" },
  ],
};

export function checkWalletBalance(): WalletBalance {
  return { ...state.balance, updatedAt: new Date().toISOString() };
}

export function getWalletHistory(): WalletHistoryEntry[] {
  return [...state.history];
}

export function creditWallet(amount: number, description: string): WalletBalance {
  state.balance.available += amount;
  state.balance.updatedAt = new Date().toISOString();
  state.history.unshift({
    id: `wh_${Math.random().toString(36).slice(2, 9)}`,
    type: "credit",
    amount,
    description,
    at: new Date().toISOString(),
  });
  return { ...state.balance };
}

export function debitWallet(amount: number, description: string): WalletBalance {
  state.balance.available = Math.max(0, state.balance.available - amount);
  state.balance.updatedAt = new Date().toISOString();
  state.history.unshift({
    id: `wh_${Math.random().toString(36).slice(2, 9)}`,
    type: "debit",
    amount,
    description,
    at: new Date().toISOString(),
  });
  return { ...state.balance };
}