export interface AboutSection {
  id: string;
  title: string;
  emoji: string;
  body: string[];
  code?: string;
  list?: string[];
}

export const ABOUT_SECTIONS: AboutSection[] = [
  {
    id: "fitur",
    title: "Fitur Utama",
    emoji: "✨",
    body: [
      "WarungSpace adalah SaaS ERP UMKM all-in-one yang dirancang mobile-first untuk warung, toko retail, kafe, dan usaha jasa.",
    ],
    list: [
      "Kasir / POS cepat dengan pencarian nama & SKU",
      "Manajemen produk, stok, variasi, dan harga grosir bertingkat",
      "Kasbon & Buku Piutang dengan invoice otomatis",
      "Laporan bisnis: hari ini, 7 hari, 30 hari, dan ekspor Excel/CSV",
      "Profit Intelligence: kalkulator HPP + margin & penjaga margin",
      "Resep & Bahan Baku (BOM) untuk usaha F&B",
      "Shift kasir, absensi, dan payroll karyawan",
      "Tanya AI, Loyalty, Voucher, CRM Campaign, dan Marketplace add-on",
    ],
  },
  {
    id: "kategori",
    title: "Kategori Konten",
    emoji: "🗂️",
    body: [
      "Konten aplikasi dikelompokkan agar mudah dinavigasi oleh pemilik maupun kasir.",
    ],
    list: [
      "Kasir & POS — transaksi, voucher, shift",
      "Produk & Stok — produk, SKU, supplier, konsinyasi, inventori lanjutan",
      "Laporan & Analitik — laporan bisnis, profit intelligence, Tanya AI",
      "Keuangan — kasbon, QRIS, pengeluaran, akuntansi & tutup buku",
      "Pelanggan & CRM — pelanggan, loyalty, campaign, feedback",
      "Restoran & F&B — menu, resep, meja, dapur, reservasi",
      "Marketplace & Add-on — Menu QR, invoice template, add-on berbayar",
      "Akun & Pengaturan — peran, izin, tampilan, mobile",
      "Mitra — program reseller dan dompet komisi",
    ],
  },
  {
    id: "arsitektur",
    title: "Arsitektur Sistem",
    emoji: "🏗️",
    body: [
      "Sistem menggunakan arsitektur multi-tenant dengan isolasi data per tenant melalui Row Level Security (RLS) pada PostgreSQL.",
    ],
    list: [
      "Frontend & API Routes: Next.js App Router (TypeScript)",
      "Database & Auth: Supabase (PostgreSQL + RLS)",
      "Payment Gateway: Xendit / Midtrans dengan webhook otomatis",
      "Setiap tabel operasional memiliki kolom tenant_id untuk isolasi data",
      "Trigger database untuk pengurangan stok & auto-utang",
    ],
  },
  {
    id: "teknologi",
    title: "Teknologi",
    emoji: "🧰",
    body: ["Stack utama yang digunakan untuk membangun WarungSpace."],
    list: [
      "Next.js (App Router) + TypeScript",
      "Tailwind CSS / SCSS untuk styling dinamis",
      "Supabase (PostgreSQL) + Row Level Security",
      "Prisma ORM untuk query type-safe",
      "JWT untuk autentikasi & otorisasi peran",
      "Xendit / Midtrans untuk pembayaran QRIS",
      "html5-qrcode & qrcode.react untuk scan & QR",
    ],
  },
  {
    id: "instalasi",
    title: "Instalasi",
    emoji: "📦",
    body: ["Clone repositori dan pasang dependensi proyek."],
    code: `git clone https://github.com/alhikmah-my-id/warungspace.git
cd warungspace
npm install
cp .env.example .env.local
npm run dev`,
  },
  {
    id: "konfigurasi",
    title: "Konfigurasi",
    emoji: "⚙️",
    body: ["Isi variabel lingkungan berikut pada file .env.local."],
    code: `NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
JWT_SECRET=your_jwt_secret
XENDIT_SECRET_KEY=your_xendit_key
XENDIT_WEBHOOK_TOKEN=your_webhook_token`,
  },
  {
    id: "penggunaan",
    title: "Penggunaan",
    emoji: "🚀",
    body: ["Alur dasar penggunaan aplikasi untuk pemilik dan kasir."],
    list: [
      "Daftar akun UMKM dan buat profil toko",
      "Tambahkan produk beserta SKU, harga, dan stok",
      "Buka shift kasir dengan modal awal",
      "Proses transaksi di kasir: tunai, QRIS, transfer, atau kasbon",
      "Pantau laporan dan buku piutang dari dashboard pemilik",
      "Tutup shift dan rekonsiliasi kas aktual",
    ],
  },
  {
    id: "api",
    title: "API Documentation",
    emoji: "🔌",
    body: ["Endpoint utama REST API WarungSpace."],
    code: `# Member
POST   /api/attendance/clock-in
POST   /api/attendance/clock-out
POST   /api/leaves
GET    /api/leaves/me

# Admin
GET    /api/admin/dashboard-stats
PATCH  /api/admin/leaves/:id
GET    /api/admin/reports/print

# Kasir & Produk
GET    /api/products/scan/:barcode
POST   /api/transactions/create-qr
POST   /api/transactions/webhook-callback`,
  },
  {
    id: "tappx",
    title: "Monetisasi Tappx",
    emoji: "💰",
    body: [
      "Slot iklan Tappx dapat diintegrasikan pada halaman katalog publik dan Menu QR untuk monetisasi tambahan tanpa mengganggu alur kasir.",
    ],
    list: [
      "Integrasi SDK Tappx pada halaman publik (non-dashboard)",
      "Penempatan iklan non-intrusif di katalog & Menu QR",
      "Tidak mengganggu performa kasir dan transaksi",
    ],
  },
  {
    id: "platform",
    title: "Platform Support",
    emoji: "📱",
    body: ["Aplikasi berjalan di berbagai perangkat tanpa instalasi."],
    list: [
      "Mobile (Android & iOS) via browser",
      "Tablet & iPad — touchscreen-friendly",
      "Desktop & laptop",
      "PWA: kasir offline saat internet terputus",
    ],
  },
  {
    id: "deployment",
    title: "Deployment",
    emoji: "☁️",
    body: ["Deploy ke Vercel atau platform Node.js lainnya."],
    code: `# Deploy ke Vercel
npm run build
vercel --prod

# Atau jalankan produksi lokal
npm run build && npm start`,
  },
  {
    id: "kontribusi",
    title: "Kontribusi",
    emoji: "🤝",
    body: ["Kami terbuka untuk kontribusi dari komunitas."],
    list: [
      "Fork repositori dan buat branch fitur",
      "Ikuti gaya kode dan tulis commit yang jelas",
      "Ajukan Pull Request dengan deskripsi lengkap",
      "Laporkan bug atau usulan fitur lewat Issues",
    ],
  },
  {
    id: "lisensi",
    title: "Lisensi",
    emoji: "📄",
    body: [
      "Proyek ini dirilis di bawah lisensi MIT. Anda bebas menggunakan, memodifikasi, dan mendistribusikan dengan tetap menyertakan atribusi.",
    ],
  },
  {
    id: "kontak",
    title: "Kontak",
    emoji: "📬",
    body: ["Hubungi tim WarungSpace untuk pertanyaan, kemitraan, atau dukungan."],
    list: [
      "Website: awdev.my.id",
      "GitHub: github.com/alhikmah-my-id",
      "Dukungan: paypal.me/wahyudi9kdl",
    ],
  },
];