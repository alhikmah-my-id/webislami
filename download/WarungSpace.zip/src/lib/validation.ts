import { XENDIT_WEBHOOK_TOKEN, type WebhookPayload } from "@/lib/xendit-service";
import { canAfford } from "@/lib/wallet-api";

export type Severity = "error" | "warning" | "ok";

export interface ValidationIssue {
  field: string;
  severity: Severity;
  message: string;
}

export interface ValidationReport {
  valid: boolean;
  issues: ValidationIssue[];
  checkedAt: string;
}

const WALLET_CHANNELS = ["DANA", "OVO", "GOPAY", "SHOPEEPAY"];
const MIN_PAYOUT = 10000;
const MAX_PAYOUT = 50000000;

export function validatePhone(value: string): boolean {
  return /^(\+62|62|0)8[1-9][0-9]{6,11}$/.test(value.replace(/[\s-]/g, ""));
}

export function validateAccount(value: string): boolean {
  return /^[0-9]{8,20}$/.test(value.replace(/[\s-]/g, ""));
}

export function validateEmail(value: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value.trim());
}

export function validatePayoutPayload(input: {
  externalID: string;
  amount: number;
  channelCode: string;
  accountNumber: string;
  description: string;
}): ValidationReport {
  const issues: ValidationIssue[] = [];

  if (!input.externalID || input.externalID.trim().length < 6) {
    issues.push({
      field: "externalID",
      severity: "error",
      message: "externalID wajib diisi, minimal 6 karakter (idempotency key).",
    });
  } else if (!/^[A-Z0-9-]+$/i.test(input.externalID)) {
    issues.push({
      field: "externalID",
      severity: "warning",
      message: "externalID sebaiknya hanya huruf, angka, dan tanda hubung.",
    });
  }

  if (!Number.isFinite(input.amount)) {
    issues.push({ field: "amount", severity: "error", message: "amount harus berupa angka." });
  } else if (input.amount < MIN_PAYOUT) {
    issues.push({
      field: "amount",
      severity: "error",
      message: `amount minimal Rp ${MIN_PAYOUT.toLocaleString("id-ID")}.`,
    });
  } else if (input.amount > MAX_PAYOUT) {
    issues.push({
      field: "amount",
      severity: "error",
      message: `amount melebihi batas Rp ${MAX_PAYOUT.toLocaleString("id-ID")}.`,
    });
  } else if (input.amount % 1000 !== 0) {
    issues.push({
      field: "amount",
      severity: "warning",
      message: "amount sebaiknya kelipatan 1.000 untuk menghindari pembulatan.",
    });
  }

  const channel = input.channelCode?.toUpperCase();
  if (!channel) {
    issues.push({ field: "channelCode", severity: "error", message: "channelCode wajib diisi." });
  } else if (!WALLET_CHANNELS.includes(channel)) {
    issues.push({
      field: "channelCode",
      severity: "warning",
      message: `channelCode "${channel}" belum terdaftar (${WALLET_CHANNELS.join(", ")}).`,
    });
  }

  if (!input.accountNumber) {
    issues.push({
      field: "accountNumber",
      severity: "error",
      message: "accountNumber wajib diisi.",
    });
  } else if (channel && WALLET_CHANNELS.includes(channel) && !validatePhone(input.accountNumber)) {
    issues.push({
      field: "accountNumber",
      severity: "error",
      message: "Nomor HP e-wallet tidak valid (contoh: 083842170430).",
    });
  } else if (channel && !WALLET_CHANNELS.includes(channel) && !validateAccount(input.accountNumber)) {
    issues.push({
      field: "accountNumber",
      severity: "error",
      message: "Nomor rekening bank harus 8–20 digit angka.",
    });
  }

  if (!input.description || input.description.trim().length < 3) {
    issues.push({
      field: "description",
      severity: "warning",
      message: "description sebaiknya diisi untuk jejak audit.",
    });
  }

  return {
    valid: !issues.some((i) => i.severity === "error"),
    issues,
    checkedAt: new Date().toISOString(),
  };
}

export function validateWebhookPayload(
  token: string,
  body: Partial<WebhookPayload>
): ValidationReport {
  const issues: ValidationIssue[] = [];

  if (!token) {
    issues.push({ field: "x-callback-token", severity: "error", message: "Header token tidak ada." });
  } else if (token !== XENDIT_WEBHOOK_TOKEN) {
    issues.push({
      field: "x-callback-token",
      severity: "error",
      message: "Token webhook tidak cocok — request ditolak (401).",
    });
  } else {
    issues.push({
      field: "x-callback-token",
      severity: "ok",
      message: "Token webhook valid.",
    });
  }

  if (!body.external_id) {
    issues.push({ field: "external_id", severity: "error", message: "external_id wajib ada." });
  }
  if (!body.id) {
    issues.push({ field: "id", severity: "error", message: "gateway id wajib ada." });
  }
  if (!body.status) {
    issues.push({ field: "status", severity: "error", message: "status wajib ada." });
  } else if (!["COMPLETED", "FAILED", "PENDING"].includes(body.status)) {
    issues.push({
      field: "status",
      severity: "error",
      message: `status "${body.status}" tidak dikenal.`,
    });
  }

  return {
    valid: !issues.some((i) => i.severity === "error"),
    issues,
    checkedAt: new Date().toISOString(),
  };
}

export function validateBalanceSufficiency(
  available: number,
  amount: number,
  fee = 0
): ValidationReport {
  const issues: ValidationIssue[] = [];
  if (!Number.isFinite(available) || available < 0) {
    issues.push({ field: "available", severity: "error", message: "Saldo tidak valid." });
  }
  if (!canAfford(available, amount, fee)) {
    issues.push({
      field: "amount",
      severity: "error",
      message: `Saldo tidak cukup. Butuh Rp ${(amount + fee).toLocaleString("id-ID")}, tersedia Rp ${available.toLocaleString("id-ID")}.`,
    });
  } else {
    issues.push({ field: "amount", severity: "ok", message: "Saldo mencukupi." });
  }
  return {
    valid: !issues.some((i) => i.severity === "error"),
    issues,
    checkedAt: new Date().toISOString(),
  };
}

export function validateTenantConfig(input: {
  businessName: string;
  email: string;
  phone: string;
  subdomain: string;
}): ValidationReport {
  const issues: ValidationIssue[] = [];

  if (!input.businessName || input.businessName.trim().length < 3) {
    issues.push({
      field: "businessName",
      severity: "error",
      message: "Nama usaha minimal 3 karakter.",
    });
  }
  if (!validateEmail(input.email)) {
    issues.push({ field: "email", severity: "error", message: "Format email tidak valid." });
  }
  if (!validatePhone(input.phone)) {
    issues.push({ field: "phone", severity: "error", message: "Format nomor HP tidak valid." });
  }
  if (!/^[a-z0-9-]{3,30}$/.test(input.subdomain)) {
    issues.push({
      field: "subdomain",
      severity: "error",
      message: "Subdomain hanya huruf kecil, angka, dan tanda hubung (3–30).",
    });
  }

  return {
    valid: !issues.some((i) => i.severity === "error"),
    issues,
    checkedAt: new Date().toISOString(),
  };
}