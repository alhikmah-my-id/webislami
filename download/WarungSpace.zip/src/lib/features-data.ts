export interface FeatureGroup {
  id: string;
  title: string;
  emoji: string;
  tag?: string;
  items: string[];
}

export const FEATURE_GROUPS: FeatureGroup[] = [
  {
    id: "pos",
    title: "Kasir / POS",
    emoji: "🧾",
    items: [
      "Tampilan kasir simpel & cepat, ramah pemula",
      "Pencarian produk cepat lewat nama atau SKU",
      "Metode bayar: Tunai, QRIS, Transfer, Kartu, dan Kasbon",
      "Uang diterima + tombol cepat (25rb/50rb/75rb/100rb) & kembalian otomatis",
      "Tahan / Simpan pesanan (mis. “Meja 5”) lalu buka lagi nanti",
      "Bayar tunai kurang dari total otomatis jadi kasbon",
      "Kasir Offline (PWA): keranjang aman saat internet putus; pembayaran ditahan sampai koneksi pulih, lalu kasir melanjutkan secara manual",
    ],
  },
  {
    id: "products",
    title: "Manajemen Produk & Stok",
    emoji: "📦",
    items: [
      "Tambah, edit, dan hapus produk",
      "Kelompokkan produk berdasarkan kategori",
      "Variasi produk (warna, ukuran, dan lainnya)",
      "Stok per produk dan per variasi",
      "Harga grosir bertingkat (mis. beli 10 lebih murah, beli 30 lebih murah lagi)",
      "Riwayat perubahan stok (log masuk/keluar)",
      "Impor produk via CSV",
      "Foto produk untuk tampilan kasir",
    ],
  },
  {
    id: "sku",
    title: "SKU & Pencarian Produk",
    emoji: "🔎",
    items: [
      "Setiap produk memiliki kode SKU unik",
      "Pencarian produk berdasarkan nama atau SKU",
      "Pencarian cepat saat transaksi di kasir",
    ],
  },
  {
    id: "reports",
    title: "Laporan Bisnis",
    emoji: "📊",
    items: [
      "Ringkasan penjualan: hari ini, 7 hari, 30 hari",
      "Produk terlaris dan tren penjualan",
      "Laporan per metode pembayaran",
      "Kinerja kasir per pegawai",
      "Ekspor laporan ke Excel (.xlsx) rapi & CSV aman-Excel",
      "Laporan bulanan otomatis via email",
    ],
  },
  {
    id: "debts",
    title: "Kasbon & Buku Piutang",
    emoji: "📕",
    items: [
      "Catat penjualan hutang (kasbon) per pelanggan",
      "Buku Piutang: total piutang, siapa berhutang, dan cicilan",
      "Invoice otomatis ter-update tiap cicilan sampai lunas",
      "Penjualan kasbon tetap dihitung omzet, terpisah dari kas masuk",
    ],
  },
  {
    id: "shift",
    title: "Shift Kasir & Absensi",
    emoji: "⏱️",
    items: [
      "Buka/tutup shift dengan modal awal & kas aktual; selisih kas otomatis",
      "Absensi karyawan (clock-in/out) dan kinerja",
      "Bisa dinyalakan/dimatikan sesuai kebutuhan toko",
      "Data lama tetap aman saat fitur dimatikan",
    ],
  },
  {
    id: "profit",
    title: "Profit Intelligence",
    emoji: "💡",
    items: [
      "Kalkulator harga jual dari HPP + target margin (otomatis & akurat)",
      "Penjaga margin: peringatan rugi / margin tipis",
      "Ranking produk paling menguntungkan (dari penjualan nyata)",
      "Net profit memperhitungkan diskon yang diberikan",
    ],
  },
  {
    id: "bom",
    title: "Resep & Bahan Baku (BOM)",
    emoji: "🍲",
    tag: "Gratis & opsional",
    items: [
      "Untuk usaha F&B: susun resep per menu (bahan baku + jumlah pemakaian per porsi)",
      "Saat menu terjual di kasir, stok bahan baku otomatis terpotong",
      "HPP menu dihitung otomatis dari harga modal bahan terbaru",
      "Nyalakan di Pengaturan, lalu atur resep di halaman Resep & Bahan Baku",
    ],
  },
  {
    id: "invoice",
    title: "Invoice & Template",
    emoji: "🖨️",
    tag: "Add-on Gratis",
    items: [
      "4 template: Berwarna, Sederhana, Elegan (ramah thermal), & Custom",
      "Editor template drag-and-drop untuk desain sendiri",
      "Atur template berbeda untuk Email/WhatsApp vs Cetak",
      "Kirim struk PDF langsung lewat WhatsApp atau email",
      "Invoice kasbon menampilkan sisa hutang & status LUNAS",
    ],
  },
  {
    id: "ai",
    title: "Tanya AI",
    emoji: "🤖",
    items: [
      "Tanya kondisi toko lewat percakapan natural",
      "Laporan otomatis: penjualan hari ini, stok menipis, produk terlaris",
      "Pertanyaan pintar siap pakai",
      "Riwayat percakapan tersimpan 7 hari",
      "Akses terpisah per peran (Pemilik, Manajer Toko, Kasir, Mitra)",
    ],
  },
  {
    id: "loyalty",
    title: "Program Poin (Loyalty) Pelanggan",
    emoji: "🎁",
    tag: "Gratis & opsional",
    items: [
      "Pelanggan otomatis mengumpulkan poin tiap belanja",
      "Poin bisa ditukar jadi potongan harga langsung di kasir",
      "Riwayat poin per pelanggan + koreksi manual (komplain/retur) yang teraudit",
      "Nyalakan di Pengaturan bila ingin memakainya",
    ],
  },
  {
    id: "voucher",
    title: "Kode Promo / Voucher",
    emoji: "🏷️",
    tag: "Langganan",
    items: [
      "Buat kode diskon persen atau nominal",
      "Atur batas pemakaian dan masa berlaku",
      "Kasir tinggal memasukkan kode saat transaksi",
    ],
  },
];

export const FAQS = [
  {
    q: "Apakah WarungSpace bisa dipakai tanpa internet?",
    a: "Bisa. Mode Kasir Offline (PWA) menjaga keranjang tetap aman saat koneksi putus. Pembayaran ditahan sampai internet pulih, lalu kasir melanjutkan transaksi secara manual.",
  },
  {
    q: "Apakah fitur resep, poin, dan invoice berbayar?",
    a: "Tidak. Resep & Bahan Baku (BOM), Program Poin, dan Invoice Template tersedia gratis dan opsional — cukup dinyalakan di Pengaturan bila ingin dipakai.",
  },
  {
    q: "Bagaimana cara kerja kasbon dan buku piutang?",
    a: "Setiap penjualan hutang dicatat per pelanggan. Buku Piutang menampilkan total piutang, siapa yang berhutang, dan cicilan. Invoice otomatis ter-update tiap cicilan sampai berstatus LUNAS.",
  },
  {
    q: "Apakah ada uji coba gratis?",
    a: "Ya. Anda bisa mencoba WarungSpace gratis selama 7 hari dengan akses ke seluruh modul inti tanpa perlu kartu kredit.",
  },
  {
    q: "Bisakah laporan diekspor?",
    a: "Bisa. Laporan dapat diekspor ke Excel (.xlsx) yang rapi maupun CSV yang aman dibuka di Excel, dan laporan bulanan bisa dikirim otomatis via email.",
  },
];