export interface PayoutRequest {
  externalID: string;
  amount: number;
  channelCode: string;
  accountNumber: string;
  description: string;
}

export interface PayoutResult {
  id: string;
  externalID: string;
  amount: number;
  channelCode: string;
  accountNumber: string;
  status: "PENDING" | "COMPLETED" | "FAILED";
  fee: number;
  createdAt: string;
}

export const PAYOUT_MIN = 10000;
export const PAYOUT_MAX = 10000000;
export const PAYOUT_FEE = 2500;

const CHANNEL_CODES = ["DANA", "OVO", "GOPAY", "SHOPEEPAY", "BCA", "MANDIRI", "BNI", "BRI"];

export function isValidPayoutChannel(code: string) {
  return CHANNEL_CODES.includes(code.toUpperCase());
}

export function isValidPayoutAccount(code: string, account: string) {
  const clean = account.replace(/[\s-]/g, "");
  const wallet = ["DANA", "OVO", "GOPAY", "SHOPEEPAY"].includes(code.toUpperCase());
  if (wallet) return /^(\+62|62|0)8[1-9][0-9]{6,11}$/.test(clean);
  return /^[0-9]{8,20}$/.test(clean);
}

export function validatePayout(req: PayoutRequest): string | null {
  if (!req.externalID) return "externalID wajib diisi.";
  if (!req.amount || req.amount < PAYOUT_MIN)
    return `Nominal minimal Rp ${PAYOUT_MIN.toLocaleString("id-ID")}.`;
  if (req.amount > PAYOUT_MAX)
    return `Nominal maksimal Rp ${PAYOUT_MAX.toLocaleString("id-ID")}.`;
  if (!isValidPayoutChannel(req.channelCode))
    return `Channel "${req.channelCode}" tidak didukung.`;
  if (!isValidPayoutAccount(req.channelCode, req.accountNumber))
    return "Nomor tujuan tidak valid untuk channel ini.";
  if (!req.description || req.description.trim().length < 3)
    return "Deskripsi minimal 3 karakter.";
  return null;
}

export const Payout = {
  async createPayout(req: PayoutRequest): Promise<PayoutResult> {
    const error = validatePayout(req);
    if (error) throw new Error(error);

    await new Promise((r) => setTimeout(r, 800));

    return {
      id: `po_${Math.random().toString(36).slice(2, 12)}`,
      externalID: req.externalID,
      amount: req.amount,
      channelCode: req.channelCode.toUpperCase(),
      accountNumber: req.accountNumber,
      status: "COMPLETED",
      fee: PAYOUT_FEE,
      createdAt: new Date().toISOString(),
    };
  },
};

export interface TopUpPreset {
  id: string;
  label: string;
  amount: number;
  channelCode: string;
  accountNumber: string;
  member: string;
}

export const DEFAULT_TOPUPS: TopUpPreset[] = [
  {
    id: "t1",
    label: "Top Up Cepat",
    amount: 50000,
    channelCode: "DANA",
    accountNumber: "083842170430",
    member: "Andi Pratama",
  },
  {
    id: "t2",
    label: "Top Up Harian",
    amount: 100000,
    channelCode: "OVO",
    accountNumber: "081298765432",
    member: "Siti Rahma",
  },
  {
    id: "t3",
    label: "Top Up Mingguan",
    amount: 250000,
    channelCode: "GOPAY",
    accountNumber: "081377788899",
    member: "Budi Santoso",
  },
];