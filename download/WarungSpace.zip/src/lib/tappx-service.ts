export interface AppKey {
  id: number;
  key: string;
  platform: "android" | "ios" | "web";
  status: "active" | "standby" | "cooldown";
  impressions: number;
  revenue: number;
  fillRate: number;
  lastUsed: string;
}

export interface RotationEvent {
  id: string;
  fromKey: string;
  toKey: string;
  reason: string;
  at: string;
}

export interface PlatformSupport {
  platform: "Web" | "Android" | "iOS";
  icon: string;
  requirements: string[];
  accent: string;
}

export const APP_KEYS: AppKey[] = [
  { id: 1, key: "pub-65263-android-0300", platform: "android", status: "active", impressions: 184230, revenue: 412.5, fillRate: 92.4, lastUsed: "2025-02-01T09:12:00Z" },
  { id: 2, key: "pub-57747-android-0996", platform: "android", status: "standby", impressions: 142890, revenue: 318.2, fillRate: 88.1, lastUsed: "2025-02-01T07:40:00Z" },
  { id: 3, key: "pub-60567-android-4416", platform: "android", status: "standby", impressions: 98760, revenue: 221.9, fillRate: 85.7, lastUsed: "2025-01-31T22:15:00Z" },
  { id: 4, key: "pub-65262-android-8892", platform: "android", status: "cooldown", impressions: 76340, revenue: 168.4, fillRate: 79.3, lastUsed: "2025-01-31T18:02:00Z" },
  { id: 5, key: "pub-79956-android-6297", platform: "android", status: "standby", impressions: 65410, revenue: 141.7, fillRate: 81.6, lastUsed: "2025-01-31T14:30:00Z" },
  { id: 6, key: "pub-79955-android-5582", platform: "android", status: "standby", impressions: 51220, revenue: 112.3, fillRate: 76.8, lastUsed: "2025-01-31T10:11:00Z" },
];

export const PLATFORM_SUPPORT: PlatformSupport[] = [
  {
    platform: "Web",
    icon: "🌐",
    accent: "sky",
    requirements: ["Chrome 90+", "Firefox 88+", "Safari 14+", "Edge 90+", "PWA installable"],
  },
  {
    platform: "Android",
    icon: "📱",
    accent: "emerald",
    requirements: ["Android 5.0+ (API 21)", "Kotlin & Java", "Material Design 3", "Google Play Store ready"],
  },
  {
    platform: "iOS",
    icon: "🍎",
    accent: "rose",
    requirements: ["iOS 14.0+", "Swift 5.9+", "SwiftUI & UIKit", "App Store ready"],
  },
];

export const DEPLOYMENT_OPTIONS = [
  { name: "VPS", detail: "Ubuntu + Nginx + PM2", icon: "🖥️" },
  { name: "Vercel / Netlify", detail: "Frontend hosting", icon: "▲" },
  { name: "Docker", detail: "Containerized deployment", icon: "🐳" },
  { name: "Railway / Render", detail: "API hosting", icon: "🚂" },
];

export function getActiveKey(keys: AppKey[]): AppKey | undefined {
  return keys.find((k) => k.status === "active");
}

export function rotateKeys(keys: AppKey[], reason: string): { keys: AppKey[]; event: RotationEvent } {
  const currentIdx = keys.findIndex((k) => k.status === "active");
  const nextIdx = (currentIdx + 1) % keys.length;

  const updated = keys.map((k, i) => {
    if (i === currentIdx) return { ...k, status: "cooldown" as const };
    if (i === nextIdx) return { ...k, status: "active" as const, lastUsed: new Date().toISOString() };
    return k;
  });

  const event: RotationEvent = {
    id: `rot_${Math.random().toString(36).slice(2, 9)}`,
    fromKey: keys[currentIdx]?.key ?? "—",
    toKey: keys[nextIdx]?.key ?? "—",
    reason,
    at: new Date().toISOString(),
  };

  return { keys: updated, event };
}

export function totalRevenue(keys: AppKey[]): number {
  return keys.reduce((sum, k) => sum + k.revenue, 0);
}

export function totalImpressions(keys: AppKey[]): number {
  return keys.reduce((sum, k) => sum + k.impressions, 0);
}

export function averageFillRate(keys: AppKey[]): number {
  if (!keys.length) return 0;
  return keys.reduce((sum, k) => sum + k.fillRate, 0) / keys.length;
}