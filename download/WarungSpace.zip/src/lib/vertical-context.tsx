import { createContext, useContext, useState, type ReactNode } from "react";

export interface VerticalKpi {
  label: string;
  value: string;
  delta: string;
}

export interface Vertical {
  id: string;
  name: string;
  emoji: string;
  kpis: VerticalKpi[];
}

export const VERTICALS: Vertical[] = [
  {
    id: "sembako",
    name: "Toko Sembako",
    emoji: "🛒",
    kpis: [
      { label: "Penjualan Hari Ini", value: "Rp 4.250.000", delta: "+12%" },
      { label: "Produk Terjual", value: "128 item", delta: "+8%" },
      { label: "Piutang Aktif", value: "Rp 8.650.000", delta: "-3%" },
    ],
  },
  {
    id: "kopi",
    name: "Kedai Kopi",
    emoji: "☕",
    kpis: [
      { label: "Penjualan Hari Ini", value: "Rp 2.780.000", delta: "+18%" },
      { label: "Cup Terjual", value: "214 cup", delta: "+11%" },
      { label: "Piutang Aktif", value: "Rp 1.200.000", delta: "-5%" },
    ],
  },
  {
    id: "laundry",
    name: "Laundry Kiloan",
    emoji: "🧺",
    kpis: [
      { label: "Penjualan Hari Ini", value: "Rp 1.640.000", delta: "+6%" },
      { label: "Order Selesai", value: "86 order", delta: "+4%" },
      { label: "Piutang Aktif", value: "Rp 640.000", delta: "-2%" },
    ],
  },
];

interface VerticalValue {
  vertical: Vertical;
  setVerticalId: (id: string) => void;
}

const VerticalContext = createContext<VerticalValue | null>(null);

export function VerticalProvider({ children }: { children: ReactNode }) {
  const [verticalId, setVerticalId] = useState(VERTICALS[0].id);
  const vertical = VERTICALS.find((v) => v.id === verticalId) ?? VERTICALS[0];
  return (
    <VerticalContext.Provider value={{ vertical, setVerticalId }}>
      {children}
    </VerticalContext.Provider>
  );
}

export function useVertical() {
  const ctx = useContext(VerticalContext);
  if (!ctx) throw new Error("useVertical must be used within VerticalProvider");
  return ctx;
}