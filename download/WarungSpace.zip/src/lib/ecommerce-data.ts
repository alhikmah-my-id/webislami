export interface Benefit {
  id: string;
  title: string;
  description: string;
  metric: string;
  metricLabel: string;
  icon: string;
  accent: string;
}

export interface FlowStep {
  id: string;
  label: string;
  detail: string;
  status: "Selesai" | "Berjalan" | "Menunggu";
}

export const BENEFITS: Benefit[] = [
  {
    id: "b1",
    title: "Efisiensi Operasional",
    description:
      "Otomatisasi proses bisnis mengurangi beban kerja manual dan meminimalisir kesalahan input.",
    metric: "68%",
    metricLabel: "waktu kerja manual terpangkas",
    icon: "zap",
    accent: "bg-emerald-50 text-emerald-700",
  },
  {
    id: "b2",
    title: "Insight Bisnis",
    description:
      "Analisis data komprehensif membantu pengambilan keputusan yang lebih baik dan terukur.",
    metric: "12",
    metricLabel: "laporan siap pakai",
    icon: "chart",
    accent: "bg-sky-50 text-sky-700",
  },
  {
    id: "b3",
    title: "Omnichannel Experience",
    description:
      "Berikan pengalaman belanja yang konsisten di semua channel penjualan dan website Anda.",
    metric: "6",
    metricLabel: "channel tersinkron",
    icon: "globe",
    accent: "bg-indigo-50 text-indigo-700",
  },
  {
    id: "b4",
    title: "Fulfillment Lebih Cepat",
    description:
      "Proses order yang lebih cepat dan akurat meningkatkan kepuasan pelanggan secara langsung.",
    metric: "2.4x",
    metricLabel: "lebih cepat diproses",
    icon: "truck",
    accent: "bg-amber-50 text-amber-700",
  },
  {
    id: "b5",
    title: "Loyalitas Pelanggan",
    description:
      "Program loyalitas terintegrasi meningkatkan retensi dan nilai pelanggan jangka panjang.",
    metric: "41%",
    metricLabel: "kenaikan repeat order",
    icon: "crown",
    accent: "bg-rose-50 text-rose-700",
  },
  {
    id: "b6",
    title: "Skalabilitas",
    description:
      "Sistem yang dapat tumbuh seiring dengan perkembangan bisnis e-commerce Anda tanpa hambatan.",
    metric: "99.9%",
    metricLabel: "uptime infrastruktur",
    icon: "layers",
    accent: "bg-teal-50 text-teal-700",
  },
];

export const FLOW_STEPS: FlowStep[] = [
  { id: "f1", label: "Pesanan Masuk", detail: "Shopee · Tokopedia · Website", status: "Selesai" },
  { id: "f2", label: "Validasi Stok", detail: "Sinkronisasi real-time 248 SKU", status: "Selesai" },
  { id: "f3", label: "Picking & Packing", detail: "Gudang utama · 3 picker", status: "Berjalan" },
  { id: "f4", label: "Handover Ekspedisi", detail: "JNE · SiCepat · J&T", status: "Menunggu" },
  { id: "f5", label: "Rekonsiliasi Pembayaran", detail: "Midtrans · Xendit", status: "Menunggu" },
];

export const KPIS = [
  { label: "Omzet Bulan Ini", value: "Rp 1,24 M", delta: "+18,4%", tone: "text-emerald-700" },
  { label: "Pesanan Diproses", value: "8.420", delta: "+12,1%", tone: "text-emerald-700" },
  { label: "Rata-rata Waktu Fulfillment", value: "6,2 jam", delta: "-24,0%", tone: "text-emerald-700" },
  { label: "Pelanggan Berulang", value: "41%", delta: "+5,3%", tone: "text-emerald-700" },
];