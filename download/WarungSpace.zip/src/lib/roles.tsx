import { createContext, useContext, useState, type ReactNode } from "react";

export type Role = "saas_admin" | "member" | "staff";

interface RoleContextValue {
  role: Role;
  setRole: (r: Role) => void;
}

const RoleContext = createContext<RoleContextValue | null>(null);

export const ROLE_META: Record<Role, { label: string; desc: string; accent: string }> = {
  saas_admin: {
    label: "SaaS Admin",
    desc: "Pemilik WarungOS — MRR, tenant, server",
    accent: "bg-indigo-500",
  },
  member: {
    label: "Member",
    desc: "Pemilik UMKM — produk, keuangan, karyawan",
    accent: "bg-emerald-500",
  },
  staff: {
    label: "Staff / Kasir",
    desc: "Karyawan toko — POS & absen",
    accent: "bg-amber-500",
  },
};

export function RoleProvider({ children }: { children: ReactNode }) {
  const [role, setRole] = useState<Role>("member");
  return (
    <RoleContext.Provider value={{ role, setRole }}>{children}</RoleContext.Provider>
  );
}

export function useRole() {
  const ctx = useContext(RoleContext);
  if (!ctx) throw new Error("useRole must be used within RoleProvider");
  return ctx;
}