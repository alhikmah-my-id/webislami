export interface Tenant {
  id: string;
  business: string;
  owner: string;
  plan: "free_trial" | "active" | "expired";
  mrr: number;
  until: string;
  status: "aktif" | "diblokir";
}

export interface ServerNode {
  id: string;
  name: string;
  region: string;
  cpu: number;
  ram: number;
  disk: number;
  status: "normal" | "padat" | "kritis";
}

export const TENANTS: Tenant[] = [
  { id: "t1", business: "Toko Bangunan Jaya", owner: "Hendra S.", plan: "active", mrr: 149000, until: "2025-07-18", status: "aktif" },
  { id: "t2", business: "Warung Bu Siti", owner: "Siti Aminah", plan: "active", mrr: 99000, until: "2025-07-02", status: "aktif" },
  { id: "t3", business: "Kopi Kenangan Kita", owner: "Rizky P.", plan: "free_trial", mrr: 0, until: "2025-06-25", status: "aktif" },
  { id: "t4", business: "Sembako Makmur", owner: "Budi T.", plan: "expired", mrr: 0, until: "2025-06-10", status: "diblokir" },
  { id: "t5", business: "Apotek Sehat Selalu", owner: "Dewi L.", plan: "active", mrr: 199000, until: "2025-08-01", status: "aktif" },
  { id: "t6", business: "Bakso Pak Kumis", owner: "Fajar N.", plan: "expired", mrr: 0, until: "2025-06-05", status: "diblokir" },
];

export const SERVERS: ServerNode[] = [
  { id: "s1", name: "app-node-01", region: "asia-southeast2", cpu: 42, ram: 58, disk: 61, status: "normal" },
  { id: "s2", name: "app-node-02", region: "asia-southeast2", cpu: 78, ram: 81, disk: 72, status: "padat" },
  { id: "s3", name: "db-primary", region: "asia-southeast2", cpu: 34, ram: 66, disk: 88, status: "padat" },
  { id: "s4", name: "worker-wa-bot", region: "asia-southeast1", cpu: 91, ram: 74, disk: 45, status: "kritis" },
];

export const DEPLOY_LOG = [
  { id: "d1", time: "09:41", text: "git pull origin main — 12 file berubah" },
  { id: "d2", time: "09:41", text: "npm run build — sukses dalam 24s" },
  { id: "d3", time: "09:42", text: "./.cloudshell/deploy-backend.sh — migrasi tenant_id OK" },
  { id: "d4", time: "09:42", text: "Deploy ke app-node-01 & app-node-02 — live" },
];

export const MRR_TREND = [
  { month: "Jan", mrr: 4200000 },
  { month: "Feb", mrr: 5100000 },
  { month: "Mar", mrr: 6400000 },
  { month: "Apr", mrr: 7900000 },
  { month: "Mei", mrr: 9600000 },
  { month: "Jun", mrr: 11800000 },
];

export const PAYMENT_CHANNELS = [
  { name: "DANA", amount: 5400000, share: 46 },
  { name: "QRIS", amount: 4200000, share: 36 },
  { name: "Transfer Bank", amount: 2200000, share: 18 },
];