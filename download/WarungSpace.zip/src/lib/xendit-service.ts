export interface Disbursement {
  id: string;
  amount: number;
  bankCode: string;
  accountNumber: string;
  accountName: string;
  status: "PENDING" | "COMPLETED" | "FAILED";
  createdAt: string;
}

export interface AuditLog {
  id: string;
  action: string;
  detail: string;
  at: string;
}

export interface XenditSnapshot {
  disbursements: Disbursement[];
  auditLogs: AuditLog[];
  webhookToken: string;
  lastWebhookAt: string | null;
}

export interface WebhookPayload {
  external_id: string;
  status: "PAID" | "SETTLEMENT" | "PENDING" | "FAILED";
  amount: number;
  bank_code?: string;
  account_number?: string;
  account_name?: string;
}

export interface WebhookResult {
  ok: boolean;
  message: string;
  disbursement?: Disbursement;
}

type Listener = (snapshot: XenditSnapshot) => void;

const state: XenditSnapshot = {
  disbursements: [
    {
      id: "disb_001",
      amount: 2500000,
      bankCode: "BCA",
      accountNumber: "1234567890",
      accountName: "Toko Makmur Jaya",
      status: "COMPLETED",
      createdAt: "2025-01-30T11:00:00Z",
    },
    {
      id: "disb_002",
      amount: 1750000,
      bankCode: "BNI",
      accountNumber: "0987654321",
      accountName: "Toko Makmur Jaya",
      status: "PENDING",
      createdAt: "2025-02-01T08:00:00Z",
    },
  ],
  auditLogs: [
    { id: "log_001", action: "disbursement.created", detail: "disb_002 dibuat", at: "2025-02-01T08:00:00Z" },
    { id: "log_002", action: "disbursement.completed", detail: "disb_001 selesai", at: "2025-01-30T11:05:00Z" },
  ],
  webhookToken: "xnd_wh_token_demo_9f3a",
  lastWebhookAt: null,
};

const listeners = new Set<Listener>();

function emit() {
  const snap = getSnapshot();
  listeners.forEach((l) => l(snap));
}

export function getSnapshot(): XenditSnapshot {
  return {
    disbursements: state.disbursements.map((d) => ({ ...d })),
    auditLogs: state.auditLogs.map((l) => ({ ...l })),
    webhookToken: state.webhookToken,
    lastWebhookAt: state.lastWebhookAt,
  };
}

export function subscribeXendit(listener: Listener): () => void {
  listeners.add(listener);
  listener(getSnapshot());
  return () => {
    listeners.delete(listener);
  };
}

export function getDisbursements(): Disbursement[] {
  return state.disbursements.map((d) => ({ ...d }));
}

export function getAuditLogs(): AuditLog[] {
  return state.auditLogs.map((l) => ({ ...l }));
}

function pushLog(action: string, detail: string) {
  state.auditLogs.unshift({
    id: `log_${Math.random().toString(36).slice(2, 9)}`,
    action,
    detail,
    at: new Date().toISOString(),
  });
}

export function handleWebhook(
  token: string,
  payload: WebhookPayload
): WebhookResult {
  if (token !== state.webhookToken) {
    pushLog("webhook.rejected", `Token tidak valid untuk ${payload.external_id}`);
    emit();
    return { ok: false, message: "Token webhook tidak valid." };
  }

  state.lastWebhookAt = new Date().toISOString();

  const success = payload.status === "PAID" || payload.status === "SETTLEMENT";
  if (!success) {
    pushLog("webhook.received", `${payload.external_id} status ${payload.status}`);
    emit();
    return { ok: true, message: `Webhook diterima, status ${payload.status}.` };
  }

  const existing = state.disbursements.find((d) => d.id === payload.external_id);
  if (existing) {
    existing.status = "COMPLETED";
    pushLog("disbursement.completed", `${existing.id} ditandai selesai`);
    emit();
    return { ok: true, message: `Disbursement ${existing.id} selesai.`, disbursement: { ...existing } };
  }

  const created: Disbursement = {
    id: payload.external_id,
    amount: payload.amount,
    bankCode: payload.bank_code ?? "UNKNOWN",
    accountNumber: payload.account_number ?? "-",
    accountName: payload.account_name ?? "-",
    status: "COMPLETED",
    createdAt: new Date().toISOString(),
  };
  state.disbursements.unshift(created);
  pushLog("disbursement.completed", `${created.id} dibuat & selesai`);
  emit();
  return { ok: true, message: `Disbursement ${created.id} dibuat.`, disbursement: { ...created } };
}

export function simulateWebhook(
  status: WebhookPayload["status"] = "PAID"
): WebhookResult {
  const payload: WebhookPayload = {
    external_id: `disb_${Math.random().toString(36).slice(2, 7)}`,
    status,
    amount: Math.floor(Math.random() * 2000000) + 500000,
    bank_code: "BCA",
    account_number: "1234567890",
    account_name: "Toko Makmur Jaya",
  };
  return handleWebhook(state.webhookToken, payload);
}

export function createDisbursement(
  amount: number,
  bankCode: string,
  accountNumber: string,
  accountName: string
): Disbursement {
  const d: Disbursement = {
    id: `disb_${Math.random().toString(36).slice(2, 7)}`,
    amount,
    bankCode,
    accountNumber,
    accountName,
    status: "PENDING",
    createdAt: new Date().toISOString(),
  };
  state.disbursements.unshift(d);
  pushLog("disbursement.created", `${d.id} dibuat (${bankCode})`);
  emit();
  return { ...d };
}