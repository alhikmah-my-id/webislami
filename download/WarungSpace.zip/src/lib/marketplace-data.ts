export interface Channel {
  id: string;
  name: string;
  logo: string;
  connected: boolean;
  products: number;
  ordersToday: number;
  revenue: number;
  lastSync: string;
  accent: string;
}

export interface Order {
  id: string;
  channel: string;
  customer: string;
  items: number;
  total: number;
  status: "Baru" | "Diproses" | "Dikirim" | "Selesai" | "Batal";
  courier: string;
  tracking: string;
  date: string;
}

export interface TopProduct {
  name: string;
  channel: string;
  sold: number;
  revenue: number;
  margin: number;
}

export interface Customer {
  id: string;
  name: string;
  tier: "Bronze" | "Silver" | "Gold" | "Platinum";
  points: number;
  orders: number;
  spent: number;
  lastOrder: string;
}

export interface PaymentProvider {
  id: string;
  name: string;
  connected: boolean;
  methods: string[];
  volume: number;
  fee: number;
  settled: number;
}

export const CHANNELS: Channel[] = [
  { id: "c1", name: "Tokopedia", logo: "T", connected: true, products: 248, ordersToday: 34, revenue: 18750000, lastSync: "2 menit lalu", accent: "bg-emerald-100 text-emerald-700" },
  { id: "c2", name: "Shopee", logo: "S", connected: true, products: 248, ordersToday: 51, revenue: 26400000, lastSync: "1 menit lalu", accent: "bg-orange-100 text-orange-700" },
  { id: "c3", name: "Lazada", logo: "L", connected: true, products: 240, ordersToday: 18, revenue: 9200000, lastSync: "5 menit lalu", accent: "bg-sky-100 text-sky-700" },
  { id: "c4", name: "TikTok Shop", logo: "T", connected: false, products: 0, ordersToday: 0, revenue: 0, lastSync: "Belum terhubung", accent: "bg-slate-100 text-slate-600" },
  { id: "c5", name: "WooCommerce", logo: "W", connected: true, products: 248, ordersToday: 12, revenue: 6400000, lastSync: "8 menit lalu", accent: "bg-indigo-100 text-indigo-700" },
  { id: "c6", name: "Magento", logo: "M", connected: false, products: 0, ordersToday: 0, revenue: 0, lastSync: "Belum terhubung", accent: "bg-slate-100 text-slate-600" },
];

export const ORDERS: Order[] = [
  { id: "INV-88421", channel: "Shopee", customer: "Andi Wijaya", items: 3, total: 285000, status: "Baru", courier: "JNE Reguler", tracking: "-", date: "2025-06-18" },
  { id: "INV-88420", channel: "Tokopedia", customer: "Rina Kusuma", items: 1, total: 145000, status: "Diproses", courier: "SiCepat", tracking: "SC-99213", date: "2025-06-18" },
  { id: "INV-88419", channel: "WooCommerce", customer: "Budi Hartono", items: 5, total: 620000, status: "Dikirim", courier: "J&T Express", tracking: "JT-44120", date: "2025-06-17" },
  { id: "INV-88418", channel: "Lazada", customer: "Siti Rahma", items: 2, total: 210000, status: "Selesai", courier: "Anteraja", tracking: "AJ-77301", date: "2025-06-17" },
  { id: "INV-88417", channel: "Shopee", customer: "Dewi Lestari", items: 4, total: 480000, status: "Selesai", courier: "JNE Reguler", tracking: "JNE-11204", date: "2025-06-16" },
  { id: "INV-88416", channel: "Tokopedia", customer: "Fajar Nugroho", items: 1, total: 95000, status: "Batal", courier: "-", tracking: "-", date: "2025-06-16" },
];

export const TOP_PRODUCTS: TopProduct[] = [
  { name: "Kopi Bubuk Premium 200g", channel: "Shopee", sold: 412, revenue: 24720000, margin: 38 },
  { name: "Paket Sembako Hemat", channel: "Tokopedia", sold: 286, revenue: 42900000, margin: 22 },
  { name: "Snack Kemasan 50pcs", channel: "Shopee", sold: 198, revenue: 11880000, margin: 31 },
  { name: "Madu Hutan Murni 500ml", channel: "WooCommerce", sold: 124, revenue: 18600000, margin: 44 },
  { name: "Teh Herbal Sachet", channel: "Lazada", sold: 96, revenue: 4800000, margin: 27 },
];

export const CUSTOMERS: Customer[] = [
  { id: "u1", name: "Dewi Lestari", tier: "Platinum", points: 4820, orders: 42, spent: 6840000, lastOrder: "2025-06-17" },
  { id: "u2", name: "Andi Wijaya", tier: "Gold", points: 3140, orders: 28, spent: 4120000, lastOrder: "2025-06-18" },
  { id: "u3", name: "Rina Kusuma", tier: "Gold", points: 2760, orders: 24, spent: 3680000, lastOrder: "2025-06-18" },
  { id: "u4", name: "Budi Hartono", tier: "Silver", points: 1480, orders: 15, spent: 2140000, lastOrder: "2025-06-17" },
  { id: "u5", name: "Siti Rahma", tier: "Silver", points: 1120, orders: 11, spent: 1580000, lastOrder: "2025-06-17" },
  { id: "u6", name: "Fajar Nugroho", tier: "Bronze", points: 420, orders: 4, spent: 520000, lastOrder: "2025-06-16" },
];

export const PAYMENT_PROVIDERS: PaymentProvider[] = [
  { id: "p1", name: "Midtrans", connected: true, methods: ["QRIS", "VA", "Kartu", "E-Wallet"], volume: 42800000, fee: 1.5, settled: 42158000 },
  { id: "p2", name: "Xendit", connected: true, methods: ["QRIS", "VA", "Retail", "E-Wallet"], volume: 26400000, fee: 1.8, settled: 25924800 },
  { id: "p3", name: "DOKU", connected: false, methods: ["VA", "Kartu"], volume: 0, fee: 2.0, settled: 0 },
];

export const MARKETPLACE_MODULES = [
  "Integrasi Marketplace",
  "Order Management",
  "Analisis Penjualan",
  "Website Integration",
  "CRM & Loyalty",
  "Payment Gateway",
];