export const LOCKED_PHONE = "083842170430";
export const DEFAULT_TOPUP_AMOUNT = 50000;

export interface WalletBalance {
  accountType: "CASH";
  balance: number;
  currency: "IDR";
}

export interface TopUpRecord {
  refId: string;
  phoneNumber: string;
  amount: number;
  gatewayId: string;
  status: "PENDING" | "SUCCESS" | "FAILED";
  failureCode?: string;
  createdAt: string;
}

export interface WalletAuditLog {
  id: string;
  timestamp: string;
  action: string;
  refId: string;
  target?: string;
  gatewayId?: string;
}

export function formatRupiah(n: number): string {
  return "Rp " + n.toLocaleString("id-ID");
}

export function nowStamp(): string {
  const d = new Date();
  const p = (v: number) => String(v).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(
    d.getHours()
  )}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

export function makeRefId(): string {
  return `TOPUP-DANA-${Date.now()}`;
}

export function makeGatewayId(): string {
  return `xnd_pay_${Math.floor(100000 + Math.random() * 899999)}`;
}

export const INITIAL_BALANCE: WalletBalance = {
  accountType: "CASH",
  balance: 5250000,
  currency: "IDR",
};

export const INITIAL_TOPUPS: TopUpRecord[] = [
  {
    refId: "TOPUP-DANA-1738300000000",
    phoneNumber: LOCKED_PHONE,
    amount: 50000,
    gatewayId: "xnd_pay_441902",
    status: "SUCCESS",
    createdAt: "2025-01-30 09:12:04",
  },
  {
    refId: "TOPUP-DANA-1738210000000",
    phoneNumber: LOCKED_PHONE,
    amount: 75000,
    gatewayId: "xnd_pay_338117",
    status: "FAILED",
    failureCode: "INSUFFICIENT_BALANCE",
    createdAt: "2025-01-29 14:02:41",
  },
];

export const INITIAL_WALLET_LOGS: WalletAuditLog[] = [
  {
    id: "w1",
    timestamp: "2025-01-30 09:12:04",
    action: "WEBHOOK_TOPUP_SUCCESS",
    refId: "TOPUP-DANA-1738300000000",
    gatewayId: "xnd_pay_441902",
  },
  {
    id: "w2",
    timestamp: "2025-01-30 09:11:58",
    action: "AUTO_TOPUP_INITIATED",
    refId: "TOPUP-DANA-1738300000000",
    target: LOCKED_PHONE,
  },
  {
    id: "w3",
    timestamp: "2025-01-29 14:02:41",
    action: "WEBHOOK_TOPUP_FAILED",
    refId: "TOPUP-DANA-1738210000000",
    gatewayId: "xnd_pay_338117",
  },
];