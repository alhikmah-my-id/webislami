import { create } from "zustand";

export type Product = {
  id: string;
  name: string;
  sku: string;
  stock: number;
  unit: string;
  price: number;
};

export type Customer = {
  id: string;
  name: string;
  phone: string;
  currentDebt: number;
};

export type Debt = {
  id: string;
  customerId: string;
  customerName: string;
  amount: number;
  dueDate: string;
  status: "unpaid" | "paid";
};

export type Sale = {
  id: string;
  invoice: string;
  total: number;
  method: "cash" | "transfer" | "credit";
  date: string;
  items: number;
};

type State = {
  products: Product[];
  customers: Customer[];
  debts: Debt[];
  sales: Sale[];
  addProduct: (p: Omit<Product, "id">) => void;
  restock: (id: string, qty: number) => void;
  checkout: (args: {
    items: { productId: string; qty: number }[];
    method: "cash" | "transfer" | "credit";
    customerId?: string;
  }) => void;
  payDebt: (id: string) => void;
};

const uid = () => Math.random().toString(36).slice(2, 10);

export const useStore = create<State>((set, get) => ({
  products: [
    { id: uid(), name: "Beras Premium 5kg", sku: "BRS-5", stock: 24, unit: "karung", price: 68000 },
    { id: uid(), name: "Minyak Goreng 2L", sku: "MYK-2", stock: 40, unit: "pouch", price: 36000 },
    { id: uid(), name: "Gula Pasir 1kg", sku: "GLA-1", stock: 55, unit: "pack", price: 15500 },
    { id: uid(), name: "Telur Ayam 1kg", sku: "TLR-1", stock: 18, unit: "kg", price: 29000 },
    { id: uid(), name: "Kopi Sachet (10pcs)", sku: "KPI-10", stock: 8, unit: "pack", price: 12000 },
  ],
  customers: [
    { id: uid(), name: "Bu Siti", phone: "0812-1111-2222", currentDebt: 45000 },
    { id: uid(), name: "Pak Budi", phone: "0813-3333-4444", currentDebt: 0 },
    { id: uid(), name: "Warung Pak Anto", phone: "0857-5555-6666", currentDebt: 120000 },
  ],
  debts: [],
  sales: [],

  addProduct: (p) => set((s) => ({ products: [{ ...p, id: uid() }, ...s.products] })),

  restock: (id, qty) =>
    set((s) => ({
      products: s.products.map((p) => (p.id === id ? { ...p, stock: p.stock + qty } : p)),
    })),

  checkout: ({ items, method, customerId }) => {
    const { products, customers, debts } = get();
    let total = 0;
    const updatedProducts = products.map((p) => {
      const line = items.find((i) => i.productId === p.id);
      if (!line) return p;
      total += line.qty * p.price;
      return { ...p, stock: Math.max(0, p.stock - line.qty) };
    });

    const invoice = `INV-${new Date().getTime().toString().slice(-6)}`;
    const newSale: Sale = {
      id: uid(),
      invoice,
      total,
      method,
      date: new Date().toISOString(),
      items: items.reduce((a, i) => a + i.qty, 0),
    };

    let newDebts = debts;
    let newCustomers = customers;

    if (method === "credit" && customerId) {
      const cust = customers.find((c) => c.id === customerId);
      if (cust) {
        newCustomers = customers.map((c) =>
          c.id === customerId ? { ...c, currentDebt: c.currentDebt + total } : c
        );
        const due = new Date();
        due.setDate(due.getDate() + 14);
        newDebts = [
          {
            id: uid(),
            customerId,
            customerName: cust.name,
            amount: total,
            dueDate: due.toISOString().slice(0, 10),
            status: "unpaid",
          },
          ...debts,
        ];
      }
    }

    set({
      products: updatedProducts,
      sales: [newSale, ...get().sales],
      debts: newDebts,
      customers: newCustomers,
    });
  },

  payDebt: (id) =>
    set((s) => {
      const debt = s.debts.find((d) => d.id === id);
      if (!debt) return s;
      return {
        debts: s.debts.map((d) => (d.id === id ? { ...d, status: "paid" } : d)),
        customers: s.customers.map((c) =>
          c.id === debt.customerId
            ? { ...c, currentDebt: Math.max(0, c.currentDebt - debt.amount) }
            : c
        ),
      };
    }),
}));