export type VerticalId = "retail" | "konveksi" | "fnb" | "farmasi" | "jasa" | "logistik";

export interface Vertical {
  id: VerticalId;
  emoji: string;
  name: string;
  tagline: string;
  accent: string;
  modules: string[];
  kpis: { label: string; value: string; delta: string }[];
}

export const VERTICALS: Vertical[] = [
  {
    id: "retail",
    emoji: "🏪",
    name: "Retail & Warung",
    tagline: "POS, stok, utang pelanggan",
    accent: "from-emerald-700 to-emerald-900",
    modules: ["Kasir", "Stok", "Utang", "Absensi"],
    kpis: [
      { label: "Omzet Hari Ini", value: "Rp 4.250.000", delta: "+12%" },
      { label: "Transaksi", value: "87", delta: "+8%" },
      { label: "Piutang Aktif", value: "Rp 1.180.000", delta: "-3%" },
    ],
  },
  {
    id: "konveksi",
    emoji: "🏗️",
    name: "Konveksi & Garment",
    tagline: "Custom order, production line",
    accent: "from-indigo-700 to-indigo-900",
    modules: ["Order Custom", "Produksi", "Bahan", "Invoice"],
    kpis: [
      { label: "Order Aktif", value: "34", delta: "+5" },
      { label: "Produksi Berjalan", value: "12 batch", delta: "+2" },
      { label: "Nilai Order", value: "Rp 128.400.000", delta: "+18%" },
    ],
  },
  {
    id: "fnb",
    emoji: "🍽️",
    name: "Food & Beverage",
    tagline: "Recipe, inventory, POS",
    accent: "from-amber-600 to-amber-800",
    modules: ["Kasir", "Resep", "Bahan Baku", "Dapur"],
    kpis: [
      { label: "Omzet Hari Ini", value: "Rp 6.780.000", delta: "+22%" },
      { label: "Pesanan", value: "214", delta: "+31%" },
      { label: "Food Cost", value: "31%", delta: "-2%" },
    ],
  },
  {
    id: "farmasi",
    emoji: "💊",
    name: "Farmasi & Kesehatan",
    tagline: "Batch, expiry, compliance",
    accent: "from-sky-700 to-sky-900",
    modules: ["Kasir", "Batch", "Kadaluarsa", "Resep"],
    kpis: [
      { label: "Omzet Hari Ini", value: "Rp 3.120.000", delta: "+6%" },
      { label: "Batch Aktif", value: "412", delta: "+9" },
      { label: "Akan Kadaluarsa", value: "18 item", delta: "-4" },
    ],
  },
  {
    id: "jasa",
    emoji: "🏢",
    name: "Jasa Profesional",
    tagline: "Project, invoice, timesheet",
    accent: "from-violet-700 to-violet-900",
    modules: ["Proyek", "Timesheet", "Invoice", "Klien"],
    kpis: [
      { label: "Proyek Aktif", value: "9", delta: "+1" },
      { label: "Jam Bulan Ini", value: "1.284 jam", delta: "+7%" },
      { label: "Invoice Outstanding", value: "Rp 42.900.000", delta: "-11%" },
    ],
  },
  {
    id: "logistik",
    emoji: "🚚",
    name: "Logistik & Pengiriman",
    tagline: "Rute, tracking, shipment",
    accent: "from-rose-700 to-rose-900",
    modules: ["Shipment", "Rute", "Armada", "Tracking"],
    kpis: [
      { label: "Pengiriman Hari Ini", value: "156", delta: "+14%" },
      { label: "Dalam Perjalanan", value: "43", delta: "+6" },
      { label: "Terkirim", value: "98%", delta: "+1%" },
    ],
  },
];

export const DEFAULT_VERTICAL: VerticalId = "retail";