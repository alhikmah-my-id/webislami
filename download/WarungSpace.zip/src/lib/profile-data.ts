export interface PaymentProvider {
  id: number;
  code: string;
  name: string;
  category: "E-WALLET" | "DIGITAL_BANK";
  emoji: string;
  color: string;
}

export interface FintechProfile {
  id: number;
  providerId: number;
  externalCustomerId: string;
  maskedPhone: string;
  accountStatus: "BASIC" | "PREMIUM";
  isPrimary: boolean;
  bindingStatus: "PENDING" | "LINKED" | "UNLINKED" | "EXPIRED";
  linkedAt: string;
}

export interface FintechAuditLog {
  id: number;
  timestamp: string;
  action: string;
  providerCode: string;
  status: "SUCCESS" | "FAILED";
  ip: string;
  detail: string;
}

export const PROVIDERS: PaymentProvider[] = [
  { id: 1, code: "DANA", name: "DANA Wallet", category: "E-WALLET", emoji: "💙", color: "bg-blue-50 text-blue-700 border-blue-200" },
  { id: 2, code: "OVO", name: "OVO Cash", category: "E-WALLET", emoji: "💜", color: "bg-purple-50 text-purple-700 border-purple-200" },
  { id: 3, code: "GOPAY", name: "GoPay", category: "E-WALLET", emoji: "💚", color: "bg-emerald-50 text-emerald-700 border-emerald-200" },
  { id: 4, code: "SHOPEEPAY", name: "ShopeePay", category: "E-WALLET", emoji: "🧡", color: "bg-orange-50 text-orange-700 border-orange-200" },
  { id: 5, code: "BCA_DIGITAL", name: "blu by BCA Digital", category: "DIGITAL_BANK", emoji: "🏦", color: "bg-sky-50 text-sky-700 border-sky-200" },
  { id: 6, code: "JAGO", name: "Bank Jago", category: "DIGITAL_BANK", emoji: "🐱", color: "bg-yellow-50 text-yellow-700 border-yellow-200" },
  { id: 7, code: "SEABANK", name: "SeaBank", category: "DIGITAL_BANK", emoji: "🌊", color: "bg-teal-50 text-teal-700 border-teal-200" },
  { id: 8, code: "MANDIRI", name: "Livin' Mandiri", category: "DIGITAL_BANK", emoji: "🏛️", color: "bg-amber-50 text-amber-700 border-amber-200" },
];

export const INITIAL_PROFILES: FintechProfile[] = [
  {
    id: 1,
    providerId: 1,
    externalCustomerId: "DANA-CUST-88213",
    maskedPhone: "0812****3456",
    accountStatus: "PREMIUM",
    isPrimary: true,
    bindingStatus: "LINKED",
    linkedAt: "2025-01-08 14:22:10",
  },
  {
    id: 2,
    providerId: 3,
    externalCustomerId: "GOPAY-USR-40192",
    maskedPhone: "0812****3456",
    accountStatus: "BASIC",
    isPrimary: false,
    bindingStatus: "LINKED",
    linkedAt: "2025-01-10 09:05:44",
  },
];

export const INITIAL_FINTECH_LOGS: FintechAuditLog[] = [
  {
    id: 1,
    timestamp: "2025-01-10 09:05:44",
    action: "ACCOUNT_BINDING",
    providerCode: "GOPAY",
    status: "SUCCESS",
    ip: "103.28.14.9",
    detail: "Binding token diterima, refresh_token tersimpan (encrypted)",
  },
  {
    id: 2,
    timestamp: "2025-01-08 14:22:10",
    action: "ACCOUNT_BINDING",
    providerCode: "DANA",
    status: "SUCCESS",
    ip: "103.28.14.9",
    detail: "external_customer_id DANA-CUST-88213 terverifikasi",
  },
  {
    id: 3,
    timestamp: "2025-01-08 14:20:02",
    action: "ACCOUNT_BINDING",
    providerCode: "OVO",
    status: "FAILED",
    ip: "103.28.14.9",
    detail: "OTP expired — gateway mengembalikan 401 Unauthorized",
  },
];

export function nowStamp(): string {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(
    d.getHours()
  )}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

export function maskPhone(raw: string): string {
  const digits = raw.replace(/\D/g, "");
  if (digits.length < 8) return raw;
  return `${digits.slice(0, 4)}****${digits.slice(-4)}`;
}