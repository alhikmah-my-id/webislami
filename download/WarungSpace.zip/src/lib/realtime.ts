type Listener = (payload: { invoice: string; status: "PAID" | "FAILED" }) => void;

class RealtimeChannel {
  private listeners = new Set<Listener>();
  private rooms = new Set<string>();
  private timers = new Map<string, ReturnType<typeof setTimeout>>();
  private connected = true;
  private connectionListeners = new Set<(c: boolean) => void>();

  isConnected() {
    return this.connected;
  }

  onConnectionChange(cb: (c: boolean) => void) {
    this.connectionListeners.add(cb);
    return () => this.connectionListeners.delete(cb);
  }

  private setConnected(value: boolean) {
    if (this.connected === value) return;
    this.connected = value;
    this.connectionListeners.forEach((cb) => cb(value));
  }

  join(invoice: string) {
    this.rooms.add(invoice);
    this.setConnected(true);
  }

  leave(invoice: string) {
    this.rooms.delete(invoice);
    const t = this.timers.get(invoice);
    if (t) {
      clearTimeout(t);
      this.timers.delete(invoice);
    }
  }

  on(cb: Listener) {
    this.listeners.add(cb);
    return () => this.listeners.delete(cb);
  }

  private emit(invoice: string, status: "PAID" | "FAILED") {
    this.listeners.forEach((cb) => cb({ invoice, status }));
  }

  simulateWebhook(invoice: string) {
    if (this.timers.has(invoice)) return;
    const delay = 4000 + Math.random() * 8000;
    const timer = setTimeout(() => {
      this.timers.delete(invoice);
      if (!this.rooms.has(invoice)) return;
      const failed = Math.random() < 0.12;
      this.emit(invoice, failed ? "FAILED" : "PAID");
    }, delay);
    this.timers.set(invoice, timer);
  }

  simulateDisconnect() {
    this.setConnected(false);
  }

  simulateReconnect() {
    this.setConnected(true);
  }
}

export const realtime = new RealtimeChannel();

export function playSuccessChime() {
  try {
    const Ctx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    const now = ctx.currentTime;
    const notes = [880, 1174.66, 1567.98];
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = freq;
      const start = now + i * 0.13;
      gain.gain.setValueAtTime(0, start);
      gain.gain.linearRampToValueAtTime(0.18, start + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, start + 0.28);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(start);
      osc.stop(start + 0.3);
    });
    setTimeout(() => ctx.close().catch(() => {}), 1200);
  } catch {
    /* audio not available */
  }
}