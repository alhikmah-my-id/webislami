import { createContext, useCallback, useContext, useState, type ReactNode } from "react";
import { INITIAL_AUDIT_LOGS, type AuditLog } from "@/lib/payment-data";

interface AuditContextValue {
  logs: AuditLog[];
  log: (action: string, description: string, operator?: string) => void;
}

const AuditContext = createContext<AuditContextValue | null>(null);

function nowStamp(): string {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(
    d.getHours()
  )}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

export function AuditProvider({ children }: { children: ReactNode }) {
  const [logs, setLogs] = useState<AuditLog[]>(INITIAL_AUDIT_LOGS);

  const log = useCallback((action: string, description: string, operator = "owner@warungspace.id") => {
    setLogs((prev) => [
      {
        id: `a${Date.now()}${Math.random().toString(36).slice(2, 6)}`,
        timestamp: nowStamp(),
        operator,
        action,
        description,
        ip: "103.28.14.9",
      },
      ...prev,
    ]);
  }, []);

  return <AuditContext.Provider value={{ logs, log }}>{children}</AuditContext.Provider>;
}

export function useAudit(): AuditContextValue {
  const ctx = useContext(AuditContext);
  if (!ctx) throw new Error("useAudit must be used within AuditProvider");
  return ctx;
}