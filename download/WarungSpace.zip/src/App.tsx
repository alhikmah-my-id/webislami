import { useState } from "react";
import {
  LayoutDashboard,
  ShoppingCart,
  Package,
  Wallet,
  Users,
  Layers,
  Store,
  FileText,
  Truck,
  BookOpen,
  FolderKanban,
  Users2,
  Factory,
  UtensilsCrossed,
  Receipt,
  Armchair,
  ChefHat,
  Ticket,
  Building2,
  Plug,
  PackageCheck,
  BarChart3,
  Crown,
  CreditCard,
  Rocket,
  ShieldCheck,
  Smartphone,
  Home,
  QrCode,
  ScrollText,
  UserCog,
  Zap,
  Printer,
} from "lucide-react";
import { VerticalProvider, useVertical } from "@/lib/vertical-context";
import { StoreProvider } from "@/lib/store";
import { RoleProvider, useRole } from "@/lib/role-context";
import { AuditProvider } from "@/lib/audit-context";
import VerticalSwitcher from "@/components/VerticalSwitcher";
import RoleSwitcher from "@/components/RoleSwitcher";
import DashboardPage from "@/pages/DashboardPage";
import PosPage from "@/pages/PosPage";
import InventoryPage from "@/pages/InventoryPage";
import DebtsPage from "@/pages/DebtsPage";
import EmployeesPage from "@/pages/EmployeesPage";
import ModulesPage from "@/pages/ModulesPage";
import SalesPage from "@/pages/SalesPage";
import PurchasingPage from "@/pages/PurchasingPage";
import AccountingPage from "@/pages/AccountingPage";
import ProjectsPage from "@/pages/ProjectsPage";
import CrmPage from "@/pages/CrmPage";
import ManufacturingPage from "@/pages/ManufacturingPage";
import MenuPage from "@/pages/MenuPage";
import RestaurantPosPage from "@/pages/RestaurantPosPage";
import TablesPage from "@/pages/TablesPage";
import KitchenPage from "@/pages/KitchenPage";
import VouchersPage from "@/pages/VouchersPage";
import OutletsPage from "@/pages/OutletsPage";
import MarketplacePage from "@/pages/MarketplacePage";
import OrdersPage from "@/pages/OrdersPage";
import AnalyticsPage from "@/pages/AnalyticsPage";
import LoyaltyPage from "@/pages/LoyaltyPage";
import PaymentsPage from "@/pages/PaymentsPage";
import EcommerceOverviewPage from "@/pages/EcommerceOverviewPage";
import SuperAdminPage from "@/pages/SuperAdminPage";
import StaffPosPage from "@/pages/StaffPosPage";
import PaymentPosPage from "@/pages/PaymentPosPage";
import AuditTrailPage from "@/pages/AuditTrailPage";
import ProfileSettingsPage from "@/pages/ProfileSettingsPage";
import DisbursementPage from "@/pages/DisbursementPage";
import ThermalReceiptPage from "@/pages/ThermalReceiptPage";
import AuthPage from "@/pages/AuthPage";
import LandingPage from "@/pages/LandingPage";
import FeaturesPage from "@/pages/FeaturesPage";
import SegmentsPage from "@/pages/SegmentsPage";
import AboutPage from "@/pages/AboutPage";

type TabId =
  | "dashboard"
  | "sales"
  | "pos"
  | "payment-pos"
  | "receipt"
  | "disbursement"
  | "audit"
  | "profile"
  | "inventory"
  | "purchasing"
  | "accounting"
  | "projects"
  | "crm"
  | "employees"
  | "debts"
  | "manufacturing"
  | "menu"
  | "resto-pos"
  | "tables"
  | "kitchen"
  | "vouchers"
  | "outlets"
  | "marketplace"
  | "orders"
  | "analytics"
  | "loyalty"
  | "payments"
  | "ecommerce"
  | "modules";

interface TabDef {
  id: TabId;
  label: string;
  icon: typeof LayoutDashboard;
  group: "retail" | "resto" | "marketplace" | "shared";
}

const TABS: TabDef[] = [
  { id: "dashboard", label: "Ringkasan", icon: LayoutDashboard, group: "shared" },
  { id: "sales", label: "Penjualan", icon: FileText, group: "retail" },
  { id: "pos", label: "Kasir", icon: ShoppingCart, group: "retail" },
  { id: "payment-pos", label: "Kasir QRIS", icon: QrCode, group: "shared" },
  { id: "receipt", label: "Cetak Struk", icon: Printer, group: "shared" },
  { id: "disbursement", label: "Auto-Disbursement", icon: Zap, group: "shared" },
  { id: "audit", label: "Audit Trail", icon: ScrollText, group: "shared" },
  { id: "profile", label: "Profil & Fintech", icon: UserCog, group: "shared" },
  { id: "inventory", label: "Inventori", icon: Package, group: "retail" },
  { id: "purchasing", label: "Pembelian", icon: Truck, group: "shared" },
  { id: "accounting", label: "Akuntansi", icon: BookOpen, group: "shared" },
  { id: "projects", label: "Projek", icon: FolderKanban, group: "retail" },
  { id: "crm", label: "CRM", icon: Users2, group: "retail" },
  { id: "employees", label: "HR & Gaji", icon: Users, group: "shared" },
  { id: "debts", label: "Utang", icon: Wallet, group: "retail" },
  { id: "manufacturing", label: "Manufaktur", icon: Factory, group: "retail" },
  { id: "menu", label: "Menu & Resep", icon: UtensilsCrossed, group: "resto" },
  { id: "resto-pos", label: "POS Restoran", icon: Receipt, group: "resto" },
  { id: "tables", label: "Meja & Reservasi", icon: Armchair, group: "resto" },
  { id: "kitchen", label: "Operasional Dapur", icon: ChefHat, group: "resto" },
  { id: "vouchers", label: "Voucher & Promo", icon: Ticket, group: "resto" },
  { id: "outlets", label: "Multi-Outlet", icon: Building2, group: "resto" },
  { id: "ecommerce", label: "ERP E-Commerce", icon: Rocket, group: "marketplace" },
  { id: "marketplace", label: "Marketplace", icon: Plug, group: "marketplace" },
  { id: "orders", label: "Order Management", icon: PackageCheck, group: "marketplace" },
  { id: "analytics", label: "Analisis Penjualan", icon: BarChart3, group: "marketplace" },
  { id: "loyalty", label: "CRM & Loyalty", icon: Crown, group: "marketplace" },
  { id: "payments", label: "Payment Gateway", icon: CreditCard, group: "marketplace" },
  { id: "modules", label: "Modul", icon: Layers, group: "shared" },
];

function MemberShell({ onHome }: { onHome: () => void }) {
  const { vertical } = useVertical();
  const [tab, setTab] = useState<TabId>("dashboard");

  const groupForVertical: TabDef["group"] =
    vertical.id === "kopi" ? "resto" : vertical.id === "marketplace" ? "marketplace" : "retail";

  const visibleTabs = TABS.filter((t) => t.group === "shared" || t.group === groupForVertical);
  const activeTab = visibleTabs.find((t) => t.id === tab) ?? visibleTabs[0];

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900">
      <div className="mx-auto flex min-h-screen max-w-7xl flex-col md:flex-row">
        <aside className="bg-gradient-to-b from-emerald-800 to-emerald-950 md:w-72 md:shrink-0">
          <div className="flex flex-col gap-4 p-4 md:sticky md:top-0 md:h-screen md:overflow-y-auto md:p-6">
            <div className="flex items-center gap-3">
              <div className="grid h-10 w-10 place-items-center rounded-xl bg-emerald-500/20 text-emerald-300">
                <Store className="h-5 w-5" />
              </div>
              <div>
                <p className="font-serif text-lg font-bold leading-none text-white">
                  WarungSpace
                </p>
                <p className="text-xs text-emerald-300">All-in-One SaaS UMKM</p>
              </div>
            </div>

            <button
              onClick={onHome}
              className="flex items-center gap-2 rounded-xl px-3 py-2 text-xs font-medium text-emerald-200 transition hover:bg-emerald-800/60"
            >
              <Home className="h-3.5 w-3.5" />
              Kembali ke Beranda
            </button>

            <RoleSwitcher />
            <VerticalSwitcher />

            <nav className="flex gap-2 overflow-x-auto pb-1 md:flex-col md:overflow-visible md:pb-0">
              {visibleTabs.map(({ id, label, icon: Icon }) => {
                const active = activeTab.id === id;
                return (
                  <button
                    key={id}
                    onClick={() => setTab(id)}
                    className={`flex shrink-0 items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition md:w-full ${
                      active
                        ? "bg-white text-emerald-900 shadow-sm"
                        : "text-emerald-100 hover:bg-emerald-700/50"
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    <span>{label}</span>
                  </button>
                );
              })}
            </nav>

            <div className="mt-auto hidden rounded-xl bg-emerald-900/60 p-4 md:block">
              <p className="text-xs font-semibold text-emerald-200">Paket Free Trial</p>
              <p className="mt-1 text-xs text-emerald-300">
                Aktif hingga 7 hari ke depan. Upgrade untuk fitur lengkap.
              </p>
              <button className="mt-3 w-full rounded-lg bg-emerald-500 py-2 text-xs font-semibold text-white transition hover:bg-emerald-400">
                Upgrade Sekarang
              </button>
            </div>
          </div>
        </aside>

        <main className="flex-1 p-4 md:p-8">
          <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-xs font-semibold uppercase tracking-widest text-emerald-700">
                {vertical.emoji} {vertical.name}
              </p>
              <h1 className="font-serif text-2xl font-bold text-slate-900 md:text-3xl">
                {activeTab.label}
              </h1>
            </div>
            <div className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 shadow-sm">
              <div className="grid h-8 w-8 place-items-center rounded-lg bg-emerald-100 text-sm font-bold text-emerald-700">
                T
              </div>
              <div className="leading-tight">
                <p className="text-xs font-semibold text-slate-800">Toko Berkah</p>
                <p className="text-xs text-slate-500">Pemilik</p>
              </div>
            </div>
          </div>

          {activeTab.id === "dashboard" && <DashboardPage />}
          {activeTab.id === "sales" && <SalesPage />}
          {activeTab.id === "pos" && <PosPage />}
          {activeTab.id === "payment-pos" && <PaymentPosPage />}
          {activeTab.id === "receipt" && <ThermalReceiptPage />}
          {activeTab.id === "disbursement" && <DisbursementPage />}
          {activeTab.id === "audit" && <AuditTrailPage />}
          {activeTab.id === "profile" && <ProfileSettingsPage />}
          {activeTab.id === "inventory" && <InventoryPage />}
          {activeTab.id === "purchasing" && <PurchasingPage />}
          {activeTab.id === "accounting" && <AccountingPage />}
          {activeTab.id === "projects" && <ProjectsPage />}
          {activeTab.id === "crm" && <CrmPage />}
          {activeTab.id === "employees" && <EmployeesPage />}
          {activeTab.id === "debts" && <DebtsPage />}
          {activeTab.id === "manufacturing" && <ManufacturingPage />}
          {activeTab.id === "menu" && <MenuPage />}
          {activeTab.id === "resto-pos" && <RestaurantPosPage />}
          {activeTab.id === "tables" && <TablesPage />}
          {activeTab.id === "kitchen" && <KitchenPage />}
          {activeTab.id === "vouchers" && <VouchersPage />}
          {activeTab.id === "outlets" && <OutletsPage />}
          {activeTab.id === "ecommerce" && <EcommerceOverviewPage />}
          {activeTab.id === "marketplace" && <MarketplacePage />}
          {activeTab.id === "orders" && <OrdersPage />}
          {activeTab.id === "analytics" && <AnalyticsPage />}
          {activeTab.id === "loyalty" && <LoyaltyPage />}
          {activeTab.id === "payments" && <PaymentsPage />}
          {activeTab.id === "modules" && <ModulesPage />}
        </main>
      </div>
    </div>
  );
}

function StaffShell({ onHome }: { onHome: () => void }) {
  return (
    <div className="min-h-screen bg-slate-100 text-slate-900">
      <div className="mx-auto max-w-4xl p-4 md:p-8">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-xs font-semibold uppercase tracking-widest text-emerald-700">
              Mode Staff / Kasir
            </p>
            <h1 className="font-serif text-2xl font-bold text-slate-900 md:text-3xl">
              Layar POS Karyawan
            </h1>
          </div>
          <div className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 shadow-sm">
            <div className="grid h-8 w-8 place-items-center rounded-lg bg-emerald-100 text-emerald-700">
              <Smartphone className="h-4 w-4" />
            </div>
            <div className="leading-tight">
              <p className="text-xs font-semibold text-slate-800">Andi (Kasir)</p>
              <p className="text-xs text-slate-500">Shift Pagi</p>
            </div>
          </div>
        </div>
        <div className="mb-6 space-y-3">
          <button
            onClick={onHome}
            className="flex items-center gap-2 text-xs font-medium text-emerald-700 transition hover:text-emerald-900"
          >
            <Home className="h-3.5 w-3.5" />
            Kembali ke Beranda
          </button>
          <RoleSwitcher />
        </div>
        <StaffPosPage />
      </div>
    </div>
  );
}

function AdminShell({ onHome }: { onHome: () => void }) {
  const [tab, setTab] = useState<"super" | "disbursement" | "audit" | "profile">("super");
  const tabs = [
    { id: "super" as const, label: "SuperSaaS" },
    { id: "disbursement" as const, label: "Auto-Disbursement" },
    { id: "audit" as const, label: "Audit Trail" },
    { id: "profile" as const, label: "Profil & Fintech" },
  ];
  return (
    <div className="min-h-screen bg-slate-100 text-slate-900">
      <div className="mx-auto max-w-6xl p-4 md:p-8">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-xs font-semibold uppercase tracking-widest text-rose-600">
              Mode Pemilik WarungSpace
            </p>
            <h1 className="font-serif text-2xl font-bold text-slate-900 md:text-3xl">
              Panel SuperSaaS Admin
            </h1>
          </div>
          <div className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 shadow-sm">
            <div className="grid h-8 w-8 place-items-center rounded-lg bg-rose-100 text-rose-700">
              <ShieldCheck className="h-4 w-4" />
            </div>
            <div className="leading-tight">
              <p className="text-xs font-semibold text-slate-800">Owner</p>
              <p className="text-xs text-slate-500">Akses Penuh</p>
            </div>
          </div>
        </div>
        <div className="mb-6 space-y-3">
          <button
            onClick={onHome}
            className="flex items-center gap-2 text-xs font-medium text-emerald-700 transition hover:text-emerald-900"
          >
            <Home className="h-3.5 w-3.5" />
            Kembali ke Beranda
          </button>
          <RoleSwitcher />
          <div className="flex flex-wrap gap-2">
            {tabs.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`rounded-xl px-4 py-2 text-sm font-semibold transition ${
                  tab === t.id
                    ? "bg-rose-600 text-white"
                    : "bg-white text-slate-600 hover:bg-slate-50"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>
        {tab === "super" && <SuperAdminPage />}
        {tab === "disbursement" && <DisbursementPage />}
        {tab === "audit" && <AuditTrailPage />}
        {tab === "profile" && <ProfileSettingsPage />}
      </div>
    </div>
  );
}

function Shell({ onHome }: { onHome: () => void }) {
  const { role } = useRole();
  if (role === "admin") return <AdminShell onHome={onHome} />;
  if (role === "staff") return <StaffShell onHome={onHome} />;
  return <MemberShell onHome={onHome} />;
}

type View = "landing" | "features" | "segments" | "about" | "auth" | "app";

function AppInner() {
  const [view, setView] = useState<View>("landing");

  if (view === "landing") {
    return (
      <LandingPage
        onEnterApp={() => setView("app")}
        onViewAllFeatures={() => setView("features")}
        onViewSegments={() => setView("segments")}
        onViewAbout={() => setView("about")}
        onLogin={() => setView("auth")}
      />
    );
  }

  if (view === "auth") {
    return (
      <AuthPage onBack={() => setView("landing")} onSuccess={() => setView("app")} />
    );
  }

  if (view === "features") {
    return (
      <FeaturesPage onBack={() => setView("landing")} onEnterApp={() => setView("app")} />
    );
  }

  if (view === "segments") {
    return (
      <SegmentsPage onBack={() => setView("landing")} onEnterApp={() => setView("app")} />
    );
  }

  if (view === "about") {
    return (
      <AboutPage onBack={() => setView("landing")} onEnterApp={() => setView("app")} />
    );
  }

  return <Shell onHome={() => setView("landing")} />;
}

export default function App() {
  return (
    <StoreProvider>
      <VerticalProvider>
        <RoleProvider>
          <AuditProvider>
            <AppInner />
          </AuditProvider>
        </RoleProvider>
      </VerticalProvider>
    </StoreProvider>
  );
}