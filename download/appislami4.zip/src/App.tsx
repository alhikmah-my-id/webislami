import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import DownloadSection from "@/components/DownloadSection";
import AppPromoBanner from "@/components/AppPromoBanner";
import {
  Search,
  BookOpen,
  Compass,
  Clock,
  Volume2,
  Sparkles,
  Menu,
  ChevronRight,
  TrendingUp,
  Calendar,
  Library,
  PenTool,
  BookMarked,
  Radio,
  GraduationCap,
  ScrollText,
  Users,
  Info,
  Video,
  Bell,
  BookText,
  Languages,
  Feather,
  Timer,
  Headphones,
  FileText,
  Palette,
} from "lucide-react";

const categories = [
  { name: "Al-Qur'an Digital", icon: BookOpen, count: 42 },
  { name: "Murotal 30 Juz", icon: Headphones, count: 30 },
  { name: "Kisah Hikmah", icon: Sparkles, count: 128 },
  { name: "Kitab/Buku", icon: BookMarked, count: 76 },
  { name: "Pendidikan", icon: GraduationCap, count: 94 },
  { name: "Sholawat", icon: Radio, count: 210 },
  { name: "Khutbah", icon: ScrollText, count: 58 },
  { name: "Kisah dan Tokoh", icon: Users, count: 87 },
  { name: "Tafsir Web", icon: BookText, count: 114 },
  { name: "Perpustakaan", icon: Library, count: 63 },
  { name: "Arabic Pegon", icon: Languages, count: 25 },
  { name: "Arabic Calligraphy", icon: Feather, count: 41 },
  { name: "Kalender Hijriyah", icon: Calendar, count: 12 },
  { name: "Timer", icon: Timer, count: 8 },
  { name: "Adhan", icon: Bell, count: 15 },
  { name: "Iqro'", icon: BookOpen, count: 6 },
  { name: "Vidio", icon: Video, count: 132 },
  { name: "Informasi", icon: Info, count: 47 },
  { name: "WebOffice", icon: FileText, count: 9 },
  { name: "CorelDRAW Arabic", icon: Palette, count: 18 },
  { name: "Aplikasi", icon: PenTool, count: 22 },
];

const quickNav = ["ADZKAR", "AL-QUR'AN", "TAKLIM", "HADIST", "SHOLAWAT", "ARABIC"];

const featuredArticles = [
  {
    title: "Keutamaan Membaca Al-Qur'an Setiap Hari",
    category: "Al-Qur'an Digital",
    excerpt:
      "Rasulullah ﷺ bersabda bahwa setiap huruf Al-Qur'an bernilai satu kebaikan yang dilipatgandakan sepuluh kali...",
    readTime: "8 menit",
    views: "12.4K",
  },
  {
    title: "Sejarah Peradaban Islam di Nusantara",
    category: "Kisah dan Tokoh",
    excerpt:
      "Jejak dakwah Wali Songo yang membentuk karakter Islam Nusantara dengan pendekatan budaya dan kearifan lokal...",
    readTime: "12 menit",
    views: "9.8K",
  },
  {
    title: "Panduan Lengkap Sholat Tahajud",
    category: "Pendidikan",
    excerpt:
      "Tata cara, waktu terbaik, dan keutamaan sholat tahajud berdasarkan dalil Al-Qur'an dan hadits shahih...",
    readTime: "6 menit",
    views: "15.2K",
  },
];

const popularPosts = [
  "Doa Sebelum Tidur Lengkap Arab & Latin",
  "10 Sholawat Pembuka Rezeki",
  "Cara Cepat Belajar Iqro' untuk Pemula",
  "Kalender Hijriyah 1447 H Terbaru",
  "Kumpulan Khutbah Jumat Singkat",
];

export default function App() {
  const [search, setSearch] = useState("");

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-50 via-white to-teal-50/40">
      <header className="sticky top-0 z-40 border-b border-emerald-900/10 bg-emerald-950/95 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-400 to-teal-600 shadow-lg shadow-emerald-900/40">
              <Sparkles className="h-5 w-5 text-white" />
            </div>
            <div className="leading-tight">
              <p className="font-serif text-lg font-bold text-white">ALHIKMAH</p>
              <p className="text-xs text-emerald-300/80">alhikmah.my.id</p>
            </div>
          </div>

          <nav className="hidden items-center gap-1 lg:flex">
            {quickNav.map((item) => (
              <button
                key={item}
                className="rounded-lg px-3 py-2 text-xs font-semibold uppercase tracking-wide text-emerald-100/80 transition-colors hover:bg-emerald-800/50 hover:text-white"
              >
                {item}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <Button
              size="sm"
              className="hidden rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-white hover:from-emerald-400 hover:to-teal-400 sm:inline-flex"
              onClick={() => document.getElementById("download")?.scrollIntoView({ behavior: "smooth" })}
            >
              Download App
            </Button>
            <Button
              size="icon"
              variant="ghost"
              className="text-emerald-100 hover:bg-emerald-800/50 lg:hidden"
            >
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl space-y-8 px-4 py-6 sm:px-6 sm:py-8">
        <AppPromoBanner />

        <section className="relative overflow-hidden rounded-3xl border border-emerald-900/10 bg-gradient-to-br from-emerald-900 via-teal-900 to-emerald-950 p-6 shadow-xl sm:p-10">
          <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-emerald-400/10 blur-3xl" />
          <div className="pointer-events-none absolute -bottom-24 -left-24 h-72 w-72 rounded-full bg-teal-400/10 blur-3xl" />

          <div className="relative grid gap-8 lg:grid-cols-3 lg:items-center">
            <div className="lg:col-span-2 space-y-5">
              <Badge className="border border-emerald-400/30 bg-emerald-500/20 text-emerald-200 hover:bg-emerald-500/30">
                <Sparkles className="mr-1 h-3 w-3" /> Portal Islam Terpercaya
              </Badge>
              <h1 className="font-serif text-3xl font-bold leading-tight text-white sm:text-5xl">
                Ilmu & Hikmah dalam <span className="text-emerald-300">Satu Portal</span>
              </h1>
              <p className="max-w-2xl text-sm leading-relaxed text-emerald-100/80 sm:text-base">
                Pendidikan, sejarah, sosial, dan budaya Islam — dikemas dalam artikel
                mendalam, tools interaktif, dan aplikasi mobile yang ringan.
              </p>

              <div className="flex max-w-xl items-center gap-2 rounded-2xl border border-emerald-400/20 bg-emerald-950/40 p-1.5 backdrop-blur-sm">
                <Search className="ml-2 h-4 w-4 text-emerald-300" />
                <Input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Cari artikel, doa, atau kitab…"
                  className="border-0 bg-transparent text-white placeholder:text-emerald-200/50 focus-visible:ring-0"
                />
                <Button className="rounded-xl bg-emerald-500 text-white hover:bg-emerald-400">
                  Cari
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 lg:grid-cols-1">
              {[
                { icon: BookOpen, label: "Artikel", value: "1.240+" },
                { icon: Compass, label: "Tools", value: "22" },
                { icon: Clock, label: "Adzan", value: "Real-time" },
                { icon: Volume2, label: "Murotal", value: "30 Juz" },
              ].map((s) => (
                <div
                  key={s.label}
                  className="flex items-center gap-3 rounded-2xl border border-emerald-400/20 bg-emerald-950/40 p-3 backdrop-blur-sm"
                >
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/20">
                    <s.icon className="h-5 w-5 text-emerald-300" />
                  </div>
                  <div>
                    <p className="text-xs text-emerald-200/70">{s.label}</p>
                    <p className="text-sm font-bold text-white">{s.value}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <DownloadSection />

        <section className="space-y-4">
          <div className="flex items-end justify-between">
            <div>
              <h2 className="font-serif text-2xl font-bold text-emerald-950">
                Jelajahi Kategori
              </h2>
              <p className="text-sm text-emerald-800/60">
                22 kategori konten Islami lengkap
              </p>
            </div>
            <Button variant="ghost" className="text-emerald-700 hover:bg-emerald-100">
              Lihat Semua <ChevronRight className="ml-1 h-4 w-4" />
            </Button>
          </div>

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {categories.map((c) => (
              <button
                key={c.name}
                className="group flex items-center gap-3 rounded-2xl border border-emerald-900/10 bg-white p-3 text-left shadow-sm transition-all hover:-translate-y-0.5 hover:border-emerald-500/40 hover:shadow-md"
              >
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700 transition-colors group-hover:bg-emerald-500 group-hover:text-white">
                  <c.icon className="h-5 w-5" />
                </div>
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-emerald-950">
                    {c.name}
                  </p>
                  <p className="text-xs text-emerald-800/50">{c.count} konten</p>
                </div>
              </button>
            ))}
          </div>
        </section>

        <section className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-emerald-600" />
              <h2 className="font-serif text-2xl font-bold text-emerald-950">
                Artikel Pilihan
              </h2>
            </div>

            <div className="space-y-4">
              {featuredArticles.map((a, i) => (
                <Card
                  key={a.title}
                  className="group overflow-hidden border-emerald-900/10 bg-white shadow-sm transition-all hover:shadow-md"
                >
                  <CardContent className="flex gap-4 p-4 sm:p-5">
                    <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 text-2xl font-bold text-white shadow-md">
                      {i + 1}
                    </div>
                    <div className="min-w-0 flex-1">
                      <Badge className="mb-2 border border-emerald-200 bg-emerald-50 text-emerald-700 hover:bg-emerald-100">
                        {a.category}
                      </Badge>
                      <h3 className="font-serif text-lg font-bold text-emerald-950 transition-colors group-hover:text-emerald-700">
                        {a.title}
                      </h3>
                      <p className="mt-1 line-clamp-2 text-sm text-emerald-800/70">
                        {a.excerpt}
                      </p>
                      <div className="mt-3 flex items-center gap-4 text-xs text-emerald-800/50">
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" /> {a.readTime}
                        </span>
                        <span className="flex items-center gap-1">
                          <Users className="h-3 w-3" /> {a.views} views
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <aside className="space-y-4">
            <Card className="border-emerald-900/10 bg-white shadow-sm">
              <CardContent className="p-5">
                <div className="mb-3 flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-amber-500" />
                  <h3 className="font-serif text-base font-bold text-emerald-950">
                    Popular Post
                  </h3>
                </div>
                <ol className="space-y-3">
                  {popularPosts.map((p, i) => (
                    <li key={p} className="flex gap-3">
                      <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-emerald-100 text-xs font-bold text-emerald-700">
                        {i + 1}
                      </span>
                      <a
                        href="#"
                        className="text-sm text-emerald-900/80 transition-colors hover:text-emerald-600"
                      >
                        {p}
                      </a>
                    </li>
                  ))}
                </ol>
              </CardContent>
            </Card>

            <Card className="border-emerald-900/10 bg-gradient-to-br from-emerald-50 to-teal-50 shadow-sm">
              <CardContent className="p-5">
                <div className="mb-3 flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-emerald-600" />
                  <h3 className="font-serif text-base font-bold text-emerald-950">
                    Arsip
                  </h3>
                </div>
                <div className="space-y-2">
                  {["Desember 2025", "November 2025", "Oktober 2025", "September 2025"].map(
                    (m) => (
                      <button
                        key={m}
                        className="flex w-full items-center justify-between rounded-xl border border-emerald-900/10 bg-white/70 px-3 py-2 text-sm text-emerald-900/80 transition-colors hover:border-emerald-500/40 hover:text-emerald-700"
                      >
                        {m}
                        <ChevronRight className="h-4 w-4" />
                      </button>
                    )
                  )}
                </div>
              </CardContent>
            </Card>
          </aside>
        </section>
      </main>

      <footer className="mt-12 border-t border-emerald-900/10 bg-emerald-950 text-emerald-100">
        <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
          <div className="grid gap-8 md:grid-cols-4">
            <div className="md:col-span-2 space-y-3">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-400 to-teal-600">
                  <Sparkles className="h-5 w-5 text-white" />
                </div>
                <p className="font-serif text-lg font-bold text-white">ALHIKMAH</p>
              </div>
              <p className="max-w-md text-sm text-emerald-200/70">
                Portal Islam terpercaya untuk pendidikan, sejarah, sosial, dan budaya.
              </p>
              <Button
                className="mt-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-white hover:from-emerald-400 hover:to-teal-400"
                onClick={() => document.getElementById("download")?.scrollIntoView({ behavior: "smooth" })}
              >
                Download Aplikasi
              </Button>
            </div>

            <div>
              <p className="mb-3 text-sm font-semibold text-white">Navigasi</p>
              <ul className="space-y-2 text-sm text-emerald-200/70">
                {quickNav.map((n) => (
                  <li key={n}>
                    <a href="#" className="transition-colors hover:text-emerald-300">
                      {n}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <p className="mb-3 text-sm font-semibold text-white">Legal</p>
              <ul className="space-y-2 text-sm text-emerald-200/70">
                {["About Us", "Kontak Kami", "Privacy Policy", "Disclaimers", "Sitemap", "Terms & Conditions"].map(
                  (l) => (
                    <li key={l}>
                      <a href="#" className="transition-colors hover:text-emerald-300">
                        {l}
                      </a>
                    </li>
                  )
                )}
              </ul>
            </div>
          </div>

          <div className="mt-8 border-t border-emerald-800/40 pt-6 text-center text-xs text-emerald-300/60">
            Design By ADMIN ALHIKMAH | Copyright 2025 All Application International Islamic
            <br />
            ALHIKMAH.MY.ID — Portal Islam terpercaya untuk pendidikan, sejarah, sosial, dan budaya.
          </div>
        </div>
      </footer>
    </div>
  );
}