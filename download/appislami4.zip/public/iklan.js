/* ============================================================
 * ALHIKMAH — Tappx Ad Rotation Module (iklan.js)
 * Domain: alhikmah.my.id
 * ============================================================ */
(function () {
  "use strict";

  var TAPPX_KEYS = [
    "pub-65263-android-0300",
    "pub-57747-android-0996",
    "pub-60567-android-4416",
    "pub-65262-android-8892",
    "pub-79956-android-6297",
    "pub-79955-android-5582"
  ];

  var ROTATE_MS = 8000;
  var keyIndex = 0;
  var slots = [];

  function currentKey() {
    return TAPPX_KEYS[keyIndex % TAPPX_KEYS.length];
  }

  function rotateKey() {
    keyIndex = (keyIndex + 1) % TAPPX_KEYS.length;
    return currentKey();
  }

  function renderSlot(slot) {
    var key = currentKey();
    slot.setAttribute("data-tappx-key", key);
    slot.setAttribute("data-tappx-state", "loaded");
    slot.innerHTML =
      '<div class="tappx-ad" data-key="' + key + '" ' +
      'style="display:flex;align-items:center;justify-content:center;' +
      'min-height:90px;border-radius:12px;border:1px dashed rgba(16,185,129,.35);' +
      'background:rgba(6,95,70,.08);color:#065f46;font-size:12px;font-family:system-ui">' +
      '<span>Tappx Ad Slot &middot; ' + key + "</span></div>";
  }

  function initSlots() {
    slots = Array.prototype.slice.call(
      document.querySelectorAll("[data-tappx-slot]")
    );
    slots.forEach(renderSlot);
  }

  function startRotation() {
    if (slots.length === 0) return;
    setInterval(function () {
      rotateKey();
      slots.forEach(renderSlot);
    }, ROTATE_MS);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function () {
      initSlots();
      startRotation();
    });
  } else {
    initSlots();
    startRotation();
  }

  window.ALHIKMAH_ADS = {
    keys: TAPPX_KEYS,
    current: currentKey,
    rotate: rotateKey,
    refresh: function () {
      slots.forEach(renderSlot);
    }
  };
})();